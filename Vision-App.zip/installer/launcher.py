"""Start HotScout: install a newer version if the team published one, run the
server, and open it in the browser. Closing this window stops HotScout.

    launcher.py [--share] [--port 8000] [--no-update]

``--share`` lets other team members open this computer's HotScout from their
browser (http://<computer name>:8000); they must sign in with a team Google account.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import os
import socket
import subprocess
import sys
import tempfile
import threading
import time
import webbrowser
import zipfile
from pathlib import Path

APP = Path(__file__).resolve().parents[1]  # %LOCALAPPDATA%\HotScout\app
DATA = APP.parent / "data"
sys.path.insert(0, str(APP / "backend"))


def _version(text: str) -> tuple[int, ...]:
    return tuple(int(p) for p in str(text).strip().split(".") if p.isdigit())


def current_version() -> str:
    f = APP / "VERSION"
    return f.read_text(encoding="utf-8").strip() if f.is_file() else ""


def _running(port: int) -> bool:
    import httpx

    try:
        return httpx.get(f"http://127.0.0.1:{port}/api/health", timeout=1.5).status_code == 200
    except httpx.HTTPError:
        return False


def _update(args) -> bool:
    """Start installing a newer published version; True means this process should exit."""
    from app.services import cloud

    if not current_version() or not cloud.signed_in():
        return False
    try:
        rel = cloud.get_doc("config/release")
        if not rel or _version(rel["version"]) <= _version(current_version()):
            return False
        if not str(rel.get("file", "")).startswith("releases/"):
            raise RuntimeError("the published release has no file")
        print(f"Updating HotScout {current_version()} -> {rel['version']} ...")
        data = cloud.download(rel["file"])
        if hashlib.sha256(data).hexdigest() != rel["sha256"]:
            raise RuntimeError("the downloaded update is damaged")
        dest = Path(tempfile.mkdtemp(prefix="hotscout-update-"))
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            z.extractall(dest)  # strips absolute and ".." paths
        relaunch = f"--port {args.port}" + (" --share" if args.share else "")
        subprocess.Popen(
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(dest / "installer" / "install.ps1"), "-Quiet", "-Relaunch", relaunch],
            creationflags=subprocess.CREATE_NEW_CONSOLE,
        )
        return True
    except Exception as exc:
        print(f"Update skipped ({exc}); starting the installed version.")
        return False


def _port_free(port: int) -> bool:
    # Windows lets 0.0.0.0 and 127.0.0.1 be taken separately; uvicorn needs the one it binds.
    for host in ("127.0.0.1", "0.0.0.0"):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((host, port))
            except OSError:
                return False
    return True


def _open_when_ready(url: str, port: int) -> None:
    # The first start on a new computer is slow (antivirus scans the freshly installed libraries).
    start = time.time()
    while time.time() - start < 900:
        if _running(port):
            webbrowser.open(url)
            print(f"\nHotScout is open at {url}\n")
            return
        time.sleep(1)
    print(f"\nHotScout is taking unusually long to start; try opening {url} in your browser.")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--share", action="store_true", help="let team members on the network open this HotScout")
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--no-update", action="store_true")
    args = ap.parse_args()

    DATA.mkdir(parents=True, exist_ok=True)
    os.chdir(DATA)  # .env, outputs, models and datasets live here
    # Firebase sign-in only allows localhost by default (not 127.0.0.1).
    url = f"http://localhost:{args.port}"
    last = DATA / "last-port.txt"  # where HotScout ended up if the asked-for port was busy
    for port in dict.fromkeys([args.port, int(last.read_text().strip()) if last.is_file() and last.read_text().strip().isdigit() else args.port]):
        if _running(port):
            webbrowser.open(f"http://localhost:{port}")
            return
    if not args.no_update and _update(args):
        return
    if not _port_free(args.port):
        free = next((p for p in range(args.port + 1, args.port + 50) if _port_free(p)), None)
        if free is None:
            raise RuntimeError(f"port {args.port} and the next 49 are all in use by other programs")
        print(f"Port {args.port} is used by another program; using {free} instead.")
        args.port = free
        url = f"http://localhost:{args.port}"
    last.write_text(str(args.port), encoding="utf-8")

    print(f"HotScout {current_version() or '(dev)'} - data in {DATA}")
    print("Starting... the first start on a new computer can take a few minutes.")
    if args.share:
        print(f"Shared: team members open http://{socket.gethostname()}:{args.port} and sign in with Google.")
    print("Close this window to stop HotScout.\n")
    threading.Thread(target=_open_when_ready, args=(url, args.port), daemon=True).start()

    import uvicorn

    from app.main import app as web_app  # imported here so a failure is shown and logged with its real cause

    uvicorn.run(web_app, host="0.0.0.0" if args.share else "127.0.0.1", port=args.port, log_level="info")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except BaseException as exc:  # keep the window open so the error can be read
        if isinstance(exc, SystemExit) and not exc.code:
            raise
        import traceback

        msg = traceback.format_exc()
        print("\nHotScout could not start:\n\n" + msg)
        try:
            DATA.mkdir(parents=True, exist_ok=True)
            (DATA / "launcher-error.log").write_text(time.strftime("%Y-%m-%d %H:%M:%S\n") + msg, encoding="utf-8")
            print(f"(saved to {DATA / 'launcher-error.log'})")
        except OSError:
            pass
        input("Press Enter to close")
        sys.exit(1)
