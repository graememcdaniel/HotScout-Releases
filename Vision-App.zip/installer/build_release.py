"""Build a HotScout release zip, and optionally publish it to the team cloud so
every installed computer updates itself the next time HotScout starts.

    $env:PYTHONPATH="backend"
    .venv\\Scripts\\python.exe installer\\build_release.py            # dist\\hotscout-<version>.zip
    .venv\\Scripts\\python.exe installer\\build_release.py --publish  # also upload (team admins only)

New computers: unzip the release and double-click Install-HotScout.cmd.
"""

from __future__ import annotations

import argparse
import hashlib
import sys
import time
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
DIRS = ("backend", "frontend", "installer", "firebase")
FILES = ("requirements.txt", ".env.example", "Install-HotScout.cmd")
SKIP_DIRS = {"__pycache__"}
SKIP_SUFFIXES = {".pyc", ".new", ".tmp", ".pt"}  # model weights download on first use


def _files():
    for d in DIRS:
        for f in sorted((REPO / d).rglob("*")):
            if f.is_file() and not SKIP_DIRS & set(f.relative_to(REPO).parts) and f.suffix not in SKIP_SUFFIXES:
                yield f
    for name in FILES:
        yield REPO / name


def build(version: str) -> Path:
    team_env = (REPO / "installer" / "team.env").read_text(encoding="utf-8")
    if "FIREBASE_WEB_API_KEY=\n" in team_env or "FIREBASE_WEB_API_KEY=\r\n" in team_env:
        print("warning: installer/team.env has no FIREBASE_WEB_API_KEY; new installs cannot sign in until it is set")
    out = REPO / "dist" / f"hotscout-{version}.zip"
    out.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in _files():
            z.write(f, f.relative_to(REPO).as_posix())
        z.writestr("VERSION", version + "\n")
    return out


def publish(path: Path, version: str, sha: str) -> None:
    sys.path.insert(0, str(REPO / "backend"))
    from app.services import cloud

    if not cloud.signed_in():
        raise SystemExit("Sign in to the team cloud in HotScout on this computer first (needs an admin account).")
    name = f"releases/{path.name}"
    cloud.upload(name, path.read_bytes(), "application/zip")
    cloud.set_doc("config/release", {"version": version, "sha256": sha, "file": name, "published_at": time.time(), "published_by": cloud.status()["email"]})
    print(f"published {version}; team computers update on their next start")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--publish", action="store_true", help="upload to the team cloud (team admins only)")
    args = ap.parse_args()
    version = time.strftime("%Y.%m.%d.%H%M")
    path = build(version)
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    print(f"{path}\n  version {version}\n  {path.stat().st_size / 1e6:.1f} MB  sha256 {sha}")
    if args.publish:
        publish(path, version, sha)


if __name__ == "__main__":
    main()
