# Installs (or updates) HotScout for the current Windows user. No admin rights needed.
#
#   %LOCALAPPDATA%\HotScout\app    program (replaced on every update)
#   %LOCALAPPDATA%\HotScout\venv   Python + packages (only reinstalled when requirements change)
#   %LOCALAPPDATA%\HotScout\data   .env, outputs, models, datasets (never touched by updates)
#
# The robot detector, team looks, calibrations and hand checks come from the team
# cloud after signing in, so nothing else needs copying between computers.
param(
    [switch]$Quiet,  # called by the launcher for an update: no shortcuts, no pause
    [string]$Relaunch = ""  # launcher arguments to start HotScout with afterwards
)
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$Src = Split-Path -Parent $PSScriptRoot
$Root = Join-Path $env:LOCALAPPDATA "HotScout"
$App = Join-Path $Root "app"
$Venv = Join-Path $Root "venv"
$Data = Join-Path $Root "data"
$Tools = Join-Path $Root "tools"
New-Item -ItemType Directory -Force -Path $Root, $Data, $Tools | Out-Null

function Step($text) { Write-Host "==> $text" -ForegroundColor Cyan }

# ---- uv: fetches Python and packages (single exe, per user)
$Uv = (Get-Command uv -ErrorAction SilentlyContinue).Source
if (-not $Uv) {
    $Uv = Join-Path $Tools "uv.exe"
    if (-not (Test-Path $Uv)) {
        Step "Downloading uv"
        $zip = Join-Path $env:TEMP "uv-hotscout.zip"
        Invoke-WebRequest "https://github.com/astral-sh/uv/releases/latest/download/uv-x86_64-pc-windows-msvc.zip" -OutFile $zip
        Expand-Archive $zip -DestinationPath $Tools -Force
        Remove-Item $zip
    }
}

# ---- program files
if ((Resolve-Path $Src).Path -ne (Resolve-Path $App -ErrorAction SilentlyContinue).Path) {
    Step "Copying HotScout to $App"
    New-Item -ItemType Directory -Force -Path $App | Out-Null
    foreach ($dir in "backend", "frontend", "installer", "firebase") {
        if (Test-Path (Join-Path $Src $dir)) {
            robocopy (Join-Path $Src $dir) (Join-Path $App $dir) /MIR /XD __pycache__ /NFL /NDL /NJH /NJS /NP | Out-Null
            if ($LASTEXITCODE -ge 8) { throw "Copying $dir failed (robocopy $LASTEXITCODE)" }
        }
    }
    foreach ($file in "requirements.txt", "VERSION", ".env.example") {
        if (Test-Path (Join-Path $Src $file)) { Copy-Item (Join-Path $Src $file) $App -Force }
    }
}

# ---- settings: team cloud web config (public values, no secrets)
$EnvFile = Join-Path $Data ".env"
if (-not (Test-Path $EnvFile)) {
    $team = Join-Path $App "installer\team.env"
    if (Test-Path $team) { Copy-Item $team $EnvFile } else { New-Item -ItemType File -Path $EnvFile | Out-Null }
}

# ---- Python packages (skipped when nothing changed)
$Gpu = [bool](Get-Command nvidia-smi -ErrorAction SilentlyContinue)
$Req = Join-Path $App "requirements.txt"
$Extra = Join-Path $App "installer\requirements-extra.txt"
$Stamp = Join-Path $Venv "hotscout-requirements.sha256"
$Hash = ((Get-FileHash $Req).Hash + (Get-FileHash $Extra).Hash + "gpu=$Gpu")
if (-not (Test-Path $Stamp) -or (Get-Content $Stamp -Raw).Trim() -ne $Hash) {
    if (-not (Test-Path (Join-Path $Venv "Scripts\python.exe"))) {
        Step "Setting up Python 3.11"
        & $Uv venv $Venv --python 3.11 --seed
        if ($LASTEXITCODE) { throw "uv venv failed" }
    }
    $Py = Join-Path $Venv "Scripts\python.exe"
    $TorchIndex = if ($Gpu) { "https://download.pytorch.org/whl/cu126" } else { "https://download.pytorch.org/whl/cpu" }
    Step "Installing PyTorch ($(if ($Gpu) { 'NVIDIA GPU' } else { 'CPU only - slow; consider opening the team URL instead' })). This is a large download."
    & $Uv pip install --python $Py torch torchvision --index-url $TorchIndex
    if ($LASTEXITCODE) { throw "PyTorch install failed" }
    Step "Installing HotScout packages"
    & $Uv pip install --python $Py -r $Req
    if ($LASTEXITCODE) { throw "Package install failed" }
    # easyocr would pull opencv-python-headless, which clashes with opencv-python
    & $Uv pip install --python $Py --no-deps -r $Extra
    if ($LASTEXITCODE) { throw "Extra package install failed" }
    Set-Content -Path $Stamp -Value $Hash
}

# ---- check the install actually starts (catches broken or blocked packages here, not at first launch)
Step "Checking the install"
$env:PYTHONPATH = Join-Path $App "backend"
Push-Location $Data  # app settings and folders are relative to the data folder
& (Join-Path $Venv "Scripts\python.exe") -c "import torch, cv2, ultralytics, easyocr, uvicorn; import app.main"
$ok = -not $LASTEXITCODE
Pop-Location
Remove-Item Env:PYTHONPATH
if (-not $ok) {
    Remove-Item $Stamp -ErrorAction SilentlyContinue  # reinstall packages on the next run
    throw "HotScout's Python packages do not load (see the error above). Run Install-HotScout.cmd again; if it repeats, send this window to the team."
}

# ---- shortcuts
if (-not $Quiet) {
    Step "Creating shortcuts"
    $shell = New-Object -ComObject WScript.Shell
    $targets = @(
        @{ Name = "HotScout"; Args = "" },
        @{ Name = "HotScout (share on network)"; Args = " --share" }
    )
    $places = @([Environment]::GetFolderPath("Desktop"), (Join-Path ([Environment]::GetFolderPath("Programs")) "HotScout"))
    foreach ($place in $places) {
        New-Item -ItemType Directory -Force -Path $place | Out-Null
        foreach ($t in $targets) {
            if ($place -like "*Desktop*" -and $t.Args) { continue }  # keep the desktop tidy
            $lnk = $shell.CreateShortcut((Join-Path $place "$($t.Name).lnk"))
            $lnk.TargetPath = Join-Path $Venv "Scripts\python.exe"
            $lnk.Arguments = "`"$(Join-Path $App 'installer\launcher.py')`"$($t.Args)"
            $lnk.WorkingDirectory = $Data
            $lnk.Description = "HotScout auto tracker"
            $lnk.Save()
        }
    }
    Write-Host ""
    Write-Host "HotScout is installed. Start it from the desktop shortcut, then click 'Sign in with Google'." -ForegroundColor Green
    Read-Host "Press Enter to close"
}

if ($PSBoundParameters.ContainsKey("Relaunch")) {
    $launchArgs = @("`"$(Join-Path $App 'installer\launcher.py')`"", "--no-update") + @($Relaunch -split " " | Where-Object { $_ })
    Start-Process -FilePath (Join-Path $Venv "Scripts\python.exe") -ArgumentList $launchArgs -WorkingDirectory $Data
}
