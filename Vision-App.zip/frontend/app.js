// Through the web address, slow API calls answer 202 + a ticket; wait for the real answer.
const nativeFetch = window.fetch.bind(window);
window.fetch = async (input, init) => {
  let res = await nativeFetch(input, init);
  let ticket = res.status === 202 && res.headers.get("x-hotscout-pending");
  while (ticket) {
    res = await nativeFetch(`/api/pending/${encodeURIComponent(ticket)}`, { signal: init?.signal });
    ticket = res.status === 202 && res.headers.get("x-hotscout-pending");
  }
  return res;
};

const logEl = document.getElementById("log");
const calibPointsEl = document.getElementById("calibPoints");
const canvas = document.getElementById("pathCanvas");
const ctx = canvas.getContext("2d");
const processBtnEl = document.getElementById("process");
const statusEl = document.getElementById("status");
let uploadedVideoPath = "";
let calibrationPoints = [];
let elevatedPoints = [];
let manualTagObservations = [];
let manualTagMode = false;
let frameImage = null;
let frameMeta = null;
let lastResult = null;
let eventMatches = [];
// Robots view: 3 red + 3 blue slots built from tracklets; edits are saved via /api/assign-robots.
const ROBOT_IDS = ["red1", "red2", "red3", "blue1", "blue2", "blue3"];
const SLOT_COLORS = { red1: "#ff4d4d", red2: "#ff9f1c", red3: "#ff5fd2", blue1: "#3a86ff", blue2: "#00d1d1", blue3: "#a78bfa" };
let robotEdits = {}; // robot_id -> { team_key, track_ids }
let selectedRobot = "all";
let matchTeams = null; // { red: [team keys], blue: [...] } in driver-station order
let resultTrackStart = 0; // video time (s) of tracking t = 0
let momentT = null; // tracking time shown on the video frame (null = calibration frame)
let savingRobots = false;
let pendingSave = false;
const fieldCanvas = document.getElementById("fieldCanvas");
const fctx = fieldCanvas.getContext("2d");
const fieldTimeEl = document.getElementById("fieldTime");

const trackStartSecEl = document.getElementById("trackStartSec");
const trackEndSecEl = document.getElementById("trackEndSec");
const trackStartSliderEl = document.getElementById("trackStartSlider");
const trackEndSliderEl = document.getElementById("trackEndSlider");
const eventSelectEl = document.getElementById("eventSelect");
const matchSelectEl = document.getElementById("matchSelect");
const apriltagLayoutTextEl = document.getElementById("apriltagLayoutText");
const showCornersEl = document.getElementById("showCorners");
const showDetectedTagsEl = document.getElementById("showDetectedTags");
const showProjectedTagsEl = document.getElementById("showProjectedTags");
const showRobotPathEl = document.getElementById("showRobotPath");
const manualTagModeBtnEl = document.getElementById("manualTagMode");
const manualTagIdEl = document.getElementById("manualTagId");
const eventCalibStatusEl = document.getElementById("eventCalibStatus");
const useEventCalibrationEl = document.getElementById("useEventCalibration");
let savedEventCalibration = null;

const TAG_LAYOUT_2026_ANDYMARK_URL =
  "https://raw.githubusercontent.com/wpilibsuite/allwpilib/main/fields/src/main/native/resources/org/wpilib/fields/frc/2026-rebuilt-andymark.json";
const TAG_LAYOUT_2026_WELDED_URL =
  "https://raw.githubusercontent.com/wpilibsuite/allwpilib/main/fields/src/main/native/resources/org/wpilib/fields/frc/2026-rebuilt-welded.json";
const APRILTAG_LAYOUT_STORAGE_KEY = "visiontracker.apriltag_layout_text";
const DEFAULT_TEAM_KEY = "frc67";

function getRuntimeInputs() {
  return {
    tba_auth_key: document.getElementById("tbaAuthKey").value.trim(),
    default_tracker: document.getElementById("defaultTracker").value.trim(),
    yolo_model: document.getElementById("yoloModel").value.trim(),
    auto_seconds: Number(document.getElementById("autoSeconds").value),
    tracker_conf: Number(document.getElementById("trackerConf").value),
    tracker_iou: Number(document.getElementById("trackerIou").value),
    max_interp_gap_frames: Number(document.getElementById("maxInterpGap").value),
  };
}

function applyRuntimeInputs(cfg) {
  document.getElementById("tbaAuthKey").value = cfg.tba_auth_key || "";
  document.getElementById("defaultTracker").value = cfg.default_tracker || "tracktrack.yaml";
  document.getElementById("yoloModel").value = cfg.yolo_model || "yolo11n.pt";
  document.getElementById("autoSeconds").value = String(cfg.auto_seconds ?? 20);
  document.getElementById("trackerConf").value = String(cfg.tracker_conf ?? 0.2);
  document.getElementById("trackerIou").value = String(cfg.tracker_iou ?? 0.45);
  document.getElementById("maxInterpGap").value = String(cfg.max_interp_gap_frames ?? 15);
}

async function loadRuntimeSettings() {
  const res = await fetch("/api/runtime-config");
  const data = await res.json();
  if (!res.ok) return log(data);
  applyRuntimeInputs(data);
}

async function saveRuntimeSettings() {
  const payload = getRuntimeInputs();
  const res = await fetch("/api/runtime-config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  log(data);
  if (!res.ok) return;
  applyRuntimeInputs(data);
}

function log(data) {
  let safe = data;
  if (safe && typeof safe === "object" && "frame_data_url" in safe) {
    const clone = { ...safe };
    const raw = String(clone.frame_data_url || "");
    clone.frame_data_url = `[omitted data URL, ${raw.length} chars]`;
    safe = clone;
  }

  const msg = typeof safe === "string" ? safe : JSON.stringify(safe, null, 2);
  logEl.textContent = `${msg}\n${logEl.textContent}`;
}

function setStatus(text, level = "") {
  statusEl.textContent = text;
  statusEl.className = `status${level ? ` ${level}` : ""}`;
}

function normalizeTeamKey(input) {
  const key = (input || "").trim().toLowerCase();
  if (!key) return key;
  if (key.startsWith("frc")) return key;
  if (/^\d+$/.test(key)) return `frc${key}`;
  return key;
}

function setSelectOptions(selectEl, options, placeholder) {
  selectEl.innerHTML = "";
  const first = document.createElement("option");
  first.value = "";
  first.textContent = placeholder;
  selectEl.appendChild(first);

  options.forEach((opt) => {
    const o = document.createElement("option");
    o.value = opt.value;
    o.textContent = opt.label;
    selectEl.appendChild(o);
  });
}

function getInputs() {
  const endText = document.getElementById("trackEndSec").value.trim();
  const forcedTrackText = document.getElementById("forcedTrackId").value.trim();
  const rawTeamKey = document.getElementById("teamKey").value.trim();
  return {
    season: Number(document.getElementById("season").value),
    eventKey: document.getElementById("eventKey").value.trim(),
    teamKey: rawTeamKey || DEFAULT_TEAM_KEY,
    matchKey: document.getElementById("matchKey").value.trim(),
    alliance: document.getElementById("alliance").value,
    robotPos: Number(document.getElementById("robotPos").value),
    fieldWidthM: Number(document.getElementById("fieldWidthM").value),
    fieldHeightM: Number(document.getElementById("fieldHeightM").value),
    calibFrameSec: Number(document.getElementById("calibFrameSec").value),
    lockWindowSec: Number(document.getElementById("lockWindowSec").value),
    forcedTrackId: forcedTrackText ? Number(forcedTrackText) : null,
    trackStartSec: Number(document.getElementById("trackStartSec").value),
    trackEndSec: endText ? Number(endText) : null,
    apriltagLayoutText: document.getElementById("apriltagLayoutText").value.trim(),
    tagLayoutTransform: document.getElementById("tagLayoutTransform").value,
    autoSeconds: Number(document.getElementById("autoSeconds").value),
    trackerConfig: document.getElementById("defaultTracker").value.trim(),
  };
}

async function loadTeamEvents() {
  const { season, teamKey, eventKey } = getInputs();
  if (!teamKey) return log("Enter a Team Key (example: frc67)");

  const normalizedTeamKey = normalizeTeamKey(teamKey);
  document.getElementById("teamKey").value = normalizedTeamKey;

  const res = await fetch(`/api/team/${normalizedTeamKey}/events/${season}`);
  const data = await res.json();
  if (!res.ok) return log(data);

  const options = (data.events || []).map((e) => {
    const key = e.key || "";
    const name = e.name || key;
    const date = e.start_date || "";
    return { value: key, label: `${key} - ${name}${date ? ` (${date})` : ""}` };
  });

  setSelectOptions(eventSelectEl, options, "Select event for this team/season");
  setSelectOptions(matchSelectEl, [], "Select match after choosing an event");

  if (eventKey && options.some((o) => o.value === eventKey)) {
    eventSelectEl.value = eventKey;
  }

  if (!options.length) {
    log(`No events returned for ${normalizedTeamKey} in ${season}`);
  }

  log({ loaded_events: options.length, team: normalizedTeamKey, season });
}

async function loadEventMatches() {
  const { eventKey, teamKey } = getInputs();
  if (!eventKey) return log("Select an Event first");
  if (!teamKey) return log("Enter a Team Key (example: frc67)");

  const normalizedTeamKey = normalizeTeamKey(teamKey);
  document.getElementById("teamKey").value = normalizedTeamKey;

  const res = await fetch(`/api/events/${eventKey}/team/${normalizedTeamKey}/matches`);
  const data = await res.json();
  if (!res.ok) return log(data);

  eventMatches = Array.isArray(data.matches) ? data.matches : [];
  const options = (data.matches || []).map((m) => {
    const key = m.key || "";
    const level = m.comp_level || "?";
    const num = m.match_number || "?";
    const setNum = m.set_number || 1;
    return { value: key, label: `${key} (${level} ${setNum}-${num})` };
  });

  setSelectOptions(matchSelectEl, options, "Select match from this event");
  if (!options.length) {
    log(`No matches returned for ${normalizedTeamKey} at ${eventKey}`);
  }

  log({ loaded_matches: options.length, team: normalizedTeamKey, event: eventKey });
}

async function refreshEventCalibrationStatus() {
  const eventKey = currentEventKey();
  savedEventCalibration = null;
  eventCalibStatusEl.title = "";
  if (!EVENT_KEY_RE.test(eventKey)) {
    eventCalibStatusEl.textContent = "";
    eventCalibStatusEl.className = "status";
    return;
  }
  const res = await fetch(`/api/events/${encodeURIComponent(eventKey)}/calibration`);
  if (res.status === 404) {
    eventCalibStatusEl.textContent =
      "Camera setup needed: open \"Camera setup and single-match tools\" below (one time per event).";
    eventCalibStatusEl.className = "status busy";
    return;
  }
  const data = await res.json();
  if (!res.ok) {
    eventCalibStatusEl.textContent = `Could not check camera setup: ${data?.detail || `HTTP ${res.status}`}`;
    eventCalibStatusEl.className = "status error";
    return;
  }
  savedEventCalibration = data;
  // Recalibrating an event should keep its tag layout orientation.
  const savedTransform = data?.calibration_meta?.tag_layout_transform;
  const transformEl = document.getElementById("tagLayoutTransform");
  if (savedTransform && [...transformEl.options].some((o) => o.value === savedTransform)) {
    transformEl.value = savedTransform;
  }
  const s = data.summary || {};
  const rmse = s.reprojection_rmse_px != null ? `${Number(s.reprojection_rmse_px).toFixed(1)} px` : "n/a";
  eventCalibStatusEl.textContent = `Camera setup ready${s.calibrated_at ? ` (saved ${String(s.calibrated_at).slice(0, 10)})` : ""}.`;
  eventCalibStatusEl.title =
    `${s.image_width}x${s.image_height}, tags ${(s.detected_ids || []).join(",") || "none"}, RMSE ${rmse}`;
  eventCalibStatusEl.className = "status ok";
}

function saveApriltagLayoutToLocalStorage() {
  try {
    localStorage.setItem(APRILTAG_LAYOUT_STORAGE_KEY, apriltagLayoutTextEl.value || "");
  } catch {
    // Ignore storage quota/privacy mode errors.
  }
}

function loadApriltagLayoutFromLocalStorage() {
  try {
    const saved = localStorage.getItem(APRILTAG_LAYOUT_STORAGE_KEY);
    if (saved) {
      apriltagLayoutTextEl.value = saved;
      log("Loaded saved AprilTag layout from browser storage");
    }
  } catch {
    // Ignore storage quota/privacy mode errors.
  }
}

async function loadApriltagLayoutFromUrl(url, label) {
  const res = await fetch(url);
  if (!res.ok) {
    log(`${label} load failed: HTTP ${res.status}`);
    return;
  }
  const text = await res.text();
  apriltagLayoutTextEl.value = text;
  saveApriltagLayoutToLocalStorage();
  log(`${label} loaded and saved`);
}

function syncScrubbers() {
  trackStartSecEl.value = trackStartSliderEl.value;
  if (!trackEndSecEl.value) {
    trackEndSecEl.value = trackEndSliderEl.value;
  }
}

function getManualReferences() {
  const i = getInputs();
  const corners = [
    { field_x_m: 0.0, field_y_m: 0.0 },
    { field_x_m: i.fieldWidthM, field_y_m: 0.0 },
    { field_x_m: i.fieldWidthM, field_y_m: i.fieldHeightM },
    { field_x_m: 0.0, field_y_m: i.fieldHeightM },
  ];

  const groundRefs = calibrationPoints.slice(0, 4).map((p, idx) => ({
    image_x: p.sx,
    image_y: p.sy,
    field_x_m: corners[idx].field_x_m,
    field_y_m: corners[idx].field_y_m,
    field_z_m: 0.0,
  }));

  const zTop = Number(document.getElementById("farStationTopZM").value) || 1.2;
  const elevatedRefs = [];
  if (elevatedPoints[0]) {
    elevatedRefs.push({
      image_x: elevatedPoints[0].sx,
      image_y: elevatedPoints[0].sy,
      field_x_m: 0.0,
      field_y_m: 0.0,
      field_z_m: zTop,
    });
  }
  if (elevatedPoints[1]) {
    elevatedRefs.push({
      image_x: elevatedPoints[1].sx,
      image_y: elevatedPoints[1].sy,
      field_x_m: i.fieldWidthM,
      field_y_m: 0.0,
      field_z_m: zTop,
    });
  }

  return [...groundRefs, ...elevatedRefs];
}

function getManualTagObservations() {
  return manualTagObservations.map((t) => ({
    id: Number(t.id),
    image_x: Number(t.sx),
    image_y: Number(t.sy),
  }));
}

function sourceToDisplay(sx, sy) {
  if (!frameMeta || !frameMeta.sourceWidth || !frameMeta.sourceHeight) {
    return { x: sx, y: sy };
  }
  return {
    x: sx * (canvas.width / frameMeta.sourceWidth),
    y: sy * (canvas.height / frameMeta.sourceHeight),
  };
}

function displayToSource(dx, dy) {
  if (!frameMeta || !frameMeta.sourceWidth || !frameMeta.sourceHeight) {
    return { sx: dx, sy: dy };
  }
  return {
    sx: dx * (frameMeta.sourceWidth / canvas.width),
    sy: dy * (frameMeta.sourceHeight / canvas.height),
  };
}

function displayEventToCanvasPixels(evt) {
  const rect = canvas.getBoundingClientRect();
  const dx = (evt.clientX - rect.left) * (canvas.width / rect.width);
  const dy = (evt.clientY - rect.top) * (canvas.height / rect.height);
  return { dx, dy };
}

function invert3x3(m) {
  const a = m[0][0], b = m[0][1], c = m[0][2];
  const d = m[1][0], e = m[1][1], f = m[1][2];
  const g = m[2][0], h = m[2][1], i = m[2][2];

  const A = e * i - f * h;
  const B = -(d * i - f * g);
  const C = d * h - e * g;
  const D = -(b * i - c * h);
  const E = a * i - c * g;
  const F = -(a * h - b * g);
  const G = b * f - c * e;
  const H = -(a * f - c * d);
  const I = a * e - b * d;

  const det = a * A + b * B + c * C;
  if (!det || !Number.isFinite(det)) return null;
  const invDet = 1 / det;

  return [
    [A * invDet, D * invDet, G * invDet],
    [B * invDet, E * invDet, H * invDet],
    [C * invDet, F * invDet, I * invDet],
  ];
}

function applyHomography(m, x, y) {
  const tx = m[0][0] * x + m[0][1] * y + m[0][2];
  const ty = m[1][0] * x + m[1][1] * y + m[1][2];
  const tw = m[2][0] * x + m[2][1] * y + m[2][2];
  if (!tw || !Number.isFinite(tw)) return null;
  return { x: tx / tw, y: ty / tw };
}

function drawAprilTagOverlay(result) {
  if (!showDetectedTagsEl.checked && !showProjectedTagsEl.checked) return;

  const apriltag = result?.calibration_meta?.apriltag;
  const detections = Array.isArray(apriltag?.detected_tags) ? apriltag.detected_tags : [];
  if (showDetectedTagsEl.checked && detections.length) {
    ctx.strokeStyle = "#ff9800";
    ctx.fillStyle = "#ff9800";
    ctx.lineWidth = 2;
    detections.forEach((tag) => {
      const p = sourceToDisplay(Number(tag.center_x) || 0, Number(tag.center_y) || 0);
      ctx.beginPath();
      if (Array.isArray(tag.corners) && tag.corners.length === 4) {
        tag.corners.forEach(([cx, cy], i) => {
          const c = sourceToDisplay(Number(cx) || 0, Number(cy) || 0);
          if (i === 0) ctx.moveTo(c.x, c.y);
          else ctx.lineTo(c.x, c.y);
        });
        ctx.closePath();
      }
      ctx.moveTo(p.x - 8, p.y);
      ctx.lineTo(p.x + 8, p.y);
      ctx.moveTo(p.x, p.y - 8);
      ctx.lineTo(p.x, p.y + 8);
      ctx.stroke();
      const suffix = tag.source === "pose_structural" ? "?" : "";
      ctx.fillText(`T${tag.id}${suffix}`, p.x + 10, p.y - 10);
    });
  }

  const h = result?.calibration_meta?.selected_homography_matrix;
  const selectedModel = result?.calibration_meta?.selected_projection_model;
  const projected3d = Array.isArray(apriltag?.projected_layout_points)
    ? apriltag.projected_layout_points
    : [];
  const layout = Array.isArray(result?.calibration_meta?.tag_layout_points)
    ? result.calibration_meta.tag_layout_points
    : [];
  const is3dModel = selectedModel === "apriltag_3d_pose" || selectedModel === "manual_3d_pose";

  const drawPolyline = (pts) => {
    if (!Array.isArray(pts) || pts.length < 2) return;
    ctx.beginPath();
    pts.forEach((pt, i) => {
      const x = Array.isArray(pt) ? pt[0] : pt?.image_x;
      const y = Array.isArray(pt) ? pt[1] : pt?.image_y;
      const d = sourceToDisplay(Number(x) || 0, Number(y) || 0);
      if (i === 0) ctx.moveTo(d.x, d.y);
      else ctx.lineTo(d.x, d.y);
    });
    ctx.stroke();
  };
  if (showProjectedTagsEl.checked && is3dModel) {
    const outline = Array.isArray(apriltag?.projected_field_outline) ? apriltag.projected_field_outline : [];
    ctx.strokeStyle = "#ffe14d";
    ctx.lineWidth = 2;
    outline.forEach(drawPolyline);
    const autoLines = Array.isArray(apriltag?.auto_straight_lines) ? apriltag.auto_straight_lines : [];
    ctx.strokeStyle = "#ff4fd8";
    ctx.setLineDash([6, 4]);
    autoLines.forEach(drawPolyline);
    ctx.setLineDash([]);
  }

  if (showProjectedTagsEl.checked && is3dModel && projected3d.length) {
    ctx.strokeStyle = "#6cff4f";
    ctx.fillStyle = "#6cff4f";
    ctx.lineWidth = 2;
    projected3d.forEach((tag) => {
      const p = sourceToDisplay(Number(tag.center_x) || 0, Number(tag.center_y) || 0);
      ctx.beginPath();
      if (Array.isArray(tag.corners) && tag.corners.length === 4) {
        tag.corners.forEach(([cx, cy], i) => {
          const c = sourceToDisplay(Number(cx) || 0, Number(cy) || 0);
          if (i === 0) ctx.moveTo(c.x, c.y);
          else ctx.lineTo(c.x, c.y);
        });
        ctx.closePath();
      } else {
        ctx.rect(p.x - 6, p.y - 6, 12, 12);
      }
      ctx.stroke();
      ctx.fillText(`P${tag.id}`, p.x + 8, p.y + 14);
    });
    return;
  }

  // In strict 3D display mode, never fall back to planar homography overlays.
  if (showProjectedTagsEl.checked && is3dModel) {
    return;
  }

  if (!showProjectedTagsEl.checked || !h || !layout.length) return;

  const inv = invert3x3(h);
  if (!inv) return;

  ctx.strokeStyle = "#6cff4f";
  ctx.fillStyle = "#6cff4f";
  ctx.lineWidth = 2;
  layout.forEach((tag) => {
    const fxCm = (Number(tag.field_x_m) || 0) * 100;
    const fyCm = (Number(tag.field_y_m) || 0) * 100;
    const img = applyHomography(inv, fxCm, fyCm);
    if (!img) return;
    const p = sourceToDisplay(img.x, img.y);
    ctx.beginPath();
    ctx.rect(p.x - 6, p.y - 6, 12, 12);
    ctx.stroke();
    ctx.fillText(`P${tag.id}`, p.x + 8, p.y + 14);
  });
}

function drawRobotOverlay(result) {
  if (!showRobotPathEl.checked) return;
  if (result?.mode === "calibration") return;
  if (Array.isArray(result?.robots) && result.robots.length) {
    drawRobotsOnVideo();
    return;
  }

  const trackMeta = result?.quality_report?.track_meta || {};
  const candidates = Array.isArray(trackMeta.track_candidates) ? trackMeta.track_candidates : [];
  const selectedTrackId = trackMeta.selected_track_id;

  candidates.forEach((c) => {
    const pos = sourceToDisplay(Number(c.start_px) || 0, Number(c.start_py) || 0);
    const isSelected = selectedTrackId !== null && Number(c.track_id) === Number(selectedTrackId);
    const guess = String(c.alliance_guess || "?").toUpperCase();
    ctx.strokeStyle = isSelected ? "#ffffff" : "#8be9ff";
    ctx.fillStyle = isSelected ? "#ffffff" : "#8be9ff";
    ctx.lineWidth = isSelected ? 3 : 2;
    ctx.beginPath();
    ctx.rect(pos.x - 8, pos.y - 8, 16, 16);
    ctx.stroke();
    ctx.fillText(`ID${c.track_id} ${guess} @${Number(c.first_t_sec || 0).toFixed(1)}s${isSelected ? " *" : ""}`, pos.x + 10, pos.y - 10);
  });

  const imagePoints = Array.isArray(result?.image_track_points) ? result.image_track_points : [];
  const pathPoints = Array.isArray(result?.path?.points) ? result.path.points.filter((p) => p.px != null && p.py != null) : [];
  const pathNodes = Array.isArray(result?.path?.nodes) ? result.path.nodes.filter((p) => p.px != null && p.py != null) : [];
  if (pathPoints.length) {
    drawConfidencePath(imagePoints, pathPoints, pathNodes);
    return;
  }
  if (!imagePoints.length) return;

  ctx.strokeStyle = "#12c7ff";
  ctx.lineWidth = 3;
  ctx.beginPath();
  imagePoints.forEach((p, idx) => {
    const pos = sourceToDisplay(Number(p.px) || 0, Number(p.py) || 0);
    if (idx === 0) ctx.moveTo(pos.x, pos.y);
    else ctx.lineTo(pos.x, pos.y);
  });
  ctx.stroke();

  ctx.fillStyle = "#ffe45e";
  imagePoints.forEach((p, idx) => {
    if (idx % 5 !== 0 && idx !== imagePoints.length - 1) return;
    const pos = sourceToDisplay(Number(p.px) || 0, Number(p.py) || 0);
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 3, 0, Math.PI * 2);
    ctx.fill();
  });

  const first = sourceToDisplay(Number(imagePoints[0].px) || 0, Number(imagePoints[0].py) || 0);
  const last = sourceToDisplay(
    Number(imagePoints[imagePoints.length - 1].px) || 0,
    Number(imagePoints[imagePoints.length - 1].py) || 0,
  );

  ctx.fillStyle = "#54ff54";
  ctx.beginPath();
  ctx.arc(first.x, first.y, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.fillText("START", first.x + 10, first.y - 8);

  ctx.fillStyle = "#ff5252";
  ctx.beginPath();
  ctx.arc(last.x, last.y, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.fillText("END", last.x + 10, last.y - 8);
}

function confidenceColor(conf, alpha = 1) {
  const c = Math.max(0, Math.min(1, Number(conf) || 0));
  return `hsla(${Math.round(c * 120)}, 95%, 55%, ${alpha})`;
}

// Auto path drawn from confident nodes joined by built segments, not raw samples.
// Colour = confidence (red..green), dashed = no detection on that stretch,
// magenta = climb segment, node size = confidence, z label when lifted.
function drawConfidencePath(rawPoints, pathPoints, pathNodes) {
  ctx.save();

  ctx.fillStyle = "rgba(18, 199, 255, 0.35)";
  rawPoints.forEach((p) => {
    if (!p.inferred) {
      const pos = sourceToDisplay(Number(p.px) || 0, Number(p.py) || 0);
      ctx.fillRect(pos.x - 1, pos.y - 1, 2, 2);
    }
  });

  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  for (let i = 1; i < pathPoints.length; i += 1) {
    const a = pathPoints[i - 1];
    const b = pathPoints[i];
    const pa = sourceToDisplay(Number(a.px), Number(a.py));
    const pb = sourceToDisplay(Number(b.px), Number(b.py));
    ctx.strokeStyle = b.kind === "climb" ? "#ff4fd8" : confidenceColor(b.confidence, 0.9);
    ctx.setLineDash(b.inferred ? [6, 6] : []);
    ctx.beginPath();
    ctx.moveTo(pa.x, pa.y);
    ctx.lineTo(pb.x, pb.y);
    ctx.stroke();
  }
  ctx.setLineDash([]);

  pathNodes.forEach((n, idx) => {
    const pos = sourceToDisplay(Number(n.px), Number(n.py));
    const conf = Number(n.confidence) || 0;
    const isStart = idx === 0;
    const isEnd = idx === pathNodes.length - 1;
    ctx.fillStyle = isStart ? "#54ff54" : isEnd ? "#ff5252" : confidenceColor(conf, 0.4 + 0.6 * conf);
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, isStart || isEnd ? 7 : 3 + 4 * conf, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    const labels = [];
    if (isStart) labels.push("START");
    if (isEnd) labels.push("END");
    if (n.kind && !["start", "end", "observed"].includes(n.kind)) labels.push(String(n.kind).toUpperCase());
    if ((Number(n.z_m) || 0) > 0.1) labels.push(`z ${Number(n.z_m).toFixed(2)}m`);
    if (labels.length) {
      ctx.fillStyle = "#ffffff";
      ctx.fillText(labels.join(" "), pos.x + 10, pos.y - 8);
    }
  });

  ctx.restore();
}

// One colour per robot. Solid = seen, dashed = hidden (position inferred),
// hollow node = HIDE (went out of view), filled node = BACK (reappeared).
function drawColoredPath(path, color, label) {
  const pts = (path?.points || []).filter((p) => p.px != null && p.py != null);
  const nodes = (path?.nodes || []).filter((p) => p.px != null && p.py != null);
  if (!pts.length) return;
  ctx.save();
  ctx.lineWidth = 3;
  ctx.lineCap = "round";
  ctx.strokeStyle = color;
  for (let i = 1; i < pts.length; i += 1) {
    const a = sourceToDisplay(Number(pts[i - 1].px), Number(pts[i - 1].py));
    const b = sourceToDisplay(Number(pts[i].px), Number(pts[i].py));
    ctx.globalAlpha = pts[i].inferred ? 0.6 : 0.95;
    ctx.setLineDash(pts[i].inferred ? [5, 7] : []);
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }
  ctx.setLineDash([]);
  ctx.globalAlpha = 1;
  ctx.font = "12px sans-serif";
  nodes.forEach((n) => {
    const pos = sourceToDisplay(Number(n.px), Number(n.py));
    if (n.kind === "hide" || n.kind === "reappear") {
      ctx.fillStyle = color;
      ctx.strokeStyle = "#000000";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
      if (n.kind === "reappear") ctx.fill();
      ctx.stroke();
      ctx.strokeStyle = color;
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, 5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = "#ffffff";
      ctx.fillText(`${n.kind === "hide" ? "HIDE" : "BACK"} ${Number(n.t_sec).toFixed(1)}s`, pos.x + 7, pos.y + 12);
    }
  });
  const first = sourceToDisplay(Number(pts[0].px), Number(pts[0].py));
  const last = sourceToDisplay(Number(pts[pts.length - 1].px), Number(pts[pts.length - 1].py));
  ctx.fillStyle = color;
  ctx.strokeStyle = "#000000";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(first.x, first.y, 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillRect(last.x - 5, last.y - 5, 10, 10);
  ctx.strokeRect(last.x - 5, last.y - 5, 10, 10);
  ctx.font = "bold 14px sans-serif";
  ctx.lineWidth = 3;
  ctx.strokeText(label, first.x + 8, first.y - 8);
  ctx.fillText(label, first.x + 8, first.y - 8);
  ctx.restore();
}

// ---------------------------------------------------------------- robots ---

function robotTitle(rid) {
  return `${rid.startsWith("red") ? "Red" : "Blue"} ${rid.slice(-1)}`;
}

function teamNumber(key) {
  return key ? key.replace(/^frc/, "") : "";
}

function robotLabel(rid) {
  const short = `${rid.startsWith("red") ? "R" : "B"}${rid.slice(-1)}`;
  const team = robotEdits[rid]?.team_key;
  return team ? `${short} ${teamNumber(team)}` : short;
}

function robotById(rid) {
  return (lastResult?.robots || []).find((r) => r.robot_id === rid) || null;
}

function ownerOf(trackId) {
  return ROBOT_IDS.find((rid) => robotEdits[rid]?.track_ids.includes(trackId)) || null;
}

function pathPts(robot) {
  return (robot?.path?.points || []).map((p) => ({ t: p.t_sec, x: p.x_m, y: p.y_m, px: p.px, py: p.py, inferred: p.inferred }));
}

function trkPts(tl) {
  return (tl?.points || []).map((a) => ({ t: a[0], x: a[1], y: a[2], px: a[3], py: a[4], inferred: false }));
}

// Linear interpolation of a time-sorted point list; null outside it or across gaps > maxGap.
function pointAt(pts, t, maxGap = Infinity) {
  if (!pts.length || t < pts[0].t - 1e-6 || t > pts[pts.length - 1].t + 1e-6) return null;
  const i = pts.findIndex((p) => p.t >= t);
  if (i === -1) return pts[pts.length - 1];
  if (i === 0) return pts[0];
  const a = pts[i - 1];
  const b = pts[i];
  if (b.t - a.t > maxGap) return null;
  const f = (t - a.t) / Math.max(1e-6, b.t - a.t);
  const lerp = (u, v) => (u == null || v == null ? null : u + (v - u) * f);
  return { t, x: lerp(a.x, b.x), y: lerp(a.y, b.y), px: lerp(a.px, b.px), py: lerp(a.py, b.py), inferred: b.inferred };
}

function activeTracklet(rid, t) {
  return (lastResult?.tracklets || []).find(
    (tl) => robotEdits[rid]?.track_ids.includes(tl.track_id) && t >= tl.first_t_sec && t <= tl.last_t_sec,
  );
}

function seenText(rid) {
  const r = robotById(rid);
  if (!r || r.first_t_sec == null) return "no tracklets";
  const hides = r.path?.summary?.hide_count ?? 0;
  return `seen ${r.first_t_sec.toFixed(1)}-${r.last_t_sec.toFixed(1)} s, ${Math.round(100 * r.observed_fraction)}% visible, ${hides} hide(s)`;
}

function trackletText(tl) {
  return `T${tl.track_id} ${tl.first_t_sec.toFixed(1)}-${tl.last_t_sec.toFixed(1)} s`;
}

function initRobots(result) {
  robotEdits = {};
  ROBOT_IDS.forEach((rid) => {
    const r = (result?.robots || []).find((x) => x.robot_id === rid);
    robotEdits[rid] = { team_key: r?.team_key || null, track_ids: r ? [...r.track_ids] : [] };
  });
  selectedRobot = "all";
  momentT = null;
  const ends = [...(result?.tracklets || []), ...(result?.robots || [])].map((x) => Number(x.last_t_sec) || 0);
  fieldTimeEl.max = Math.max(1, ...ends).toFixed(1);
  fieldTimeEl.value = "0";
  renderRobotsPanel();
  if (result?.robots?.length) {
    loadMatchTeams(false).catch((err) => log(`TBA teams error: ${err.message}`));
  }
}

function renderRobotsPanel() {
  const panel = document.getElementById("robotsPanel");
  panel.hidden = !(lastResult?.robots || []).length;
  if (panel.hidden) return;
  renderRobotTabs();
  renderRobotDetail();
  renderTeamsHint();
  drawFieldView();
}

function selectRobot(rid) {
  selectedRobot = rid;
  renderRobotsPanel();
  redrawCanvas();
}

function renderRobotTabs() {
  const tabs = document.getElementById("robotTabs");
  tabs.replaceChildren();
  ["all", ...ROBOT_IDS].forEach((rid) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = `robot-tab${rid === selectedRobot ? " active" : ""}`;
    if (rid !== "all") b.style.borderColor = SLOT_COLORS[rid];
    const team = rid === "all" ? "" : teamNumber(robotEdits[rid]?.team_key);
    b.textContent = rid === "all" ? "All" : `${robotTitle(rid)}${team ? ` - ${team}` : ""}`;
    b.addEventListener("click", () => selectRobot(rid));
    tabs.appendChild(b);
  });
}

function teamSelect(rid) {
  const alliance = rid.startsWith("red") ? "red" : "blue";
  const current = robotEdits[rid].team_key;
  const teams = matchTeams?.[alliance] || [];
  if (!teams.length) {
    const input = document.createElement("input");
    input.type = "text";
    input.size = 7;
    input.placeholder = "team #";
    input.value = teamNumber(current);
    input.addEventListener("change", () => setTeam(rid, input.value.trim() ? normalizeTeamKey(input.value) : null));
    return input;
  }
  const sel = document.createElement("select");
  sel.add(new Option("- not assigned -", ""));
  teams.forEach((key, idx) => {
    const usedBy = ROBOT_IDS.find((o) => o !== rid && robotEdits[o].team_key === key);
    const station = `${alliance === "red" ? "Red" : "Blue"} station ${idx + 1}`;
    sel.add(new Option(`${teamNumber(key)} (${station})${usedBy ? ` - now on ${robotTitle(usedBy)}` : ""}`, key));
  });
  if (current && !teams.includes(current)) sel.add(new Option(teamNumber(current), current));
  sel.value = current || "";
  sel.addEventListener("change", () => setTeam(rid, sel.value || null));
  return sel;
}

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text != null) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function teamIdText(rid) {
  const r = (lastResult?.robots || []).find((x) => x.robot_id === rid);
  const info = r?.team_id;
  if (!info || r.team_key !== robotEdits[rid]?.team_key) return robotEdits[rid]?.team_key ? "manual" : "-";
  const conf = info.confidence != null ? ` ${Math.round(info.confidence * 100)}%` : "";
  const label = { bumper_ocr: "bumper OCR", appearance: "by look (from good matches)", elimination: "by elimination", best_guess: "GUESS - please check" }[info.method] || info.method;
  return `${label}${conf}`;
}

function renderRobotDetail() {
  const box = document.getElementById("robotDetail");
  box.replaceChildren();
  const tracklets = lastResult?.tracklets || [];

  if (selectedRobot === "all") {
    const table = el("table");
    const head = el("tr");
    ["Robot", "Team", "Team ID", "Tracking", "Tracklets"].forEach((h) => head.appendChild(el("th", h)));
    table.appendChild(head);
    ROBOT_IDS.forEach((rid) => {
      const row = el("tr");
      const name = el("td");
      const sw = el("span", null, "swatch");
      sw.style.background = SLOT_COLORS[rid];
      const link = el("a", robotTitle(rid));
      link.href = "#";
      link.addEventListener("click", (evt) => {
        evt.preventDefault();
        selectRobot(rid);
      });
      name.append(sw, " ", link);
      const team = el("td");
      team.appendChild(teamSelect(rid));
      row.append(name, team, el("td", teamIdText(rid)), el("td", seenText(rid)), el("td", robotEdits[rid].track_ids.map((id) => `T${id}`).join(", ") || "-"));
      table.appendChild(row);
    });
    box.appendChild(table);
    const loose = tracklets.filter((tl) => !ownerOf(tl.track_id));
    if (loose.length) {
      box.appendChild(
        el("p", `Not on any robot (grey on the map): ${loose.map((tl) => `${trackletText(tl)} (${tl.alliance})`).join(", ")}`, "overlay-legend"),
      );
    }
    return;
  }

  const rid = selectedRobot;
  const top = el("div", null, "robot-detail-row");
  top.append(el("strong", robotTitle(rid)), " Team: ", teamSelect(rid), el("span", ` ${seenText(rid)}`, "overlay-legend"));
  box.appendChild(top);

  const chips = el("div", null, "robot-detail-row");
  chips.appendChild(el("span", "Tracklets: "));
  const mine = tracklets.filter((tl) => robotEdits[rid].track_ids.includes(tl.track_id));
  if (!mine.length) chips.appendChild(el("span", "none", "overlay-legend"));
  mine.forEach((tl) => {
    const chip = el("span", trackletText(tl), "chip");
    chip.style.borderColor = SLOT_COLORS[rid];
    const rm = el("button", "x");
    rm.type = "button";
    rm.title = "Remove this tracklet from the robot";
    rm.addEventListener("click", () => moveTracklet(tl.track_id, null));
    chip.appendChild(rm);
    chips.appendChild(chip);
  });
  box.appendChild(chips);

  const add = el("div", null, "robot-detail-row");
  const sel = el("select");
  const alliance = rid.startsWith("red") ? "red" : "blue";
  const others = tracklets
    .filter((tl) => tl.alliance === alliance && !robotEdits[rid].track_ids.includes(tl.track_id))
    .sort((a, b) => a.first_t_sec - b.first_t_sec);
  sel.add(new Option(others.length ? "- pick a tracklet -" : `- no other ${alliance}-bumper tracklets -`, ""));
  others.forEach((tl) => {
    const owner = ownerOf(tl.track_id);
    sel.add(new Option(`${trackletText(tl)} (${owner ? `on ${robotTitle(owner)}` : "unassigned"})`, String(tl.track_id)));
  });
  const btn = el("button", "Move to this robot");
  btn.type = "button";
  btn.addEventListener("click", () => {
    if (sel.value) moveTracklet(Number(sel.value), rid);
  });
  add.append("Add tracklet: ", sel, " ", btn);
  box.appendChild(add);
}

function renderTeamsHint() {
  const hint = document.getElementById("matchTeamsHint");
  if (matchTeams) {
    const list = (side) => (matchTeams[side] || []).map((k, i) => `${teamNumber(k)} (st ${i + 1})`).join(", ") || "-";
    hint.textContent = `TBA ${matchTeams.match_key}: Red ${list("red")} | Blue ${list("blue")}`;
  } else {
    hint.textContent = "Teams not loaded from TBA: set the TBA API key and a match key, then press Load match teams (or type team numbers).";
  }
}

function setTeam(rid, teamKey) {
  if (teamKey && !/^frc[0-9]{1,5}$/.test(teamKey)) {
    setStatus(`Invalid team number for ${robotTitle(rid)}`, "error");
    renderRobotsPanel();
    return;
  }
  ROBOT_IDS.forEach((o) => {
    if (teamKey && robotEdits[o].team_key === teamKey) robotEdits[o].team_key = null;
  });
  robotEdits[rid].team_key = teamKey;
  saveRobots();
}

function moveTracklet(trackId, toRid) {
  ROBOT_IDS.forEach((rid) => {
    robotEdits[rid].track_ids = robotEdits[rid].track_ids.filter((x) => x !== trackId);
  });
  if (toRid) robotEdits[toRid].track_ids.push(trackId);
  saveRobots();
}

async function saveRobots() {
  renderRobotsPanel();
  if (!lastResult?.run_id) {
    log("Process a match first (no saved tracking run).");
    return;
  }
  if (savingRobots) {
    pendingSave = true;
    return;
  }
  savingRobots = true;
  setStatus("Rebuilding robot paths...", "busy");
  try {
    const body = {
      run_id: lastResult.run_id,
      match_key: lastResult.match_key || "",
      robots: ROBOT_IDS.map((rid) => ({ robot_id: rid, team_key: robotEdits[rid].team_key, track_ids: robotEdits[rid].track_ids })),
    };
    const res = await fetch("/api/assign-robots", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) {
      const detail = typeof data?.detail === "string" ? data.detail : JSON.stringify(data?.detail ?? res.status);
      setStatus(`Save failed: ${detail}`, "error");
      log(data);
      return;
    }
    lastResult.robots = data.robots;
    lastResult.tracklets = data.tracklets;
    if (data.field_occlusion) lastResult.field_occlusion = data.field_occlusion;
    if (!pendingSave) {
      data.robots.forEach((r) => {
        if (robotEdits[r.robot_id]) robotEdits[r.robot_id].track_ids = [...r.track_ids];
      });
    }
    if (data.warnings?.length) log({ warnings: data.warnings });
    setStatus(`Saved ${data.output_files?.json || "robots.json"} + ${data.output_files?.team_count || 0} team file(s)`, "ok");
  } catch (err) {
    setStatus(`Save failed: ${err.message}`, "error");
  } finally {
    savingRobots = false;
    if (pendingSave) {
      pendingSave = false;
      saveRobots();
    } else {
      renderRobotsPanel();
      redrawCanvas();
    }
  }
}

async function exportTeamPaths() {
  if (savingRobots || pendingSave) {
    setStatus("Still saving robot edits; try again in a moment.", "error");
    return;
  }
  const matchKey = lastResult?.match_key || "";
  const teams = ROBOT_IDS.map((rid) => robotEdits[rid]?.team_key).filter(Boolean);
  if (!lastResult?.run_id || !teams.length) {
    setStatus("Assign a team to at least one robot first.", "error");
    return;
  }
  for (const teamKey of teams) {
    const res = await fetch(`/api/match/${encodeURIComponent(matchKey)}/team-path/${encodeURIComponent(teamKey)}`);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data?.detail || `${teamKey}: HTTP ${res.status}`);
    }
    const name = /filename="?([^";]+)/.exec(res.headers.get("Content-Disposition") || "")?.[1] || `${matchKey}_${teamNumber(teamKey)}.json`;
    const url = URL.createObjectURL(await res.blob());
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  }
  setStatus(`Exported ${teams.length} team path file(s)`, "ok");
}

async function uploadFirebase() {
  if (savingRobots || pendingSave) {
    setStatus("Still saving robot edits; try again in a moment.", "error");
    return;
  }
  const matchKey = lastResult?.match_key || "";
  if (!matchKey) {
    setStatus("Process a match first.", "error");
    return;
  }
  setStatus("Uploading to Firebase...", "busy");
  const res = await fetch(`/api/match/${encodeURIComponent(matchKey)}/firebase-upload`, { method: "POST" });
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  log({ firebase: data });
  const errs = data.errors?.length ? `, ${data.errors.length} error(s) - see log` : "";
  setStatus(`Uploaded ${data.uploaded?.length || 0} auto(s) to Firebase${errs}`, errs ? "error" : "ok");
}

async function refreshFirebaseStatus() {
  const pill = document.getElementById("firebaseStatus");
  const res = await fetch("/api/firebase/status");
  const data = await res.json();
  pill.textContent = data.configured ? "Cloud sync: on" : "Cloud sync: off (saved on this computer)";
  pill.title = data.configured ? `Autos upload to Firebase project ${data.project_id} as ${data.via}` : data.reason || "";
  pill.className = `pill ${data.configured ? "ok" : "busy"}`;
}

// ---------- Team cloud (Google sign-in; shared detector, calibrations, hand checks) ----------
const FIREBASE_SDK = "https://www.gstatic.com/firebasejs/10.12.2";
let cloudState = null;
let cloudAuthPromise = null;

function cloudAuth(config) {
  cloudAuthPromise ||= Promise.all([import(`${FIREBASE_SDK}/firebase-app.js`), import(`${FIREBASE_SDK}/firebase-auth.js`)]).then(
    ([fbApp, fbAuth]) => ({ auth: fbAuth.getAuth(fbApp.initializeApp(config)), lib: fbAuth })
  );
  return cloudAuthPromise;
}

async function refreshCloud() {
  const res = await fetch("/api/cloud/status");
  cloudState = await res.json();
  const btn = document.getElementById("cloudBtn");
  const out = document.getElementById("cloudSignOut");
  btn.hidden = !cloudState.configured;
  out.hidden = !cloudState.signed_in;
  btn.textContent = cloudState.signed_in ? "Sync now" : "Sign in with Google";
  btn.title = cloudState.signed_in
    ? `Signed in as ${cloudState.email}. Shares the robot detector, team looks, calibrations and hand checks with the other team computers.`
    : "Sign in with a team Google account to share the robot detector, calibrations and hand checks";
  out.title = cloudState.signed_in ? `Sign out ${cloudState.email}` : "";
  // Load the sign-in code early: the popup must open soon after the click.
  if (cloudState.web_config && !cloudState.signed_in) cloudAuth(cloudState.web_config).catch((err) => log(`Firebase SDK: ${err.message}`));
  return cloudState;
}

async function cloudSignIn() {
  const st = cloudState || (await refreshCloud());
  if (!st.web_config) throw new Error("The team cloud is not set up on this computer (FIREBASE_WEB_API_KEY in .env).");
  const { auth, lib } = await cloudAuth(st.web_config);
  const cred = await lib.signInWithPopup(auth, new lib.GoogleAuthProvider());
  setStatus("Checking the team list...", "busy");
  const res = await fetch("/api/cloud/session", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id_token: await cred.user.getIdToken(), refresh_token: cred.user.refreshToken }),
  });
  const data = await res.json();
  await lib.signOut(auth); // the server keeps the session from here
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  if (!st.local) {
    location.reload();
    return;
  }
  await refreshCloud();
  refreshFirebaseStatus().catch((err) => log(`Firebase status error: ${err.message}`));
  await cloudSync();
}

async function cloudSync() {
  setStatus("Syncing with the team cloud...", "busy");
  const res = await fetch(`/api/cloud/sync?season=${detectorSeason()}`, { method: "POST" });
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  log({ cloud_sync: data });
  const errs = data.errors?.length ? ` (${data.errors.length} problem(s) - see log)` : "";
  setStatus(`Team cloud: ${data.synced?.length ? data.synced.join(", ") : "already up to date"}${errs}`, errs ? "error" : "ok");
  refreshDetector().catch(detectorError);
}

async function cloudSignOut() {
  await fetch("/api/cloud/sign-out", { method: "POST" });
  if (cloudState && !cloudState.local) {
    location.reload();
    return;
  }
  await refreshCloud();
  refreshFirebaseStatus().catch((err) => log(`Firebase status error: ${err.message}`));
  setStatus("Signed out of the team cloud", "ok");
}

async function refreshGpuStatus() {
  const pill = document.getElementById("gpuStatus");
  const res = await fetch("/api/system");
  const gpu = (await res.json()).gpu || {};
  const onGpu = gpu.device && gpu.device !== "cpu";
  pill.textContent = onGpu ? `GPU: ${gpu.name}` : "GPU: none (CPU only)";
  pill.title = onGpu
    ? `${gpu.name}, ${gpu.memory_gb} GB (${gpu.device}). In Task Manager its load shows under "Cuda"/"Compute", not "3D".`
    : gpu.warning || "";
  pill.className = `pill ${onGpu ? "ok" : "busy"}`;
}

// ---------- Robot detector training ----------
let detectorTimer = null;

function detectorSeason() {
  return Number(document.getElementById("season").value) || new Date().getFullYear();
}

async function refreshDetector() {
  const res = await fetch(`/api/detector/status?season=${detectorSeason()}`);
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  const statusEl = document.getElementById("detectorStatus");
  const job = data.job;
  const running = job && ["queued", "running"].includes(job.status);
  const parts = [
    data.checked_images
      ? `${data.approved_images} training frames: ${data.approved_images - data.checked_images} from matches marked good, ${data.checked_images} corrected in hand checks of ${data.checked_matches} match(es) (${data.images} collected from ${data.matches} scouted)`
      : `${data.approved_images} training frames from ${data.approved_matches} matches marked good (${data.images} collected from ${data.matches} scouted)`,
  ];
  const missing = data.good_matches - (data.good_frame_matches ?? data.approved_matches);
  if (missing > 0) parts.push(`${missing} good match(es) have no frames yet - use "Only collect pictures"`);
  for (const ext of data.external || []) {
    const used = Object.entries(ext.classes).filter(([, role]) => role !== "ignored").map(([name, role]) => `${name}→${role}`);
    parts.push(`outside set "${ext.name}": ${ext.images} pictures${used.length ? ` (${used.join(", ")})` : " - no robot classes, not used"}`);
  }
  if (data.model) {
    const m = data.model;
    const base = m.eval?.baseline;
    const share = (v) => `${Math.round(100 * (v || 0))}%`;
    parts.push(
      m.recall != null
        ? `detector finds ${share(m.recall)} of robots (AP50 ${m.map50.toFixed(2)})${base?.ap50 != null ? ` vs YOLO-World ${share(base.recall)} (${base.ap50.toFixed(2)})` : ""} on ${m.val_frames} held-out frames`
        : `detector mAP50 ${m.map50.toFixed(2)} on ${m.val_images} held-out pictures (older model)`,
    );
    parts.push(data.in_use ? "in use" : m.active ? "not in use" : `not used (needs AP50 ${data.min_map50} and to match YOLO-World)`);
    if (data.new_images > 0) parts.push(`${data.new_images} new since last training (retrains itself at ${data.auto_retrain_images})`);
  } else {
    parts.push(
      data.approved_matches < data.min_matches
        ? `mark more good matches: training needs ${data.min_matches}`
        : `not trained yet (trains itself at ${data.auto_retrain_images} new frames, or press Train)`,
    );
  }
  let text = parts.join(" - ");
  let cls = data.in_use ? "ok" : "";
  let pct = 0;
  if (job) {
    const p = job.progress || {};
    if (running) {
      cls = "busy";
      pct = p.epochs ? (100 * p.epoch) / p.epochs : p.total ? (100 * p.done) / p.total : 0;
    }
    if (job.message || job.error) text += ` | ${job.auto ? "auto " : ""}${job.status}: ${job.error || job.message}`;
    if (job.status === "failed") cls = "error";
  }
  statusEl.textContent = text;
  statusEl.className = `status ${cls}`;
  document.getElementById("detectorProgress").style.width = `${pct}%`;
  const enabled = document.getElementById("detectorEnabled");
  enabled.disabled = !data.model || running;
  enabled.checked = Boolean(data.model && data.model.enabled);
  document.getElementById("detectorTrain").disabled = running;
  document.getElementById("detectorCollect").disabled = running;
  document.getElementById("detectorCancel").disabled = !running;
  clearTimeout(detectorTimer);
  // Training can also start by itself after matches are marked good.
  detectorTimer = setTimeout(() => refreshDetector().catch((err) => log(`Detector status error: ${err.message}`)), running ? 3000 : 30000);
}

async function startDetectorJob(train) {
  const backfill = document.getElementById("detectorBackfill").checked;
  if (!train && !backfill) throw new Error("Tick 'Also collect pictures' first.");
  const res = await fetch("/api/detector/train", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ season: detectorSeason(), train, backfill }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  await refreshDetector();
}

async function postDetector(path, body) {
  const res = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  await refreshDetector();
}

function detectorError(err) {
  const el = document.getElementById("detectorStatus");
  el.textContent = err.message;
  el.className = "status error";
}

// ---------- Team computers ----------
let devicesTimer = null;

function agoText(sec) {
  if (sec < 90) return `${Math.round(sec)} s ago`;
  if (sec < 5400) return `${Math.round(sec / 60)} min ago`;
  if (sec < 172800) return `${Math.round(sec / 3600)} h ago`;
  return `${Math.round(sec / 86400)} days ago`;
}

function deviceGpuText(d) {
  const g = d.gpu || {};
  let text = g.name ? `${g.name} (${g.memory_gb} GB)` : "No GPU (CPU only)";
  const l = d.load;
  if (d.online && l) {
    const bits = [];
    if (l.util_pct != null) bits.push(`load ${Math.round(l.util_pct)}%`);
    if (l.mem_used_gb != null) bits.push(`memory ${l.mem_used_gb}/${l.mem_total_gb} GB`);
    if (l.temp_c != null) bits.push(`${Math.round(l.temp_c)}°C`);
    if (bits.length) text += ` - ${bits.join(", ")}`;
  }
  return text;
}

function deviceWorkText(d) {
  if (!d.online) return d.stopped_at ? `Closed ${agoText(Date.now() / 1000 - d.stopped_at)}` : `Last heard ${agoText(d.age_sec)}`;
  const parts = [];
  const s = d.scout;
  if (s) {
    const what = `${s.team_key ? `team ${teamNumber(s.team_key)} at ` : ""}${s.event_key}`;
    const state = s.status === "queued" ? "waiting for the GPU" : s.status === "watching" ? "watching for new videos" : `${s.completed}/${s.total} matches`;
    parts.push(`Scouting ${what}: ${state}${s.current ? ` - ${matchTitle(s.current)}` : ""}${s.remote_for ? ` (for ${s.remote_for})` : ""}`);
  }
  const t = d.training;
  if (t) {
    const p = t.progress || {};
    const step = p.epochs ? ` epoch ${p.epoch}/${p.epochs}` : p.total ? ` ${p.done}/${p.total}` : "";
    parts.push(`${t.auto ? "Auto-training" : "Training"} the ${t.season} detector${step}${t.message ? ` - ${t.message}` : ""}`);
  }
  return parts.join(" | ") || "Idle";
}

function renderDevices(data) {
  const list = document.getElementById("deviceList");
  list.replaceChildren();
  const recent = (data.devices || []).filter((d) => d.this || d.online || d.age_sec < 7 * 86400);
  recent.forEach((d) => {
    const busy = d.online && (d.scout || d.training);
    const item = el("div", null, `device-item${d.online ? "" : " offline"}${busy ? " busy" : ""}`);
    item.appendChild(el("strong", `${d.name || d.id}${d.this ? " (this computer)" : ""}`));
    item.appendChild(el("span", deviceGpuText(d), "sub"));
    item.appendChild(el("span", deviceWorkText(d), "sub"));
    const who = [d.email, d.version ? `version ${d.version}` : "", d.accept_remote ? "takes scout runs from others" : ""].filter(Boolean);
    item.appendChild(el("span", who.join(" - "), "sub"));
    list.appendChild(item);
  });
  if (!recent.length) list.appendChild(el("p", "No team computers yet.", "empty"));
  const status = document.getElementById("devicesStatus");
  const problem = !data.signed_in
    ? "Sign in to the team cloud to see the other team computers."
    : data.error
      ? `Could not read the other team computers: ${/403/.test(data.error) ? "the team cloud rules need the devices update (firebase deploy --only firestore:rules)" : data.error}`
      : "";
  status.textContent = problem;
  status.className = `status${problem ? " error" : ""}`;
  document.getElementById("acceptRemote").checked = Boolean(data.accept_remote);

  const select = document.getElementById("scoutDevice");
  const picked = select.value;
  const usable = (data.devices || []).filter((d) => !d.this && d.online && d.accept_remote);
  select.replaceChildren(new Option("This computer", ""));
  if (usable.length) select.add(new Option(`All team GPUs (this computer + ${usable.map((d) => d.name).join(", ")})`, "all"));
  usable.forEach((d) => select.add(new Option(`${d.name}${d.gpu?.name ? ` (${d.gpu.name})` : ""}`, d.id)));
  if (picked === "all" && !usable.length) {
    select.add(new Option("All team GPUs (no other computer available)", "all"));
  } else if (picked && picked !== "all" && !usable.some((d) => d.id === picked)) {
    select.add(new Option(`${(data.devices || []).find((d) => d.id === picked)?.name || "Other computer"} (not available)`, picked));
  }
  select.value = picked;
}

async function refreshDevices() {
  clearTimeout(devicesTimer);
  try {
    const res = await fetch("/api/devices");
    const data = await res.json();
    if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
    renderDevices(data);
  } finally {
    const open = document.getElementById("devicesCard").open;
    devicesTimer = setTimeout(() => refreshDevices().catch(devicesError), open ? 30000 : 120000);
  }
}

function devicesError(err) {
  const status = document.getElementById("devicesStatus");
  status.textContent = err.message;
  status.className = "status error";
}

async function setAcceptRemote(on) {
  const res = await fetch("/api/devices/settings", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ accept_remote: on }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  await refreshDevices();
}

// ---------- One-click scouting ----------
let scoutJobId = null;
let scoutRemote = false; // scoutJobId is a run on another team computer
let scoutTimer = null;
let scoutPolling = false;
const ACTIVE_JOB = ["queued", "running", "watching"];
const MATCH_STATUS_TEXT = {
  pending: "Waiting",
  downloading: "Downloading video",
  processing: "Drawing autos",
  done: "Done",
  skipped: "Already scouted",
  no_video: "No video",
  failed: "Failed",
  cancelled: "Stopped",
  elsewhere: "On another computer",
  shared: "Scouted on another computer",
};
const LEVEL_ORDER = { qm: 0, ef: 1, qf: 2, sf: 3, f: 4 };
const EVENT_KEY_RE = /^[0-9]{4}[a-z0-9]+$/;

function setScoutStatus(text, level = "") {
  const s = document.getElementById("scoutStatus");
  s.textContent = text;
  s.className = `status${level ? ` ${level}` : ""}`;
}

function setScoutRunning(running) {
  document.getElementById("scoutStart").disabled = running;
  document.getElementById("rescoutTagged").disabled = running;
  document.getElementById("scoutCancel").disabled = !running;
}

function parseMatchKey(key) {
  const m = /_(qm|ef|qf|sf|f)(?:(\d+)m)?(\d+)$/.exec(key || "");
  return m ? { level: m[1], set: Number(m[2] || 0), num: Number(m[3]) } : { level: "", set: 0, num: 0 };
}

function matchTitle(key) {
  const { level, set, num } = parseMatchKey(key);
  if (level === "qm") return `Qual ${num}`;
  if (level === "f") return `Final ${num}`;
  if (level === "sf") return num > 1 ? `Playoff ${set} (game ${num})` : `Playoff ${set}`;
  if (level === "qf") return `Quarterfinal ${set}-${num}`;
  if (level === "ef") return `Eighthfinal ${set}-${num}`;
  return key;
}

function matchOrder(a, b) {
  const x = parseMatchKey(a);
  const y = parseMatchKey(b);
  return (LEVEL_ORDER[x.level] ?? 9) - (LEVEL_ORDER[y.level] ?? 9) || x.set - y.set || x.num - y.num;
}

function currentEventKey() {
  return document.getElementById("eventKey").value.trim().toLowerCase();
}

async function startScout(rescoutOnly = false) {
  const i = getInputs();
  const mode = rescoutOnly ? "event" : document.querySelector('input[name="scoutMode"]:checked')?.value || "live";
  const eventKey = currentEventKey();
  if (!EVENT_KEY_RE.test(eventKey)) {
    setScoutStatus("Pick an event first (step 1).", "error");
    return;
  }
  const teamKey = normalizeTeamKey(document.getElementById("teamKey").value.trim());
  if (mode === "team" && !/^frc[0-9]{1,5}$/.test(teamKey)) {
    setScoutStatus("Enter your team number (step 1).", "error");
    return;
  }
  const maxText = document.getElementById("scoutMaxMatches").value.trim();
  const body = {
    season: i.season,
    event_key: eventKey,
    team_key: mode === "team" ? teamKey : null,
    live: mode === "live",
    tracking_start_sec: Number(document.getElementById("scoutStartSec").value) || 0,
    auto_seconds: i.autoSeconds || null,
    keep_videos: document.getElementById("scoutKeepVideos").checked,
    skip_existing: document.getElementById("scoutSkipExisting").checked,
    comp_levels: document.getElementById("scoutQualsOnly").checked ? ["qm"] : ["qm", "ef", "qf", "sf", "f"],
    max_matches: maxText ? Number(maxText) : null,
    auto_rescout: document.getElementById("scoutAutoRescout").checked,
    rescout_only: rescoutOnly,
  };
  if (rescoutOnly) {
    body.comp_levels = ["qm", "ef", "qf", "sf", "f"];
    body.max_matches = null;
  }
  setScoutRunning(true);
  const target = document.getElementById("scoutDevice").value;
  const pool = target === "all";
  const res = await fetch(pool ? "/api/scout/pool" : target ? "/api/remote-jobs" : "/api/scout/jobs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(target && !pool ? { device_id: target, request: body } : body),
  });
  const data = await res.json();
  if (!res.ok) {
    setScoutRunning(false);
    const detail = typeof data?.detail === "string" ? data.detail : JSON.stringify(data?.detail);
    if (/calibration/i.test(detail)) {
      setScoutStatus("This event needs a one-time camera setup first. Open \"Camera setup and single-match tools\" below.", "error");
      document.getElementById("workbench").open = true;
    } else {
      setScoutStatus(detail, "error");
    }
    return;
  }
  scoutJobId = data.job_id;
  scoutRemote = Boolean(target) && !pool;
  if (mode === "team" && !scoutRemote) {
    document.getElementById("autosTeamFilter").value = teamNumber(teamKey);
    scheduleAutosRender();
  }
  setScoutStatus(scoutRemote ? `Sent to ${data.remote?.device_name || "the other computer"}...` : "Getting ready...", "busy");
  startScoutPolling();
}

function startScoutPolling() {
  clearInterval(scoutTimer);
  const tick = () => pollScout().catch((err) => setScoutStatus(`Lost contact with the tracker (${err.message}); retrying...`, "error"));
  scoutTimer = setInterval(tick, scoutRemote ? 10000 : 5000);
  tick();
}

function renderScoutMatches(job) {
  const list = document.getElementById("scoutLog");
  list.replaceChildren();
  const active = ACTIVE_JOB.includes(job.status);
  if (!(job.matches || []).length) {
    list.appendChild(el("p", active ? "Looking up matches on The Blue Alliance..." : "No matches found.", "empty"));
    return;
  }
  job.matches.forEach((m) => {
    const working = m.status === "downloading" || m.status === "processing";
    const item = el("div", null, `match-item st-${working ? "active" : m.status}`);
    item.appendChild(el("strong", matchTitle(m.match_key)));
    let sub = MATCH_STATUS_TEXT[m.status] || m.status;
    if ((m.status === "elsewhere" || m.status === "shared") && m.message) sub = m.message;
    if (m.yt_wait) sub = "Waiting - YouTube bot check";
    if (m.status === "failed" && active) sub += " - will retry";
    if ((m.status === "done" || m.status === "skipped") && m.teams?.length) {
      const seen = m.teams.filter((t) => t.detected !== false).length;
      const unsure = m.teams.filter((t) => t.detected !== false && (t.method === "best_guess" || t.needs_review)).length;
      sub += ` - ${seen}/${m.teams.length} seen${unsure ? `, ${unsure} ?` : ""}`;
    }
    if (m.rescout && m.status === "done") sub += " (re-scouted)";
    if (m.rescout_tag && (m.status === "done" || m.status === "skipped")) {
      sub += " - needs re-scout";
      item.classList.add("needs-rescout");
    }
    item.appendChild(el("span", sub, "sub"));
    if (m.rescout_tag) item.title = m.rescout_tag.reason;
    else if (m.message && m.status !== "done") item.title = m.message;
    list.appendChild(item);
  });
}

async function pollScout() {
  if (!scoutJobId || scoutPolling) return;
  scoutPolling = true;
  let res, job;
  try {
    res = await fetch(scoutRemote ? `/api/remote-jobs/${scoutJobId}` : `/api/scout/jobs/${scoutJobId}`);
    job = await res.json();
  } finally {
    scoutPolling = false;
  }
  if (!res.ok) throw new Error(job?.detail || `HTTP ${res.status}`);
  renderScoutMatches(job);

  const matches = job.matches || [];
  const count = (...st) => matches.filter((m) => st.includes(m.status)).length;
  const scouted = count("done", "skipped", "shared");
  const bar = document.getElementById("scoutProgress");
  bar.style.width = `${job.total ? Math.round((100 * job.completed) / job.total) : 0}%`;
  bar.classList.toggle("live", job.status === "watching");

  // A remote run's autos are on the other computer (and in the team cloud), not here.
  if (!scoutRemote && job.event_key === currentEventKey()) {
    const ready = matches.filter((m) => m.status === "done" || m.status === "skipped");
    // Entries change when a re-scout or the team history rewrites them: fetch again.
    ready.forEach((m) => {
      const rev = `${m.attempts}:${m.rev || 0}`;
      if (scoutEntryRevs.has(m.match_key) && scoutEntryRevs.get(m.match_key) !== rev) refreshAutos(m.match_key);
      scoutEntryRevs.set(m.match_key, rev);
    });
    queueAutos(ready.map((m) => m.match_key));
  }

  const who = job.team_key ? `team ${teamNumber(job.team_key)} at ` : "";
  const remote = job.remote;
  const where = remote ? `On ${remote.device_name}: ` : "";
  const helpers = job.pool?.devices?.length ? ` - sharing with ${job.pool.devices.join(", ")}` : "";
  if (remote?.stale && ACTIVE_JOB.includes(job.status)) {
    setScoutStatus(`${remote.device_name} stopped answering (last heard ${agoText(Date.now() / 1000 - remote.updated_at)}). It may be off or offline.`, "error");
    return;
  }
  if (job.status === "queued") {
    if (!remote) setScoutStatus("Getting ready...", "busy");
    else if (remote.status === "queued") setScoutStatus(`Waiting for ${remote.device_name} to pick up the run...`, "busy");
    else setScoutStatus(`${where}waiting for its GPU (it finishes its detector training or scout run first)...`, "busy");
    return;
  }
  if (job.status === "running") {
    const retry = job.retry_round ? ` - retrying failed matches (round ${job.retry_round})` : "";
    const redo = job.rescout_round ? " - re-scouting matches that looked wrong" : "";
    const now = job.current ? ` - working on ${matchTitle(job.current)}` : count("elsewhere") ? " - waiting for the other computers" : "";
    setScoutStatus(`${where}Scouting ${who}${job.event_key}: ${job.completed} of ${job.total} matches finished${now}${retry}${redo}${helpers}`, "busy");
    return;
  }
  if (job.status === "watching") {
    const secs = job.next_check_at ? Math.max(0, Math.round(job.next_check_at - Date.now() / 1000)) : 0;
    setScoutStatus(`${where}All caught up (${scouted} matches scouted). Watching for new match videos - next check in ${secs} s.`, "busy");
    return;
  }

  clearInterval(scoutTimer);
  scoutTimer = null;
  setScoutRunning(false);
  bar.classList.remove("live");
  const failed = count("failed");
  const noVideo = count("no_video");
  if (job.status === "failed") {
    setScoutStatus(`${where}Stopped because of a problem: ${job.error}`, "error");
  } else if (job.status === "cancelled") {
    setScoutStatus(`${where}Stopped. ${scouted} match(es) scouted so far are saved.`, "ok");
  } else {
    const extras = [noVideo ? `${noVideo} had no video` : "", failed ? `${failed} could not be scouted` : ""].filter(Boolean);
    const tagged = matches.filter((m) => m.rescout_tag).length;
    const tagNote = tagged ? ` ${tagged} match(es) are tagged for re-scouting.` : "";
    const cloudNote = remote ? " The autos are in the team cloud." : "";
    setScoutStatus(`${where}Finished! ${scouted} match(es) scouted${extras.length ? ` (${extras.join(", ")})` : ""}.${tagNote}${cloudNote}`, failed ? "error" : "ok");
  }
  if (!remote && job.event_key === currentEventKey()) {
    // Final checks may have changed tags and teams of any match.
    resetAutosGallery();
    loadSavedAutos().catch((err) => log(`Saved autos error: ${err.message}`));
  }
}

async function resumeActiveScout() {
  const res = await fetch("/api/scout/jobs");
  const data = await res.json();
  let job = (data.jobs || []).find((j) => ACTIVE_JOB.includes(j.status));
  scoutRemote = false;
  if (!job) {
    // A run this computer sent to another one?
    const dres = await fetch("/api/devices?jobs=true");
    const ddata = dres.ok ? await dres.json() : {};
    const sent = (ddata.remote_jobs || []).find((j) => !j.cancel_requested && ["queued", "claimed", "waiting", "running", "watching"].includes(j.status));
    if (!sent) return;
    job = { job_id: sent.id, event_key: sent.event_key };
    scoutRemote = true;
  }
  scoutJobId = job.job_id;
  if (job.event_key !== currentEventKey()) {
    ensureEventOption(job.event_key);
    document.getElementById("eventKey").value = job.event_key;
    onEventChanged();
  }
  setScoutRunning(true);
  startScoutPolling();
}

// ---------- Event picker (events the team is registered for) ----------
let seasonEvents = [];
let shownEventKey = null;
let pickerLoadSeq = 0;

function eventLabel(e) {
  return `${e.name || e.key}${e.start_date ? ` - ${e.start_date}` : ""}`;
}

function ensureEventOption(key) {
  const select = document.getElementById("eventKey");
  if (!key || [...select.options].some((o) => o.value === key)) return;
  const o = document.createElement("option");
  o.value = key;
  o.textContent = key;
  select.appendChild(o);
}

// Default pick: the event happening now, else the next one, else the most recent.
function defaultEventKey(events) {
  const today = new Date().toISOString().slice(0, 10);
  const live = events.find((e) => e.start_date <= today && today <= (e.end_date || e.start_date));
  const next = events.find((e) => e.start_date > today);
  return (live || next || events[events.length - 1])?.key || "";
}

async function loadPickerEvents() {
  const select = document.getElementById("eventKey");
  const nameEl = document.getElementById("eventName");
  const season = Number(document.getElementById("season").value);
  const teamKey = normalizeTeamKey(document.getElementById("teamKey").value);
  const previous = currentEventKey();
  const seq = ++pickerLoadSeq;
  seasonEvents = [];
  if (!/^frc[0-9]{1,5}$/.test(teamKey)) {
    select.replaceChildren(new Option("Enter your team number first", ""));
    nameEl.textContent = "Only events your team is registered for are listed.";
    onEventChanged();
    return;
  }
  select.replaceChildren(new Option(`Loading team ${teamNumber(teamKey)}'s events...`, ""));
  const res = await fetch(`/api/team/${teamKey}/events/${season}`);
  const data = await res.json();
  if (seq !== pickerLoadSeq) return; // a newer team/season was entered meanwhile
  if (!res.ok) {
    select.replaceChildren(new Option("Could not load events", ""));
    nameEl.textContent =
      res.status === 404
        ? `Team ${teamNumber(teamKey)} was not found on The Blue Alliance.`
        : typeof data?.detail === "string"
          ? data.detail
          : "Could not load your team's events.";
    onEventChanged();
    return;
  }
  seasonEvents = data.events || [];
  if (!seasonEvents.length) {
    select.replaceChildren(new Option(`No ${season} events for team ${teamNumber(teamKey)}`, ""));
  } else {
    select.replaceChildren(...seasonEvents.map((e) => new Option(eventLabel(e), e.key)));
    select.value = seasonEvents.some((e) => e.key === previous) ? previous : defaultEventKey(seasonEvents);
  }
  onEventChanged();
}

function showEventName() {
  const key = currentEventKey();
  const ev = seasonEvents.find((e) => e.key === key);
  const where = ev ? [ev.city, ev.state_prov].filter(Boolean).join(", ") : "";
  if (ev) {
    document.getElementById("eventName").textContent =
      `${ev.name}${where ? ` - ${where}` : ""}${ev.start_date ? ` (${ev.start_date} to ${ev.end_date})` : ""}`;
  } else if (key) {
    document.getElementById("eventName").textContent = key;
  }
}

function onEventChanged() {
  const key = currentEventKey();
  showEventName();
  if (key === shownEventKey) return;
  shownEventKey = key;
  refreshEventCalibrationStatus().catch((err) => log(`Event calibration status error: ${err.message}`));
  resetAutosGallery();
  loadSavedAutos().catch((err) => log(`Saved autos error: ${err.message}`));
}

// ---------- Autos gallery ----------
const autosData = new Map(); // match_key -> compact team autos
const autosTags = new Map(); // match_key -> re-scout tag (or null)
const autosGood = new Map(); // match_key -> scout checked the autos and they are right
const autosCameraHighY = new Map(); // match_key -> camera films from the field's high-y side
const autosSwap = { key: null, team: null, note: "", error: false }; // card in swap mode, first team picked, message on the card
const autosVersions = new Map(); // match_key -> token that changes when its autos or marks change
const AUTOS_VIEW_STORAGE_KEY = "hotscout.autosView";
const autosRequested = new Set();
const autosQueue = [];
const scoutEntryRevs = new Map();
let autosPumping = false;
let autosRenderTimer = null;

function resetAutosGallery() {
  autosData.clear();
  autosTags.clear();
  autosGood.clear();
  autosCameraHighY.clear();
  autosVersions.clear();
  autosRequested.clear();
  autosQueue.length = 0;
  renderAutosGallery();
}

function refreshAutos(key) {
  autosRequested.delete(key);
  queueAutos([key]);
}

function queueAutos(keys) {
  keys.forEach((k) => {
    if (!autosRequested.has(k) && !autosQueue.includes(k)) autosQueue.push(k);
  });
  pumpAutos();
}

async function pumpAutos() {
  if (autosPumping) return;
  autosPumping = true;
  try {
    while (autosQueue.length) {
      const key = autosQueue.shift();
      if (autosRequested.has(key)) continue;
      autosRequested.add(key);
      try {
        const res = await fetch(`/api/match/${encodeURIComponent(key)}/autos`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (key.startsWith(`${currentEventKey()}_`) && (data.teams || []).length) {
          autosData.set(key, data.teams);
          autosTags.set(key, data.rescout || null);
          autosGood.set(key, data.good === true);
          autosCameraHighY.set(key, data.camera_high_y === true);
          scheduleAutosRender();
        }
      } catch {
        autosRequested.delete(key); // picked up again on the next poll
      }
    }
  } finally {
    autosPumping = false;
  }
}

async function loadSavedAutos() {
  const ev = currentEventKey();
  if (!EVENT_KEY_RE.test(ev)) return;
  const res = await fetch(`/api/events/${encodeURIComponent(ev)}/scouted-matches/versions`);
  const data = await res.json();
  let changed = !res.ok;
  if (res.ok && ev === currentEventKey()) {
    const versions = data.versions || {};
    (data.matches || []).forEach((k) => {
      const old = autosVersions.get(k);
      autosVersions.set(k, versions[k]);
      if (old !== versions[k]) changed = true;
      if (old !== undefined && old !== versions[k]) refreshAutos(k); // changed here or on another team computer
    });
    queueAutos(data.matches || []);
  }
  if (changed) refreshTrackingAccuracy().catch((err) => log(`Accuracy error: ${err.message}`));
}

// Matches scouted or changed on the other team computers show up on their own.
setInterval(() => {
  if (document.visibilityState !== "visible" || !EVENT_KEY_RE.test(currentEventKey())) return;
  loadSavedAutos().catch(() => {});
}, 30000);

function scheduleAutosRender() {
  clearTimeout(autosRenderTimer);
  autosRenderTimer = setTimeout(renderAutosGallery, 200);
}

function autosFocusTeam() {
  const raw = document.getElementById("autosTeamFilter").value.trim();
  return raw ? normalizeTeamKey(raw) : "";
}

// Slot colours for tracked robots; teams that were not seen take a free colour.
function autoColors(teams) {
  const out = new Map();
  ["red", "blue"].forEach((al) => {
    const mine = teams.filter((t) => t.alliance === al);
    mine.forEach((t) => {
      if (SLOT_COLORS[t.robot_slot]) out.set(t.team_key, SLOT_COLORS[t.robot_slot]);
    });
    const used = new Set(out.values());
    const free = [1, 2, 3].map((n) => SLOT_COLORS[`${al}${n}`]).filter((c) => !used.has(c));
    mine.forEach((t) => {
      if (!out.has(t.team_key)) out.set(t.team_key, free.shift() || "#999");
    });
  });
  return out;
}

// Points are in the official field frame: blue alliance wall at x=0, red at x=L.
// rotated=true turns the map 180 degrees so it matches a camera on the high-y side.
function drawMiniField(cv, teams, colors, focus, rotated) {
  const c = cv.getContext("2d");
  const W = cv.width;
  const H = cv.height;
  const dims = teams.find((t) => Array.isArray(t.field_dims_m))?.field_dims_m || [16.54, 8.21];
  const L = Number(dims[0]) || 16.54;
  const D = Number(dims[1]) || 8.21;
  const pad = 10;
  const s = Math.min((W - 2 * pad) / L, (H - 2 * pad) / D);
  const ox = (W - L * s) / 2;
  const oy = (H - D * s) / 2;
  const fx = (x) => ox + (rotated ? L - x : x) * s;
  const fy = (y) => oy + (rotated ? y : D - y) * s;
  const blueLeft = !rotated;

  c.fillStyle = "#070708";
  c.fillRect(0, 0, W, H);
  c.fillStyle = "#17171a";
  c.fillRect(ox, oy, L * s, D * s);
  c.fillStyle = "rgba(76, 141, 255, 0.07)";
  c.fillRect(blueLeft ? ox : ox + (L * s) / 2, oy, (L * s) / 2, D * s);
  c.fillStyle = "rgba(255, 59, 59, 0.07)";
  c.fillRect(blueLeft ? ox + (L * s) / 2 : ox, oy, (L * s) / 2, D * s);
  c.strokeStyle = "rgba(255,255,255,0.05)";
  c.lineWidth = 1;
  for (let x = 1; x < L; x += 1) {
    c.beginPath();
    c.moveTo(fx(x), fy(0));
    c.lineTo(fx(x), fy(D));
    c.stroke();
  }
  c.strokeStyle = "rgba(255,255,255,0.35)";
  c.setLineDash([6, 6]);
  c.beginPath();
  c.moveTo(fx(L / 2), fy(0));
  c.lineTo(fx(L / 2), fy(D));
  c.stroke();
  c.setLineDash([]);
  c.strokeStyle = "#5a5a62";
  c.strokeRect(ox, oy, L * s, D * s);
  c.fillStyle = "#4c8dff";
  c.fillRect(blueLeft ? ox - 4 : ox + L * s, oy, 4, D * s);
  c.fillStyle = "#ff3b3b";
  c.fillRect(blueLeft ? ox + L * s : ox - 4, oy, 4, D * s);

  const order = [...teams].sort((a, b) => (a.team_key === focus) - (b.team_key === focus));
  order.forEach((t) => {
    const pts = t.points || [];
    if (!pts.length) return;
    const color = colors.get(t.team_key);
    const dim = focus && t.team_key !== focus;
    c.globalAlpha = dim ? 0.18 : 1;
    c.strokeStyle = color;
    c.lineWidth = focus && !dim ? 4 : 2.5;
    c.lineCap = "round";
    for (let k = 1; k < pts.length; k += 1) {
      c.setLineDash(pts[k][3] ? [5, 5] : []);
      c.beginPath();
      c.moveTo(fx(pts[k - 1][1]), fy(pts[k - 1][2]));
      c.lineTo(fx(pts[k][1]), fy(pts[k][2]));
      c.stroke();
    }
    c.setLineDash([]);
    const a = pts[0];
    const b = pts[pts.length - 1];
    c.fillStyle = color;
    c.strokeStyle = "#000";
    c.lineWidth = 1;
    c.beginPath();
    c.arc(fx(a[1]), fy(a[2]), 6, 0, Math.PI * 2);
    c.fill();
    c.stroke();
    c.fillRect(fx(b[1]) - 5, fy(b[2]) - 5, 10, 10);
    c.strokeRect(fx(b[1]) - 5, fy(b[2]) - 5, 10, 10);
    c.font = "bold 15px Segoe UI, sans-serif";
    c.lineWidth = 3;
    c.strokeText(String(t.team_number ?? teamNumber(t.team_key)), fx(a[1]) + 8, fy(a[2]) - 7);
    c.fillText(String(t.team_number ?? teamNumber(t.team_key)), fx(a[1]) + 8, fy(a[2]) - 7);
    c.globalAlpha = 1;
  });
}

function renderAutosGallery() {
  const box = document.getElementById("autosGallery");
  const filterEl = document.getElementById("autosTeamFilter");
  const likeVideo = document.getElementById("autosView").value === "camera";
  const focus = autosFocusTeam();
  const keys = [...autosData.keys()].sort(matchOrder);
  const shown = keys.filter((k) => !focus || autosData.get(k).some((t) => t.team_key === focus));
  const tagged = keys.filter((k) => autosTags.get(k)).length;
  const good = keys.filter((k) => autosGood.get(k)).length;
  const tagNote = `${good ? ` ${good} marked good.` : ""}${tagged ? ` ${tagged} tagged for re-scouting.` : ""}`;
  document.getElementById("autosCount").textContent = keys.length
    ? focus
      ? `Team ${teamNumber(focus)}: ${shown.length} auto(s) out of ${keys.length} scouted matches.${tagNote}`
      : `${keys.length} scouted match(es).${tagNote}`
    : "";
  box.replaceChildren();
  if (!shown.length) {
    const msg = keys.length ? `No scouted matches with team ${teamNumber(focus)} yet.` : "Autos appear here as matches are scouted.";
    box.appendChild(el("p", msg, "empty"));
    return;
  }
  shown.forEach((key) => {
    const teams = autosData.get(key);
    const tag = autosTags.get(key);
    const isGood = autosGood.get(key) === true;
    const colors = autoColors(teams);
    const card = el("div", null, `auto-card${tag ? " needs-rescout" : ""}${isGood ? " marked-good" : ""}`);
    const head = el("h4", matchTitle(key));
    head.appendChild(el("small", `${teams.filter((t) => t.detected).length}/${teams.length} robots seen`));
    const goodBtn = el("button", isGood ? "Good \u2713" : "Good", `btn-secondary good-btn${isGood ? " on" : ""}`);
    goodBtn.type = "button";
    goodBtn.title = isGood
      ? "Marked as right. Click to take the mark back."
      : "These autos are right (teams and paths). Good matches teach the robot detector for the rest of the season.";
    goodBtn.addEventListener("click", () => toggleGood(key, goodBtn).catch((err) => log(`Mark good error: ${err.message}`)));
    head.appendChild(goodBtn);
    const tagBtn = el("button", tag ? "Tagged - undo" : "Re-scout", `btn-secondary rescout-btn${tag ? " on" : ""}`);
    tagBtn.type = "button";
    tagBtn.title = tag
      ? "Remove the re-scout tag"
      : "Tag this match to be tracked again (use \"Re-scout tagged matches\" in step 3)";
    tagBtn.addEventListener("click", () => toggleRescout(key, tagBtn).catch((err) => log(`Re-scout tag error: ${err.message}`)));
    head.appendChild(tagBtn);
    const checked = gtChecked.has(key);
    const checkBtn = el("button", checked ? "Checked \u2713" : "Check", `btn-secondary check-btn${checked ? " on" : ""}`);
    checkBtn.type = "button";
    checkBtn.title = "Place the robots by hand on the video; this measures how accurate tracking is";
    checkBtn.addEventListener("click", () => gtOpen(key).catch((err) => gtStatus(err.message, "error")));
    head.appendChild(checkBtn);
    const swapping = autosSwap.key === key;
    const swapBtn = el("button", swapping ? "Cancel swap" : "Swap", `btn-secondary swap-btn${swapping ? " on" : ""}`);
    swapBtn.type = "button";
    swapBtn.title = "Teams mixed up? Click this, then the two teams (same alliance) to swap their paths - no re-scout needed";
    swapBtn.addEventListener("click", () => {
      Object.assign(
        autosSwap,
        swapping ? { key: null, team: null, note: "", error: false } : { key, team: null, note: "Click the first team to swap.", error: false },
      );
      renderAutosGallery();
    });
    head.appendChild(swapBtn);
    const cv = document.createElement("canvas");
    cv.width = 660;
    cv.height = 340;
    const chips = el("div", null, "team-chips");
    const firstPick = swapping ? teams.find((x) => x.team_key === autosSwap.team) : null;
    teams.forEach((t) => {
      const unsure = t.detected && (t.method === "best_guess" || t.needs_review);
      const label = `${t.team_number ?? teamNumber(t.team_key)}${!t.detected ? " - not seen" : unsure ? " ?" : ""}`;
      const picked = swapping && autosSwap.team === t.team_key;
      const chip = el("button", label, `team-chip${t.detected ? "" : " missing"}${t.team_key === focus ? " focus" : ""}${picked ? " picked" : ""}`);
      chip.type = "button";
      chip.style.borderColor = colors.get(t.team_key);
      chip.title = !t.detected
        ? "This robot was not found in the video"
        : t.method === "hand_check"
          ? "Path and team from your hand check (Check)"
          : t.method === "team_history"
          ? `Team matched from where it starts and drives in its other autos${unsure ? " - please double-check" : ""}`
          : unsure
            ? "Team guessed from position - please double-check"
            : t.method === "bumper_ocr"
              ? "Team read from the bumper"
              : t.method === "appearance"
                ? "Team recognised by how the robot looks in matches marked good"
                : "Team assigned";
      if (firstPick && firstPick.team_key !== t.team_key) {
        const why =
          firstPick.alliance !== t.alliance
            ? "Other alliance - only teams on the same alliance can be swapped"
            : !firstPick.detected && !t.detected
              ? "Neither robot was seen - there is no path to swap"
              : "";
        if (why) {
          chip.disabled = true;
          chip.title = why;
        } else {
          chip.title = `Swap with ${teamNumber(firstPick.team_key)}`;
        }
      }
      chip.addEventListener("click", () => {
        if (swapping) {
          pickSwapTeam(key, t, teams).catch((err) => {
            Object.assign(autosSwap, { note: `Swap failed: ${err.message}`, error: true });
            setStatus(`Swap failed: ${err.message}`, "error");
            renderAutosGallery();
          });
          return;
        }
        filterEl.value = t.team_key === focus ? "" : teamNumber(t.team_key);
        renderAutosGallery();
      });
      chips.appendChild(chip);
    });
    card.append(head);
    if (tag) card.appendChild(el("p", `${tag.source === "auto" ? "Looks wrong" : "Tagged"}: ${tag.reason}`, "rescout-note"));
    card.append(cv, chips);
    if (swapping && autosSwap.note) card.appendChild(el("p", autosSwap.note, `swap-note${autosSwap.error ? " error" : ""}`));
    box.appendChild(card);
    drawMiniField(cv, teams, colors, focus, likeVideo && autosCameraHighY.get(key) === true);
  });
}

async function pickSwapTeam(key, t, teams) {
  const first = teams.find((x) => x.team_key === autosSwap.team);
  if (!first || first.team_key === t.team_key) {
    Object.assign(autosSwap, {
      team: first ? null : t.team_key,
      note: first
        ? "Click the first team to swap."
        : `Now click the ${t.alliance || "same-alliance"} team to swap ${teamNumber(t.team_key)} with.`,
      error: false,
    });
    renderAutosGallery();
    return;
  }
  Object.assign(autosSwap, { note: `Swapping ${teamNumber(first.team_key)} and ${teamNumber(t.team_key)}...`, error: false });
  renderAutosGallery();
  setStatus(`Swapping ${teamNumber(first.team_key)} and ${teamNumber(t.team_key)}...`, "busy");
  const res = await fetch(`/api/match/${encodeURIComponent(key)}/swap-teams`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ team_a: first.team_key, team_b: t.team_key }),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  Object.assign(autosSwap, { key: null, team: null, note: "", error: false });
  autosData.set(key, data.teams);
  autosTags.set(key, data.rescout || null);
  autosGood.set(key, data.good === true);
  renderAutosGallery();
  const note = data.firebase_error ? ` (saved here; Firebase upload failed: ${data.firebase_error})` : "";
  setStatus(`${matchTitle(key)}: swapped ${teamNumber(first.team_key)} and ${teamNumber(t.team_key)}${note}`, note ? "error" : "ok");
  refreshTrackingAccuracy().catch(() => {});
}

async function toggleRescout(key, btn) {
  const tagged = Boolean(autosTags.get(key));
  btn.disabled = true;
  try {
    const res = await fetch(`/api/match/${encodeURIComponent(key)}/rescout`, {
      method: tagged ? "DELETE" : "POST",
      headers: { "Content-Type": "application/json" },
      body: tagged ? undefined : JSON.stringify({ reason: null }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
    autosTags.set(key, data.rescout || null);
    if (data.rescout) autosGood.set(key, false);
  } finally {
    btn.disabled = false;
  }
  renderAutosGallery();
}

async function toggleGood(key, btn) {
  const good = !autosGood.get(key);
  btn.disabled = true;
  try {
    const res = await fetch(`/api/match/${encodeURIComponent(key)}/good`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ good }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
    autosGood.set(key, data.good === true);
    autosTags.set(key, data.rescout || null);
  } finally {
    btn.disabled = false;
  }
  renderAutosGallery();
  refreshDetector().catch(() => {});
}

// ---------- Hand-checked robot positions (measures tracking accuracy) ----------
const gt = { data: null, key: null, k: 0, sel: null, img: null, drag: null, saveTimer: null, dirty: false, imgToken: 0 };
const gtChecked = new Set(); // match keys whose every frame was checked
const gtDialog = document.getElementById("gtDialog");
const gtCanvas = document.getElementById("gtCanvas");
const GT_STATE_TEXT = { pos: "placed", hidden: "hidden", absent: "not on field" };

function gtSeason() {
  const ev = currentEventKey();
  return /^\d{4}/.test(ev) ? Number(ev.slice(0, 4)) : detectorSeason();
}

async function refreshTrackingAccuracy() {
  const res = await fetch(`/api/season/${gtSeason()}/tracking-accuracy`);
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  gtChecked.clear();
  (data.matches || []).forEach((m) => gtChecked.add(m.match_key));
  const t = data.total || {};
  const pct = (v) => (v == null ? "-" : `${(100 * v).toFixed(1)}%`);
  document.getElementById("trackingAccuracy").textContent = t.labelled
    ? `Tracking accuracy on ${data.matches.length} hand-checked match(es): robot within ${data.match_radius_m} m of where it really is ${pct(t.tracking)} of the time, with the right team number ${pct(t.end_to_end)}. ${t.robot_autos_passing}/${t.robot_autos} robot autos are right at least ${Math.round(100 * data.pass_share)}% of the time.`
    : "Tracking accuracy: no hand-checked matches yet. Press Check on a match to place its robots by hand.";
  scheduleAutosRender();
}

function gtColors() {
  const out = {};
  const n = { red: 0, blue: 0 };
  gt.data.teams.forEach((t) => {
    n[t.alliance] = (n[t.alliance] || 0) + 1;
    out[t.team_key] = SLOT_COLORS[`${t.alliance}${n[t.alliance]}`] || "#999";
  });
  return out;
}

function gtLabel(tk, k) {
  return gt.data.labels[tk]?.[k] || null;
}

// Tracker's guess, unless the previous checked frame puts the robot clearly elsewhere.
function gtSuggestion(tk, k) {
  const prev = k > 0 ? gtLabel(tk, k - 1) : null;
  const px = gt.data.suggest[tk]?.[k] || null;
  if (prev?.s === "pos" && (!px || Math.hypot(px[0] - prev.px[0], px[1] - prev.px[1]) > 0.06 * gtCanvas.width)) {
    return { s: "pos", px: prev.px };
  }
  if (px) return { s: "pos", px };
  if (prev?.s === "absent") return { s: "absent" };
  return null;
}

function gtSet(tk, value) {
  gt.data.labels[tk] = gt.data.labels[tk] || new Array(gt.data.times.length).fill(null);
  gt.data.labels[tk][gt.k] = value;
  gt.dirty = true;
  clearTimeout(gt.saveTimer);
  gt.saveTimer = setTimeout(() => gtSave().catch((err) => gtStatus(err.message, "error")), 1500);
  gtRender();
}

function gtStatus(text, cls = "") {
  const s = document.getElementById("gtStatus");
  s.textContent = text;
  s.className = `status ${cls}`;
}

function gtFrameDone(k) {
  return gt.data.teams.every((t) => gtLabel(t.team_key, k));
}

function gtRender() {
  if (!gt.data) return;
  const c = gtCanvas.getContext("2d");
  const colors = gtColors();
  c.clearRect(0, 0, gtCanvas.width, gtCanvas.height);
  if (gt.img) c.drawImage(gt.img, 0, 0, gtCanvas.width, gtCanvas.height);
  const r = Math.max(10, gtCanvas.width / 110);
  c.lineWidth = 3;
  (gt.data.others || []).forEach((pts) => {
    const p = pts[gt.k];
    if (!p) return;
    c.strokeStyle = "rgba(200,200,200,0.8)";
    c.beginPath();
    c.arc(p[0], p[1], r * 0.6, 0, Math.PI * 2);
    c.stroke();
  });
  c.font = `bold ${Math.round(r * 1.5)}px Segoe UI, sans-serif`;
  gt.data.teams.forEach((t) => {
    const lab = gtLabel(t.team_key, gt.k);
    const mark = lab || gtSuggestion(t.team_key, gt.k);
    if (mark?.s !== "pos") return;
    const [x, y] = mark.px;
    const sel = gt.sel === t.team_key;
    c.strokeStyle = colors[t.team_key];
    c.fillStyle = colors[t.team_key];
    c.setLineDash(lab ? [] : [6, 5]);
    c.lineWidth = sel ? 5 : 3;
    c.beginPath();
    c.arc(x, y, sel ? r * 1.4 : r, 0, Math.PI * 2);
    c.stroke();
    if (lab) {
      c.beginPath();
      c.arc(x, y, 3, 0, Math.PI * 2);
      c.fill();
    }
    c.setLineDash([]);
    c.lineWidth = 4;
    c.strokeStyle = "#000";
    const text = String(teamNumber(t.team_key));
    c.strokeText(text, x + r * 1.3, y - r * 0.6);
    c.fillText(text, x + r * 1.3, y - r * 0.6);
  });
  const box = document.getElementById("gtTeams");
  box.replaceChildren();
  gt.data.teams.forEach((t, i) => {
    const lab = gtLabel(t.team_key, gt.k);
    const sug = lab ? null : gtSuggestion(t.team_key, gt.k);
    const btn = el("button", null, `gt-team${gt.sel === t.team_key ? " sel" : ""}`);
    btn.type = "button";
    btn.style.borderLeftColor = colors[t.team_key];
    btn.append(
      el("span", `${i + 1}. ${teamNumber(t.team_key)}`),
      el("small", lab ? GT_STATE_TEXT[lab.s] : sug ? `guess: ${GT_STATE_TEXT[sug.s]}` : "not placed"),
    );
    btn.addEventListener("click", () => {
      gt.sel = t.team_key;
      gtRender();
    });
    box.appendChild(btn);
  });
  const n = gt.data.times.length;
  const done = gt.data.times.filter((_, k) => gtFrameDone(k)).length;
  const tRel = gt.data.times[gt.k] - gt.data.start_sec;
  document.getElementById("gtFrameLabel").textContent = `Frame ${gt.k + 1}/${n} (${tRel.toFixed(1)} s into auto) - ${done}/${n} frames checked${gtFrameDone(gt.k) ? " - this frame done" : ""}`;
}

function gtShowFrame(k) {
  gt.k = Math.max(0, Math.min(gt.data.times.length - 1, k));
  document.getElementById("gtSlider").value = String(gt.k);
  const token = ++gt.imgToken;
  const url = (i) => `/api/match/${encodeURIComponent(gt.key)}/ground-truth/frame?t_sec=${gt.data.times[i]}`;
  const img = new Image();
  img.onload = () => {
    if (token !== gt.imgToken) return;
    gt.img = img;
    gtRender();
  };
  img.onerror = () => gtStatus("Could not load this video frame", "error");
  img.src = url(gt.k);
  if (gt.k + 1 < gt.data.times.length) new Image().src = url(gt.k + 1); // preload
  gtRender();
}

function gtConfirm() {
  const missing = [];
  gt.data.teams.forEach((t) => {
    if (gtLabel(t.team_key, gt.k)) return;
    const sug = gtSuggestion(t.team_key, gt.k);
    if (sug) gtSet(t.team_key, sug);
    else missing.push(teamNumber(t.team_key));
  });
  if (missing.length) {
    gtStatus(`Place ${missing.join(", ")} (or mark hidden / not on field) first.`, "error");
    return;
  }
  gtStatus("");
  if (gt.k + 1 < gt.data.times.length) gtShowFrame(gt.k + 1);
  else gtStatus("Last frame done. Tick \"Every frame checked\" when you are happy with all of them.", "ok");
}

function gtMark(state) {
  if (!gt.sel) return gtStatus("Pick a team first (click it or press 1-6).", "error");
  gtSet(gt.sel, state ? { s: state } : null);
}

function gtVideoPoint(e) {
  const rect = gtCanvas.getBoundingClientRect();
  return [((e.clientX - rect.left) * gtCanvas.width) / rect.width, ((e.clientY - rect.top) * gtCanvas.height) / rect.height];
}

async function gtSave() {
  if (!gt.data || !gt.dirty) return;
  clearTimeout(gt.saveTimer);
  gt.dirty = false;
  const res = await fetch(`/api/match/${encodeURIComponent(gt.key)}/ground-truth`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      start_sec: gt.data.start_sec,
      end_sec: gt.data.end_sec,
      teams: gt.data.teams,
      labels: gt.data.labels,
      complete: document.getElementById("gtComplete").checked,
    }),
  });
  const data = await res.json();
  if (!res.ok) {
    gt.dirty = true;
    throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  }
  const pct = (v) => (v == null ? "-" : `${(100 * v).toFixed(1)}%`);
  const autos = data.autos_updated
    ? ` Your clicks are now this match's autos${data.firebase_error ? ` (Firebase upload failed: ${data.firebase_error})` : ""}.`
    : "";
  document.getElementById("gtScore").textContent = data.labelled
    ? `Saved. Tracking matched your checks ${pct(data.tracking)} of the time (${pct(data.end_to_end)} with the right team) over ${data.labelled} placed robot-frames.${autos} ${gtTrainingText(data.training)}`
    : `Saved.${autos} ${gtTrainingText(data.training)}`;
  if (data.autos_updated) refreshAutos(gt.key);
}

// Whether this check's corrections are becoming robot detector training pictures.
function gtTrainingText(tr) {
  if (!tr || tr.error) return "";
  if (!tr.collecting) return "Training pictures are off (COLLECT_TRAINING_FRAMES).";
  if (!tr.corrected) return "No corrections, so no training pictures.";
  const waiting = tr.ready - tr.pictures;
  let text = `Detector training: ${tr.corrected} corrected frame(s), ${tr.pictures} saved as training pictures`;
  if (tr.pending) text += ` (updating ${tr.delay_sec} s after your last change)`;
  else if (waiting > 0) text += ` (${waiting} could not be used, e.g. a hidden robot overlaps one you placed)`;
  if (tr.corrected > tr.ready) text += `; ${tr.corrected - tr.ready} need every team placed first`;
  return `${text}.`;
}

async function gtOpen(key) {
  gt.key = key;
  gt.data = null;
  gt.img = null;
  gt.sel = null;
  gt.dirty = false;
  document.getElementById("gtTitle").textContent = `Check robot positions - ${matchTitle(key)}`;
  document.getElementById("gtScore").textContent = "";
  document.getElementById("gtFrameLabel").textContent = "";
  document.getElementById("gtTeams").replaceChildren();
  gtCanvas.getContext("2d").clearRect(0, 0, gtCanvas.width, gtCanvas.height);
  gtDialog.showModal();
  gtStatus("Loading (the first time this downloads the match video)...", "busy");
  const res = await fetch(`/api/match/${encodeURIComponent(key)}/ground-truth`);
  const data = await res.json();
  if (!res.ok) throw new Error(typeof data?.detail === "string" ? data.detail : `HTTP ${res.status}`);
  if (gt.key !== key) return;
  if (data.video_size?.[0]) [gtCanvas.width, gtCanvas.height] = data.video_size;
  gt.data = data;
  gt.sel = data.teams[0]?.team_key || null;
  document.getElementById("gtScore").textContent = gtTrainingText(data.training);
  document.getElementById("gtComplete").checked = data.complete;
  document.getElementById("gtSlider").max = String(data.times.length - 1);
  const first = data.times.findIndex((_, k) => !gtFrameDone(k));
  gtStatus("");
  gtShowFrame(first < 0 ? 0 : first);
}

async function gtClose() {
  try {
    await gtSave();
  } catch (err) {
    gtStatus(`Not saved: ${err.message}`, "error");
    return;
  }
  gtDialog.close();
}

gtCanvas.addEventListener("mousedown", (e) => {
  if (!gt.data) return;
  const [x, y] = gtVideoPoint(e);
  const reach = (18 * gtCanvas.width) / gtCanvas.getBoundingClientRect().width;
  let best = null;
  gt.data.teams.forEach((t) => {
    const mark = gtLabel(t.team_key, gt.k) || gtSuggestion(t.team_key, gt.k);
    if (mark?.s !== "pos") return;
    const d = Math.hypot(mark.px[0] - x, mark.px[1] - y);
    if (d <= reach && (!best || d < best.d)) best = { tk: t.team_key, d };
  });
  if (best) {
    gt.sel = best.tk;
    gt.drag = best.tk;
    gtRender();
    return;
  }
  if (!gt.sel) return gtStatus("Pick a team first (click it or press 1-6).", "error");
  gt.drag = gt.sel;
  gtSet(gt.sel, { s: "pos", px: [x, y] });
});
gtCanvas.addEventListener("mousemove", (e) => {
  if (!gt.drag || e.buttons !== 1) return;
  const [x, y] = gtVideoPoint(e);
  gtSet(gt.drag, { s: "pos", px: [x, y] });
});
window.addEventListener("mouseup", () => {
  gt.drag = null;
});
gtDialog.addEventListener("keydown", (e) => {
  if (!gt.data || e.target.tagName === "INPUT") return;
  const n = Number(e.key);
  if (n >= 1 && n <= gt.data.teams.length) {
    gt.sel = gt.data.teams[n - 1].team_key;
    gtRender();
  } else if (e.key === "h" || e.key === "H") gtMark("hidden");
  else if (e.key === "n" || e.key === "N") gtMark("absent");
  else if (e.key === "Delete" || e.key === "Backspace") gtMark(null);
  else if (e.key === "Enter") gtConfirm();
  else if (e.key === "ArrowRight") gtShowFrame(gt.k + 1);
  else if (e.key === "ArrowLeft") gtShowFrame(gt.k - 1);
  else return;
  e.preventDefault();
});
gtDialog.addEventListener("cancel", (e) => {
  e.preventDefault();
  gtClose().then(() => refreshTrackingAccuracy()).catch((err) => log(`Accuracy error: ${err.message}`));
});
document.getElementById("gtClose").addEventListener("click", () => {
  gtClose().then(() => refreshTrackingAccuracy()).catch((err) => log(`Accuracy error: ${err.message}`));
});
document.getElementById("gtHidden").addEventListener("click", () => gtMark("hidden"));
document.getElementById("gtAbsent").addEventListener("click", () => gtMark("absent"));
document.getElementById("gtClear").addEventListener("click", () => gtMark(null));
document.getElementById("gtConfirm").addEventListener("click", gtConfirm);
document.getElementById("gtPrev").addEventListener("click", () => gt.data && gtShowFrame(gt.k - 1));
document.getElementById("gtNext").addEventListener("click", () => gt.data && gtShowFrame(gt.k + 1));
document.getElementById("gtSlider").addEventListener("input", (e) => gt.data && gtShowFrame(Number(e.target.value)));
document.getElementById("gtComplete").addEventListener("change", (e) => {
  if (!gt.data) return;
  const left = gt.data.times.filter((_, k) => !gtFrameDone(k)).length;
  if (e.target.checked && left) {
    e.target.checked = false;
    gtStatus(`${left} frame(s) still have robots not placed.`, "error");
    return;
  }
  gt.dirty = true;
  gtSave().catch((err) => gtStatus(err.message, "error"));
});

async function fixTeamMixups() {
  const ev = currentEventKey();
  const count = document.getElementById("autosCount");
  if (!EVENT_KEY_RE.test(ev)) {
    count.textContent = "Pick an event first (step 1).";
    return;
  }
  const btn = document.getElementById("autosTeamHistory");
  btn.disabled = true;
  count.textContent = "Comparing every team's autos...";
  try {
    const res = await fetch(`/api/events/${encodeURIComponent(ev)}/team-history`, { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      count.textContent = typeof data?.detail === "string" ? data.detail : `Could not fix team mix-ups (HTTP ${res.status}).`;
      return;
    }
    const n = (data.changes || []).length;
    const matches = new Set((data.changes || []).map((c) => c.match_key)).size;
    log(`Team history: ${JSON.stringify(data.changes || [])}`);
    resetAutosGallery();
    await loadSavedAutos();
    count.textContent = n
      ? `Fixed ${n} robot(s) in ${matches} match(es) using ${data.teams_modelled} teams' autos.`
      : `No mix-ups found (${data.teams_modelled} teams' autos compared).`;
  } finally {
    btn.disabled = false;
  }
}

async function fetchSampleVideo() {
  const ev = currentEventKey();
  if (!EVENT_KEY_RE.test(ev)) {
    setStatus("Pick the event at the top first.", "error");
    return;
  }
  const btn = document.getElementById("fetchSampleVideo");
  btn.disabled = true;
  setStatus("Downloading a match video from this event (this can take a minute)...", "busy");
  try {
    const res = await fetch(`/api/events/${encodeURIComponent(ev)}/sample-video`, { method: "POST" });
    const data = await res.json();
    if (!res.ok) {
      setStatus(`Could not get a video: ${typeof data?.detail === "string" ? data.detail : res.status}`, "error");
      return;
    }
    uploadedVideoPath = data.video_path;
    document.getElementById("matchKey").value = data.match_key;
    document.getElementById("calibFrameSec").value = String(data.start_hint_sec || 0);
    if (await loadCalibrationFrame()) {
      setStatus(`Got ${matchTitle(data.match_key)}. Click the visible field corners (optional if tags are visible), then Calibrate.`, "ok");
    }
  } finally {
    btn.disabled = false;
  }
}

async function loadMatchTeams(showErrors = true) {
  const key = (lastResult?.match_key || document.getElementById("matchKey").value || "").trim();
  if (!key) {
    if (showErrors) setStatus("Enter a match key to load teams from TBA", "error");
    return;
  }
  const res = await fetch(`/api/match/${encodeURIComponent(key)}/teams`);
  const data = await res.json();
  if (!res.ok) {
    matchTeams = null;
    if (showErrors) setStatus(`TBA teams: ${typeof data?.detail === "string" ? data.detail : res.status}`, "error");
  } else {
    matchTeams = data;
  }
  renderRobotsPanel();
}

// Top-down field (x along the field length, y up), metres.
function drawFieldView() {
  const W = fieldCanvas.width;
  const H = fieldCanvas.height;
  const dims = lastResult?.field_dims;
  const L = Array.isArray(dims) && dims.length >= 2 ? Number(dims[0]) : 16.54;
  const D = Array.isArray(dims) && dims.length >= 2 ? Number(dims[1]) : 8.21;
  const m = 28;
  const s = Math.min((W - 2 * m) / L, (H - 2 * m) / D);
  const ox = (W - L * s) / 2;
  const oy = (H - D * s) / 2;
  // Orient like the camera sees the field: far side at the top, image right = screen right.
  const view = lastResult?.field_occlusion?.view;
  const flipX = !!view?.flip_x;
  const farLowY = view ? !!view.far_is_low_y : false;
  const fx = (x) => ox + (flipX ? L - x : x) * s;
  const fy = (y) => oy + (farLowY ? y : D - y) * s;
  const top = oy;
  const bottom = oy + D * s;
  const rectF = (x0, x1) => {
    const a = fx(x0);
    const b = fx(x1);
    c.fillRect(Math.min(a, b), top, Math.abs(b - a), D * s);
  };
  const t = Number(fieldTimeEl.value) || 0;
  document.getElementById("fieldTimeLabel").textContent = `${t.toFixed(1)} s`;

  const c = fctx;
  c.save();
  c.fillStyle = "#151a24";
  c.fillRect(0, 0, W, H);
  c.fillStyle = "#262d3b";
  rectF(0, L);

  // Tint each half by the alliance whose robots start there.
  const startX = (side) => {
    const xs = ROBOT_IDS.filter((r) => r.startsWith(side))
      .map((r) => pathPts(robotById(r))[0]?.x)
      .filter((x) => x != null);
    return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null;
  };
  const redX = startX("red");
  const blueX = startX("blue");
  const redLow = redX != null ? redX < L / 2 : blueX != null ? blueX > L / 2 : true;
  c.fillStyle = "rgba(255, 70, 70, 0.08)";
  rectF(redLow ? 0 : L / 2, redLow ? L / 2 : L);
  c.fillStyle = "rgba(60, 130, 255, 0.08)";
  rectF(redLow ? L / 2 : 0, redLow ? L : L / 2);
  const redLeft = fx(redLow ? L / 4 : (3 * L) / 4) < fx(L / 2);

  c.strokeStyle = "rgba(255,255,255,0.07)";
  c.lineWidth = 1;
  for (let x = 1; x < L; x += 1) {
    c.beginPath();
    c.moveTo(fx(x), fy(0));
    c.lineTo(fx(x), fy(D));
    c.stroke();
  }
  for (let y = 1; y < D; y += 1) {
    c.beginPath();
    c.moveTo(fx(0), fy(y));
    c.lineTo(fx(L), fy(y));
    c.stroke();
  }
  c.strokeStyle = "rgba(255,255,255,0.5)";
  c.setLineDash([6, 6]);
  c.beginPath();
  c.moveTo(fx(L / 2), fy(0));
  c.lineTo(fx(L / 2), fy(D));
  c.stroke();
  c.setLineDash([]);
  c.strokeStyle = "#e8e8e8";
  c.lineWidth = 2;
  c.strokeRect(ox, top, L * s, D * s);

  c.font = "11px sans-serif";
  c.fillStyle = "#9aa3b5";
  for (let x = 0; x <= L; x += 2) c.fillText(`${x}`, fx(x) - 3, bottom + 14);
  for (let y = 0; y <= D; y += 2) c.fillText(`${y}`, ox - 16, fy(y) + 4);
  c.fillText("x (m)", ox + L * s - 28, bottom + 24);
  c.fillText(view ? "y (m) - camera side at bottom" : "y (m)", ox - 24, top - 10);
  c.font = "bold 13px sans-serif";
  c.fillStyle = "rgba(255,110,110,0.9)";
  c.fillText("RED", redLeft ? ox + 6 : ox + L * s - 36, top + 16);
  c.fillStyle = "rgba(110,160,255,0.9)";
  c.fillText("BLUE", redLeft ? ox + L * s - 40 : ox + 6, top + 16);

  // Floor the camera cannot see (behind field elements), then the elements themselves.
  const occ = lastResult?.field_occlusion;
  const polyPath = (poly) => {
    c.beginPath();
    poly.forEach(([x, y], i) => (i ? c.lineTo(fx(x), fy(y)) : c.moveTo(fx(x), fy(y))));
    c.closePath();
  };
  (occ?.hidden || []).forEach((poly) => {
    c.save();
    polyPath(poly);
    c.fillStyle = "rgba(0,0,0,0.35)";
    c.fill();
    c.clip();
    c.strokeStyle = "rgba(255,255,255,0.12)";
    c.lineWidth = 1;
    for (let k = -H; k < W; k += 8) {
      c.beginPath();
      c.moveTo(k, H);
      c.lineTo(k + H, 0);
      c.stroke();
    }
    c.restore();
  });
  (occ?.solids || []).forEach((poly) => {
    polyPath(poly);
    c.fillStyle = "#4a5263";
    c.fill();
    c.strokeStyle = "#9aa3b5";
    c.lineWidth = 1;
    c.stroke();
  });
  if (occ?.hidden?.length) {
    c.font = "11px sans-serif";
    c.fillStyle = "#9aa3b5";
    c.fillText("hatched = hidden from camera", fx(L / 2) - 80, bottom + 24);
  }

  const tracklets = lastResult?.tracklets || [];
  const isAll = selectedRobot === "all";

  // Tracklets not on any robot: grey.
  c.font = "11px sans-serif";
  tracklets
    .filter((tl) => !ownerOf(tl.track_id))
    .forEach((tl) => {
      const pts = trkPts(tl);
      if (!pts.length) return;
      c.strokeStyle = "rgba(190,190,190,0.45)";
      c.lineWidth = 1.5;
      c.beginPath();
      pts.forEach((p, i) => (i ? c.lineTo(fx(p.x), fy(p.y)) : c.moveTo(fx(p.x), fy(p.y))));
      c.stroke();
      c.fillStyle = "rgba(210,210,210,0.8)";
      c.fillText(`T${tl.track_id}`, fx(pts[0].x) + 4, fy(pts[0].y) - 4);
    });

  const drawRobot = (rid, alpha, width) => {
    const pts = pathPts(robotById(rid));
    if (!pts.length) return;
    const color = SLOT_COLORS[rid];
    c.strokeStyle = color;
    c.lineWidth = width;
    c.lineCap = "round";
    for (let i = 1; i < pts.length; i += 1) {
      c.globalAlpha = alpha * (pts[i].inferred ? 0.65 : 1);
      c.setLineDash(pts[i].inferred ? [5, 6] : []);
      c.beginPath();
      c.moveTo(fx(pts[i - 1].x), fy(pts[i - 1].y));
      c.lineTo(fx(pts[i].x), fy(pts[i].y));
      c.stroke();
    }
    c.setLineDash([]);
    c.globalAlpha = alpha;
    (robotById(rid).path?.nodes || []).forEach((n) => {
      if (n.kind !== "hide" && n.kind !== "reappear") return;
      c.beginPath();
      c.arc(fx(n.x_m), fy(n.y_m), 4, 0, Math.PI * 2);
      c.fillStyle = color;
      if (n.kind === "reappear") c.fill();
      c.strokeStyle = color;
      c.lineWidth = 2;
      c.stroke();
    });
    const a = pts[0];
    const b = pts[pts.length - 1];
    c.fillStyle = color;
    c.strokeStyle = "#000";
    c.lineWidth = 1;
    c.beginPath();
    c.arc(fx(a.x), fy(a.y), 6, 0, Math.PI * 2);
    c.fill();
    c.stroke();
    c.fillRect(fx(b.x) - 5, fy(b.y) - 5, 10, 10);
    c.strokeRect(fx(b.x) - 5, fy(b.y) - 5, 10, 10);
    c.font = "bold 13px sans-serif";
    c.fillText(robotLabel(rid), fx(a.x) + 8, fy(a.y) - 8);
    c.globalAlpha = 1;
  };

  ROBOT_IDS.filter((rid) => !isAll && rid !== selectedRobot).forEach((rid) => drawRobot(rid, 0.22, 1.5));
  (isAll ? ROBOT_IDS : [selectedRobot]).forEach((rid) => drawRobot(rid, 1, isAll ? 2.5 : 3.5));

  // Selected robot: mark where each of its tracklets starts.
  if (!isAll) {
    c.font = "bold 11px sans-serif";
    c.fillStyle = "#ffffff";
    tracklets
      .filter((tl) => robotEdits[selectedRobot]?.track_ids.includes(tl.track_id))
      .forEach((tl) => {
        const p = trkPts(tl)[0];
        if (p) c.fillText(`T${tl.track_id}`, fx(p.x) + 6, fy(p.y) + 14);
      });
  }

  // Positions at the slider time.
  tracklets
    .filter((tl) => !ownerOf(tl.track_id))
    .forEach((tl) => {
      const p = pointAt(trkPts(tl), t, 0.5);
      if (!p) return;
      c.fillStyle = "#cfcfcf";
      c.fillRect(fx(p.x) - 3, fy(p.y) - 3, 6, 6);
    });
  ROBOT_IDS.forEach((rid) => {
    const p = pointAt(pathPts(robotById(rid)), t);
    if (!p) return;
    const focus = isAll || rid === selectedRobot;
    c.globalAlpha = focus ? 1 : 0.4;
    c.beginPath();
    c.arc(fx(p.x), fy(p.y), focus ? 8 : 6, 0, Math.PI * 2);
    c.fillStyle = SLOT_COLORS[rid];
    c.strokeStyle = "#ffffff";
    c.lineWidth = 2;
    if (p.inferred) {
      c.strokeStyle = SLOT_COLORS[rid];
      c.stroke();
    } else {
      c.fill();
      c.stroke();
    }
    if (focus) {
      const tl = activeTracklet(rid, t);
      c.font = "bold 12px sans-serif";
      c.fillStyle = "#ffffff";
      c.fillText(`${robotLabel(rid)}${tl ? ` (T${tl.track_id})` : p.inferred ? " (hidden)" : ""}`, fx(p.x) + 10, fy(p.y) + 4);
    }
    c.globalAlpha = 1;
  });
  c.restore();
}

// Video overlay in robots mode: selected robot path (or all), plus labelled
// positions of every robot and tracklet at the moment shown on the frame.
function drawRobotsOnVideo() {
  const ids = selectedRobot === "all" ? (momentT == null ? ROBOT_IDS : []) : [selectedRobot];
  ids.forEach((rid) => {
    const r = robotById(rid);
    if (r) drawColoredPath(r.path, SLOT_COLORS[rid], robotLabel(rid));
  });
  if (momentT == null) return;
  ctx.save();
  ctx.font = "12px sans-serif";
  (lastResult?.tracklets || []).forEach((tl) => {
    const p = pointAt(trkPts(tl), momentT, 0.5);
    if (!p || p.px == null) return;
    const pos = sourceToDisplay(p.px, p.py);
    const owner = ownerOf(tl.track_id);
    ctx.strokeStyle = owner ? SLOT_COLORS[owner] : "#d0d0d0";
    ctx.lineWidth = 2;
    ctx.strokeRect(pos.x - 5, pos.y - 5, 10, 10);
    ctx.fillStyle = "#ffffff";
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 3;
    const txt = `T${tl.track_id}`;
    ctx.strokeText(txt, pos.x + 8, pos.y + 16);
    ctx.fillText(txt, pos.x + 8, pos.y + 16);
  });
  ROBOT_IDS.forEach((rid) => {
    const p = pointAt(pathPts(robotById(rid)), momentT);
    if (!p || p.px == null) return;
    const pos = sourceToDisplay(p.px, p.py);
    const focus = selectedRobot === "all" || selectedRobot === rid;
    ctx.globalAlpha = focus ? 1 : 0.45;
    ctx.strokeStyle = SLOT_COLORS[rid];
    ctx.lineWidth = focus ? 4 : 2;
    ctx.setLineDash(p.inferred ? [4, 4] : []);
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, focus ? 18 : 12, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.font = "bold 15px sans-serif";
    ctx.fillStyle = SLOT_COLORS[rid];
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 4;
    const txt = `${robotLabel(rid)}${p.inferred ? " (hidden)" : ""}`;
    ctx.strokeText(txt, pos.x + 20, pos.y - 14);
    ctx.fillText(txt, pos.x + 20, pos.y - 14);
    ctx.globalAlpha = 1;
  });
  ctx.restore();
}

async function loadVideoFrame(tSec) {
  const query = new URLSearchParams({ video_path: uploadedVideoPath, t_sec: String(tSec) }).toString();
  const res = await fetch(`/api/video-frame?${query}`);
  const data = await res.json();
  if (!res.ok) {
    log(data);
    return null;
  }
  // Fit the canvas to a practical working size while preserving the source
  // aspect ratio for accurate click mapping.
  const srcW = Number(data.width) || 1280;
  const srcH = Number(data.height) || 720;
  const scale = Math.min(1600 / srcW, 900 / srcH, 1);
  canvas.width = Math.max(640, Math.round(srcW * scale));
  canvas.height = Math.max(360, Math.round(srcH * scale));
  canvas.style.width = `${canvas.width}px`;
  canvas.style.height = `${canvas.height}px`;
  frameMeta = { sourceWidth: srcW, sourceHeight: srcH };
  frameImage = await new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Could not decode video frame"));
    img.src = data.frame_data_url;
  });
  return data;
}

async function showMomentOnVideo() {
  if (!uploadedVideoPath) return log("Upload a video first");
  const t = Number(fieldTimeEl.value) || 0;
  setStatus("Loading video frame...", "busy");
  const data = await loadVideoFrame(resultTrackStart + t);
  if (!data) return setStatus("Failed to load video frame", "error");
  momentT = t;
  redrawCanvas();
  setStatus(`Video at ${(resultTrackStart + t).toFixed(1)} s (tracking t = ${t.toFixed(1)} s)`, "ok");
  canvas.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function redrawCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  if (frameImage) {
    ctx.drawImage(frameImage, 0, 0, canvas.width, canvas.height);
  }

  ctx.fillStyle = "#ff2f92";
  ctx.strokeStyle = "#00fff0";
  ctx.lineWidth = 2;
  ctx.font = "15px sans-serif";
  if (showCornersEl.checked) {
    const displayPoints = [];
    calibrationPoints.forEach((p, idx) => {
      const disp = sourceToDisplay(p.sx, p.sy);
      const x = disp.x;
      const y = disp.y;
      displayPoints.push({ x, y });

      ctx.beginPath();
      ctx.arc(x, y, 7, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillText(`${idx + 1}`, x + 8, y - 8);
    });

    if (displayPoints.length >= 2) {
      ctx.beginPath();
      ctx.moveTo(displayPoints[0].x, displayPoints[0].y);
      for (let i = 1; i < displayPoints.length; i += 1) {
        ctx.lineTo(displayPoints[i].x, displayPoints[i].y);
      }
      if (displayPoints.length === 4) {
        ctx.closePath();
      }
      ctx.stroke();
    }

    ctx.fillStyle = "#ffb347";
    ctx.strokeStyle = "#ffd8a8";
    elevatedPoints.forEach((p, idx) => {
      const disp = sourceToDisplay(p.sx, p.sy);
      ctx.beginPath();
      ctx.rect(disp.x - 6, disp.y - 6, 12, 12);
      ctx.fill();
      ctx.stroke();
      ctx.fillText(`E${idx + 1}`, disp.x + 8, disp.y - 8);
    });

    ctx.fillStyle = "#ffd400";
    ctx.strokeStyle = "#fff1a6";
    manualTagObservations.forEach((t) => {
      const disp = sourceToDisplay(t.sx, t.sy);
      ctx.beginPath();
      ctx.arc(disp.x, disp.y, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.fillText(`M${t.id}`, disp.x + 8, disp.y - 8);
    });
  }

  calibPointsEl.textContent = JSON.stringify(
    [
      ...calibrationPoints.map((p, idx) => ({
        point: idx + 1,
        type: "ground",
        image_x: Math.round(p.sx),
        image_y: Math.round(p.sy),
      })),
      ...elevatedPoints.map((p, idx) => ({
        point: idx + 5,
        type: "elevated",
        image_x: Math.round(p.sx),
        image_y: Math.round(p.sy),
      })),
      ...manualTagObservations.map((t, idx) => ({
        point: idx + 1,
        type: "manual_tag",
        tag_id: t.id,
        image_x: Math.round(t.sx),
        image_y: Math.round(t.sy),
      })),
    ],
    null,
    2,
  );

  if (lastResult) {
    drawAprilTagOverlay(lastResult);
    drawRobotOverlay(lastResult);
  }
}

function drawPath(result) {
  lastResult = result || null;
  redrawCanvas();
}

document.getElementById("calibrateOnly").addEventListener("click", async (evt) => {
  const calibrateBtnEl = evt.currentTarget;
  if (calibrateBtnEl.disabled) return;
  const i = getInputs();
  if (!uploadedVideoPath) return log("Upload a video first");

  calibrateBtnEl.disabled = true;
  setStatus("Calibrating tags...", "busy");
  const body = {
    season: i.season,
    video_path: uploadedVideoPath,
    event_key: i.eventKey || null,
    calibration: {
      prefer_apriltag: true,
      frame_sec: i.calibFrameSec,
      apriltag_layout_text: i.apriltagLayoutText,
      layout_transform: i.tagLayoutTransform,
      manual_references: getManualReferences(),
      manual_tag_observations: getManualTagObservations(),
    },
  };

  try {
    const res = await fetch(`/api/calibrate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const rawText = await res.text();
    let data = null;
    try {
      data = rawText ? JSON.parse(rawText) : null;
    } catch {
      data = { detail: rawText || `HTTP ${res.status}` };
    }
    log(data);
    if (!res.ok) {
      const detail = data?.detail || `HTTP ${res.status}`;
      setStatus(`Calibration failed: ${detail}`, "error");
      return;
    }

    const calibrationResult = {
      mode: "calibration",
      calibration_meta: data.calibration_meta || {},
      image_track_points: [],
      quality_report: { track_meta: {} },
    };
    drawPath(calibrationResult);

    const apr = data?.calibration_meta?.apriltag || {};
    const pose = apr?.camera_pose || {};
    const tagDiag = {
      apriltag_method: apr.method,
      tag_count: apr.tag_count,
      matched_layout_tag_count: apr.matched_layout_tag_count,
      detected_ids: apr.detected_ids,
      tag_layout_transform: data?.calibration_meta?.tag_layout_transform,
      pose_quality: pose.quality || null,
      reprojection_rmse_px: pose.reprojection_rmse_px ?? null,
      selected_projection_model: data?.calibration_meta?.selected_projection_model,
      projection_alignment: apr.projection_alignment || null,
      hfov_deg: pose.hfov_deg ?? null,
      camera_position_m: pose.camera_position_m || null,
      ref_solve_subset: pose.ref_solve_subset || null,
      ref_mirror_y: pose.ref_mirror_y ?? null,
      rmse_all_refs_px: pose.rmse_all_refs_px ?? null,
      manual_ref_diagnostics: pose.manual_ref_diagnostics || null,
      layout_transform_check: data?.calibration_meta?.layout_transform_check || null,
      pose_verification: apr.pose_verification || null,
      refine_mode: pose.refine_mode || null,
      tag_rmse_px: pose.tag_rmse_px ?? null,
      ignored_tag_ids: pose.ignored_tag_ids || null,
      ref_trust: pose.ref_trust || null,
      ref_field_remap: data?.calibration_meta?.ref_field_remap || null,
    };
    log({ calibration_only: tagDiag });

    if (["apriltag_3d_pose", "manual_3d_pose"].includes(data?.calibration_meta?.selected_projection_model)) {
      const reused = data?.calibration_meta?.calibration_cache?.hit ? " - reused previous result, inputs unchanged" : "";
      const ignored = (pose.ignored_tag_ids || []).length
        ? ` - ignored tag ${pose.ignored_tag_ids.join(", ")} (doesn't fit the others; check its ID)`
        : "";
      setStatus(
        (data?.saved_event_key
          ? `Calibration saved for event ${data.saved_event_key} (3D)`
          : "Calibration overlays updated (3D) - not saved, no event selected") + reused + ignored,
        "ok",
      );
    } else {
      setStatus("Calibration overlays updated (2D only)", "busy");
    }
    refreshEventCalibrationStatus().catch((err) => log(`Event calibration status error: ${err.message}`));
  } catch (err) {
    log(`Calibration request error: ${err.message}`);
    setStatus("Calibration failed", "error");
  } finally {
    calibrateBtnEl.disabled = false;
  }
});

eventSelectEl.addEventListener("change", () => {
  ensureEventOption(eventSelectEl.value);
  document.getElementById("eventKey").value = eventSelectEl.value || "";
  setSelectOptions(matchSelectEl, [], "Loading matches...");
  loadEventMatches().catch((err) => log(`Auto-load matches error: ${err.message}`));
  onEventChanged();
});

document.getElementById("eventKey").addEventListener("change", onEventChanged);

document.getElementById("showEventCalibration").addEventListener("click", async () => {
  await refreshEventCalibrationStatus();
  if (!savedEventCalibration) return log("No saved calibration for this event");
  if (!frameImage) log("Tip: load a frame from this event's video first to check the overlay still lines up");
  drawPath({
    mode: "calibration",
    calibration_meta: savedEventCalibration.calibration_meta || {},
    image_track_points: [],
    quality_report: { track_meta: {} },
  });
  log({ saved_event_calibration: savedEventCalibration.summary });
});

matchSelectEl.addEventListener("change", () => {
  document.getElementById("matchKey").value = matchSelectEl.value || "";
});

apriltagLayoutTextEl.addEventListener("input", saveApriltagLayoutToLocalStorage);

document.getElementById("load2026AndymarkTags").addEventListener("click", async () => {
  await loadApriltagLayoutFromUrl(TAG_LAYOUT_2026_ANDYMARK_URL, "2026 AndyMark tags");
});

document.getElementById("load2026WeldedTags").addEventListener("click", async () => {
  await loadApriltagLayoutFromUrl(TAG_LAYOUT_2026_WELDED_URL, "2026 Welded tags");
});

document.getElementById("clearApriltagLayout").addEventListener("click", () => {
  apriltagLayoutTextEl.value = "";
  saveApriltagLayoutToLocalStorage();
  log("AprilTag layout cleared");
});

document.getElementById("uploadVideo").addEventListener("click", async () => {
  const fileInput = document.getElementById("videoFile");
  const file = fileInput.files?.[0];
  if (!file) return log("Pick a video or picture first");

  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch("/api/upload-video", { method: "POST", body: formData });
  const data = await res.json();
  if (!res.ok) {
    setStatus(data.detail || "Upload failed", "error");
    return log(data);
  }
  uploadedVideoPath = data.video_path || "";
  log(data);
  if (data.still) {
    document.getElementById("calibFrameSec").value = "0";
    await loadCalibrationFrame();
  }
});

async function loadCalibrationFrame() {
  const { calibFrameSec } = getInputs();
  if (!uploadedVideoPath) {
    setStatus("Get a match video first (step 1).", "error");
    return false;
  }
  setStatus("Loading picture...", "busy");

  const data = await loadVideoFrame(calibFrameSec);
  if (!data) {
    setStatus("Could not load a picture from the video", "error");
    return false;
  }

  calibrationPoints = [];
  elevatedPoints = [];
  manualTagObservations = [];
  lastResult = null;
  momentT = null;
  renderRobotsPanel();
  redrawCanvas();
  setStatus("Picture loaded - click visible field corners (optional if tags are visible)", "ok");
  log(data);
  return true;
}

document.getElementById("loadFrame").addEventListener("click", () => {
  loadCalibrationFrame().catch((err) => setStatus(`Picture error: ${err.message}`, "error"));
});
document.getElementById("fetchSampleVideo").addEventListener("click", () => {
  fetchSampleVideo().catch((err) => setStatus(`Video download error: ${err.message}`, "error"));
});

document.getElementById("clearPoints").addEventListener("click", () => {
  calibrationPoints = [];
  elevatedPoints = [];
  manualTagObservations = [];
  redrawCanvas();
});

document.getElementById("clearManualTags").addEventListener("click", () => {
  manualTagObservations = [];
  redrawCanvas();
});

manualTagModeBtnEl.addEventListener("click", () => {
  manualTagMode = !manualTagMode;
  manualTagModeBtnEl.textContent = `Tag Click Mode: ${manualTagMode ? "On" : "Off"}`;
});

canvas.addEventListener("click", (evt) => {
  if (!frameImage || !frameImage.complete) return;
  if (!frameMeta || !frameMeta.sourceWidth || !frameMeta.sourceHeight) return;

  const { dx, dy } = displayEventToCanvasPixels(evt);
  const { sx, sy } = displayToSource(dx, dy);

  if (manualTagMode) {
    const idText = manualTagIdEl.value.trim();
    if (!idText) {
      log("Enter a Manual Tag ID before clicking in Tag Click Mode");
      return;
    }
    const tagId = Number(idText);
    if (!Number.isFinite(tagId)) {
      log("Manual Tag ID must be numeric");
      return;
    }

    manualTagObservations = manualTagObservations.filter((t) => Number(t.id) !== tagId);
    manualTagObservations.push({ id: tagId, sx, sy });
    redrawCanvas();
    return;
  }

  if (calibrationPoints.length < 4) {
    calibrationPoints.push({ sx, sy });
  } else if (elevatedPoints.length < 2) {
    elevatedPoints.push({ sx, sy });
  }
  redrawCanvas();
});

document.getElementById("process").addEventListener("click", async () => {
  const i = getInputs();
  if (!uploadedVideoPath) return log("Upload a video first");

  if (i.trackEndSec !== null && i.trackEndSec <= i.trackStartSec) {
    return log("Track End must be greater than Track Start");
  }

  const body = {
    season: i.season,
    event_key: i.eventKey,
    team_key: i.teamKey,
    match_key: i.matchKey,
    target_alliance: i.alliance,
    target_robot_position: i.robotPos,
    video_path: uploadedVideoPath,
    auto_seconds: i.autoSeconds,
    tracker_config: i.trackerConfig,
    tracking_start_sec: i.trackStartSec,
    tracking_end_sec: i.trackEndSec,
    lock_window_sec: i.lockWindowSec,
    forced_track_id: i.forcedTrackId,
    use_event_calibration: useEventCalibrationEl.checked,
    auto_identify_teams: document.getElementById("autoIdentifyTeams").checked,
    calibration: {
      prefer_apriltag: true,
      frame_sec: i.calibFrameSec,
      apriltag_layout_text: i.apriltagLayoutText,
      layout_transform: i.tagLayoutTransform,
      manual_references: getManualReferences(),
      manual_tag_observations: getManualTagObservations(),
    },
  };

  processBtnEl.disabled = true;
  processBtnEl.textContent = "Processing...";
  setStatus("Processing match...", "busy");

  try {
    const res = await fetch(`/api/process-match`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const rawText = await res.text();
    let data = null;
    try {
      data = rawText ? JSON.parse(rawText) : null;
    } catch {
      data = { detail: rawText || `HTTP ${res.status}` };
    }
    log(data);
    if (!res.ok) {
      const detail = data?.detail || `HTTP ${res.status}`;
      setStatus(`Processing failed: ${detail}`, "error");
      return;
    }

    resultTrackStart = Number(data?.tracking_start_sec ?? i.trackStartSec) || 0;
    if (data?.auto_start) {
      log({ auto_start: data.auto_start });
      trackStartSecEl.value = trackStartSliderEl.value = resultTrackStart.toFixed(2);
    }
    momentT = null;
    drawPath(data);
    initRobots(data);
    if (data?.team_identification) log({ team_identification: data.team_identification });
    if (data?.firebase) log({ firebase: data.firebase });
    const m = data?.quality_report?.track_meta || {};
    const removed = (m.removed_outside_field || 0) + (m.removed_speed_outliers || 0);
    if (removed > 0) {
      log({ track_filtering: m });
    }

    const apr = data?.calibration_meta?.apriltag || {};
    const pose = apr?.camera_pose || {};
    const tagDiag = {
      apriltag_method: apr.method,
      tag_count: apr.tag_count,
      matched_layout_tag_count: apr.matched_layout_tag_count,
      detected_ids: apr.detected_ids,
      tag_layout_transform: data?.calibration_meta?.tag_layout_transform,
      pose_quality: pose.quality || null,
      reprojection_rmse_px: pose.reprojection_rmse_px ?? null,
      selected_projection_model: data?.calibration_meta?.selected_projection_model,
      calibration_source: data?.calibration_meta?.calibration_source || null,
    };
    log({ tag_diagnostics: tagDiag });

    if (!["apriltag_3d_pose", "manual_3d_pose"].includes(data?.calibration_meta?.selected_projection_model)) {
      setStatus("Processed with manual projection (tags unreliable)", "busy");
      return;
    }

    setStatus("Processing complete", "ok");
  } catch (err) {
    log(`Processing request error: ${err.message}`);
    setStatus("Processing failed", "error");
  } finally {
    processBtnEl.disabled = false;
    processBtnEl.textContent = "Process Match";
  }
});

trackStartSliderEl.addEventListener("input", syncScrubbers);
trackEndSliderEl.addEventListener("input", () => {
  trackEndSecEl.value = trackEndSliderEl.value;
});
trackStartSecEl.addEventListener("input", () => {
  trackStartSliderEl.value = trackStartSecEl.value;
});
trackEndSecEl.addEventListener("input", () => {
  if (!trackEndSecEl.value) return;
  trackEndSliderEl.value = trackEndSecEl.value;
});

document.getElementById("saveRuntimeSettings").addEventListener("click", saveRuntimeSettings);

function reloadTeamEvents() {
  loadPickerEvents().catch((err) => log(`Team events error: ${err.message}`));
  loadTeamEvents().catch((err) => log(`Auto-load events error: ${err.message}`));
}

document.getElementById("season").addEventListener("change", reloadTeamEvents);
document.getElementById("teamKey").addEventListener("change", reloadTeamEvents);

[showCornersEl, showDetectedTagsEl, showProjectedTagsEl, showRobotPathEl].forEach((el) => {
  el.addEventListener("change", redrawCanvas);
});

document.getElementById("saveRobots").addEventListener("click", () => saveRobots());
document.getElementById("exportTeamPaths").addEventListener("click", () => {
  exportTeamPaths().catch((err) => setStatus(`Export failed: ${err.message}`, "error"));
});

document.getElementById("exportHotscoutCsv").addEventListener("click", async () => {
  const eventKey = currentEventKey();
  if (!EVENT_KEY_RE.test(eventKey)) {
    setScoutStatus("Pick an event first (step 1).", "error");
    return;
  }
  try {
    const res = await fetch(`/api/export/hotscout-csv?event_key=${encodeURIComponent(eventKey)}`);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data?.detail || `HTTP ${res.status}`);
    }
    const url = URL.createObjectURL(await res.blob());
    const a = document.createElement("a");
    a.href = url;
    a.download = `hotscout_vision_${eventKey}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    setScoutStatus("Downloaded. In the HotScout app: Import / Export > CSV Import.", "ok");
  } catch (err) {
    setScoutStatus(`CSV export failed: ${err.message}`, "error");
  }
});
document.getElementById("uploadFirebase").addEventListener("click", () => {
  uploadFirebase().catch((err) => setStatus(`Firebase upload failed: ${err.message}`, "error"));
});
document.getElementById("scoutStart").addEventListener("click", () => {
  startScout().catch((err) => {
    setScoutRunning(false);
    setScoutStatus(`Could not start: ${err.message}`, "error");
  });
});
document.getElementById("rescoutTagged").addEventListener("click", () => {
  startScout(true).catch((err) => {
    setScoutRunning(false);
    setScoutStatus(`Could not start: ${err.message}`, "error");
  });
});
document.getElementById("scoutCancel").addEventListener("click", () => {
  if (!scoutJobId) return;
  document.getElementById("scoutCancel").disabled = true;
  setScoutStatus("Stopping after the current match...", "busy");
  fetch(scoutRemote ? `/api/remote-jobs/${scoutJobId}/cancel` : `/api/scout/jobs/${scoutJobId}/cancel`, { method: "POST" }).then(() => pollScout());
});
document.getElementById("acceptRemote").addEventListener("change", (e) => {
  setAcceptRemote(e.target.checked).catch(devicesError);
});
document.getElementById("devicesCard").addEventListener("toggle", (e) => {
  if (e.target.open) refreshDevices().catch(devicesError);
});
// Pick up a computer that just started sharing its GPU.
document.getElementById("scoutDevice").addEventListener("mouseenter", () => refreshDevices().catch(devicesError));
document.getElementById("autosTeamFilter").addEventListener("input", scheduleAutosRender);
{
  const viewEl = document.getElementById("autosView");
  try {
    const saved = localStorage.getItem(AUTOS_VIEW_STORAGE_KEY);
    if (saved === "camera" || saved === "standard") viewEl.value = saved;
  } catch {
    // storage unavailable: keep the default
  }
  viewEl.addEventListener("change", () => {
    try {
      localStorage.setItem(AUTOS_VIEW_STORAGE_KEY, viewEl.value);
    } catch {
      // storage unavailable
    }
    renderAutosGallery();
  });
}
document.getElementById("autosLoadSaved").addEventListener("click", () => {
  resetAutosGallery();
  loadSavedAutos().catch((err) => log(`Saved autos error: ${err.message}`));
});
document.getElementById("autosTeamHistory").addEventListener("click", () => {
  fixTeamMixups().catch((err) => {
    document.getElementById("autosTeamHistory").disabled = false;
    log(`Team history error: ${err.message}`);
  });
});
document.getElementById("loadMatchTeams").addEventListener("click", () => {
  loadMatchTeams(true).catch((err) => setStatus(`TBA teams error: ${err.message}`, "error"));
});
document.getElementById("showMomentOnVideo").addEventListener("click", () => {
  showMomentOnVideo().catch((err) => setStatus(`Video frame error: ${err.message}`, "error"));
});
fieldTimeEl.addEventListener("input", drawFieldView);
document.getElementById("detectorTrain").addEventListener("click", () => startDetectorJob(true).catch(detectorError));
document.getElementById("detectorCollect").addEventListener("click", () => startDetectorJob(false).catch(detectorError));
document.getElementById("detectorCancel").addEventListener("click", () => postDetector("/api/detector/cancel").catch(detectorError));
document.getElementById("detectorEnabled").addEventListener("change", (e) => {
  postDetector("/api/detector/use", { season: detectorSeason(), enabled: e.target.checked }).catch(detectorError);
});
document.getElementById("season").addEventListener("change", () => refreshDetector().catch(detectorError));
const SIGN_IN_ERRORS = {
  "auth/operation-not-allowed": "Google sign-in is turned off. Firebase console > Authentication > Sign-in method > Google > Enable.",
  "auth/configuration-not-found": "Google sign-in is turned off. Firebase console > Authentication > Sign-in method > Google > Enable.",
  "auth/unauthorized-domain": `This address (${location.hostname}) is not allowed. Firebase console > Authentication > Settings > Authorized domains.`,
  "auth/popup-blocked": "The browser blocked the sign-in window; allow pop-ups for this page and try again.",
  "auth/popup-closed-by-user": "Sign-in window was closed before finishing.",
  "auth/cancelled-popup-request": "Sign-in window was closed before finishing.",
};
document.getElementById("cloudBtn").addEventListener("click", () => {
  (cloudState?.signed_in ? cloudSync() : cloudSignIn()).catch((err) => {
    log({ cloud_error: err.code || err.message });
    setStatus(`Team cloud: ${SIGN_IN_ERRORS[err.code] || err.message}`, "error");
  });
});
document.getElementById("cloudSignOut").addEventListener("click", () => {
  cloudSignOut().catch((err) => setStatus(`Sign out error: ${err.message}`, "error"));
});

function startApp() {
  loadApriltagLayoutFromLocalStorage();
  refreshGpuStatus().catch((err) => log(`GPU status error: ${err.message}`));
  refreshDetector().catch(detectorError);
  refreshDevices().catch(devicesError);
  refreshFirebaseStatus().catch((err) => log(`Firebase status error: ${err.message}`));
  loadRuntimeSettings().catch((err) => log(`Runtime settings load error: ${err.message}`));
  loadTeamEvents().catch((err) => log(`Initial event load error: ${err.message}`));
  loadPickerEvents()
    .catch((err) => log(`Team events error: ${err.message}`))
    .then(() => resumeActiveScout())
    .catch((err) => log(`Resume scouting error: ${err.message}`));
}

refreshCloud()
  .then((st) => {
    if (st.local || st.signed_in) return startApp();
    setStatus(
      st.configured
        ? "Sign in with a team Google account (top right) to use HotScout from this computer."
        : "This HotScout server only accepts its own computer (team cloud not set up).",
      "error"
    );
  })
  .catch((err) => {
    log(`Team cloud status error: ${err.message}`);
    startApp();
  });
