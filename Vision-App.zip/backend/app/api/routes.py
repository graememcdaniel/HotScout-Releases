from pathlib import Path
from functools import partial
import base64
import hashlib
import json
import re
import uuid

import cv2
import httpx
import numpy as np
from fastapi import APIRouter, File, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, Response

from app.calibration.apriltag import (
    _is_strong_detection,
    _mat_to_quat,
    _project_layout_tags_to_image,
    _quat_to_mat,
    estimate_camera_pose_from_apriltags,
    project_field_outline,
)
from app.calibration.manual import build_manual_homography
from app.core.config import settings
from app.core.runtime_config import get_runtime_config, update_runtime_config
from app.models.schemas import (
    AssignRobotsRequest,
    AssignRobotsResult,
    CalibrateRequest,
    CalibrateResult,
    CalibrationReference,
    DetectorTrainRequest,
    DetectorUseRequest,
    ImageTrackPoint,
    ProcessMatchRequest,
    ProcessResult,
    RescoutTagRequest,
    GoodMarkRequest,
    SwapTeamsRequest,
    RuntimeConfigResponse,
    RuntimeConfigUpdate,
    ScoutJobRequest,
    TrajectoryPoint,
)
from app.projection.topdown import project_track_to_field
from app.services.quality_report import build_quality_report
from app.services.apriltag_layout_parser import parse_apriltag_layout_text, parse_layout_field_dimensions
from app.services.event_calibration_store import (
    delete_event_calibration,
    list_event_calibrations,
    load_event_calibration,
    normalize_event_key,
    save_event_calibration,
    summarize_event_calibration,
)
from app.services.tba_client import (
    get_event_matches,
    get_match_simple,
    get_season_events,
    get_team_event_matches,
    get_team_events,
)
from app.services import cloud, detector_training, devices, firebase_store, ground_truth, rescout, scout_jobs, shared_matches, team_history
from app.core.gpu import gpu_info
from app.services.tracker import run_tracking_pipeline
from app.services.trajectory_export import (
    export_csv_json,
    export_robots_json,
    export_team_paths,
    parse_match_key,
    read_match_autos,
    team_path_file,
    team_paths_dir,
)
from app.services.video_ingest import IMAGE_TYPES, VIDEO_TYPES, save_uploaded_image, save_uploaded_video
from app.tracking.camera import CameraModel
from app.tracking.view_shift import encode_reference, estimate_view_affine
from app.tracking.match_start import find_auto_start
from app.tracking.pipeline import (
    assign_tracklets,
    load_run,
    read_run_context,
    run_field_tracking,
    tracklet_summary as _tracklet_summary,
)
from app.tracking.terrain import FieldTerrain

router = APIRouter()

_DEFAULT_FIELD_LENGTH_M = 16.54
_DEFAULT_FIELD_WIDTH_M = 8.21
_DEFAULT_FIELD_DIMS = (_DEFAULT_FIELD_LENGTH_M, _DEFAULT_FIELD_WIDTH_M)


def _runs_dir() -> Path:
    return Path(settings.output_dir) / "runs"


_MATCH_KEY_RE = re.compile(r"[0-9]{4}[a-z0-9]+_[a-z0-9]+")


async def _upload_firebase(match_key: str, team_files: list[str]) -> dict:
    manifest = team_paths_dir(match_key).parent / "firebase_docs.json"
    return await run_in_threadpool(firebase_store.upload_team_files, team_files, manifest)


async def _match_lineup(match_key: str) -> tuple[dict | None, str | None]:
    """Team keys per alliance from TBA, or (None, reason)."""
    if not _MATCH_KEY_RE.fullmatch(match_key or ""):
        return None, "Match key is not a TBA key; teams not identified"
    key = str(get_runtime_config().get("tba_auth_key") or "").strip()
    if not key:
        return None, "No TBA key; teams not identified"
    try:
        match = await get_match_simple(match_key, key)
    except httpx.HTTPError as exc:
        return None, f"TBA lookup failed ({exc}); teams not identified"
    alliances = (match or {}).get("alliances") or {}
    lineup = {c: list((alliances.get(c) or {}).get("team_keys") or []) for c in ("red", "blue")}
    if not (lineup["red"] or lineup["blue"]):
        return None, "TBA has no line-up for this match"
    return lineup, None


def _export_robots(
    match_key: str, run_id: str, robots: list[dict], meta: dict, lineup: dict | None = None
) -> tuple[list[dict], dict[str, str], list[str]]:
    """Write robots.json + one JSON per lineup team; return UI robots, file info and team files.

    Lineup teams that no tracked robot was assigned to get a "not detected"
    placeholder file so a match always has all six teams.
    """
    assigned = {r.get("team_key") for r in robots if r.get("team_key")}
    missing = [
        {"team_key": t, "alliance": color}
        for color in ("red", "blue")
        for t in (lineup or {}).get(color, [])
        if t and t not in assigned
    ]
    payload = {
        "match_key": match_key,
        "run_id": run_id,
        "time_reference": "t_sec is seconds from tracking_start_sec in the video",
        # robots.json stays in the calibration frame (field_transform maps it to the
        # official frame); the team files are written in the official frame.
        "field_frame": "calibration",
        **meta,
        "lineup": lineup,
        "missing_teams": missing,
        "robots": [
            {
                **{k: v for k, v in r.items() if k not in {"samples", "path"}},
                "path_summary": r["path"].get("summary", {}),
                "path_nodes": r["path"].get("nodes", []),
                "path_points": r["path"].get("points", []),
                "trajectory": [p.model_dump() for p in _trajectory_points(r["samples"])],
            }
            for r in robots
        ],
    }
    files = {"json": export_robots_json(match_key, payload)}
    team_files = export_team_paths(match_key, payload)
    # Re-scouted a hand-checked match: keep the clicked paths.
    team_files = sorted(set(team_files) | set(ground_truth.apply_to_autos(match_key)))
    files["teams_dir"] = str(team_paths_dir(match_key).resolve())
    files["team_count"] = str(len(team_files))
    return [{k: v for k, v in r.items() if k != "samples"} for r in robots], files, team_files


def _trajectory_points(samples: list[dict]) -> list[TrajectoryPoint]:
    return [
        TrajectoryPoint(
            t_sec=s["t_sec"],
            x_m=s["x_m"],
            y_m=s["y_m"],
            z_m=s["z_m"],
            confidence=s["confidence"],
            inferred=not s["observed"],
            sigma_m=s["sigma_m"],
            position_confidence=s["position_confidence"],
            identity_confidence=s["identity_confidence"],
            z_source=s["z_source"],
            track_id=s["track_id"],
        )
        for s in samples
    ]


def _remap_refs_to_field_dims(manual_references: list, dims: tuple[float, float] | None) -> tuple[list, dict | None]:
    # References placed on the field corners default to 16.54 x 8.21 m; when
    # the tag layout states the real field size, use it so refs and tags
    # share one coordinate frame.
    if not dims or not manual_references:
        return manual_references, None
    length, width = dims
    out = []
    changed = 0
    for r in manual_references:
        update = {}
        if abs(float(r.field_x_m) - _DEFAULT_FIELD_LENGTH_M) < 0.01 and abs(length - _DEFAULT_FIELD_LENGTH_M) >= 0.005:
            update["field_x_m"] = length
        if abs(float(r.field_y_m) - _DEFAULT_FIELD_WIDTH_M) < 0.01 and abs(width - _DEFAULT_FIELD_WIDTH_M) >= 0.005:
            update["field_y_m"] = width
        if update:
            changed += 1
            out.append(r.model_copy(update=update))
        else:
            out.append(r)
    if not changed:
        return manual_references, None
    return out, {"field_length_m": length, "field_width_m": width, "refs_remapped": changed}


def _apply_layout_transform(
    points: list[dict],
    transform: str,
    manual_references: list,
) -> list[dict]:
    mode = (transform or "none").strip().lower()
    if mode not in {"none", "flip_x", "flip_y", "rotate_180"}:
        mode = "none"

    if mode == "none" or not points:
        return [dict(p) for p in points]

    width = 0.0
    height = 0.0
    for r in manual_references or []:
        width = max(width, float(getattr(r, "field_x_m", 0.0)))
        height = max(height, float(getattr(r, "field_y_m", 0.0)))
    for p in points:
        width = max(width, float(p.get("field_x_m") or 0.0))
        height = max(height, float(p.get("field_y_m") or 0.0))

    if width <= 0.0:
        width = 16.54
    if height <= 0.0:
        height = 8.21

    out: list[dict] = []
    reflect = {
        "flip_x": (-1.0, 1.0, 1.0),
        "flip_y": (1.0, -1.0, 1.0),
        "rotate_180": (-1.0, -1.0, 1.0),
    }[mode]
    for p in points:
        q = dict(p)
        x = float(q.get("field_x_m") or 0.0)
        y = float(q.get("field_y_m") or 0.0)
        if mode == "flip_x":
            x = width - x
        elif mode == "flip_y":
            y = height - y
        elif mode == "rotate_180":
            x = width - x
            y = height - y
        q["field_x_m"] = x
        q["field_y_m"] = y
        r = _quat_to_mat(
            float(q.get("qw") or 0.0), float(q.get("qx") or 0.0), float(q.get("qy") or 0.0), float(q.get("qz") or 0.0)
        )
        if r is not None:
            # Move the tag's facing direction with the layout; for reflections,
            # flip the tag's own y axis to keep a proper rotation.
            r2 = np.diag(reflect) @ r
            if np.linalg.det(r2) < 0:
                r2[:, 1] *= -1.0
            q["qw"], q["qx"], q["qy"], q["qz"] = _mat_to_quat(r2)
        out.append(q)
    return out


def _score_layout_transforms(merged_layout: list[dict], manual_refs: list, apriltag_meta: dict) -> dict | None:
    import numpy as np

    pose = apriltag_meta.get("camera_pose") if isinstance(apriltag_meta, dict) else None
    if not pose or not merged_layout:
        return None
    dets = [d for d in (apriltag_meta.get("detected_tags") or []) if _is_strong_detection(d)]
    if not dets:
        return None

    scores: dict[str, float | None] = {}
    for mode in ("none", "flip_x", "flip_y", "rotate_180"):
        pts = _apply_layout_transform(merged_layout, mode, manual_refs)
        layout = {
            int(t["id"]): {
                "field_x_m": float(t["field_x_m"]),
                "field_y_m": float(t["field_y_m"]),
                "field_z_m": float(t.get("field_z_m") or 0.0),
            }
            for t in pts
        }
        projected = {int(p["id"]): p for p in _project_layout_tags_to_image(tag_layout=layout, pose=pose)}
        residuals = []
        for d in dets:
            p = projected.get(int(d["id"]))
            if p is not None:
                residuals.append(float(np.hypot(d["center_x"] - p["center_x"], d["center_y"] - p["center_y"])))
        scores[mode] = float(np.median(residuals)) if residuals else None

    valid = {m: s for m, s in scores.items() if s is not None}
    return {
        "median_residual_px": scores,
        "suggested": min(valid, key=valid.get) if valid else None,
        "detections_scored": len(dets),
    }


def _build_calibration_meta(
    *,
    season: int,
    video_path: str,
    calibration,
) -> tuple[dict, object, dict]:
    import numpy as np

    calibration_meta: dict = {}
    parsed_text_layout: list[dict] = []
    if calibration.apriltag_layout_text.strip():
        try:
            parsed_text_layout = parse_apriltag_layout_text(calibration.apriltag_layout_text)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    merged_layout = parsed_text_layout or [t.model_dump() for t in calibration.apriltag_layout]
    manual_refs, ref_remap = _remap_refs_to_field_dims(
        calibration.manual_references,
        parse_layout_field_dimensions(calibration.apriltag_layout_text) if parsed_text_layout else None,
    )
    calibration_meta["ref_field_remap"] = ref_remap
    transformed_layout = _apply_layout_transform(
        points=merged_layout,
        transform=getattr(calibration, "layout_transform", "none"),
        manual_references=manual_refs,
    )
    tag_layout = {
        int(t["id"]): {
            "field_x_m": float(t["field_x_m"]),
            "field_y_m": float(t["field_y_m"]),
            "field_z_m": float(t.get("field_z_m") or 0.0),
            "qw": float(t.get("qw") or 0.0),
            "qx": float(t.get("qx") or 0.0),
            "qy": float(t.get("qy") or 0.0),
            "qz": float(t.get("qz") or 0.0),
        }
        for t in transformed_layout
    }
    calibration_meta["tag_layout_points"] = [
        {
            "id": int(t["id"]),
            "field_x_m": float(t["field_x_m"]),
            "field_y_m": float(t["field_y_m"]),
            "field_z_m": float(t.get("field_z_m") or 0.0),
        }
        for t in transformed_layout
    ]
    calibration_meta["tag_layout_transform"] = getattr(calibration, "layout_transform", "none")
    calibration_meta["apriltag_layout_source"] = "text" if parsed_text_layout else "structured"
    calibration_meta["apriltag_layout_count"] = len(tag_layout)

    homography, manual_meta = build_manual_homography(
        manual_references=[r.model_dump() for r in manual_refs],
        season=season,
    )
    calibration_meta["manual"] = manual_meta

    apriltag_meta = estimate_camera_pose_from_apriltags(
        video_path=video_path,
        season=season,
        frame_sec=calibration.frame_sec,
        tag_layout=tag_layout or None,
        seed_homography_image_to_field_cm=homography,
        manual_references=[r.model_dump() for r in manual_refs],
        manual_tag_observations=[t.model_dump() for t in calibration.manual_tag_observations],
        straight_lines=[[p.model_dump() for p in ln] for ln in getattr(calibration, "straight_lines", [])],
    )
    if isinstance(apriltag_meta, dict) and apriltag_meta.get("camera_pose"):
        dims = parse_layout_field_dimensions(calibration.apriltag_layout_text) if parsed_text_layout else None
        apriltag_meta["projected_field_outline"] = project_field_outline(
            apriltag_meta["camera_pose"], *tuple(dims or _DEFAULT_FIELD_DIMS)
        )
    calibration_meta["apriltag"] = apriltag_meta
    calibration_meta["layout_transform_check"] = _score_layout_transforms(merged_layout, manual_refs, apriltag_meta)

    pose_model = ((apriltag_meta.get("camera_pose") or {}).get("model") if isinstance(apriltag_meta, dict) else None)
    pose_quality = ((apriltag_meta.get("camera_pose") or {}).get("quality") if isinstance(apriltag_meta, dict) else None)

    has_projected_layout = bool(apriltag_meta.get("projected_layout_points")) if isinstance(apriltag_meta, dict) else False
    apr_method = (apriltag_meta.get("method") if isinstance(apriltag_meta, dict) else "") or ""

    if calibration.prefer_apriltag and pose_model == "solvepnp_manual_3d" and apriltag_meta.get("camera_pose") is not None and pose_quality in {"manual", "manual_weak", "manual_refined", "good"}:
        calibration_meta["selected_projection_model"] = "manual_3d_pose"
        calibration_meta["selected_homography"] = "manual"
    elif calibration.prefer_apriltag and apr_method == "manual_3d_refs" and has_projected_layout:
        calibration_meta["selected_projection_model"] = "manual_3d_pose"
        calibration_meta["selected_homography"] = "manual"
    elif calibration.prefer_apriltag and apriltag_meta.get("camera_pose") is not None and pose_quality in {"good", "seeded", "manual", "manual_weak", "manual_refined"}:
        calibration_meta["selected_projection_model"] = "apriltag_3d_pose"
        calibration_meta["selected_homography"] = "manual"
    elif getattr(calibration, "strict_3d_only", True):
        camera_pose = (apriltag_meta.get("camera_pose") if isinstance(apriltag_meta, dict) else None) or {}
        diag = {
            "apriltag_method": apr_method,
            "detected_ids": apriltag_meta.get("detected_ids") if isinstance(apriltag_meta, dict) else None,
            "tag_count": apriltag_meta.get("tag_count") if isinstance(apriltag_meta, dict) else None,
            "pose_quality": camera_pose.get("quality"),
            "reprojection_rmse_px": camera_pose.get("reprojection_rmse_px"),
        }
        raise HTTPException(
            status_code=422,
            detail={
                "message": (
                    "Couldn't place the camera. Click at least 6 AprilTags spread across the picture "
                    "(type each tag's ID, Tag Click Mode on), then save again."
                ),
                "diagnostics": diag,
            },
        )
    elif calibration.prefer_apriltag and apriltag_meta.get("homography") is not None:
        homography = np.array(apriltag_meta["homography"], dtype=float)
        calibration_meta["selected_homography"] = "apriltag"
        calibration_meta["selected_projection_model"] = "apriltag_homography"
    else:
        calibration_meta["selected_homography"] = "manual"
        calibration_meta["selected_projection_model"] = "manual_homography"

    calibration_meta["selected_homography_matrix"] = homography.tolist()
    return calibration_meta, homography, apriltag_meta


def _calibration_cache_key(*, season: int, video_path: str, calibration) -> str:
    # Same video + same inputs + same calibration code => same result, so the
    # (slow) tag detection / pose solve never needs to run twice.
    app_dir = Path(__file__).resolve().parents[1]
    code_files = sorted(
        [*(app_dir / "calibration").glob("*.py"), app_dir / "services" / "apriltag_layout_parser.py", Path(__file__).resolve()]
    )
    video = Path(video_path).resolve()
    size = video.stat().st_size
    # Identify the video by content (re-uploading the same file rewrites its
    # mtime/path): size + hash of the first and last 4 MB.
    chunk = 4 * 1024 * 1024
    digest = hashlib.sha256()
    with video.open("rb") as f:
        digest.update(f.read(chunk))
        if size > chunk:
            f.seek(max(chunk, size - chunk))
            digest.update(f.read(chunk))
    payload = {
        "season": season,
        "video": [size, digest.hexdigest()],
        "calibration": calibration.model_dump(),
        "code": [[p.name, p.stat().st_mtime_ns] for p in code_files if p.exists()],
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()[:32]


def _cached_calibration_meta(*, season: int, video_path: str, calibration) -> tuple[dict, object, dict]:
    key = _calibration_cache_key(season=season, video_path=video_path, calibration=calibration)
    cache_file = Path(settings.output_dir) / "calib_cache" / f"{key}.json"
    if cache_file.exists():
        try:
            meta = json.loads(cache_file.read_text(encoding="utf-8"))
            homography = np.array(meta["selected_homography_matrix"], dtype=float)
            meta["calibration_cache"] = {"hit": True, "key": key}
            return meta, homography, meta.get("apriltag") or {}
        except (OSError, ValueError, KeyError):
            pass  # corrupt entry: recalibrate and overwrite

    meta, homography, apriltag_meta = _build_calibration_meta(
        season=season, video_path=video_path, calibration=calibration
    )
    cache_file.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache_file.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(meta), encoding="utf-8")
    tmp.replace(cache_file)
    meta["calibration_cache"] = {"hit": False, "key": key}
    return meta, homography, apriltag_meta


def _filter_raw_track_points(raw_tracks: dict, manual_refs: list) -> dict:
    import numpy as np

    points = sorted(raw_tracks.get("points", []), key=lambda p: float(p.get("t_sec", 0.0)))
    if not points:
        return raw_tracks

    polygon = None
    if manual_refs and len(manual_refs) >= 4:
        polygon = [
            (float(r.image_x), float(r.image_y))
            for r in manual_refs[:4]
        ]
        polygon = np.array(polygon, dtype=np.float32).reshape((-1, 1, 2))

    filtered = []
    removed_outside = 0
    removed_speed = 0
    max_speed_px_per_sec = 900.0
    border_margin_px = 28.0

    for p in points:
        px = float(p.get("px", 0.0))
        py = float(p.get("py", 0.0))
        t = float(p.get("t_sec", 0.0))

        if polygon is not None:
            inside = cv2.pointPolygonTest(
                contour=polygon,
                pt=(px, py),
                measureDist=True,
            )
            if inside < -border_margin_px:
                removed_outside += 1
                continue

        if filtered:
            prev = filtered[-1]
            dt = max(1e-3, t - float(prev["t_sec"]))
            dx = px - float(prev["px"])
            dy = py - float(prev["py"])
            speed = ((dx * dx + dy * dy) ** 0.5) / dt
            if speed > max_speed_px_per_sec:
                removed_speed += 1
                continue

        filtered.append(p)

    if not filtered:
        filtered = points

    out = dict(raw_tracks)
    out["points"] = filtered
    meta = dict(out.get("meta") or {})
    meta["points_before_filter"] = len(points)
    meta["points_after_filter"] = len(filtered)
    meta["removed_outside_field"] = removed_outside
    meta["removed_speed_outliers"] = removed_speed
    out["meta"] = meta
    return out


def _normalize_team_key(team_key: str) -> str:
    key = (team_key or "").strip().lower()
    if not key:
        return key
    if key.startswith("frc"):
        return key
    if key.isdigit():
        return f"frc{key}"
    return key


def _video_size(video_path: str) -> tuple[int, int]:
    cap = cv2.VideoCapture(video_path)
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    cap.release()
    return w, h


def _load_event_calibration_or_400(event_key: str) -> dict | None:
    try:
        record = load_event_calibration(event_key)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if record is None:  # calibrated on another team computer?
        record = cloud.quietly(cloud.pull_calibration, normalize_event_key(event_key))
    return record


def _scale_track_points(raw_tracks: dict, sx: float, sy: float) -> dict:
    out = dict(raw_tracks)
    out["points"] = [{**p, "px": float(p["px"]) * sx, "py": float(p["py"]) * sy} for p in raw_tracks.get("points", [])]
    return out


@router.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/runtime-config", response_model=RuntimeConfigResponse)
def runtime_config_get() -> RuntimeConfigResponse:
    return RuntimeConfigResponse(**_masked(get_runtime_config()))


@router.post("/runtime-config", response_model=RuntimeConfigResponse)
def runtime_config_set(update: RuntimeConfigUpdate) -> RuntimeConfigResponse:
    if (update.tba_auth_key or "").startswith(MASK):  # the masked value shown in the page
        update.tba_auth_key = None
    return RuntimeConfigResponse(**_masked(update_runtime_config(update)))


MASK = "\u2022\u2022\u2022\u2022"


def _masked(cfg: dict) -> dict:
    """Never send the TBA key back to a browser; the last 4 characters identify it."""
    key = str(cfg.get("tba_auth_key") or "")
    return {**cfg, "tba_auth_key": MASK + key[-4:] if key else ""}


def _require_tba_key() -> str:
    runtime_cfg = get_runtime_config()
    tba_auth_key = str(runtime_cfg.get("tba_auth_key") or "").strip()
    if not tba_auth_key:
        raise HTTPException(status_code=400, detail="Missing TBA API key. Set it in Runtime Settings.")
    return tba_auth_key


@router.get("/team/{team_key}/events/{season}")
async def team_season_events(team_key: str, season: int) -> dict:
    tba_auth_key = _require_tba_key()
    events = await get_team_events(team_key=_normalize_team_key(team_key), season=season, tba_auth_key=tba_auth_key)
    return {"events": events}


@router.get("/teams/{team_key}/events/{season}")
async def team_season_events_compat(team_key: str, season: int) -> dict:
    # Compatibility alias for clients that call /teams/... instead of /team/...
    return await team_season_events(team_key=team_key, season=season)


@router.get("/events/{event_key}/team/{team_key}/matches")
async def team_event_matches(event_key: str, team_key: str) -> dict:
    tba_auth_key = _require_tba_key()
    matches = await get_team_event_matches(
        event_key=event_key,
        team_key=_normalize_team_key(team_key),
        tba_auth_key=tba_auth_key,
    )
    return {"matches": matches}


@router.get("/match/{match_key}/teams")
async def match_teams(match_key: str) -> dict:
    """Team keys per alliance in driver-station order (index 0 = station 1)."""
    if not re.fullmatch(r"[0-9]{4}[a-z0-9]+_[a-z0-9]+", match_key or ""):
        raise HTTPException(status_code=400, detail="Invalid match key (example: 2026mibro1_qm3)")
    tba_auth_key = _require_tba_key()
    try:
        match = await get_match_simple(match_key, tba_auth_key)
    except httpx.HTTPStatusError as exc:
        code = exc.response.status_code
        raise HTTPException(status_code=404 if code == 404 else 502, detail=f"TBA returned {code} for {match_key}") from exc
    alliances = (match or {}).get("alliances") or {}
    return {
        "match_key": match_key,
        "red": list((alliances.get("red") or {}).get("team_keys") or []),
        "blue": list((alliances.get("blue") or {}).get("team_keys") or []),
    }


@router.get("/match/{match_key}/team-path/{team_key}")
async def download_team_path(match_key: str, team_key: str) -> FileResponse:
    """Download one team's path JSON (written by process-match / assign-robots)."""
    path = team_path_file(match_key, team_key)
    if path is None:
        raise HTTPException(status_code=400, detail="Invalid team key (example: frc67)")
    if not path.is_file():
        raise HTTPException(status_code=404, detail=f"No saved path for {team_key} in {match_key}; assign the team first.")
    return FileResponse(path, media_type="application/json", filename=path.name)


@router.get("/export/hotscout-csv")
async def export_hotscout_csv(event_key: str = "") -> Response:
    """Every tracked auto (of one event, or all) as a CSV for the HotScout app's CSV Import."""
    from app.services import hotscout_csv

    event_key = event_key.strip().lower()
    if event_key and not re.fullmatch(r"[0-9]{4}[a-z0-9]+", event_key):
        raise HTTPException(status_code=400, detail="Invalid event key (example: 2026mibro)")
    text, rows = await run_in_threadpool(hotscout_csv.build_csv, event_key or None)
    if not rows:
        raise HTTPException(status_code=404, detail=f"No tracked robots saved{' for ' + event_key if event_key else ''} yet.")
    name = f"hotscout_vision_{event_key or 'all'}.csv"
    return Response(text, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.post("/upload-video")
async def upload_video(file: UploadFile = File(...)) -> dict:
    name = (file.filename or "").lower()
    if name.endswith(IMAGE_TYPES):
        # A still picture (e.g. a stream screenshot) for camera setup.
        try:
            saved_path = await save_uploaded_image(file)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"video_path": saved_path, "still": True}
    if not name.endswith(VIDEO_TYPES):
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Use a video (.mp4, .mov, .mkv, .webm, .avi) "
            "or a picture (.jpg, .jpeg, .png, .bmp, .webp)",
        )
    saved_path = await save_uploaded_video(file)
    return {"video_path": saved_path, "still": False}


@router.get("/video-frame")
async def video_frame(video_path: str, t_sec: float = 0.0) -> dict:
    src = Path(video_path)
    if not src.exists():
        raise HTTPException(status_code=404, detail="Video path not found")

    cap = cv2.VideoCapture(str(src))
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    frame_idx = max(0, int(t_sec * fps))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if total_frames > 0:
        frame_idx = min(frame_idx, total_frames - 1)  # still pictures are a 2-frame clip
    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
    ok, frame = cap.read()
    cap.release()
    if not ok:
        raise HTTPException(status_code=400, detail="Could not decode frame")

    ok_jpg, jpg = cv2.imencode(".jpg", frame)
    if not ok_jpg:
        raise HTTPException(status_code=500, detail="Could not encode frame")

    encoded = base64.b64encode(jpg.tobytes()).decode("ascii")
    return {
        "frame_data_url": f"data:image/jpeg;base64,{encoded}",
        "fps": fps,
        "frame_index": frame_idx,
        "width": int(frame.shape[1]),
        "height": int(frame.shape[0]),
    }


@router.post("/process-match", response_model=ProcessResult)
async def process_match(request: ProcessMatchRequest) -> ProcessResult:
    runtime_cfg = get_runtime_config()
    default_tracker = str(runtime_cfg.get("default_tracker") or settings.default_tracker)
    yolo_model = str(runtime_cfg.get("yolo_model") or settings.yolo_model)
    tracker_conf = float(runtime_cfg.get("tracker_conf") or settings.tracker_conf)
    tracker_iou = float(runtime_cfg.get("tracker_iou") or settings.tracker_iou)
    max_interp_gap_frames = int(
        runtime_cfg.get("max_interp_gap_frames") or settings.max_interp_gap_frames
    )
    auto_seconds_default = float(runtime_cfg.get("auto_seconds") or settings.auto_seconds)

    src = Path(request.video_path)
    if not src.exists():
        raise HTTPException(status_code=404, detail="Uploaded video path not found")

    if request.tracking_end_sec is not None and request.tracking_end_sec <= request.tracking_start_sec:
        raise HTTPException(status_code=400, detail="tracking_end_sec must be greater than tracking_start_sec")

    stored = None
    if request.use_event_calibration and (request.event_key or "").strip():
        stored = _load_event_calibration_or_400(request.event_key)

    # Track points are in this video's pixels; the stored calibration is in
    # the calibration video's pixels. Same camera at another resolution is
    # fine (pure scale); a different aspect ratio means a different view.
    to_calib_scale = (1.0, 1.0)
    if stored is not None:
        calibration_meta = dict(stored["calibration_meta"])
        calibration_meta["calibration_source"] = {"type": "event", **summarize_event_calibration(stored)}
        homography = np.array(calibration_meta["selected_homography_matrix"], dtype=float)
        camera_pose = calibration_meta.get("apriltag") or {}
        filter_refs = [
            CalibrationReference(**r) for r in (stored.get("calibration_request") or {}).get("manual_references", [])
        ]
        vid_w, vid_h = _video_size(str(src))
        cal_w, cal_h = int(stored.get("image_width") or 0), int(stored.get("image_height") or 0)
        if vid_w and vid_h and cal_w and cal_h and (vid_w, vid_h) != (cal_w, cal_h):
            if abs(vid_w / vid_h - cal_w / cal_h) > 0.01:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        f"Video is {vid_w}x{vid_h} but event {stored['event_key']} was calibrated at "
                        f"{cal_w}x{cal_h} (different aspect ratio). Recalibrate or uncheck the saved event calibration."
                    ),
                )
            to_calib_scale = (cal_w / vid_w, cal_h / vid_h)
            filter_refs = [
                r.model_copy(update={"image_x": r.image_x / to_calib_scale[0], "image_y": r.image_y / to_calib_scale[1]})
                for r in filter_refs
            ]
    else:
        calibration_meta, homography, camera_pose = _cached_calibration_meta(
            season=request.season,
            video_path=str(src),
            calibration=request.calibration,
        )
        calibration_meta["calibration_source"] = {"type": "request"}
        filter_refs = request.calibration.manual_references

    camera = CameraModel.from_calibration(calibration_meta, to_calib_scale)
    if camera is not None:
        # Lineup is always fetched so every team gets a file, even if not identified.
        team_lineup, lineup_note = await _match_lineup(request.match_key)
        layout_text = (
            (stored.get("calibration_request") or {}).get("apriltag_layout_text", "")
            if stored is not None
            else request.calibration.apriltag_layout_text
        )
        dims = parse_layout_field_dimensions(layout_text) if (layout_text or "").strip() else None
        field_dims = tuple(dims or _DEFAULT_FIELD_DIMS)
        tag_transform = str(calibration_meta.get("tag_layout_transform") or "none")
        terrain = FieldTerrain.from_registry(request.season, tag_transform, *field_dims)
        start = request.tracking_start_sec
        end = request.tracking_end_sec or start + (request.auto_seconds or auto_seconds_default)
        auto_start = None
        if request.align_auto_start:
            # The clock counts down the real auto length, not the requested window.
            auto_len = float(request.auto_seconds or auto_seconds_default)
            auto_start = await run_in_threadpool(
                partial(find_auto_start, str(src), hint_sec=start, auto_len=auto_len)
            )
            if auto_start is not None:
                auto_start["hint_sec"] = start
                start = auto_start["start_sec"]
                end = start + auto_len
        view_affine = None
        if stored is not None:
            # The broadcast may have moved/resized the wide shot since the calibration frame.
            shift = await run_in_threadpool(
                partial(
                    estimate_view_affine,
                    stored,
                    str(src),
                    [start + 1.0, (start + end) / 2, end - 1.0],
                    to_calib_scale,
                    field_dims,
                )
            )
            if shift is not None:
                view_affine = shift.pop("affine")
                calibration_meta["calibration_source"]["view_shift"] = shift
                camera = CameraModel.from_calibration(calibration_meta, to_calib_scale, view_affine)
        terrain.build_visibility(camera)
        run_id = uuid.uuid4().hex
        result = await run_in_threadpool(
            partial(
                run_field_tracking,
                video_path=str(src),
                camera=camera,
                terrain=terrain,
                tracking_start_sec=start,
                tracking_end_sec=end,
                target_alliance=request.target_alliance,
                target_robot_position=request.target_robot_position,
                lock_window_sec=request.lock_window_sec,
                forced_track_id=request.forced_track_id,
                person_model=yolo_model,
                robot_model=detector_training.tracking_models(request.season),
                # Thorough (re-scout): twice the frame rate, twice the bumper reads.
                process_hz=settings.track_hz * (2 if request.thorough else 1),
                ocr_frames=24 if request.thorough else 12,
                save_run_to=_runs_dir() / f"{run_id}.json",
                run_context={
                    "season": request.season,
                    "match_key": request.match_key,
                    "calibration_meta": calibration_meta,
                    "to_calib_scale": list(to_calib_scale),
                    "view_affine": view_affine,
                    "field_dims": list(field_dims),
                    "tag_layout_transform": tag_transform,
                    "auto_start": auto_start,
                },
                team_lineup=team_lineup if request.auto_identify_teams else None,
                team_gallery=partial(detector_training.team_gallery, request.season, request.match_key),
                training_frames_dir=(
                    Path(settings.dataset_dir) / str(request.season) if settings.collect_training_frames else None
                ),
            )
        )
        samples = result["samples"]
        points = _trajectory_points(samples)
        image_points = [
            ImageTrackPoint(
                t_sec=s["t_sec"], px=s["px"], py=s["py"], confidence=s["confidence"], inferred=not s["observed"]
            )
            for s in samples
            if s.get("px") is not None and s.get("py") is not None
        ]
        path = result["path"]
        dumped = [p.model_dump() for p in points]
        robots, output_files, team_files = _export_robots(
            request.match_key,
            run_id,
            result.get("robots", []),
            {
                "tracking_start_sec": start,
                "tracking_end_sec": end,
                "auto_start_source": auto_start["method"] if auto_start else "video_start",
                "field_dims_m": list(field_dims),
                "field_transform": tag_transform,
            },
            lineup=team_lineup,
        )
        try:  # new autos: the scout has to check them again
            rescout.set_good(request.match_key, False)
        except ValueError:
            pass
        shared_matches.wake()
        await run_in_threadpool(detector_training.prune_frames, request.season)
        firebase = await _upload_firebase(request.match_key, team_files) if request.upload_firebase else None
        team_identification = (result.get("team_identification") if request.auto_identify_teams else None) or (
            {"note": lineup_note} if lineup_note else None
        )
        quality = build_quality_report(points=dumped, track_meta=result["meta"], path_summary=path["summary"])
        return ProcessResult(
            match_key=request.match_key,
            trajectory_points=points,
            image_track_points=image_points,
            path=path,
            output_files=output_files,
            quality_report=quality,
            calibration_meta=calibration_meta,
            run_id=run_id,
            robots=robots,
            tracklets=result.get("tracklets", []),
            field_dims=list(field_dims),
            field_occlusion=terrain.view_geometry(),
            team_identification=team_identification,
            firebase=firebase,
            tracking_start_sec=start,
            auto_start=auto_start,
        )

    # No 3D camera pose (homography-only calibration): legacy 2D blob tracker.
    raw_tracks = run_tracking_pipeline(
        video_path=str(src),
        auto_seconds=request.auto_seconds or auto_seconds_default,
        tracking_start_sec=request.tracking_start_sec,
        tracking_end_sec=request.tracking_end_sec,
        target_alliance=request.target_alliance,
        target_robot_position=request.target_robot_position,
        tracker_config=request.tracker_config or default_tracker,
        lock_window_sec=request.lock_window_sec,
        yolo_model=yolo_model,
        tracker_conf=tracker_conf,
        tracker_iou=tracker_iou,
        max_interp_gap_frames=max_interp_gap_frames,
        forced_track_id=request.forced_track_id,
    )

    raw_tracks = _filter_raw_track_points(
        raw_tracks=raw_tracks,
        manual_refs=filter_refs,
    )

    projection_tracks = raw_tracks
    if to_calib_scale != (1.0, 1.0):
        projection_tracks = _scale_track_points(raw_tracks, *to_calib_scale)
    projected = project_track_to_field(projection_tracks, camera_pose, homography)
    points = [TrajectoryPoint(**p) for p in projected]
    image_points = [ImageTrackPoint(**p) for p in raw_tracks.get("points", [])]

    output_files = export_csv_json(match_key=request.match_key, points=[p.model_dump() for p in points])
    quality = build_quality_report(points=[p.model_dump() for p in points], track_meta=raw_tracks.get("meta", {}))

    return ProcessResult(
        match_key=request.match_key,
        trajectory_points=points,
        image_track_points=image_points,
        output_files=output_files,
        quality_report=quality,
        calibration_meta=calibration_meta,
    )


@router.post("/assign-robots", response_model=AssignRobotsResult)
async def assign_robots(request: AssignRobotsRequest) -> AssignRobotsResult:
    """Rebuild the 6 robots from user-chosen tracklets and team numbers (no re-tracking)."""
    run_file = _runs_dir() / f"{request.run_id}.json"  # run_id is validated as 32 hex chars
    if not run_file.is_file():
        raise HTTPException(status_code=404, detail="Tracking run not found; process the match again.")
    ids = [r.robot_id for r in request.robots]
    if len(set(ids)) != len(ids):
        raise HTTPException(status_code=400, detail="Each robot slot may appear only once.")
    teams = [r.team_key for r in request.robots if r.team_key]
    if len(set(teams)) != len(teams):
        raise HTTPException(status_code=400, detail="The same team is assigned to two robots.")
    seen: dict[int, str] = {}
    for r in request.robots:
        for tid in r.track_ids:
            if seen.setdefault(tid, r.robot_id) != r.robot_id:
                raise HTTPException(status_code=400, detail=f"Tracklet {tid} is in both {seen[tid]} and {r.robot_id}.")

    def work() -> tuple[list[dict], list[str], dict, dict, dict]:
        ctx = read_run_context(run_file)
        camera = CameraModel.from_run_context(ctx)
        terrain = FieldTerrain.from_registry(ctx["season"], ctx["tag_layout_transform"], *ctx["field_dims"])
        terrain.build_visibility(camera)
        run = load_run(run_file, terrain)
        robots, warnings = assign_tracklets(
            run, camera=camera, terrain=terrain, assignments=[a.model_dump() for a in request.robots]
        )
        return robots, warnings, run, ctx, terrain.view_geometry()

    robots, warnings, run, ctx, occlusion = await run_in_threadpool(work)
    meta = {
        "tracking_start_sec": run["meta"].get("tracking_start_sec"),
        "tracking_end_sec": run["meta"].get("tracking_end_sec"),
        "field_dims_m": ctx["field_dims"],
        "field_transform": ctx.get("tag_layout_transform") or "none",
    }
    lineup = None
    try:
        prev = json.loads((team_paths_dir(request.match_key).parent / "robots.json").read_text(encoding="utf-8"))
        lineup = prev.get("lineup")
    except (OSError, ValueError):
        pass
    if lineup is None:
        lineup, _ = await _match_lineup(request.match_key)
    robots, output_files, team_files = _export_robots(request.match_key, request.run_id, robots, meta, lineup=lineup)
    firebase = await _upload_firebase(request.match_key, team_files)
    owner = {tid: r["robot_id"] for r in robots for tid in r["track_ids"]}
    tracklets = [
        _tracklet_summary(tr, run["t0"], owner.get(tr.id)) for tr in run["tracker"].tracks if tr.robot_like()
    ]
    tracklets.sort(key=lambda t: t["first_t_sec"])
    return AssignRobotsResult(
        run_id=request.run_id,
        match_key=request.match_key,
        robots=robots,
        tracklets=tracklets,
        output_files=output_files,
        warnings=warnings,
        field_occlusion=occlusion,
        firebase=firebase,
    )


@router.post("/calibrate", response_model=CalibrateResult)
async def calibrate(request: CalibrateRequest) -> CalibrateResult:
    src = Path(request.video_path)
    if not src.exists():
        raise HTTPException(status_code=404, detail="Uploaded video path not found")
    if (request.event_key or "").strip():
        try:
            normalize_event_key(request.event_key)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Keep the latest request so calibration issues can be reproduced offline.
    debug_dir = Path(settings.output_dir) / "debug"
    debug_dir.mkdir(parents=True, exist_ok=True)
    (debug_dir / "last_calibrate_request.json").write_text(request.model_dump_json(indent=2), encoding="utf-8")

    calibration_meta, _, _ = _cached_calibration_meta(
        season=request.season,
        video_path=str(src),
        calibration=request.calibration,
    )

    saved_event_key = None
    if (request.event_key or "").strip():
        img_w, img_h = _video_size(str(src))
        try:
            record = save_event_calibration(
                event_key=request.event_key,
                season=request.season,
                video_path=str(src),
                image_width=img_w,
                image_height=img_h,
                calibration_request=request.calibration.model_dump(),
                calibration_meta=calibration_meta,
                reference_frame_jpeg=encode_reference(str(src), request.calibration.frame_sec),
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        saved_event_key = record["event_key"]
        cloud.in_background(cloud.push_calibration, record)

    return CalibrateResult(calibration_meta=calibration_meta, saved_event_key=saved_event_key)


@router.get("/calibrations")
def event_calibrations_list() -> dict:
    return {"calibrations": list_event_calibrations()}


@router.get("/events/{event_key}/calibration")
def event_calibration_get(event_key: str) -> dict:
    record = _load_event_calibration_or_400(event_key)
    if record is None:
        raise HTTPException(status_code=404, detail=f"No saved calibration for event {event_key}")
    return {"summary": summarize_event_calibration(record), "calibration_meta": record["calibration_meta"]}


@router.delete("/events/{event_key}/calibration")
def event_calibration_delete(event_key: str) -> dict:
    try:
        deleted = delete_event_calibration(event_key)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not deleted:
        raise HTTPException(status_code=404, detail=f"No saved calibration for event {event_key}")
    cloud.in_background(cloud.delete_calibration, normalize_event_key(event_key))
    return {"deleted": event_key}


@router.get("/firebase/status")
def firebase_status() -> dict:
    return firebase_store.status()


@router.post("/match/{match_key}/firebase-upload")
async def firebase_upload_match(match_key: str) -> dict:
    """(Re)upload a match's saved team path files to Firestore."""
    if not _MATCH_KEY_RE.fullmatch(match_key or ""):
        raise HTTPException(status_code=400, detail="Invalid match key (example: 2026mibro1_qm3)")
    st = firebase_store.status()
    if not st["configured"]:
        raise HTTPException(status_code=400, detail=f"Firebase not configured: {st['reason']}")
    files = [str(p) for p in team_paths_dir(match_key).glob("*.json")]
    if not files:
        raise HTTPException(status_code=404, detail=f"No team paths saved for {match_key}")
    return await _upload_firebase(match_key, files)


async def _scout_process(params: dict) -> dict:
    result = await process_match(ProcessMatchRequest(**params))
    return {"robots": result.robots, "firebase": result.firebase}


_JOB_ID_RE = re.compile(r"[0-9a-f]{32}")


@router.post("/scout/jobs")
async def scout_job_start(request: ScoutJobRequest) -> dict:
    """Download, draw and store the autos of every match of an event (or one team's matches)."""
    job = await _start_scout(request)
    return {k: v for k, v in job.items() if k != "cancel_requested"}


async def _start_scout(request: ScoutJobRequest) -> dict:
    tba_auth_key = _require_tba_key()
    if _load_event_calibration_or_400(request.event_key) is None:
        raise HTTPException(
            status_code=400,
            detail=f"No saved calibration for {request.event_key}. Calibrate one match video of this event first.",
        )
    if request.upload_firebase and not firebase_store.status()["configured"]:
        request = request.model_copy(update={"upload_firebase": False})
    running = scout_jobs.active_job()
    if running is not None:
        raise HTTPException(
            status_code=409,
            detail=f"Already scouting {running['event_key']}. Stop that run first.",
        )
    detector_training.yield_to_scouting()
    return scout_jobs.start_job(request, tba_auth_key, _scout_process)


async def _start_remote_scout(params: dict) -> dict:
    """A scout run another team computer sent here (see ``devices``)."""
    return await _start_scout(ScoutJobRequest(**params))


devices.set_scout_starter(_start_remote_scout)


@router.get("/scout/jobs")
def scout_job_list() -> dict:
    keys = ("job_id", "status", "event_key", "team_key", "live", "total", "completed", "current", "created_at")
    return {"jobs": [{k: job.get(k) for k in keys} for job in scout_jobs.list_jobs()]}


@router.get("/scout/jobs/{job_id}")
def scout_job_get(job_id: str) -> dict:
    job = scout_jobs.get_job(job_id) if _JOB_ID_RE.fullmatch(job_id) else None
    if job is None:
        raise HTTPException(status_code=404, detail="Scout job not found")
    return {k: v for k, v in job.items() if k != "cancel_requested"}


@router.post("/scout/jobs/{job_id}/cancel")
def scout_job_cancel(job_id: str) -> dict:
    if not (_JOB_ID_RE.fullmatch(job_id) and scout_jobs.cancel_job(job_id)):
        raise HTTPException(status_code=404, detail="No running scout job with that id")
    for remote_id in (scout_jobs.get_job(job_id).get("pool") or {}).get("remote_jobs") or []:
        cloud.quietly(devices.cancel_remote, remote_id)  # All-GPUs run: stop the other computers too
    return {"job_id": job_id, "cancel_requested": True}


@router.get("/system")
async def system_info() -> dict:
    """Compute device used for tracking, OCR and training."""
    return {"gpu": await run_in_threadpool(gpu_info)}


@router.get("/detector/status")
def detector_status(season: int) -> dict:
    if not 1992 <= season <= 2100:
        raise HTTPException(status_code=400, detail="Invalid season")
    return detector_training.status(season)


@router.post("/detector/train")
async def detector_train(request: DetectorTrainRequest) -> dict:
    """Collect training pictures (optionally for good-marked matches that have none) and train the robot detector."""
    if detector_training.busy():
        raise HTTPException(status_code=409, detail="The detector job is already running")
    if scout_jobs.active_job() is not None:
        raise HTTPException(status_code=409, detail="A scout run is using the GPU. Wait for it or stop it first.")
    if not request.train and not request.backfill:
        raise HTTPException(status_code=400, detail="Nothing to do")
    tba_auth_key = _require_tba_key() if request.backfill else ""
    detector_training.start(
        request.season,
        train=request.train,
        backfill=request.backfill,
        tba_auth_key=tba_auth_key,
        epochs=request.epochs,
    )
    return detector_training.status(request.season)


@router.post("/detector/cancel")
def detector_cancel() -> dict:
    if not detector_training.cancel():
        raise HTTPException(status_code=404, detail="No detector job running")
    return {"cancel_requested": True}


@router.post("/detector/use")
def detector_use(request: DetectorUseRequest) -> dict:
    try:
        detector_training.set_enabled(request.season, request.enabled)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return detector_training.status(request.season)


_EVENT_KEY_RE = re.compile(r"[0-9]{4}[a-z0-9]{1,16}")
_LEVEL_ORDER = {"qm": 0, "ef": 1, "qf": 2, "sf": 3, "f": 4}


@router.get("/season/{season}/events")
async def season_events(season: int) -> dict:
    if not 1992 <= season <= 2100:
        raise HTTPException(status_code=400, detail="Invalid season")
    tba_auth_key = _require_tba_key()
    events = await get_season_events(season, tba_auth_key)
    keys = ("key", "name", "start_date", "end_date", "city", "state_prov", "country")
    return {"events": [{k: e.get(k) for k in keys} for e in events]}


@router.get("/match/{match_key}/autos")
def match_autos(match_key: str) -> dict:
    """Saved autos of all teams in a match (compact, for the gallery)."""
    if not _MATCH_KEY_RE.fullmatch(match_key or ""):
        raise HTTPException(status_code=400, detail="Invalid match key (example: 2026mibro1_qm3)")
    teams = read_match_autos(match_key)
    return {
        "match_key": match_key,
        "teams": teams,
        "rescout": rescout.get_tag(match_key),
        "good": rescout.is_good(match_key),
        "camera_high_y": _camera_high_y(match_key, teams),
    }


@router.get("/match/{match_key}/ground-truth")
async def ground_truth_session(match_key: str) -> dict:
    """Keyframes, tracker suggestions and saved labels for checking robot positions by hand."""
    _check_match_key(match_key)
    if ground_truth.load(match_key) is None:  # checked on another team computer?
        await run_in_threadpool(cloud.quietly, cloud.pull_ground_truth, match_key)
    video = ground_truth.find_video(match_key)
    if video is None:
        tba_auth_key = _require_tba_key()
        event_key = parse_match_key(match_key)["event_key"]
        try:
            matches = await get_event_matches(event_key, tba_auth_key)
        except httpx.HTTPStatusError as exc:
            raise HTTPException(status_code=502, detail=f"TBA returned {exc.response.status_code} for {event_key}") from exc
        match = next((m for m in matches if m.get("key") == match_key), None)
        if match is None:
            raise HTTPException(status_code=404, detail=f"{match_key} not found on The Blue Alliance")
        try:
            video = await run_in_threadpool(ground_truth.ensure_video, match_key, match)
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Could not download the video: {exc}") from exc
    try:
        data = await run_in_threadpool(ground_truth.session, match_key, video)
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    training = await run_in_threadpool(detector_training.checked_status, match_key)
    if training.get("ready") and not training["pictures"] and not training["pending"]:
        # checked on another computer (or before pictures existed): make them now that the video is here
        detector_training.queue_checked_frames(match_key)
        training["pending"] = True
    return {**data, "training": training}


@router.get("/match/{match_key}/ground-truth/frame")
async def ground_truth_frame(match_key: str, t_sec: float) -> Response:
    _check_match_key(match_key)
    video = ground_truth.find_video(match_key)
    if video is None:
        raise HTTPException(status_code=404, detail="Open the match for checking first (downloads its video)")
    try:
        jpeg = await run_in_threadpool(ground_truth.frame_jpeg, video, t_sec)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return Response(content=jpeg, media_type="image/jpeg", headers={"Cache-Control": "max-age=3600"})


@router.post("/match/{match_key}/ground-truth")
async def ground_truth_save(match_key: str, payload: dict) -> dict:
    """Save hand-placed robot positions and score the match's saved autos against them."""
    _check_match_key(match_key)
    if not isinstance(payload.get("labels"), dict) or payload.get("start_sec") is None or payload.get("end_sec") is None:
        raise HTTPException(status_code=400, detail="labels, start_sec and end_sec are required")
    try:
        await run_in_threadpool(ground_truth.save, match_key, payload)
        cloud.in_background(cloud.push_ground_truth, ground_truth.load(match_key))
        detector_training.queue_checked_frames(match_key)
        result = await run_in_threadpool(ground_truth.score_saved, match_key)
    except (FileNotFoundError, ValueError, KeyError, TypeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    # A finished check becomes the match's autos (paths = the clicks).
    files = await run_in_threadpool(ground_truth.apply_to_autos, match_key)
    firebase_error = None
    if files:
        if firebase_store.status()["configured"]:
            try:
                await _upload_firebase(match_key, files)
            except Exception as exc:  # saved locally either way
                firebase_error = str(exc)
        event_key = parse_match_key(match_key)["event_key"]
        await run_in_threadpool(scout_jobs.compile_team_autos, event_key, event_scouted_matches(event_key)["matches"])
        shared_matches.wake()
    return {
        **result,
        "training": await run_in_threadpool(detector_training.checked_status, match_key),
        "autos_updated": len(files),
        "firebase_error": firebase_error,
    }


@router.get("/season/{season}/tracking-accuracy")
async def tracking_accuracy(season: int) -> dict:
    """Accuracy of the saved autos on every match whose robot positions were checked by hand."""
    if not 1992 <= season <= 2100:
        raise HTTPException(status_code=400, detail="Invalid season")
    return await run_in_threadpool(ground_truth.season_score, season)


def _camera_high_y(match_key: str, teams: list[dict]) -> bool | None:
    """Whether the event camera films from the field's high-y side (official frame)."""
    event_key = parse_match_key(match_key)["event_key"]
    try:
        stored = load_event_calibration(event_key) if event_key else None
    except (OSError, ValueError):
        stored = None
    meta = (stored or {}).get("calibration_meta") or {}
    pos = ((meta.get("apriltag") or {}).get("camera_pose") or {}).get("camera_position_m")
    if not pos or len(pos) < 2:
        return None
    width = next((float(t["field_dims_m"][1]) for t in teams if t.get("field_dims_m")), _DEFAULT_FIELD_DIMS[1])
    y = float(pos[1])
    if str(meta.get("tag_layout_transform") or "none") in {"flip_y", "rotate_180"}:
        y = width - y
    return y > width / 2


def _check_match_key(match_key: str) -> None:
    if not _MATCH_KEY_RE.fullmatch(match_key or ""):
        raise HTTPException(status_code=400, detail="Invalid match key (example: 2026mibro1_qm3)")


def _check_event_key(event_key: str) -> None:
    if not _EVENT_KEY_RE.fullmatch(event_key or ""):
        raise HTTPException(status_code=400, detail="Invalid event key (example: 2026mibro1)")


@router.get("/events/{event_key}/rescout")
def event_rescout_tags(event_key: str) -> dict:
    """Matches tagged for re-scouting."""
    _check_event_key(event_key)
    return {"event_key": event_key, "matches": rescout.list_tags(event_key)}


@router.post("/match/{match_key}/rescout")
def match_rescout_tag(match_key: str, request: RescoutTagRequest | None = None) -> dict:
    """Tag a match for re-scouting."""
    _check_match_key(match_key)
    tag = rescout.set_tag(match_key, (request.reason if request else None), source="manual")
    shared_matches.wake()
    return {"match_key": match_key, "rescout": tag}


@router.delete("/match/{match_key}/rescout")
def match_rescout_untag(match_key: str) -> dict:
    _check_match_key(match_key)
    rescout.clear_tag(match_key)
    shared_matches.wake()
    return {"match_key": match_key, "rescout": None}


@router.post("/match/{match_key}/good")
async def match_mark_good(match_key: str, request: GoodMarkRequest | None = None) -> dict:
    """Mark a match's autos as checked and right (or take the mark back).

    Good matches teach the robot detector and anchor team auto history."""
    _check_match_key(match_key)
    good = request.good if request else True
    if good and not read_match_autos(match_key):
        raise HTTPException(status_code=404, detail="No saved autos for this match")
    rescout.set_good(match_key, good)
    shared_matches.wake()
    if good:
        detector_training.schedule_auto_train(int(match_key[:4]))
    return {"match_key": match_key, "good": good, "rescout": rescout.get_tag(match_key)}


@router.post("/match/{match_key}/swap-teams")
async def match_swap_teams(match_key: str, request: SwapTeamsRequest) -> dict:
    """Swap two teams' paths in a match's saved autos (same alliance), instead of re-scouting."""
    _check_match_key(match_key)
    a, b = _normalize_team_key(request.team_a), _normalize_team_key(request.team_b)
    if a == b:
        raise HTTPException(status_code=400, detail="Pick two different teams")
    gt = ground_truth.load(match_key)
    checked = bool(gt and gt.get("complete") and {a, b} <= {t.get("team_key") for t in gt.get("teams") or []})
    try:
        if checked:  # the autos are the hand check's clicks: swap those
            files = await run_in_threadpool(ground_truth.swap_teams, match_key, a, b)
        else:
            files = await run_in_threadpool(team_history.swap_teams, match_key, a, b)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if checked:
        cloud.in_background(cloud.push_ground_truth, ground_truth.load(match_key))
        detector_training.queue_checked_frames(match_key)
    firebase_error = None
    if firebase_store.status()["configured"]:
        try:
            await _upload_firebase(match_key, files)
        except Exception as exc:  # saved locally either way
            firebase_error = str(exc)
    event_key = parse_match_key(match_key)["event_key"]
    await run_in_threadpool(scout_jobs.compile_team_autos, event_key, event_scouted_matches(event_key)["matches"])
    shared_matches.wake()
    return {**match_autos(match_key), "firebase_error": firebase_error}


@router.post("/events/{event_key}/team-history")
async def event_team_history(event_key: str) -> dict:
    """Fix team mix-ups across the event's saved autos using each team's auto history."""
    _check_event_key(event_key)
    running = scout_jobs.active_job()
    if running is not None and running["event_key"] == event_key:
        raise HTTPException(status_code=409, detail="Scouting this event right now; it already does this after every match.")
    summary = await run_in_threadpool(team_history.refine_event, event_key)
    firebase = {}
    if firebase_store.status()["configured"]:
        for mk, files in summary["updated_files"].items():
            try:
                firebase[mk] = await _upload_firebase(mk, files)
            except Exception as exc:  # files are saved locally either way
                firebase[mk] = {"error": str(exc)}
    tags = await run_in_threadpool(rescout.auto_tag_event, event_key)
    match_keys = event_scouted_matches(event_key)["matches"]
    await run_in_threadpool(scout_jobs.compile_team_autos, event_key, match_keys)
    shared_matches.wake()
    return {
        "event_key": event_key,
        "symmetry": summary["symmetry"],
        "teams_modelled": summary["teams_modelled"],
        "changes": summary["changes"],
        "updated_matches": sorted(summary["updated_files"]),
        "rescout": tags,
        "firebase": {mk: bool(v) and "error" not in v for mk, v in firebase.items()},
    }


@router.get("/events/{event_key}/scouted-matches")
def event_scouted_matches(event_key: str) -> dict:
    """Match keys of this event that have saved autos."""
    if not _EVENT_KEY_RE.fullmatch(event_key or ""):
        raise HTTPException(status_code=400, detail="Invalid event key (example: 2026mibro1)")
    keys = [
        d.name
        for d in Path(settings.output_dir).glob(f"{event_key}_*")
        if _MATCH_KEY_RE.fullmatch(d.name) and any((d / "teams").glob("*.json"))
    ]

    def sort_key(k: str) -> tuple:
        info = parse_match_key(k)
        return (_LEVEL_ORDER.get(info["comp_level"], 9), info["set_number"] or 0, info["match_number"] or 0, k)

    return {"event_key": event_key, "matches": sorted(keys, key=sort_key)}


@router.get("/events/{event_key}/scouted-matches/versions")
def event_scouted_versions(event_key: str) -> dict:
    """A token per scouted match that changes when its autos or marks change (here or from another computer)."""
    keys = event_scouted_matches(event_key)["matches"]
    return {"event_key": event_key, "matches": keys, "versions": shared_matches.versions(keys)}


@router.post("/events/{event_key}/sample-video")
async def event_sample_video(event_key: str) -> dict:
    """Download one match video of the event so it can be used for calibration."""
    if not _EVENT_KEY_RE.fullmatch(event_key or ""):
        raise HTTPException(status_code=400, detail="Invalid event key (example: 2026mibro1)")
    tba_auth_key = _require_tba_key()
    try:
        matches = await get_event_matches(event_key, tba_auth_key)
    except httpx.HTTPStatusError as exc:
        raise HTTPException(status_code=502, detail=f"TBA returned {exc.response.status_code} for {event_key}") from exc
    matches.sort(
        key=lambda m: (_LEVEL_ORDER.get(m.get("comp_level"), 9), m.get("set_number") or 0, m.get("match_number") or 0)
    )
    for m in matches:
        video = scout_jobs.youtube_video(m)
        if video is None:
            continue
        try:
            path = await run_in_threadpool(scout_jobs.download_video, video[0], f"{m['key']}_calibration")
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Could not download {m['key']}: {exc}") from exc
        return {"video_path": path, "match_key": m["key"], "start_hint_sec": video[1]}
    raise HTTPException(status_code=404, detail=f"No match videos on The Blue Alliance for {event_key} yet")
