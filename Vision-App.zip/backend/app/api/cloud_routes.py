"""Team cloud: Google sign-in and syncing with the other team computers."""

from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel

from app.core import access
from app.services import cloud, detector_training, scout_jobs

router = APIRouter(prefix="/cloud")


class SessionRequest(BaseModel):
    id_token: str
    refresh_token: str = ""


@router.get("/status")
def cloud_status(request: Request) -> dict:
    st = cloud.status()
    local = access.is_local(request)
    user = st["email"] if local else access.session_email(request)
    out = {"configured": st["configured"], "web_config": st["web_config"], "local": local, "signed_in": bool(user), "email": user}
    if local or user:
        out["computer_email"] = st["email"]
        out["last_sync"] = st["last_sync"]
    return out


@router.post("/session")
async def cloud_session(body: SessionRequest, request: Request, response: Response) -> dict:
    """Local: this computer syncs as the account. Remote: a browser session for this user."""
    from google.auth.exceptions import GoogleAuthError

    local = access.is_local(request)
    if local and not body.refresh_token:
        raise HTTPException(status_code=400, detail="refresh_token is required")
    try:
        if local:
            await run_in_threadpool(cloud.sign_in, body.id_token, body.refresh_token)
            return cloud_status(request)
        claims = await run_in_threadpool(cloud.verify_user, body.id_token)
        await run_in_threadpool(cloud.check_member, body.id_token)
    except cloud.NotAllowed as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except (ValueError, GoogleAuthError) as exc:
        raise HTTPException(status_code=401, detail=f"Sign-in was not accepted: {exc}") from exc
    except Exception as exc:  # Firestore unreachable etc.
        raise HTTPException(status_code=502, detail=f"Could not reach the team cloud: {exc}") from exc
    response.set_cookie(
        access.COOKIE,
        access.new_session(claims["email"]),
        max_age=access.SESSION_SEC,
        httponly=True,
        samesite="strict",
        secure=access.is_public(request) or request.url.scheme == "https",
        path="/",
    )
    return {"signed_in": True, "email": claims["email"], "local": False}


@router.post("/sign-out")
def cloud_sign_out(request: Request, response: Response) -> dict:
    access.end_session(request)
    response.delete_cookie(access.COOKIE, path="/")
    if access.is_local(request):
        cloud.sign_out()
    return {"signed_in": False}


@router.post("/sync")
async def cloud_sync(season: int | None = None) -> dict:
    season = season or dt.date.today().year
    if not 1992 <= season <= 2100:
        raise HTTPException(status_code=400, detail="Invalid season")
    if not cloud.signed_in():
        raise HTTPException(status_code=400, detail="This computer is not signed in to the team cloud")
    # Sharing may need the GPU (team looks); leave it alone while scouting or training.
    push = scout_jobs.active_job() is None and not detector_training.busy()
    return await run_in_threadpool(cloud.sync, season, push=push)
