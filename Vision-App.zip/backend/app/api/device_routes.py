"""Team computers: who is on, what each is doing, and scout runs sent to another computer's GPU."""

from __future__ import annotations

import logging
import re
import time
import uuid

from fastapi import APIRouter, HTTPException
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.models.schemas import ScoutJobRequest
from app.services import cloud, devices

router = APIRouter()
log = logging.getLogger(__name__)

_ID_RE = re.compile(r"[0-9a-f]{32}")
_CACHE_SEC = 15.0  # several open pages share one Firestore read
_cache: dict[str, tuple[float, object]] = {}


class DeviceSettings(BaseModel):
    accept_remote: bool


class RemoteJobRequest(BaseModel):
    device_id: str = Field(pattern=r"^[0-9a-f]{32}$")
    request: ScoutJobRequest


async def _cached(key: str, fn, *args):
    hit = _cache.get(key)
    if hit and time.monotonic() - hit[0] < _CACHE_SEC:
        return hit[1]
    value = await run_in_threadpool(fn, *args)
    _cache[key] = (time.monotonic(), value)
    return value


def _cloud_error(exc: Exception) -> HTTPException:
    return HTTPException(status_code=502, detail=f"Could not reach the team cloud: {exc}")


@router.get("/devices")
async def devices_list(jobs: bool = False) -> dict:
    """Every team computer, with its GPU, load and current work (this one first)."""
    out = {"this_device": devices.device_id(), "accept_remote": devices.accepts_remote(), "signed_in": cloud.signed_in()}
    out["devices"], out["error"] = await _cached("devices", devices.list_devices)
    if jobs and out["signed_in"]:
        try:
            out["remote_jobs"] = await run_in_threadpool(devices.my_remote_jobs)
        except Exception as exc:
            out["error"] = str(exc)
    return out


@router.post("/devices/settings")
async def devices_settings(body: DeviceSettings) -> dict:
    devices.set_accept_remote(body.accept_remote)
    _cache.pop("devices", None)
    return {"accept_remote": devices.accepts_remote()}


@router.post("/scout/pool")
async def scout_pool_start(body: ScoutJobRequest) -> dict:
    """Scout on this computer and every team computer that shares its GPU; each takes
    the next match nobody has yet (see ``scout_pool``)."""
    if not cloud.signed_in():
        raise HTTPException(status_code=400, detail="Sign in to the team cloud first.")
    _cache.pop("devices", None)
    try:
        found, _ = await run_in_threadpool(devices.list_devices)
    except Exception as exc:
        raise _cloud_error(exc) from exc
    helpers = [d for d in found if not d["this"] and d["online"] and d.get("accept_remote")]
    if not helpers:
        raise HTTPException(status_code=409, detail="No other team computer is sharing its GPU right now.")
    request = body.model_copy(update={"pool_id": uuid.uuid4().hex}).model_dump()
    job = await devices.start_scout(request)  # this computer first: it checks calibration etc.
    # The other computers read this event's calibration from the team cloud.
    await run_in_threadpool(cloud.quietly, cloud.sync_calibrations)
    sent, names = [], []
    for d in helpers:
        try:
            sent.append(await run_in_threadpool(devices.queue_remote, d, request))
            names.append(d.get("name") or d["id"])
        except Exception as exc:  # that computer just doesn't help
            log.warning("All-GPUs run: could not send to %s: %s", d.get("name"), exc)
    job["pool"] = {"id": request["pool_id"], "devices": names, "remote_jobs": sent}
    return {k: v for k, v in job.items() if k != "cancel_requested"}


@router.post("/remote-jobs")
async def remote_job_start(body: RemoteJobRequest) -> dict:
    """Send a scout run to another team computer's GPU."""
    if not cloud.signed_in():
        raise HTTPException(status_code=400, detail="Sign in to the team cloud first.")
    if body.device_id == devices.device_id():
        raise HTTPException(status_code=400, detail="That is this computer; start the run normally.")
    _cache.pop("devices", None)
    try:
        target = await run_in_threadpool(devices.get_device, body.device_id)
        if target is None:
            raise HTTPException(status_code=404, detail="Unknown team computer.")
        if not target["online"]:
            raise HTTPException(status_code=409, detail=f"{target.get('name')} is off or not signed in.")
        if not target.get("accept_remote"):
            raise HTTPException(status_code=409, detail=f"{target.get('name')} does not let other computers use its GPU.")
        # The other computer reads this event's calibration from the team cloud.
        await run_in_threadpool(cloud.quietly, cloud.sync_calibrations)
        jid = await run_in_threadpool(devices.queue_remote, target, body.request.model_dump())
    except HTTPException:
        raise
    except Exception as exc:
        raise _cloud_error(exc) from exc
    return await remote_job_get(jid)


@router.get("/remote-jobs/{job_id}")
async def remote_job_get(job_id: str) -> dict:
    """The remote run in the same shape as a local scout job, plus ``remote``."""
    if not _ID_RE.fullmatch(job_id):
        raise HTTPException(status_code=404, detail="Remote job not found")
    try:
        doc = await _cached(f"job:{job_id}", devices.remote_job, job_id)
    except Exception as exc:
        raise _cloud_error(exc) from exc
    if doc is None:
        raise HTTPException(status_code=404, detail="Remote job not found")
    job = doc.get("job") or {}
    req = doc.get("request") or {}
    status = doc.get("status")
    if status == "queued" and doc.get("cancel_requested"):
        status = "cancelled"
    elif status in {"queued", "claimed", "waiting"}:
        status = "queued"
    elif status in devices.REMOTE_ACTIVE:
        status = job.get("status") or status
    return {
        "event_key": req.get("event_key"),
        "team_key": req.get("team_key"),
        "live": bool(req.get("live")),
        "total": 0,
        "completed": 0,
        "current": None,
        "matches": [],
        **job,
        "job_id": job_id,
        "status": status,
        "error": doc.get("error") or job.get("error"),
        "remote": {
            "device_id": doc.get("target"),
            "device_name": doc.get("target_name"),
            "status": doc.get("status"),
            "stale": doc.get("stale"),
            "updated_at": doc.get("updated_at"),
            "cancel_requested": bool(doc.get("cancel_requested")),
        },
    }


@router.post("/remote-jobs/{job_id}/cancel")
async def remote_job_cancel(job_id: str) -> dict:
    if not _ID_RE.fullmatch(job_id):
        raise HTTPException(status_code=404, detail="Remote job not found")
    try:
        found = await run_in_threadpool(devices.cancel_remote, job_id)
    except Exception as exc:
        raise _cloud_error(exc) from exc
    if not found:
        raise HTTPException(status_code=404, detail="Remote job not found")
    _cache.pop(f"job:{job_id}", None)
    return {"job_id": job_id, "cancel_requested": True}
