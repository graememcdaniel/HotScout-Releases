import asyncio
import datetime as dt
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.cloud_routes import router as cloud_router
from app.api.device_routes import router as device_router
from app.api.routes import router as api_router
from app.core import access, public_gateway
from app.core.config import settings
from app.core.gpu import gpu_info
from app.services import cloud, devices, shared_matches

# Code and data may live apart (installed copies run inside their data folder).
FRONTEND_DIR = Path(__file__).resolve().parents[2] / "frontend"

@asynccontextmanager
async def lifespan(_app: FastAPI):
    info = await run_in_threadpool(gpu_info)
    log = logging.getLogger("uvicorn.error")
    if info["device"] == "cpu":
        log.warning("Compute device: CPU. %s", info.get("warning", ""))
    else:
        log.info("Compute device: %s = %s (%.1f GB)", info["device"], info["name"], info["memory_gb"])
    # Latest team detector, looks, calibrations and hand checks; in the background.
    # Also shares a newer local model whose upload failed earlier.
    asyncio.get_running_loop().run_in_executor(None, cloud.push_quietly, dt.date.today().year)
    # Heartbeat for the other team computers; runs scout jobs they send here (if allowed).
    team_task = asyncio.create_task(devices.run_forever())
    # Every computer's scouted matches (autos, good marks, re-scout tags).
    shared_task = asyncio.create_task(shared_matches.run_forever())
    web = public_gateway.start(_app, settings.public_port) if settings.public_port else None
    if web:
        log.info("Web address listener on 127.0.0.1:%d (sign-in required)", settings.public_port)
    yield
    team_task.cancel()
    shared_task.cancel()
    await run_in_threadpool(devices.mark_stopped)
    if web:
        server, task = web
        server.should_exit = True
        await task


app = FastAPI(title="FRC Vision Path Tracer", version="0.1.0", lifespan=lifespan)


@app.middleware("http")
async def require_team_sign_in(request: Request, call_next):
    path = request.url.path
    if path.startswith("/api/"):
        if not access.same_origin(request):
            return JSONResponse({"detail": "Cross-site request refused"}, status_code=403)
        if path not in access.OPEN_PATHS and not access.allowed(request):
            return JSONResponse({"detail": "Sign in with a team Google account first."}, status_code=401)
        return await call_next(request)
    response = await call_next(request)
    # App files: always ask the server (cheap ETag check), so an update never runs with an old app.js.
    response.headers.setdefault("Cache-Control", "no-cache")
    return response


app.include_router(cloud_router, prefix="/api")
app.include_router(device_router, prefix="/api")
app.include_router(api_router, prefix="/api")
app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")
