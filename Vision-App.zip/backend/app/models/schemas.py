from typing import Any

from pydantic import BaseModel, Field


class MatchRequest(BaseModel):
    season: int
    event_key: str
    team_key: str
    match_key: str
    target_alliance: str
    target_robot_position: int


class CalibrationReference(BaseModel):
    image_x: float
    image_y: float
    field_x_m: float
    field_y_m: float
    field_z_m: float = 0.0


class AprilTagReference(BaseModel):
    id: int
    field_x_m: float
    field_y_m: float


class ManualTagObservation(BaseModel):
    id: int
    image_x: float
    image_y: float


class ImagePoint(BaseModel):
    image_x: float
    image_y: float


class CalibrationRequest(BaseModel):
    prefer_apriltag: bool = True
    strict_3d_only: bool = True
    manual_references: list[CalibrationReference] = Field(default_factory=list)
    apriltag_layout: list[AprilTagReference] = Field(default_factory=list)
    manual_tag_observations: list[ManualTagObservation] = Field(default_factory=list)
    # Points clicked along straight real-world edges (one list per edge); used to fit lens distortion.
    straight_lines: list[list[ImagePoint]] = Field(default_factory=list)
    apriltag_layout_text: str = ""
    layout_transform: str = "none"
    frame_sec: float = 0.0


class ProcessMatchRequest(BaseModel):
    season: int
    event_key: str
    team_key: str
    match_key: str
    target_alliance: str
    target_robot_position: int
    video_path: str
    tracker_config: str | None = None
    auto_seconds: float | None = None
    tracking_start_sec: float = 0.0
    tracking_end_sec: float | None = None
    lock_window_sec: float = 2.0
    forced_track_id: int | None = None
    use_event_calibration: bool = True
    auto_identify_teams: bool = True
    upload_firebase: bool = True
    # Slower, more careful pass (used when re-scouting a match).
    thorough: bool = False
    # Find the real auto start from the broadcast clock (tracking_start_sec is the hint).
    align_auto_start: bool = True
    calibration: CalibrationRequest = CalibrationRequest()


class CalibrateRequest(BaseModel):
    season: int
    video_path: str
    event_key: str | None = None
    calibration: CalibrationRequest = CalibrationRequest()


class TrajectoryPoint(BaseModel):
    t_sec: float
    x_m: float
    y_m: float
    confidence: float
    inferred: bool
    z_m: float | None = None
    sigma_m: float | None = None
    position_confidence: float | None = None
    identity_confidence: float | None = None
    z_source: str | None = None
    track_id: int | None = None


class ImageTrackPoint(BaseModel):
    t_sec: float
    px: float
    py: float
    confidence: float
    inferred: bool


class ProcessResult(BaseModel):
    match_key: str
    trajectory_points: list[TrajectoryPoint]
    image_track_points: list[ImageTrackPoint] = Field(default_factory=list)
    path: dict[str, Any] | None = None
    output_files: dict[str, str]
    quality_report: dict[str, Any]
    calibration_meta: dict[str, Any]
    run_id: str | None = None
    robots: list[dict[str, Any]] = Field(default_factory=list)
    tracklets: list[dict[str, Any]] = Field(default_factory=list)
    field_dims: list[float] | None = None
    field_occlusion: dict[str, Any] | None = None
    team_identification: dict[str, Any] | None = None
    firebase: dict[str, Any] | None = None
    # Video time of tracking t = 0 (the clock-aligned auto start when found).
    tracking_start_sec: float | None = None
    auto_start: dict[str, Any] | None = None


class ScoutJobRequest(BaseModel):
    season: int = Field(ge=1992, le=2100)
    event_key: str = Field(pattern=r"^[0-9]{4}[a-z0-9]{1,16}$")
    team_key: str | None = Field(default=None, pattern=r"^frc[0-9]{1,5}$")
    # Seconds from the start of the TBA/YouTube video to the start of auto.
    tracking_start_sec: float = Field(default=0.0, ge=0.0, le=600.0)
    auto_seconds: float | None = Field(default=None, gt=0.0, le=60.0)
    comp_levels: list[str] = Field(default_factory=lambda: ["qm", "ef", "qf", "sf", "f"])
    keep_videos: bool = False
    upload_firebase: bool = True
    skip_existing: bool = True
    max_matches: int | None = Field(default=None, ge=1, le=500)
    # Live: keep watching TBA for new match videos until the event is over.
    live: bool = False
    live_poll_sec: int = Field(default=120, ge=30, le=1800)
    # Extra passes over failed matches once everything else is done.
    retry_rounds: int = Field(default=2, ge=0, le=5)
    # Only re-scout matches tagged for re-scouting.
    rescout_only: bool = False
    # At the end, re-scout (once) matches whose autos fail the quality checks.
    auto_rescout: bool = False
    # Use every team's auto history to fix which robot is which team.
    use_team_history: bool = True
    # All-GPUs run: computers sharing this id split the matches (see scout_pool).
    pool_id: str | None = Field(default=None, pattern=r"^[0-9a-f]{32}$")


class RescoutTagRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=200)


class GoodMarkRequest(BaseModel):
    good: bool = True


class SwapTeamsRequest(BaseModel):
    team_a: str = Field(max_length=12)
    team_b: str = Field(max_length=12)


class DetectorTrainRequest(BaseModel):
    season: int = Field(ge=1992, le=2100)
    # Also collect pictures for good-marked matches that have none (re-downloads videos).
    backfill: bool = False
    train: bool = True
    epochs: int = Field(default=60, ge=5, le=300)


class DetectorUseRequest(BaseModel):
    season: int = Field(ge=1992, le=2100)
    enabled: bool

class RobotAssignment(BaseModel):
    robot_id: str = Field(pattern=r"^(red|blue)[1-3]$")
    team_key: str | None = Field(default=None, pattern=r"^frc[0-9]{1,5}$")
    track_ids: list[int] = Field(default_factory=list, max_length=500)


class AssignRobotsRequest(BaseModel):
    run_id: str = Field(pattern=r"^[0-9a-f]{32}$")
    match_key: str
    robots: list[RobotAssignment] = Field(min_length=1, max_length=6)


class AssignRobotsResult(BaseModel):
    run_id: str
    match_key: str
    robots: list[dict[str, Any]]
    tracklets: list[dict[str, Any]] = Field(default_factory=list)
    output_files: dict[str, str] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    field_occlusion: dict[str, Any] | None = None
    firebase: dict[str, Any] | None = None


class CalibrateResult(BaseModel):
    calibration_meta: dict[str, Any]
    saved_event_key: str | None = None


class RuntimeConfigUpdate(BaseModel):
    tba_auth_key: str | None = None
    default_tracker: str | None = None
    yolo_model: str | None = None
    tracker_conf: float | None = None
    tracker_iou: float | None = None
    max_interp_gap_frames: int | None = None
    auto_seconds: float | None = None


class RuntimeConfigResponse(BaseModel):
    tba_auth_key: str
    default_tracker: str
    yolo_model: str
    tracker_conf: float
    tracker_iou: float
    max_interp_gap_frames: int
    auto_seconds: float
