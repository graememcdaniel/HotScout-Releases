"""Recognise robots by how they look, from the same robots in earlier matches.

Every robot in a match a scout marked good is a labelled example of its team.
Crops of it are embedded with CLIP (ViT-B/32, image encoder only) and kept as
that team's gallery for the season. A robot in a new match is compared with
the galleries of the teams in its alliance; its bumper colours are greyed out
first so a team's red- and blue-alliance matches look alike.
"""

from __future__ import annotations

import logging
from pathlib import Path
from threading import Lock

import cv2
import numpy as np

log = logging.getLogger(__name__)

APP_WEIGHT = 1.5  # votes for a clear look-alike (a clean OCR read is ~1)
TEMPERATURE = 0.02  # cosine-similarity gap that counts as ~e times more likely
TOP_K = 5
MIN_BOX_H = 36  # px; smaller robots are mostly blur
MAX_PER_TEAM_MATCH = 12
_SIZE = 224
_MEAN = np.array([0.48145466, 0.4578275, 0.40821073], dtype=np.float32)
_STD = np.array([0.26862954, 0.26130258, 0.27577711], dtype=np.float32)
_model = None
_device = "cpu"
_lock = Lock()


def _load():
    global _model, _device
    with _lock:
        if _model is None:
            import clip  # ultralytics' CLIP fork (installed with YOLO-World)

            from app.core.gpu import torch_device

            _device = torch_device()
            _model, _ = clip.load("ViT-B/32", device=_device)
            _model.eval()
        return _model


def release() -> None:
    global _model
    with _lock:
        _model = None


def robot_crop(frame: np.ndarray, box: list[float]) -> np.ndarray | None:
    H, W = frame.shape[:2]
    x1, y1, x2, y2 = box
    if y2 - y1 < MIN_BOX_H:
        return None
    pw, ph = 0.06 * (x2 - x1), 0.06 * (y2 - y1)
    c = frame[int(max(0, y1 - ph)) : int(min(H, y2 + ph)), int(max(0, x1 - pw)) : int(min(W, x2 + pw))]
    return c.copy() if c.size else None


def _prep(crop: np.ndarray) -> np.ndarray:
    from app.tracking.team_id import _colour_mask

    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    img = crop.copy()
    img[(_colour_mask(hsv, "red") | _colour_mask(hsv, "blue")) > 0] = 128
    h, w = img.shape[:2]
    s = max(h, w)
    sq = np.full((s, s, 3), 128, np.uint8)
    sq[(s - h) // 2 : (s - h) // 2 + h, (s - w) // 2 : (s - w) // 2 + w] = img
    rgb = cv2.cvtColor(cv2.resize(sq, (_SIZE, _SIZE), interpolation=cv2.INTER_CUBIC), cv2.COLOR_BGR2RGB)
    return ((rgb.astype(np.float32) / 255.0 - _MEAN) / _STD).transpose(2, 0, 1)


def embed(crops: list[np.ndarray], batch: int = 16) -> np.ndarray:
    """L2-normalised CLIP image embeddings, (N, 512)."""
    if not crops:
        return np.zeros((0, 512), np.float32)
    import torch

    model = _load()
    dtype = next(model.parameters()).dtype
    out = []
    with torch.no_grad():
        for i in range(0, len(crops), batch):
            x = torch.from_numpy(np.stack([_prep(c) for c in crops[i : i + batch]])).to(_device, dtype)
            out.append(model.encode_image(x).float().cpu().numpy())
    e = np.concatenate(out)
    return (e / np.linalg.norm(e, axis=1, keepdims=True).clip(1e-6)).astype(np.float32)


def _clear(box: list[float], others: list[list[float]]) -> bool:
    """Not much of it hidden by another robot's box."""
    for o in others:
        ix = max(0.0, min(box[2], o[2]) - max(box[0], o[0]))
        iy = max(0.0, min(box[3], o[3]) - max(box[1], o[1]))
        if ix * iy > 0.3 * (box[2] - box[0]) * (box[3] - box[1]):
            return False
    return True


def match_embeddings(match_key: str, dataset_root: Path, output_dir: Path, cache_dir: Path) -> tuple[list[str], np.ndarray]:
    """(team key per crop, embeddings) of a good match's labelled frames; cached."""
    from app.tracking import training_data as td

    items, _ = td.match_labels(match_key, dataset_root, output_dir)
    labels_file = dataset_root / "labels" / f"{td.safe_name(match_key)}.json"
    key = labels_file.stat().st_mtime if labels_file.is_file() else None
    cache = cache_dir / f"{td.safe_name(match_key)}.npz"
    if key is not None and cache.is_file():
        try:
            data = np.load(cache, allow_pickle=False)
            if float(data["key"]) == key:
                return [str(t) for t in data["teams"]], data["emb"]
        except (OSError, ValueError, KeyError):
            pass
    teams, crops = [], []
    per_team: dict[str, int] = {}
    for item in items:
        img = cv2.imread(str(td.frames_dir(dataset_root) / item["image"]))
        if img is None:
            continue
        boxes = [r["box"] for r in item["robots"]]
        for r in item["robots"]:
            t = r.get("team_key")
            if not t or per_team.get(t, 0) >= MAX_PER_TEAM_MATCH:
                continue
            if not _clear(r["box"], [b for b in boxes if b is not r["box"]]):
                continue
            c = robot_crop(img, r["box"])
            if c is not None:
                teams.append(t)
                crops.append(c)
                per_team[t] = per_team.get(t, 0) + 1
    emb = embed(crops)
    if key is not None:
        cache_dir.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(cache, key=np.float64(key), teams=np.array(teams, dtype=str), emb=emb)
    return teams, emb


def season_gallery(matches: list[str], dataset_root: Path, output_dir: Path, cache_dir: Path) -> dict[str, np.ndarray]:
    """Team key -> embeddings from the given (good) matches."""
    parts: dict[str, list[np.ndarray]] = {}
    for mk in sorted(matches):
        try:
            teams, emb = match_embeddings(mk, dataset_root, output_dir, cache_dir)
        except Exception as exc:  # one broken match must not stop the rest
            log.warning("appearance gallery: %s skipped (%s)", mk, exc)
            continue
        for t, e in zip(teams, emb):
            parts.setdefault(t, []).append(e)
    return {t: np.stack(v) for t, v in parts.items()}


def similarity(query: np.ndarray, gallery: np.ndarray) -> float:
    """Mean over query crops of the mean of their top-k cosine similarities."""
    if not len(query) or not len(gallery):
        return float("nan")
    s = query @ gallery.T
    k = min(TOP_K, s.shape[1])
    return float(np.sort(s, axis=1)[:, -k:].mean())


def team_votes(embs: list[np.ndarray], teams: list[str], gallery: dict[str, np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    """(votes, similarity) as slots x teams.

    Each team's ``APP_WEIGHT`` votes are shared among the slots by how much more
    each one looks like that team (softmax over slots). Only when every slot
    and team can be compared: otherwise the robot of a team without a gallery
    may simply look most like some other team and take its votes.
    """
    sim = np.full((len(embs), len(teams)), np.nan)
    for i, e in enumerate(embs):
        for k, t in enumerate(teams):
            if t in gallery:
                sim[i, k] = similarity(e, gallery[t])
    votes = np.zeros_like(sim)
    if len(teams) < 2 or np.isnan(sim).any():
        return votes, sim
    # Remove what is common to a row or column (a robot that looks like
    # everything, a gallery that everything looks like).
    c = sim - sim.mean(axis=1, keepdims=True) - sim.mean(axis=0, keepdims=True) + sim.mean()
    z = c / TEMPERATURE
    p = np.exp(z - z.max(axis=0, keepdims=True))
    votes = APP_WEIGHT * p / p.sum(axis=0, keepdims=True)
    return votes, sim
