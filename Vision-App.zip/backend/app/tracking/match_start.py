"""Find the moment autonomous starts in a match video from the broadcast timer.

FIRST broadcasts overlay a match clock that counts the autonomous period
down from its full length, showing ``ceil(remaining)`` seconds. Every clock
reading ``r`` at video time ``t`` therefore bounds the start to
``(t - (L - r) - 1, t - (L - r)]``; intersecting several readings (majority
vote, so OCR misreads drop out) pins the start to a fraction of a second,
independent of how much pre-match footage the video has.

The clock is found anywhere in the frame (top or bottom overlays, split
screens) by OCR of whole frames, and the whole video is searched when the
hinted window has no auto clock. If only the teleop clock is readable, the
start is estimated back from the teleop start.
"""

from __future__ import annotations

import logging
import re

import cv2
import numpy as np

log = logging.getLogger(__name__)

# Known overlay timer boxes, as fractions of the frame (x1, y1, x2, y2), used
# when no clock is found by whole-frame OCR.
_TIMER_BOX = (0.40, 0.78, 0.60, 0.94)
_TOP_BOX = (0.38, 0.0, 0.62, 0.18)
_WIDE_BOX = (0.25, 0.70, 0.75, 1.0)
_CLOCK = re.compile(r"^([0-3])[:.;]?([0-5][0-9])$")
_FIND_CLOCK = re.compile(r"^([0-3])[:.;]([0-5][0-9])$")
_ALLOW = "0123456789:AUTOELPSHIFRNC "
# Seconds between the end of auto and the start of teleop (estimate when only teleop is readable).
_AUTO_TELEOP_GAP = 3.0
_MAX_READS = 400


def _crop(frame: np.ndarray, box: tuple[float, float, float, float]) -> np.ndarray:
    h, w = frame.shape[:2]
    return frame[int(box[1] * h) : int(box[3] * h), int(box[0] * w) : int(box[2] * w)]


def _read_clock(reader, frame: np.ndarray, box) -> tuple[int, bool] | None:
    """(seconds shown, period label says not-auto) of the clock in ``box``, or None."""
    crop = _crop(frame, box)
    if crop.size == 0:
        return None
    if crop.shape[0] < 60:
        crop = cv2.resize(crop, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    best = None
    labels = []
    for _, text, conf in reader.readtext(crop, allowlist=_ALLOW, detail=1):
        if sum(c.isalpha() for c in text) >= 3:
            labels.append(text.upper())
        m = _CLOCK.match(text.replace(" ", ""))
        if m and conf >= 0.3 and (best is None or conf > best[1]):
            best = (int(m.group(1)) * 60 + int(m.group(2)), conf)
    if best is None:
        return None
    # A period label that isn't auto: the last minute of teleop.
    return best[0], bool(labels) and not any("AUTO" in s for s in labels)


def _locate_clock(reader, frame: np.ndarray) -> list[tuple[tuple[float, float, float, float], float]]:
    """Candidate clock boxes (fractions of the frame) with a score, from OCR of the whole frame."""
    h, w = frame.shape[:2]
    scale = min(1.0, 1280.0 / w)
    small = cv2.resize(frame, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA) if scale < 1 else frame
    sh, sw = small.shape[:2]
    out = []
    for pts, text, conf in reader.readtext(small, allowlist="0123456789:", detail=1):
        if conf < 0.6 or not _FIND_CLOCK.match(text.replace(" ", "")):
            continue
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        x1, x2, y1, y2 = min(xs), max(xs), min(ys), max(ys)
        bw, bh = x2 - x1, y2 - y1
        if bh < 0.015 * sh:
            continue  # tiny text, not the match clock
        box = (
            max(0.0, (x1 - 0.3 * bw) / sw),
            max(0.0, (y1 - 0.4 * bh) / sh),
            min(1.0, (x2 + 0.3 * bw) / sw),
            min(1.0, (y2 + 0.4 * bh) / sh),
        )
        out.append((box, conf * bh / sh))
    return out


def _find_clock_box(reader, grab, times: list[float]):
    """The overlay clock box: the place a clock was seen most often over a few sample frames."""
    hits: list[list] = []  # [box, count, score]
    for t in times:
        frame = grab(t)
        if frame is None:
            continue
        for box, score in _locate_clock(reader, frame):
            cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
            for h in hits:
                if abs((h[0][0] + h[0][2]) / 2 - cx) < 0.03 and abs((h[0][1] + h[0][3]) / 2 - cy) < 0.03:
                    h[1] += 1
                    h[2] = max(h[2], score)
                    break
            else:
                hits.append([box, 1, score])
        best = max(hits, key=lambda h: (h[1], h[2]), default=None)
        if best is not None and best[1] >= 2:
            return best[0]
    best = max(hits, key=lambda h: (h[1], h[2]), default=None)
    return best[0] if best is not None else None


def _vote(readings: list[tuple[float, int]], auto_len: float) -> tuple[float, float, int] | None:
    """(start, half-width, votes) agreed by the auto clock readings, or None."""
    if len(readings) < 3:
        return None
    # Each reading allows starts in (t - (L - r) - 1, t - (L - r)]; vote on a fine grid.
    hi_b = np.array([t - (auto_len - r) for t, r in readings])
    lo_b = hi_b - 1.0
    grid = np.arange(lo_b.min(), hi_b.max() + 0.02, 0.02)
    votes = ((grid[:, None] > lo_b[None, :]) & (grid[:, None] <= hi_b[None, :])).sum(axis=1)
    best = int(votes.max())
    if best < 3 or best < 0.6 * len(readings):
        return None
    sel = grid[votes == best]
    # The top-voted cells are contiguous unless misreads tie; keep the run with the most cells.
    runs = np.split(sel, np.flatnonzero(np.diff(sel) > 0.03) + 1)
    run = max(runs, key=len)
    return float((run[0] + run[-1]) / 2), float(run[-1] - run[0]) / 2 + 0.02, best


def find_auto_start(
    video_path: str,
    *,
    hint_sec: float = 0.0,
    auto_len: float = 20.0,
    search_before: float = 3.0,
    search_after: float = 60.0,
) -> dict | None:
    """Video time (s) at which auto starts, from the overlay clock, or None if no clock is readable.

    Returns ``{"start_sec", "uncertainty_sec", "readings", "agree", "method", "clock_box"}``;
    method is ``overlay_clock`` (auto clock) or ``teleop_clock`` (estimated from the teleop clock).
    """
    from app.tracking.team_id import _get_reader

    reader = _get_reader()
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration = total / fps if total else hint_sec + search_after
    end_t = duration - 0.5

    def grab(t: float) -> np.ndarray | None:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(round(t * fps)))
        ok, frame = cap.read()
        return frame if ok else None

    seen: dict[float, tuple[int, bool]] = {}  # every clock reading: t -> (seconds, not-auto label)
    reads = 0

    def read(t: float, box) -> tuple[int, bool] | None:
        nonlocal reads
        t = round(t, 2)
        if t in seen:
            return seen[t]
        frame = grab(t)
        reads += 1
        if frame is None:
            return None
        r = _read_clock(reader, frame, box)
        if r is not None:
            seen[t] = r
        return r

    def running_teleop_before(t: float) -> bool:
        """A teleop clock was running before t, so a short reading at t is the end of teleop."""
        top = max((v for v, _ in seen.values()), default=0)
        return any(tt < t and auto_len < v < top for tt, (v, _) in seen.items())

    def is_auto(t: float, r) -> bool:
        return r is not None and 1 <= r[0] < auto_len and not r[1] and not running_teleop_before(t)

    def refine(first: float, box) -> dict | None:
        readings = [(first, seen[round(first, 2)][0])]
        # Dense samples over the next two clock ticks pin down the tick time,
        # sparse ones further on outvote misreads.
        for dt in (0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 3.0, 4.5, 6.0):
            if first + dt > end_t:
                break
            r = read(first + dt, box)
            if r is not None and 1 <= r[0] < auto_len and not r[1]:
                readings.append((round(first + dt, 2), r[0]))
        voted = _vote(readings, auto_len)
        if voted is None:
            log.info("auto start: clock readings disagree %s", readings)
            return None
        start, unc, agree = voted
        return {
            "start_sec": round(max(0.0, start), 3),
            "uncertainty_sec": round(unc, 3),
            "readings": [[round(t, 2), r] for t, r in readings],
            "agree": agree,
            "method": "overlay_clock",
        }

    def scan(times, box) -> dict | None:
        for t in times:
            if reads >= _MAX_READS:
                return None
            r = read(t, box)
            if is_auto(t, r):
                found = refine(t, box)
                if found is not None:
                    found["clock_box"] = [round(float(v), 4) for v in box]
                    return found
        return None

    try:
        lo = max(0.0, hint_sec - search_before)
        hi = min(end_t, hint_sec + search_after)
        window = [float(t) for t in np.arange(lo, hi + 1e-6, 1.0)]
        # The rest of the video, nearest the hint first, at a step that still lands in a 20 s auto.
        step = max(1.0, min(2.5, auto_len / 6))
        rest = [float(t) for t in np.arange(0.0, end_t, step) if not lo <= t <= hi]
        rest.sort(key=lambda t: (t < hint_sec, abs(t - hint_sec)))

        probe = [t for t in (hint_sec + 10, hint_sec + 30, hint_sec + 50, duration * 0.4, duration * 0.6) if t < end_t]
        located = _find_clock_box(reader, grab, probe)
        boxes = ([located] if located else []) + [_TIMER_BOX, _TOP_BOX, _WIDE_BOX]

        for box in boxes:
            found = scan(window, box) or scan(rest, box)
            if found is not None:
                return found
            if seen:
                break  # this box reads a clock but never an auto one: look at teleop below
            seen.clear()

        # No readable auto clock: back-calculate from a running teleop clock. The full
        # teleop length is the value the stopped clock shows for a while before teleop.
        top = max((v for v, _ in seen.values()), default=0)
        running = sorted((t, v) for t, (v, _) in seen.items() if auto_len < v < top)
        if len(running) >= 3 and sum(v == top for v, _ in seen.values()) >= 2:
            starts = np.array([t - (top - v) for t, v in running])
            med = float(np.median(starts))
            agree = int((np.abs(starts - med) <= 1.0).sum())
            if agree >= 3 and agree >= 0.6 * len(starts):
                return {
                    "start_sec": round(max(0.0, med - _AUTO_TELEOP_GAP - auto_len), 3),
                    "uncertainty_sec": 2.0,
                    "readings": [[round(t, 2), v] for t, v in running[:20]],
                    "agree": agree,
                    "method": "teleop_clock",
                }
        log.info("auto start: no auto clock found (%d reads, %d clock readings)", reads, len(seen))
        return None
    finally:
        cap.release()
