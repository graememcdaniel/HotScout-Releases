from __future__ import annotations

import json
import math
from pathlib import Path

import cv2
import numpy as np

from app.tracking.camera import CameraModel, densify_polygon

_REGISTRY = Path(__file__).resolve().parents[1] / "data" / "fields" / "registry.json"
DEFAULT_ROBOT_SIZE_M = (0.85, 0.85, 0.6)
_VIS_CELL_M = 0.1  # visibility grid resolution
_ROUTE_CELL_M = 0.2  # path-finding grid resolution
_VISIBLE_COST = 4.0  # an unseen robot is unlikely to have crossed space the camera sees


def _segments_hit_box(c: np.ndarray, pts: np.ndarray, lo: np.ndarray, hi: np.ndarray) -> np.ndarray:
    """Which segments ``c -> pts[i]`` pass through the axis-aligned box ``lo..hi`` (slab test)."""
    d = pts - c
    d = np.where(np.abs(d) < 1e-9, 1e-9, d)
    t1 = (lo - c) / d
    t2 = (hi - c) / d
    tmin = np.minimum(t1, t2).max(axis=1)
    tmax = np.maximum(t1, t2).min(axis=1)
    return (tmax >= np.maximum(tmin, 0.0)) & (tmin <= 1.0)


def _poly(feature: dict) -> np.ndarray:
    if "rect" in feature:
        x0, y0, x1, y1 = (float(v) for v in feature["rect"])
        return np.array([[x0, y0], [x1, y0], [x1, y1], [x0, y1]], dtype=np.float64)
    return np.array(feature["polygon"], dtype=np.float64).reshape(-1, 2)


def _map_xy(xy: np.ndarray, mode: str, length: float, width: float) -> np.ndarray:
    out = xy.copy()
    if mode in {"flip_x", "rotate_180"}:
        out[:, 0] = length - out[:, 0]
    if mode in {"flip_y", "rotate_180"}:
        out[:, 1] = width - out[:, 1]
    return out


class _Region:
    def __init__(self, data: dict, poly: np.ndarray):
        self.data = data
        self.poly = poly
        self.contour = poly.astype(np.float32).reshape(-1, 1, 2)
        self.xmin, self.ymin = poly.min(axis=0)
        self.xmax, self.ymax = poly.max(axis=0)
        self.height = float(data.get("height_m") or data.get("max_height_m") or 0.0)

    def contains(self, x: float, y: float, margin: float = 0.0) -> bool:
        if x < self.xmin - margin or x > self.xmax + margin or y < self.ymin - margin or y > self.ymax + margin:
            return False
        return cv2.pointPolygonTest(self.contour, (float(x), float(y)), True) >= -margin


class FieldTerrain:
    """Season field geometry (in the calibrated pose frame): floor height map,
    solid obstacles that block robots and the camera's view, and climb zones.

    Geometry comes from ``data/fields/registry.json`` in official (WPILib)
    coordinates and gets the same layout transform as the AprilTags, so it
    always lines up with the camera pose.
    """

    def __init__(
        self,
        length_m: float,
        width_m: float,
        surfaces: list[_Region] | None = None,
        solids: list[_Region] | None = None,
        climb_zones: list[_Region] | None = None,
        robot_size_m: tuple[float, float, float] = DEFAULT_ROBOT_SIZE_M,
        source: str = "none",
    ):
        self.length = float(length_m)
        self.width = float(width_m)
        self.surfaces = surfaces or []
        self.solids = solids or []
        self.climb_zones = climb_zones or []
        self.robot_size = tuple(float(v) for v in robot_size_m)
        self.source = source
        self.hidden: np.ndarray | None = None  # [row=y, col=x] cells the camera cannot see
        self._route: dict | None = None
        self.view: dict | None = None  # how to orient a top-down drawing like the camera sees it

    # ------------------------------------------------------- visibility ---

    def build_visibility(self, camera: CameraModel) -> None:
        """Mark floor cells where a robot is hidden from the camera behind solids.

        A cell is hidden when the line of sight to a robot's bumper band there
        (top of the bumpers, ~half the robot height) passes through a solid
        obstacle, e.g. the strip behind each hub as seen from the camera.
        """
        nx = int(math.ceil(self.length / _VIS_CELL_M))
        ny = int(math.ceil(self.width / _VIS_CELL_M))
        xs = (np.arange(nx) + 0.5) * _VIS_CELL_M
        ys = (np.arange(ny) + 0.5) * _VIS_CELL_M
        X, Y = np.meshgrid(xs, ys)
        probe_z = 0.5 * self.robot_size[2]
        pts = np.c_[X.ravel(), Y.ravel(), np.full(X.size, probe_z)]
        c = np.asarray(camera.center, dtype=np.float64).reshape(3)
        hidden = np.zeros(X.size, dtype=bool)
        for s in self.solids:
            if s.height <= 0:
                continue
            lo = np.array([s.xmin, s.ymin, 0.0])
            hi = np.array([s.xmax, s.ymax, s.height])
            hidden |= _segments_hit_box(c, pts, lo, hi)
        self.hidden = hidden.reshape(ny, nx)
        self._route = None
        u0, v0 = camera.calib_to_video(camera.K[0, 2], camera.K[1, 2])
        fwd = camera.ray(u0, v0)
        right = camera.ray(u0 + 50.0, v0) - fwd
        # Image right should be screen right; the far side of the field screen top.
        self.view = {
            "flip_x": bool(right[0] < 0),
            "far_is_low_y": bool(fwd[1] < 0),
            "camera_xy": [round(float(c[0]), 2), round(float(c[1]), 2)],
        }

    def _cell(self, x: float, y: float, res: float, shape: tuple[int, int]) -> tuple[int, int]:
        return (
            int(min(max(y / res, 0), shape[0] - 1)),
            int(min(max(x / res, 0), shape[1] - 1)),
        )

    def is_hidden(self, x: float, y: float) -> bool:
        if self.hidden is None:
            return False
        r, c = self._cell(x, y, _VIS_CELL_M, self.hidden.shape)
        return bool(self.hidden[r, c])

    def near_hidden(self, x: float, y: float, radius: float = 0.8) -> bool:
        if self.hidden is None:
            return False
        k = int(math.ceil(radius / _VIS_CELL_M))
        r, c = self._cell(x, y, _VIS_CELL_M, self.hidden.shape)
        return bool(self.hidden[max(0, r - k) : r + k + 1, max(0, c - k) : c + k + 1].any())

    def hidden_polygons(self) -> list[list[list[float]]]:
        """Outlines of the hidden floor (field metres), for display."""
        if self.hidden is None:
            return []
        mask = self.hidden.astype(np.uint8) * 255
        for s in self.solids:  # the obstacles themselves are drawn separately
            cv2.fillPoly(mask, [np.round(s.poly / _VIS_CELL_M).astype(np.int32)], 0)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        out = []
        for cnt in contours:
            if cv2.contourArea(cnt) < 4:
                continue
            cnt = cv2.approxPolyDP(cnt, 1.0, True).reshape(-1, 2)
            out.append([[round(float(px) * _VIS_CELL_M, 2), round(float(py) * _VIS_CELL_M, 2)] for px, py in cnt])
        return out

    def view_geometry(self) -> dict:
        """Solid obstacles and the floor hidden behind them (field metres), for display."""
        return {
            "solids": [[[round(float(x), 3), round(float(y), 3)] for x, y in s.poly] for s in self.solids],
            "hidden": self.hidden_polygons(),
            "view": self.view,
        }

    def _route_graph(self) -> dict:
        if self._route is not None:
            return self._route
        from scipy.sparse import coo_matrix

        res = _ROUTE_CELL_M
        nx = int(math.ceil(self.length / res))
        ny = int(math.ceil(self.width / res))
        xs = (np.arange(nx) + 0.5) * res
        ys = (np.arange(ny) + 0.5) * res
        X, Y = np.meshgrid(xs, ys)
        clear = 0.4 * min(self.robot_size[0], self.robot_size[1])
        free = np.ones((ny, nx), dtype=bool)
        for s in self.solids:
            free &= ~((X > s.xmin - clear) & (X < s.xmax + clear) & (Y > s.ymin - clear) & (Y < s.ymax + clear))
        hidden = np.zeros((ny, nx), dtype=bool)
        if self.hidden is not None:
            for r in range(ny):
                for c in range(nx):
                    hidden[r, c] = self.is_hidden(xs[c], ys[r])
        cost = np.where(hidden, 1.0, _VISIBLE_COST)
        idx = np.arange(ny * nx).reshape(ny, nx)
        rows, cols, w = [], [], []
        for dr, dc in ((0, 1), (1, 0), (1, 1), (1, -1)):
            r0, r1 = 0, ny - dr
            c0, c1 = max(0, -dc), nx - max(0, dc)
            a = idx[r0:r1, c0:c1]
            b = idx[r0 + dr : r1 + dr, c0 + dc : c1 + dc]
            ok = free[r0:r1, c0:c1] & free[r0 + dr : r1 + dr, c0 + dc : c1 + dc]
            step = res * math.hypot(dr, dc)
            wt = step * 0.5 * (cost[r0:r1, c0:c1] + cost[r0 + dr : r1 + dr, c0 + dc : c1 + dc])
            rows += [a[ok], b[ok]]
            cols += [b[ok], a[ok]]
            w += [wt[ok], wt[ok]]
        n = ny * nx
        graph = coo_matrix((np.concatenate(w), (np.concatenate(rows), np.concatenate(cols))), shape=(n, n)).tocsr()
        self._route = {"graph": graph, "free": free, "hidden": hidden, "xs": xs, "ys": ys, "shape": (ny, nx)}
        return self._route

    def route(
        self, a: tuple[float, float], b: tuple[float, float], via_hidden: bool = False
    ) -> tuple[np.ndarray, np.ndarray] | None:
        """Likeliest path for a robot unseen between ``a`` and ``b``: around solids,
        preferring floor the camera cannot see. With ``via_hidden`` the path is
        forced through the closest hidden floor (the robot went out of view).
        Returns ``(points[n,2], hidden[n-1])`` (whether each segment runs through
        hidden floor), or None if no route.
        """
        from scipy.sparse.csgraph import dijkstra

        g = self._route_graph()
        ny, nx = g["shape"]
        free = g["free"]

        def node(p: tuple[float, float]) -> int | None:
            r, c = self._cell(p[0], p[1], _ROUTE_CELL_M, (ny, nx))
            if free[r, c]:
                return r * nx + c
            fr, fc = np.nonzero(free[max(0, r - 4) : r + 5, max(0, c - 4) : c + 5])
            if not len(fr):
                return None
            k = int(np.argmin((fr + max(0, r - 4) - r) ** 2 + (fc + max(0, c - 4) - c) ** 2))
            return int((fr[k] + max(0, r - 4)) * nx + fc[k] + max(0, c - 4))

        s, e = node(a), node(b)
        if s is None or e is None:
            return None
        dist, pred = dijkstra(g["graph"], indices=[s, e], return_predecessors=True)
        if not np.isfinite(dist[0, e]):
            return None

        def back(k: int, src: int, to: int) -> list[int]:
            p = [to]
            while p[-1] != src:
                p.append(int(pred[k, p[-1]]))
            return p[::-1]

        if via_hidden:
            tot = np.where((g["hidden"] & free).ravel(), dist[0] + dist[1], np.inf)
            h = int(np.argmin(tot))
            if not np.isfinite(tot[h]):
                return None
            path = back(0, s, h) + back(1, e, h)[::-1][1:]
        else:
            path = back(0, s, e)
        cells = [(k // nx, k % nx) for k in path]
        pts = [np.asarray(a, dtype=np.float64)]
        pts += [np.array([g["xs"][c], g["ys"][r]]) for r, c in cells[1:-1]]
        pts.append(np.asarray(b, dtype=np.float64))
        pts = np.array(pts)
        mids = 0.5 * (pts[1:] + pts[:-1])
        seg_hidden = np.array([self.is_hidden(float(m[0]), float(m[1])) for m in mids], dtype=bool)
        return pts, seg_hidden

    @classmethod
    def from_registry(cls, season: int, layout_transform: str, length_m: float, width_m: float) -> "FieldTerrain":
        try:
            registry = json.loads(_REGISTRY.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            registry = {}
        entry = registry.get(str(season)) or {}
        mode = (layout_transform or "none").strip().lower()
        symmetric = (entry.get("symmetry") or "").strip().lower()

        def build(items: list[dict]) -> list[_Region]:
            out = []
            for item in items or []:
                poly = _poly(item)
                copies = [(item, poly)]
                if symmetric in {"rotate_180", "flip_x", "flip_y"} and not item.get("no_symmetry"):
                    mirrored = {**item, "name": f"{item.get('name', 'feature')}_mirror"}
                    copies.append((mirrored, _map_xy(poly, symmetric, length_m, width_m)))
                for data, p in copies:
                    out.append(_Region(data, _map_xy(p, mode, length_m, width_m)))
            return out

        terrain = entry.get("terrain") or []
        return cls(
            length_m,
            width_m,
            surfaces=build([t for t in terrain if t.get("type") in {"bump", "platform"}]),
            solids=build([t for t in terrain if t.get("type") == "solid"]),
            climb_zones=build(entry.get("climb_zones") or []),
            robot_size_m=tuple(entry.get("robot_size_m") or DEFAULT_ROBOT_SIZE_M),
            source=f"registry:{season}" if entry.get("terrain") or entry.get("climb_zones") else "none",
        )

    def height(self, x: float, y: float) -> float:
        z = 0.0
        for s in self.surfaces:
            if not s.contains(x, y):
                continue
            if s.data.get("type") == "platform":
                z = max(z, s.height)
                continue
            axis = 0 if (s.data.get("axis") or "x") == "x" else 1
            lo, hi = (s.xmin, s.xmax) if axis == 0 else (s.ymin, s.ymax)
            u = ((x if axis == 0 else y) - lo) / max(1e-6, hi - lo)
            ramp = max(1e-3, (1.0 - float(s.data.get("flat_top_fraction", 0.0))) / 2.0)
            z = max(z, s.height * max(0.0, min(1.0, u / ramp, (1.0 - u) / ramp)))
        return z

    def climb_zone(self, x: float, y: float, margin: float = 0.0) -> _Region | None:
        return next((c for c in self.climb_zones if c.contains(x, y, margin)), None)

    def in_field(self, x: float, y: float, margin: float = 0.0) -> bool:
        return -margin <= x <= self.length + margin and -margin <= y <= self.width + margin

    def constrain(self, x: float, y: float) -> tuple[float, float]:
        """Keep a (predicted) robot centre on the field and out of solid obstacles."""
        half = 0.5 * min(self.robot_size[0], self.robot_size[1])
        x = min(max(x, half), self.length - half)
        y = min(max(y, half), self.width - half)
        for s in self.solids:
            if not s.contains(x, y, half):
                continue
            # Push out through the nearest bounding-box side.
            options = [
                (abs(x - (s.xmin - half)), s.xmin - half, y),
                (abs((s.xmax + half) - x), s.xmax + half, y),
                (abs(y - (s.ymin - half)), x, s.ymin - half),
                (abs((s.ymax + half) - y), x, s.ymax + half),
            ]
            _, x, y = min(options)
        return x, y

    def ground_hit(self, camera: CameraModel, u: float, v: float) -> np.ndarray | None:
        """Intersect the pixel's ray with the floor height map (handles bumps/platforms)."""
        p = camera.hit_plane(u, v, 0.0)
        if p is None:
            return None
        for _ in range(4):
            z = self.height(p[0], p[1])
            q = camera.hit_plane(u, v, z)
            if q is None:
                return p
            if abs(q[2] - p[2]) < 1e-3 and np.hypot(q[0] - p[0], q[1] - p[1]) < 1e-3:
                return q
            p = q
        return p

    def occluder_mask(self, camera: CameraModel, width: int, height: int, scale: float) -> np.ndarray:
        """Image mask (at ``scale`` x video resolution) of solid obstacles."""
        mask = np.zeros((height, width), dtype=np.uint8)
        for s in self.solids:
            poly = densify_polygon(s.poly, 6)
            pts = np.vstack([np.c_[poly, np.zeros(len(poly))], np.c_[poly, np.full(len(poly), s.height)]])
            img = camera.project(pts)
            if np.isnan(img).any():
                continue
            hull = cv2.convexHull((img * scale).astype(np.int32))
            cv2.fillConvexPoly(mask, hull, 255)
        return mask

    def summary(self) -> dict:
        return {
            "source": self.source,
            "field_length_m": self.length,
            "field_width_m": self.width,
            "surfaces": [s.data.get("name") for s in self.surfaces],
            "solids": [s.data.get("name") for s in self.solids],
            "climb_zones": [c.data.get("name") for c in self.climb_zones],
            "robot_size_m": list(self.robot_size),
        }
