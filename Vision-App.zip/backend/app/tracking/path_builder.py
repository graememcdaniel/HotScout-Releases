from __future__ import annotations

import math

import numpy as np

from app.tracking.camera import CameraModel
from app.tracking.terrain import FieldTerrain


def _rdp(points: np.ndarray, eps: float) -> list[int]:
    """Ramer-Douglas-Peucker; returns kept indices."""
    if len(points) <= 2:
        return list(range(len(points)))
    keep = np.zeros(len(points), dtype=bool)
    keep[0] = keep[-1] = True
    stack = [(0, len(points) - 1)]
    while stack:
        a, b = stack.pop()
        if b <= a + 1:
            continue
        p, q = points[a], points[b]
        seg = q - p
        n = float(np.hypot(*seg))
        mid = points[a + 1 : b]
        if n < 1e-9:
            dist = np.hypot(*(mid - p).T)
        else:
            dist = np.abs(seg[0] * (mid[:, 1] - p[1]) - seg[1] * (mid[:, 0] - p[0])) / n
        k = int(np.argmax(dist))
        if dist[k] > eps:
            keep[a + 1 + k] = True
            stack.extend([(a, a + 1 + k), (a + 1 + k, b)])
    return list(np.flatnonzero(keep))


def build_path(
    samples: list[dict],
    camera: CameraModel | None,
    terrain: FieldTerrain,
    node_conf: float = 0.55,
    rdp_eps_m: float = 0.12,
    max_node_gap_s: float = 1.0,
    min_node_gap_s: float = 0.25,
    hide_gap_s: float = 0.75,
) -> dict:
    """Pick confident nodes from the target samples and connect them with
    time-parameterised cubic Hermite segments (position + smoothed velocity)."""
    if not samples:
        return {"nodes": [], "points": [], "summary": {"node_count": 0}}

    observed = [i for i, s in enumerate(samples) if s["observed"]]
    if not observed:
        observed = list(range(len(samples)))
    confident = [i for i in observed if samples[i]["confidence"] >= node_conf]
    threshold_used = node_conf
    if len(confident) < max(2, int(0.3 * len(observed))):
        ranked = sorted(observed, key=lambda i: -samples[i]["confidence"])[: max(2, int(math.ceil(0.3 * len(observed))))]
        confident = sorted(ranked)
        threshold_used = min(samples[i]["confidence"] for i in confident)

    kinds: dict[int, str] = {}
    pts = np.array([[samples[i]["x_m"], samples[i]["y_m"]] for i in confident])
    chosen = {confident[k] for k in _rdp(pts, rdp_eps_m)}

    # Dwell (stopped) and climb events are always nodes.
    speed = np.array([math.hypot(s["vx"], s["vy"]) for s in samples])
    i = 0
    while i < len(samples):
        if speed[i] < 0.25:
            j = i
            while j + 1 < len(samples) and speed[j + 1] < 0.25:
                j += 1
            if samples[j]["t"] - samples[i]["t"] >= 0.6:
                mid = 0.5 * (samples[i]["t"] + samples[j]["t"])
                pool = [c for c in confident if i <= c <= j]
                if pool:  # a stop we never actually saw is not a node
                    k = min(pool, key=lambda c: abs(samples[c]["t"] - mid))
                    chosen.add(k)
                    kinds[k] = "dwell"
            i = j + 1
        else:
            i += 1
    climb = [i for i in confident if samples[i]["z_source"] == "climb"]
    if climb:
        k = max(climb, key=lambda c: samples[c]["z_m"])
        chosen.add(k)
        kinds[k] = "climb"
    chosen.update({confident[0], confident[-1]})

    # Every hide / reappear is a node, whatever its confidence: the path must
    # show when the robot went out of view and where it came back.
    obs_set = [i for i, s in enumerate(samples) if s["observed"]]
    runs: list[list[int]] = []
    for i in obs_set:
        if runs and samples[i]["t"] - samples[runs[-1][-1]]["t"] <= hide_gap_s:
            runs[-1].append(i)
        else:
            runs.append([i])
    runs = [r for r in runs if len(r) >= 3]  # 1-2 frame flickers are not a reappearance
    for r, run in enumerate(runs):
        chosen.update({run[0], run[-1]})
        if r > 0:
            kinds.setdefault(run[0], "reappear")
        if r < len(runs) - 1:
            kinds.setdefault(run[-1], "hide")

    # Fill long gaps with an observed sample near the middle (follow what we saw).
    changed = True
    while changed:
        changed = False
        order = sorted(chosen)
        for a, b in zip(order, order[1:]):
            if samples[b]["t"] - samples[a]["t"] <= max_node_gap_s:
                continue
            inner = [c for c in obs_set if a < c < b]
            if not inner:
                continue
            mid = 0.5 * (samples[a]["t"] + samples[b]["t"])
            k = max(inner, key=lambda c: samples[c]["confidence"] - abs(samples[c]["t"] - mid))
            chosen.add(k)
            changed = True
            break

    # Enforce minimum spacing, keeping the more confident / special node.
    order = sorted(chosen)
    nodes_idx = [order[0]]
    for k in order[1:]:
        prev = nodes_idx[-1]
        if samples[k]["t"] - samples[prev]["t"] >= min_node_gap_s or k == order[-1] or kinds.get(k) in {"hide", "reappear"}:
            nodes_idx.append(k)
        elif prev != order[0] and prev not in kinds and (k in kinds or samples[k]["confidence"] > samples[prev]["confidence"]):
            nodes_idx[-1] = k

    nodes = []
    for n, k in enumerate(nodes_idx):
        s = samples[k]
        kind = kinds.get(k) or ("start" if n == 0 else "end" if n == len(nodes_idx) - 1 else "observed")
        nodes.append(
            {
                "t_sec": s["t"],
                "x_m": s["x_m"],
                "y_m": s["y_m"],
                "z_m": s["z_m"],
                "confidence": s["confidence"],
                "identity_confidence": s["identity_confidence"],
                "sigma_m": s["sigma_m"],
                "kind": kind,
                "z_source": s["z_source"],
                "sample_index": k,
            }
        )

    points = []
    t_obs = np.array([s["t"] for s in samples])
    obs_flags = np.array([s["observed"] for s in samples])
    for seg, (a, b) in enumerate(zip(nodes_idx, nodes_idx[1:])):
        sa, sb = samples[a], samples[b]
        h = sb["t"] - sa["t"]
        p0 = np.array([sa["x_m"], sa["y_m"]])
        p1 = np.array([sb["x_m"], sb["y_m"]])
        chord = float(np.hypot(*(p1 - p0)))
        v0 = np.array([sa["vx"], sa["vy"]])
        v1 = np.array([sb["vx"], sb["vy"]])
        vlim = 2.0 * chord / max(h, 1e-6)
        for v in (v0, v1):
            n = float(np.hypot(*v))
            if n > vlim:
                v *= vlim / n
        inside = (t_obs > sa["t"]) & (t_obs < sb["t"])
        gap, run, prev_t = 0.0, 0.0, sa["t"]
        for t, ob in zip(t_obs[inside], obs_flags[inside]):
            run = 0.0 if ob else run + (t - prev_t)
            gap = max(gap, run)
            prev_t = t
        if not obs_flags[b]:
            gap = max(gap, run + (sb["t"] - prev_t))
        seg_conf = min(sa["confidence"], sb["confidence"]) * math.exp(-max(0.0, gap - 0.3) / 1.5)
        climb_seg = sa["z_source"].startswith("climb") and sb["z_source"].startswith("climb")
        idxs = [a] + [int(i) for i in np.flatnonzero(inside)] + ([b] if seg == len(nodes_idx) - 2 else [])
        for i in idxs:
            t = samples[i]["t"]
            s = (t - sa["t"]) / h if h > 0 else 0.0
            h00, h10, h01, h11 = 2 * s**3 - 3 * s**2 + 1, s**3 - 2 * s**2 + s, -2 * s**3 + 3 * s**2, s**3 - s**2
            if samples[i].get("routed"):  # unseen stretch routed through hidden floor
                x, y = samples[i]["x_m"], samples[i]["y_m"]
            else:
                p = h00 * p0 + h10 * h * v0 + h01 * p1 + h11 * h * v1
                x, y = terrain.constrain(float(p[0]), float(p[1]))
            z = (1 - s) * sa["z_m"] + s * sb["z_m"] if climb_seg else terrain.height(x, y)
            points.append(
                {
                    "t_sec": t,
                    "x_m": x,
                    "y_m": y,
                    "z_m": float(z),
                    "confidence": float(seg_conf),
                    "inferred": bool(gap > 0.4),
                    "occluded": terrain.is_hidden(x, y),
                    "segment": seg,
                    "kind": "climb" if climb_seg else "drive",
                }
            )
    if len(nodes_idx) == 1:
        n0 = nodes[0]
        points.append({k: n0[k] for k in ("t_sec", "x_m", "y_m", "z_m", "confidence")} | {"inferred": False, "segment": 0, "kind": "drive"})

    if camera is not None:
        for group in (nodes, points):
            if not group:
                continue
            img = camera.project(np.array([[p["x_m"], p["y_m"], p["z_m"]] for p in group]))
            for p, (u, v) in zip(group, img):
                p["px"] = None if math.isnan(u) else float(u)
                p["py"] = None if math.isnan(v) else float(v)

    xy = np.array([[p["x_m"], p["y_m"]] for p in points])
    length = float(np.sum(np.hypot(*np.diff(xy, axis=0).T))) if len(xy) > 1 else 0.0
    return {
        "nodes": nodes,
        "points": points,
        "summary": {
            "node_count": len(nodes),
            "hide_count": sum(1 for n in nodes if n["kind"] == "hide"),
            "node_confidence_threshold": round(float(threshold_used), 3),
            "path_length_m": round(length, 2),
            "mean_confidence": round(float(np.mean([p["confidence"] for p in points])), 3) if points else 0.0,
            "inferred_fraction": round(float(np.mean([p["inferred"] for p in points])), 3) if points else 0.0,
            "max_z_m": round(float(max(p["z_m"] for p in points)), 3) if points else 0.0,
        },
    }
