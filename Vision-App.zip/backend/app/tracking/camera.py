from __future__ import annotations

import cv2
import numpy as np

_POSE_MODELS = {"solvepnp_3d", "solvepnp_manual_3d"}
_UNDISTORT_CRITERIA = (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 40, 1e-9)


def densify_polygon(poly: np.ndarray, per_edge: int = 16) -> np.ndarray:
    """Closed polygon (Nx2 or Nx3) with extra points along each edge, so its
    projection follows edges that a distorting lens bends."""
    poly = np.asarray(poly, dtype=np.float64)
    t = np.linspace(0.0, 1.0, per_edge, endpoint=False)[:, None]
    return np.vstack([a + (b - a) * t for a, b in zip(poly, np.roll(poly, -1, axis=0))])


class CameraModel:
    """Calibrated 3D camera in field coordinates, addressed in *video* pixels.

    The pose may live in a y-mirrored frame (manual solves); all public methods
    take and return true field coordinates. ``to_calib`` scales video pixels to
    the resolution the calibration was solved at; ``view_affine`` (2x3, video
    pixels -> calibration pixels) replaces it when the broadcast moved or
    resized the view since the calibration frame (``view_shift``).
    """

    def __init__(
        self, pose: dict, to_calib: tuple[float, float] = (1.0, 1.0), view_affine: list | np.ndarray | None = None
    ):
        self.K = np.array(pose["camera_matrix"], dtype=np.float64)
        self.dist = np.array(pose.get("dist_coeffs") or np.zeros(4), dtype=np.float64).reshape(-1)
        self.rvec = np.array(pose["rvec"], dtype=np.float64).reshape(3, 1)
        self.tvec = np.array(pose["tvec"], dtype=np.float64).reshape(3, 1)
        self.R, _ = cv2.Rodrigues(self.rvec)
        self.mirror_h = float(pose.get("ref_mirror_field_height_m", 0.0)) if pose.get("ref_mirror_y") else None
        self.sx, self.sy = float(to_calib[0]), float(to_calib[1])
        if view_affine is None:
            view_affine = [[self.sx, 0.0, 0.0], [0.0, self.sy, 0.0]]
        self.to_calib = np.vstack([np.asarray(view_affine, dtype=np.float64).reshape(2, 3), [0.0, 0.0, 1.0]])
        self.from_calib = np.linalg.inv(self.to_calib)
        c_pose = (-self.R.T @ self.tvec).reshape(3)
        self.center = self._from_pose(c_pose)

    @classmethod
    def from_calibration(
        cls,
        calibration_meta: dict,
        to_calib: tuple[float, float] = (1.0, 1.0),
        view_affine: list | np.ndarray | None = None,
    ) -> "CameraModel | None":
        pose = ((calibration_meta or {}).get("apriltag") or {}).get("camera_pose")
        if not isinstance(pose, dict) or pose.get("model") not in _POSE_MODELS:
            return None
        if not (pose.get("camera_matrix") and pose.get("rvec") and pose.get("tvec")):
            return None
        return cls(pose, to_calib, view_affine)

    @classmethod
    def from_run_context(cls, ctx: dict) -> "CameraModel | None":
        """The camera a saved tracking run used."""
        return cls.from_calibration(
            ctx.get("calibration_meta") or {}, tuple(ctx.get("to_calib_scale") or (1.0, 1.0)), ctx.get("view_affine")
        )

    def calib_to_video(self, u: float, v: float) -> tuple[float, float]:
        p = self.from_calib @ np.array([u, v, 1.0])
        return float(p[0]), float(p[1])

    def _to_pose(self, p: np.ndarray) -> np.ndarray:
        q = np.array(p, dtype=np.float64).copy()
        if self.mirror_h is not None:
            q[..., 1] = self.mirror_h - q[..., 1]
        return q

    def _from_pose(self, p: np.ndarray) -> np.ndarray:
        return self._to_pose(p)  # reflection is its own inverse

    def ray(self, u: float, v: float) -> np.ndarray:
        """Unit world-direction of the viewing ray through video pixel (u, v)."""
        p = self.to_calib @ np.array([u, v, 1.0])
        pts = np.array([[[p[0], p[1]]]], dtype=np.float64)
        if np.any(self.dist):
            # Default undistortPoints stops after 5 iterations: not enough for wide/fisheye lenses.
            xn, yn = cv2.undistortPointsIter(pts, self.K, self.dist, None, None, _UNDISTORT_CRITERIA).reshape(2)
        else:
            xn, yn = cv2.undistortPoints(pts, self.K, self.dist).reshape(2)
        d = self.R.T @ np.array([xn, yn, 1.0])
        if self.mirror_h is not None:
            d[1] = -d[1]
        return d / np.linalg.norm(d)

    def hit_plane(self, u: float, v: float, z: float = 0.0) -> np.ndarray | None:
        d = self.ray(u, v)
        if abs(d[2]) < 1e-9:
            return None
        s = (z - self.center[2]) / d[2]
        if s <= 0:
            return None
        return self.center + s * d

    def hit_vertical_line(self, u: float, v: float, x: float, y: float) -> np.ndarray:
        """Point on the pixel's ray closest (horizontally) to the vertical line through (x, y)."""
        d = self.ray(u, v)
        h2 = d[0] * d[0] + d[1] * d[1]
        s = ((x - self.center[0]) * d[0] + (y - self.center[1]) * d[1]) / max(h2, 1e-12)
        return self.center + max(s, 0.0) * d

    def project(self, pts: np.ndarray) -> np.ndarray:
        """Project Nx3 field points to Nx2 video pixels (NaN for points behind the camera)."""
        pts = np.atleast_2d(np.asarray(pts, dtype=np.float64))
        pose_pts = self._to_pose(pts)
        cam = (self.R @ pose_pts.T + self.tvec).T
        img, _ = cv2.projectPoints(pose_pts.reshape(-1, 1, 3), self.rvec, self.tvec, self.K, self.dist)
        img = img.reshape(-1, 2) @ self.from_calib[:2, :2].T + self.from_calib[:2, 2]
        img[cam[:, 2] <= 0.05] = np.nan
        return img

    def box_extent_px(self, x: float, y: float, z: float, size_m: tuple[float, float, float]) -> tuple[float, float]:
        """Pixel width/height of an axis-aligned box (L, W, H) standing at (x, y, z)."""
        length, width, height = size_m
        corners = np.array(
            [[x + dx, y + dy, z + dz] for dx in (-length / 2, length / 2) for dy in (-width / 2, width / 2) for dz in (0.0, height)]
        )
        img = self.project(corners)
        if np.isnan(img).any():
            return 0.0, 0.0
        return float(np.ptp(img[:, 0])), float(np.ptp(img[:, 1]))

    def ground_jacobian(self, u: float, v: float, z: float) -> np.ndarray | None:
        """d(x, y)/d(u, v) of the ray/plane hit; used to turn pixel noise into field covariance."""
        p0 = self.hit_plane(u, v, z)
        pu = self.hit_plane(u + 1.0, v, z)
        pv = self.hit_plane(u, v + 1.0, z)
        if p0 is None or pu is None or pv is None:
            return None
        return np.array([[pu[0] - p0[0], pv[0] - p0[0]], [pu[1] - p0[1], pv[1] - p0[1]]])
