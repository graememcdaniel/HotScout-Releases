"""Training pictures for the robot detector, labelled from autos a scout marked good.

Scouting saves a few raw frames of every match (``save_frames``). Once a scout
marks the match good, its confirmed robot paths label those frames
(``match_labels``): every robot gets a box - also robots the detector missed or
that overlap another robot (moved from its nearest sighting along its path) -
robots behind field structures are masked, and everything else the tracker saw
(referees, field parts) stays background. Bumpers get their own boxes so a
detector trained on them also reports the alliance colour.

Hand checks add more pictures (``checked_items``): the keyframes where a person
had to correct the tracker, labelled from their clicks.

Training uses 640px tiles cut from full-resolution frames (``tiles``), so small
far-side robots keep their pixels; the detector then runs on whole frames at
their native width.
"""

from __future__ import annotations

import json
import logging
import math
import re
from pathlib import Path

import cv2
import numpy as np

log = logging.getLogger(__name__)

CLASSES = ["robot", "red_bumper", "blue_bumper"]
FRAMES_PER_MATCH = 12
ANCHOR_MAX_SEC = 2.0  # a robot not seen this close in time is masked, not labelled
TILE = 640
MIN_INSIDE = 0.5  # a box at least this much inside a tile is labelled there; less is masked
EMPTY_TILE_KEEP = 0.35
MASK_GRAY = 114  # YOLO's letterbox gray
LABEL_VERSION = 3
_SAFE = re.compile(r"[^A-Za-z0-9_-]")


def safe_name(match_key: str) -> str:
    return _SAFE.sub("_", match_key)


def frames_dir(dataset_root: Path) -> Path:
    return dataset_root / "frames"


def match_of(p: Path) -> str:
    return p.stem.split("__")[0]


def frame_index(p: Path) -> int:
    return int(p.stem.split("__")[1])


def match_frames(dataset_root: Path, match_key: str) -> list[Path]:
    return sorted(frames_dir(dataset_root).glob(f"{safe_name(match_key)}__*.jpg"))


def checked_dir(dataset_root: Path) -> Path:
    return dataset_root / "checked"


def checked_items(dataset_root: Path) -> dict[str, list[dict]]:
    """Labelled pictures from hand checks (``ground_truth.save_training_frames``), per match."""
    folder = checked_dir(dataset_root)
    out: dict[str, list[dict]] = {}
    for p in sorted(folder.glob("*.json")):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        items = [it for it in data.get("items") or [] if (folder / Path(it["image"]).name).is_file()]
        if items and data.get("match_key"):
            out[data["match_key"]] = items
    return out


def save_frames(run: dict, video_path: str, dataset_root: Path, match_key: str, n: int = FRAMES_PER_MATCH) -> int:
    """Save ``n`` raw frames spread over the tracked window (replacing earlier ones).

    Only processed frames are picked, so every robot sighting at that moment is
    in the saved run.
    """
    grid = run["grid"]
    if not grid:
        return 0
    out = frames_dir(dataset_root)
    out.mkdir(parents=True, exist_ok=True)
    name = safe_name(match_key)
    for old in out.glob(f"{name}__*.jpg"):
        old.unlink(missing_ok=True)
    cap = cv2.VideoCapture(video_path)
    fps = run["meta"].get("fps") or cap.get(cv2.CAP_PROP_FPS) or 30.0
    picks = sorted({int(round(grid[i] * fps)) for i in np.linspace(0, len(grid) - 1, n).round().astype(int)})
    saved = 0
    try:
        for f in picks:
            cap.set(cv2.CAP_PROP_POS_FRAMES, f)
            ok, frame = cap.read()
            if ok:
                cv2.imwrite(str(out / f"{name}__{f:06d}.jpg"), frame, [cv2.IMWRITE_JPEG_QUALITY, 88])
                saved += 1
    finally:
        cap.release()
    log.info("training frames: %s saved %d", match_key, saved)
    return saved


# ------------------------------------------------------------------ labels ---


def _overlap(a: list[float], b: list[float]) -> float:
    """Fraction of ``a`` covered by ``b``."""
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    area = (a[2] - a[0]) * (a[3] - a[1])
    return ix * iy / area if area > 0 else 0.0


def _grow(b: list[float], f: float) -> list[float]:
    dw, dh = (b[2] - b[0]) * f / 2, (b[3] - b[1]) * f / 2
    return [b[0] - dw, b[1] - dh, b[2] + dw, b[3] + dh]


def _clip(b: list[float], W: int, H: int) -> list[float] | None:
    x1, y1, x2, y2 = max(0.0, b[0]), max(0.0, b[1]), min(float(W), b[2]), min(float(H), b[3])
    if x2 - x1 < 4 or y2 - y1 < 4:
        return None
    return [round(x1, 1), round(y1, 1), round(x2, 1), round(y2, 1)]


def _anchored_box(f: int, obs: dict[int, dict], samples: dict[int, dict], camera, size_m, fps: float):
    """(box, labelled) for a robot with no usable sighting at frame ``f``.

    Its nearest sighting's box, moved and scaled with the confirmed path's
    projection. Without a sighting within ``ANCHOR_MAX_SEC`` only a rough
    projected box is returned, which callers use as a mask.
    """
    s = samples[f]
    p_t = camera.project([[s["x_m"], s["y_m"], s["z_m"]]])[0]
    if np.isnan(p_t).any():
        return None, False
    ew_t, eh_t = camera.box_extent_px(s["x_m"], s["y_m"], s["z_m"], size_m)
    near = [g for g in obs if g in samples and not obs[g].get("split")]
    if near:
        g = min(near, key=lambda k: abs(k - f))
        if abs(g - f) / fps <= ANCHOR_MAX_SEC:
            so = samples[g]
            p_o = camera.project([[so["x_m"], so["y_m"], so["z_m"]]])[0]
            ew_o, eh_o = camera.box_extent_px(so["x_m"], so["y_m"], so["z_m"], size_m)
            if not np.isnan(p_o).any() and ew_o > 0 and eh_o > 0:
                k = math.sqrt(max(1e-6, ew_t * eh_t) / max(1e-6, ew_o * eh_o))
                x1, y1, x2, y2 = obs[g]["bbox"]
                w, h = (x2 - x1) * k, (y2 - y1) * k
                bx = p_t[0] + ((x1 + x2) / 2 - p_o[0]) * k
                by = p_t[1] + (y2 - p_o[1]) * k
                return [bx - w / 2, by - h, bx + w / 2, by], True
    return [p_t[0] - 0.6 * ew_t, p_t[1] - 1.2 * eh_t, p_t[0] + 0.6 * ew_t, p_t[1] + 0.6 * eh_t], False


def _label_frames(match_key: str, frames: list[Path], output_dir: Path) -> tuple[list[dict], str | None]:
    from app.tracking.camera import CameraModel
    from app.tracking.pipeline import assign_tracklets, load_run, read_run_context
    from app.tracking.team_id import bumper_strip_box
    from app.tracking.terrain import FieldTerrain

    saved = json.loads((output_dir / match_key / "robots.json").read_text(encoding="utf-8"))
    run_file = output_dir / "runs" / f"{saved['run_id']}.json"
    if not run_file.is_file():
        return [], "tracking run file is gone"
    slots = saved.get("robots") or []
    # A robot the tracker never found could be anywhere in the picture, unlabelled.
    if len(slots) < 6 or any(not r.get("track_ids") for r in slots):
        return [], "a robot was never found"
    ctx = read_run_context(run_file)
    camera = CameraModel.from_run_context(ctx)
    if camera is None:
        return [], "no camera calibration"
    terrain = FieldTerrain.from_registry(ctx["season"], ctx["tag_layout_transform"], *ctx["field_dims"])
    terrain.build_visibility(camera)
    run = load_run(run_file, terrain)
    fps = float(run["meta"].get("fps") or 30.0)
    t0 = float(run["t0"])
    entries, _ = assign_tracklets(
        run,
        camera=camera,
        terrain=terrain,
        assignments=[{"robot_id": r["robot_id"], "team_key": r.get("team_key"), "track_ids": r["track_ids"]} for r in slots],
    )
    # A good match vouches for the paths, not always for the names: keep a team
    # name only if a scout set it (no team_id) or team ID was fairly sure of it.
    trusted = {
        r["robot_id"]
        for r in slots
        if (tid := r.get("team_id")) is None
        or (not tid.get("needs_review") and float(tid.get("confidence") or 0.0) >= 0.5)
    }
    tracks = {tr.id: tr for tr in run["tracker"].tracks}
    robots = []
    for e in entries:
        if e["robot_id"] not in trusted:
            e = {**e, "team_key": None}
        obs = {}
        for tid in e["track_ids"]:
            for o in tracks[tid].obs:
                obs[int(round(o["t"] * fps))] = o["det"]
        samples = {int(round((s["t_sec"] + t0) * fps)): s for s in e["samples"]}
        robots.append((e, obs, samples))

    items = []
    for path in frames:
        f = frame_index(path)
        img = cv2.imread(str(path))
        if img is None:
            continue
        H, W = img.shape[:2]
        labels, masks, usable = [], [], True
        for e, obs, samples in robots:
            det = obs.get(f)
            if det is not None and not det.get("split"):
                labels.append((list(map(float, det["bbox"])), e))
                continue
            if f not in samples:
                usable = False  # can't say where this robot is
                break
            box, labelled = _anchored_box(f, obs, samples, camera, terrain.robot_size, fps)
            if box is None:
                continue  # behind the camera: not in the picture
            if samples[f]["occluded"] or not labelled:
                masks.append(_grow(box, 0.3))
            else:
                labels.append((box, e))
        if not usable:
            continue
        out_robots, out_bumpers = [], []
        for box, e in labels:
            b = _clip(box, W, H)
            if b is None:
                continue
            out_robots.append({"box": b, "robot_id": e["robot_id"], "team_key": e.get("team_key"), "alliance": e["alliance"]})
            strip = bumper_strip_box(img, b, e["alliance"])
            if strip is not None:
                out_bumpers.append({"box": [float(v) for v in strip], "cls": 1 if e["alliance"] == "red" else 2})
        out_masks = [m for m in (_clip(m, W, H) for m in masks) if m is not None]
        if not out_robots:
            continue
        if any(_overlap(r["box"], m) > 0.25 for r in out_robots for m in out_masks):
            continue  # a mask would erase part of a labelled robot
        items.append(
            {"image": path.name, "width": W, "height": H, "robots": out_robots, "bumpers": out_bumpers, "masks": out_masks}
        )
    return items, None


def match_labels(match_key: str, dataset_root: Path, output_dir: Path) -> tuple[list[dict], str | None]:
    """Labelled frames of a match (``image`` is relative to the frames folder), cached
    until its robots.json or frames change. Returns (items, reason if none)."""
    frames = match_frames(dataset_root, match_key)
    if not frames:
        return [], "no saved frames"
    robots_file = output_dir / match_key / "robots.json"
    if not robots_file.is_file():
        return [], "not exported"
    key = {
        "version": LABEL_VERSION,
        "robots_mtime": robots_file.stat().st_mtime,
        "frames": [p.name for p in frames],
    }
    cache = dataset_root / "labels" / f"{safe_name(match_key)}.json"
    try:
        data = json.loads(cache.read_text(encoding="utf-8"))
        if data.get("key") == key:
            return data["items"], data.get("reason")
    except (OSError, ValueError):
        pass
    try:
        items, reason = _label_frames(match_key, frames, output_dir)
    except Exception as exc:  # one broken match must not stop training
        log.warning("labelling %s failed: %s", match_key, exc)
        return [], f"labelling failed: {exc}"
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps({"key": key, "items": items, "reason": reason}), encoding="utf-8")
    return items, reason


# ------------------------------------------------------------------- tiles ---


def apply_masks(img: np.ndarray, masks: list[list[float]]) -> None:
    for x1, y1, x2, y2 in masks:
        img[max(0, int(y1)) : max(0, int(math.ceil(y2))), max(0, int(x1)) : max(0, int(math.ceil(x2)))] = MASK_GRAY


def _origins(size: int) -> list[int]:
    if size <= TILE:
        return [0]
    n = math.ceil((size - TILE) / (0.67 * TILE)) + 1
    return [int(round(v)) for v in np.linspace(0, size - TILE, n)]


def boxes_of(item: dict) -> list[tuple[int, list[float]]]:
    return [(0, r["box"]) for r in item["robots"]] + [(b["cls"], b["box"]) for b in item["bumpers"]]


def tiles(img: np.ndarray, item: dict, rng: np.random.Generator) -> list[tuple[np.ndarray, list[tuple[int, list[float]]]]]:
    """640px tiles of a (masked) frame with their (class, xyxy) labels in tile pixels.

    Boxes mostly inside a tile are labelled; slivers of boxes are masked so the
    detector is not taught that half a robot is background. Some empty tiles
    are kept as negatives.
    """
    H, W = img.shape[:2]
    boxes = boxes_of(item)
    out = []
    for oy in _origins(H):
        for ox in _origins(W):
            tw, th = min(TILE, W - ox), min(TILE, H - oy)
            win = [ox, oy, ox + tw, oy + th]
            rows, slivers = [], []
            for cls, b in boxes:
                frac = _overlap(b, win)
                if frac <= 0:
                    continue
                c = [max(b[0], win[0]) - ox, max(b[1], win[1]) - oy, min(b[2], win[2]) - ox, min(b[3], win[3]) - oy]
                (rows if frac >= MIN_INSIDE else slivers).append((cls, c))
            # Don't mask a sliver that would cover part of a kept robot: keep it as a label instead.
            keep = []
            for cls, c in slivers:
                if any(_overlap(r, c) > 0.2 or _overlap(c, r) > 0.2 for k, r in rows if k == 0):
                    rows.append((cls, c))
                else:
                    keep.append(c)
            if not rows and rng.random() > EMPTY_TILE_KEEP:
                continue
            tile = img[oy : oy + th, ox : ox + tw].copy()
            apply_masks(tile, keep)
            out.append((tile, [(cls, c) for cls, c in rows if c[2] - c[0] >= 3 and c[3] - c[1] >= 3]))
    return out


def yolo_rows(rows: list[tuple[int, list[float]]], W: int, H: int) -> str:
    return "".join(
        f"{cls} {(x1 + x2) / 2 / W:.6f} {(y1 + y2) / 2 / H:.6f} {(x2 - x1) / W:.6f} {(y2 - y1) / H:.6f}\n"
        for cls, (x1, y1, x2, y2) in rows
    )


# -------------------------------------------------------- outside datasets ---

_IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def _class_role(name: str) -> str:
    n = name.lower()
    if "bumper" in n:
        return "red_bumper" if "red" in n else "blue_bumper" if "blue" in n else "bumper"
    if "robot" in n or n in {"bot", "bots", "frc"}:
        return "robot"
    return "ignored"


def _bumper_colour(img: np.ndarray, box: list[float]) -> int | None:
    from app.tracking.team_id import _colour_mask

    x1, y1, x2, y2 = (int(v) for v in box)
    roi = img[max(0, y1) : max(0, y2), max(0, x1) : max(0, x2)]
    if roi.size == 0:
        return None
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    red, blue = (float((_colour_mask(hsv, a) > 0).mean()) for a in ("red", "blue"))
    if max(red, blue) < 0.2:
        return None
    return 1 if red > blue else 2


def external_datasets(root: Path) -> list[dict]:
    """YOLO-format exports (e.g. from Roboflow Universe) under ``root/<name>/``."""
    import yaml

    out = []
    for cfg in sorted(root.glob("*/data.yaml")):
        try:
            names = yaml.safe_load(cfg.read_text(encoding="utf-8")).get("names") or []
        except (OSError, ValueError, AttributeError, yaml.YAMLError):
            continue
        if isinstance(names, dict):
            names = [names[k] for k in sorted(names)]
        roles = {i: _class_role(str(n)) for i, n in enumerate(names)}
        images, seen = [], set()
        for p in sorted(cfg.parent.rglob("*")):
            if p.suffix.lower() not in _IMAGE_EXT or p.parent.name != "images":
                continue
            if not (p.parent.parent / "labels" / f"{p.stem}.txt").is_file():
                continue
            # Roboflow exports augmented copies as <source>_jpg.rf.<hash>: one is enough
            # (training augments anyway) and copies would outweigh this season's frames.
            source = p.name.split(".rf.")[0]
            if source in seen:
                continue
            seen.add(source)
            images.append(p)
        out.append({
            "name": cfg.parent.name,
            "images": images,
            "classes": {str(n): roles[i] for i, n in enumerate(names)},
            "roles": roles,
        })
    return out


def _derived_bumper(img: np.ndarray, box: list[float]) -> dict | None:
    """Bumper label for a robot in a dataset that labels only robots: the larger colour strip."""
    from app.tracking.team_id import bumper_strip_box

    found = []
    for cls, alliance in ((1, "red"), (2, "blue")):
        b = bumper_strip_box(img, box, alliance)
        if b is not None:
            found.append(((b[2] - b[0]) * (b[3] - b[1]), cls, [float(v) for v in b]))
    if not found:
        return None
    _, cls, b = max(found)
    return {"box": b, "cls": cls}


def external_item(img: np.ndarray, label_file: Path, roles: dict[int, str]) -> dict:
    """Read a YOLO label file (boxes or polygons) into an item with this project's classes.

    When the dataset has no bumper classes, bumpers are found by colour under each robot.
    """
    H, W = img.shape[:2]
    derive = not any(r in {"red_bumper", "blue_bumper", "bumper"} for r in roles.values())
    item = {"robots": [], "bumpers": [], "masks": []}
    for line in label_file.read_text(encoding="utf-8").splitlines():
        v = line.split()
        if len(v) < 5:
            continue
        cls, nums = int(float(v[0])), [float(x) for x in v[1:]]
        if len(nums) == 4:
            cx, cy, w, h = nums
            box = [(cx - w / 2) * W, (cy - h / 2) * H, (cx + w / 2) * W, (cy + h / 2) * H]
        else:  # polygon
            xs, ys = nums[0::2], nums[1::2]
            box = [min(xs) * W, min(ys) * H, max(xs) * W, max(ys) * H]
        box = _clip(box, W, H)
        if box is None:
            continue
        role = roles.get(cls, "ignored")
        if role == "robot":
            item["robots"].append({"box": box})
            bumper = _derived_bumper(img, box) if derive else None
            if bumper:
                item["bumpers"].append(bumper)
        elif role in {"red_bumper", "blue_bumper", "bumper"}:
            c = {"red_bumper": 1, "blue_bumper": 2}.get(role) or _bumper_colour(img, box)
            if c is None:
                item["masks"].append(box)
            else:
                item["bumpers"].append({"box": box, "cls": c})
        else:
            item["masks"].append(box)
    return item
