"""Broadcast re-framing: where the calibrated wide shot sits in a match video.

Event calibrations are clicked on one frame, often before the match. Broadcasts
then move or resize the wide shot (e.g. into the top half of a split screen once
the match starts), which moves every field point in the image. This matches
features of the calibrated field area between the calibration frame and a few
frames of the tracked window, and returns the video -> calibration pixel mapping
(a similarity: shift, scale, small rotation) for ``CameraModel``.
"""

from __future__ import annotations

import base64
import logging
from pathlib import Path

import cv2
import numpy as np

from app.tracking.camera import CameraModel

log = logging.getLogger(__name__)

REF_WIDTH = 960  # stored reference frame width (grey JPEG)
MIN_INLIERS = 40
MIN_INLIER_SHARE = 0.3
AGREE_PX = 4.0  # sampled frames must agree this well (calibration pixels)
MIN_SHIFT_PX = 2.0  # smaller changes are left alone
_WALL_Z = 2.0  # field area used for matching includes the walls up to this height


def _grab(video_path: str, t_sec: float) -> np.ndarray | None:
    cap = cv2.VideoCapture(str(video_path))
    try:
        cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, t_sec) * 1000.0)
        ok, frame = cap.read()
    finally:
        cap.release()
    return frame if ok else None


def _grey(frame: np.ndarray, width: int = REF_WIDTH) -> tuple[np.ndarray, float]:
    """Grey copy at most ``width`` wide, and its size relative to the input."""
    g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
    s = min(1.0, width / g.shape[1])
    if s < 1.0:
        g = cv2.resize(g, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    return g, s


def encode_reference(video_path: str, frame_sec: float) -> str | None:
    """The calibration frame as a small grey JPEG (base64), stored with the event calibration."""
    frame = _grab(video_path, frame_sec)
    if frame is None:
        return None
    g, _ = _grey(frame)
    ok, buf = cv2.imencode(".jpg", g, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return base64.b64encode(buf.tobytes()).decode("ascii") if ok else None


def reference_image(record: dict) -> np.ndarray | None:
    """Grey calibration frame of an event calibration record (stored, or re-read from its video)."""
    data = record.get("reference_frame_jpeg")
    if data:
        try:
            buf = np.frombuffer(base64.b64decode(data), dtype=np.uint8)
            img = cv2.imdecode(buf, cv2.IMREAD_GRAYSCALE)
            if img is not None:
                return img
        except ValueError:
            pass
    src = record.get("source_video_path")
    frame_sec = (record.get("calibration_request") or {}).get("frame_sec")
    if src and frame_sec is not None and Path(src).is_file():
        frame = _grab(src, float(frame_sec))
        if frame is not None:
            return _grey(frame)[0]
    return None


def _field_mask(camera: CameraModel, shape: tuple[int, int], to_ref: float, dims: tuple[float, float]) -> np.ndarray:
    length, width = dims
    corners = np.array([[x, y, z] for x in (0.0, length) for y in (0.0, width) for z in (0.0, _WALL_Z)])
    px = camera.project(corners)
    px = px[~np.isnan(px).any(axis=1)] * to_ref
    mask = np.zeros(shape, np.uint8)
    if len(px) >= 3:
        cv2.fillConvexPoly(mask, cv2.convexHull(px.astype(np.float32)).astype(np.int32), 255)
    return mask


def _h(a: np.ndarray) -> np.ndarray:
    return np.vstack([np.asarray(a, dtype=np.float64).reshape(2, 3), [0.0, 0.0, 1.0]])


def estimate_view_affine(
    record: dict,
    video_path: str,
    times: list[float],
    to_calib: tuple[float, float],
    field_dims: tuple[float, float],
) -> dict | None:
    """``{"affine", "shift_px", "scale", "inliers", "times"}`` when the view moved since calibration, else None.

    ``affine`` maps video pixels to calibration pixels (2x3); None also when the
    calibration frame can't be matched (keep the plain resolution scale then).
    """
    camera = CameraModel.from_calibration(record.get("calibration_meta") or {})
    ref = reference_image(record)
    cal_w = float(record.get("image_width") or 0)
    if camera is None or ref is None or cal_w <= 0:
        return None
    to_ref = ref.shape[1] / cal_w  # calibration pixels -> reference image pixels
    mask = _field_mask(camera, ref.shape[:2], to_ref, field_dims)
    if not mask.any():
        return None
    sift = cv2.SIFT_create(4000)
    k1, d1 = sift.detectAndCompute(ref, mask)
    if d1 is None or len(k1) < MIN_INLIERS:
        return None
    matcher = cv2.BFMatcher()
    found = []
    for t in times:
        frame = _grab(video_path, t)
        if frame is None:
            continue
        g, s_vid = _grey(frame)
        k2, d2 = sift.detectAndCompute(g, None)
        if d2 is None or len(k2) < MIN_INLIERS:
            continue
        good = [m[0] for m in matcher.knnMatch(d1, d2, k=2) if len(m) == 2 and m[0].distance < 0.75 * m[1].distance]
        if len(good) < MIN_INLIERS:
            continue
        src = np.float32([k1[m.queryIdx].pt for m in good])
        dst = np.float32([k2[m.trainIdx].pt for m in good])
        a, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=2.0, maxIters=5000)
        n = int(inl.sum()) if inl is not None else 0
        if a is None or n < MIN_INLIERS or n < MIN_INLIER_SHARE * len(good):
            continue
        # video px -> small video -> reference -> calibration px
        m = np.diag([1 / to_ref, 1 / to_ref, 1.0]) @ np.linalg.inv(_h(a)) @ np.diag([s_vid, s_vid, 1.0])
        found.append((t, m, n))
    if not found:
        log.info("view shift: calibration frame not matched in %s", Path(video_path).name)
        return None
    # Where the field corners land in calibration pixels under each estimate (and with no change).
    probe_cal = camera.project(np.array([[x, y, 0.0] for x in (0.0, field_dims[0]) for y in (0.0, field_dims[1])]))
    probe_cal = probe_cal[~np.isnan(probe_cal).any(axis=1)]
    plain = np.diag([to_calib[0], to_calib[1], 1.0])
    probe_vid = np.c_[probe_cal, np.ones(len(probe_cal))] @ np.linalg.inv(plain).T
    maps = [(np.c_[probe_vid] @ m.T)[:, :2] for _, m, _ in found]
    med = np.median(np.stack(maps), axis=0)
    agree = [i for i, p in enumerate(maps) if np.abs(p - med).max() <= AGREE_PX]
    if len(agree) < max(1, (len(found) + 1) // 2):
        log.warning("view shift: sampled frames disagree (%s)", [round(float(np.abs(p - med).max()), 1) for p in maps])
        return None
    best = max(agree, key=lambda i: found[i][2])
    m = found[best][1]
    moved = np.abs(maps[best] - probe_cal).max()
    if moved < MIN_SHIFT_PX:
        return None
    inv = np.linalg.inv(m)  # calibration px -> video px: how the view moved
    shift = (np.c_[probe_cal, np.ones(len(probe_cal))] @ inv.T)[:, :2] - probe_vid[:, :2]
    return {
        "affine": [[round(float(v), 6) for v in row] for row in m[:2]],
        "shift_px": [round(float(v), 1) for v in shift.mean(axis=0)],
        "scale": round(float(np.hypot(inv[0, 0], inv[1, 0]) / np.hypot(*np.linalg.inv(plain)[0, :2])), 4),
        "inliers": [found[i][2] for i in agree],
        "times": [round(found[i][0], 2) for i in agree],
    }
