from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

from app.core.gpu import torch_device
from app.tracking.camera import CameraModel, densify_polygon
from app.tracking.terrain import FieldTerrain

_HIST_BINS = [18, 8]


def _red_mask(hsv: np.ndarray) -> np.ndarray:
    return cv2.inRange(hsv, (0, 100, 70), (10, 255, 255)) | cv2.inRange(hsv, (170, 100, 70), (180, 255, 255))


def _blue_mask(hsv: np.ndarray) -> np.ndarray:
    # Navy bumpers are blue-hued but only ~S 40-90 under arena lights; grey carpet stays below S 55.
    return cv2.inRange(hsv, (100, 55, 45), (130, 255, 255))


def appearance_similarity(a: np.ndarray | None, b: np.ndarray | None) -> float:
    if a is None or b is None:
        return 0.5
    return float(max(0.0, 1.0 - cv2.compareHist(a, b, cv2.HISTCMP_BHATTACHARYYA)))


class PersonDetector:
    """COCO 'person' boxes (refs, field staff) used to veto foreground pixels."""

    def __init__(self, model_path: str, conf: float = 0.2, imgsz: int = 960):
        from ultralytics import YOLO

        self.device = torch_device()
        self.model = YOLO(model_path)
        self.conf = conf
        self.imgsz = imgsz

    def __call__(self, frame: np.ndarray) -> list[list[float]]:
        res = self.model.predict(
            frame, classes=[0], conf=self.conf, imgsz=self.imgsz, device=self.device, verbose=False
        )
        if not res or res[0].boxes is None or len(res[0].boxes) == 0:
            return []
        boxes = res[0].boxes.xyxy.cpu().numpy()
        # People are much taller than wide; a squat "person" box is usually a robot.
        return [b.tolist() for b in boxes if (b[3] - b[1]) >= 1.3 * (b[2] - b[0])]


class RobotBoxModel:
    """Learned robot box detector (open-vocabulary YOLO-World or a fine-tuned YOLO checkpoint).

    FRC robots are not a COCO class, so YOLO-World is prompted with several
    descriptions it does respond to; low scores are expected and the field
    geometry checks in ``RobotDetector.detect_boxes`` remove false hits.
    The same pass returns people (refs, staff) for the person veto.
    """

    PROMPTS = ["robot", "toy car", "box", "cart", "machine", "vehicle", "person"]

    def __init__(self, model_path: str, conf: float = 0.03, imgsz: int | None = None):
        from ultralytics import YOLO, YOLOWorld

        self.device = torch_device()
        self.bumper_cls: dict[int, str] = {}
        self.last_bumpers: list[tuple[list[float], str, float]] = []
        self.world = "world" in Path(model_path).name.lower()
        if self.world:
            self.model = YOLOWorld(model_path)
            self.model.set_classes(self.PROMPTS)
            self.person_cls = self.PROMPTS.index("person")
        else:
            # A checkpoint trained on robots: its scores are meaningful, and it has no person class.
            self.model = YOLO(model_path)
            self.person_cls = -1
            conf = max(conf, 0.15)
            names = self.model.names or {}
            self.bumper_cls = {k: n.split("_")[0] for k, n in names.items() if n in {"red_bumper", "blue_bumper"}}
            try:  # trained on full-resolution tiles: run on frames at their native width
                imgsz = imgsz or int(json.loads((Path(model_path).parent / "meta.json").read_text(encoding="utf-8"))["infer_imgsz"])
            except (OSError, ValueError, KeyError, TypeError):
                pass
        self.conf = conf
        self.imgsz = imgsz or 1280

    def __call__(self, frame: np.ndarray) -> tuple[list[tuple[list[float], float]], list[list[float]]]:
        """Returns (robot boxes with confidence, person boxes), full-resolution xyxy.

        Bumper boxes of a model trained with bumper classes are kept in
        ``last_bumpers`` as (xyxy, "red"|"blue", confidence).
        """
        res = self.model.predict(
            frame,
            conf=self.conf,
            imgsz=self.imgsz,
            device=self.device,
            half=False,  # FP16 returns no boxes for YOLO-World on Turing GPUs (and is slower)
            agnostic_nms=self.world,
            iou=0.5,
            verbose=False,
        )
        self.last_bumpers = []
        if not res or res[0].boxes is None or len(res[0].boxes) == 0:
            return [], []
        b = res[0].boxes
        robots, people = [], []
        for xy, c, k in zip(b.xyxy.cpu().numpy(), b.conf.cpu().numpy(), b.cls.cpu().numpy().astype(int)):
            if k == self.person_cls:
                if c >= 0.25 and (xy[3] - xy[1]) >= 1.3 * (xy[2] - xy[0]):
                    people.append(xy.tolist())
            elif k in self.bumper_cls:
                self.last_bumpers.append((xy.tolist(), self.bumper_cls[k], float(c)))
            else:
                robots.append((xy.tolist(), float(c)))
        return robots, people


def _box_iou(a, b) -> float:
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


class BoxEnsemble:
    """Several ``RobotBoxModel``s run on each frame, used like one.

    A robot both models find (IoU >= 0.5) scores 1-(1-a)(1-b) and keeps the
    first model's box; one only a single model finds keeps half its score.
    On held-out 2026 frames the season model + YOLO-World scored AP50 0.85
    against 0.80 for the season model alone. People and bumpers come from
    whichever member reports them.
    """

    def __init__(self, model_paths: list[str]):
        self.models = [RobotBoxModel(p) for p in model_paths]
        self.device = self.models[0].device
        self.person_cls = max(m.person_cls for m in self.models)
        self.last_bumpers: list[tuple[list[float], str, float]] = []

    def __call__(self, frame: np.ndarray) -> tuple[list[tuple[list[float], float]], list[list[float]]]:
        merged: list[tuple[list[float], list[float]]] = []  # (box, every member's score for it)
        people: list[list[float]] = []
        self.last_bumpers = []
        for m in self.models:
            robots, found = m(frame)
            people += found
            self.last_bumpers += m.last_bumpers
            n, used = len(merged), set()
            for box, c in sorted(robots, key=lambda r: -r[1]):
                j = max((k for k in range(n) if k not in used), key=lambda k: _box_iou(box, merged[k][0]), default=-1)
                if j >= 0 and _box_iou(box, merged[j][0]) >= 0.5:
                    used.add(j)
                    merged[j][1].append(c)
                else:
                    merged.append((box, [c]))
        return [(b, 1 - float(np.prod([1 - c for c in cs])) if len(cs) > 1 else 0.5 * cs[0]) for b, cs in merged], people


class RobotDetector:
    """Finds robots with a static-camera background model and the 3D field map.

    Candidates are foreground blobs inside the projected field volume whose
    foot point lands on the field and whose pixel size matches a robot standing
    at that spot. Each detection carries a field position (on the terrain), a
    measurement covariance, bumper colour evidence and an appearance histogram.
    """

    def __init__(
        self,
        camera: CameraModel,
        terrain: FieldTerrain,
        frame_size: tuple[int, int],
        proc_scale: float = 0.5,
        diff_threshold: int = 30,
        max_object_height_m: float = 1.3,
    ):
        self.camera = camera
        self.terrain = terrain
        self.w, self.h = frame_size
        self.scale = proc_scale
        self.pw, self.ph = int(round(self.w * proc_scale)), int(round(self.h * proc_scale))
        self.diff_threshold = diff_threshold
        self.background: np.ndarray | None = None
        # Red/blue that is part of the scene (score overlay and its glow, ramps, signs), from the background.
        self.graphic: np.ndarray | None = None
        self.field_mask = self._field_mask()
        # Lowest image row of the field volume per column: a blob that reaches it
        # continues outside the field (e.g. a ref standing beside the near wall).
        rows = np.arange(self.ph)[:, None]
        self._mask_bottom = np.where(self.field_mask.any(axis=0), (rows * (self.field_mask > 0)).max(axis=0), -1)
        self.solid_mask = terrain.occluder_mask(camera, self.pw, self.ph, proc_scale)
        self.occluder_mask = cv2.dilate(self.solid_mask, np.ones((5, 5), np.uint8))
        self._blockers = self.occluder_mask
        self.max_object_height_m = max_object_height_m
        self._ppm = self._pixels_per_meter_table()
        self._k_open = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        self._k_close = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
        # Bridges the white team numbers printed on bumpers.
        self._k_strip = cv2.getStructuringElement(cv2.MORPH_RECT, (7, 3))
        self._field_px = np.flatnonzero(self.field_mask.reshape(-1)[::7])

    def _field_mask(self) -> np.ndarray:
        L, W = self.terrain.length, self.terrain.width
        lift = self.terrain.robot_size[2] + 0.4
        rect = densify_polygon(np.array([[0, 0], [L, 0], [L, W], [0, W]], dtype=np.float64))
        n = len(rect)
        pts = np.vstack([np.c_[rect, np.zeros(n)], np.c_[rect, np.full(n, lift)]])
        img = self.camera.project(pts)
        mask = np.zeros((self.ph, self.pw), dtype=np.uint8)
        if np.isnan(img).any():
            mask[:] = 255
            return mask
        cv2.fillConvexPoly(mask, cv2.convexHull((img * self.scale).astype(np.int32)), 255)
        return mask

    def _pixels_per_meter_table(self, col_bins: int = 8) -> np.ndarray:
        """Vertical processing-pixels per metre of height for an object standing at each image cell."""
        rows = np.arange(0, self.ph, 4)
        table = np.full((len(rows), col_bins), np.nan)
        for ci in range(col_bins):
            u = (ci + 0.5) * self.pw / col_bins / self.scale
            for ri, r in enumerate(rows):
                p = self.camera.hit_plane(u, r / self.scale, 0.0)
                if p is None:
                    continue
                img = self.camera.project(np.array([p, p + [0.0, 0.0, 1.0]]))
                if not np.isnan(img).any():
                    table[ri, ci] = abs(img[0, 1] - img[1, 1]) * self.scale
        return table

    def _ppm_at(self, rows: np.ndarray, cols: np.ndarray) -> np.ndarray:
        ri = np.clip(rows // 4, 0, self._ppm.shape[0] - 1)
        ci = np.clip(cols * self._ppm.shape[1] // self.pw, 0, self._ppm.shape[1] - 1)
        return self._ppm[ri, ci]

    def _remove_tall_columns(self, comp: np.ndarray, x0: int, y0: int) -> np.ndarray:
        """Drop columns taller than any robot can be (people, field structures)."""
        has = comp.any(axis=0)
        h = comp.shape[0]
        top = np.argmax(comp, axis=0)
        bottom = h - 1 - np.argmax(comp[::-1], axis=0)
        cols = np.arange(comp.shape[1])
        ppm = self._ppm_at(y0 + bottom, x0 + cols)
        tall = has & (np.nan_to_num(ppm, nan=np.inf) * self.max_object_height_m < (bottom - top + 1))
        if not tall.any():
            return comp
        tall = np.convolve(tall.astype(np.uint8), np.ones(5, np.uint8), mode="same") > 0
        out = comp.copy()
        out[:, tall] = False
        return out

    def _prep(self, frame: np.ndarray) -> np.ndarray:
        small = cv2.resize(frame, (self.pw, self.ph), interpolation=cv2.INTER_AREA)
        return cv2.GaussianBlur(small, (3, 3), 0)

    def build_background(self, video_path: str, fps: float, t_lo: float, t_hi: float, samples: int = 41) -> int:
        cap = cv2.VideoCapture(video_path)
        frames = []
        for t in np.linspace(t_lo, t_hi, samples):
            cap.set(cv2.CAP_PROP_POS_FRAMES, int(t * fps))
            ok, frame = cap.read()
            if ok:
                frames.append(self._prep(frame))
        cap.release()
        if frames:
            self.background = np.median(np.stack(frames), axis=0).astype(np.uint8)
            self._scene_colour()
        return len(frames)

    def _scene_colour(self) -> None:
        """Find big red/blue areas mostly outside the field (the broadcast score
        overlay): they hide whatever is behind them and are never bumpers.
        """
        hsv = cv2.cvtColor(self.background, cv2.COLOR_BGR2HSV)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(_red_mask(hsv) | _blue_mask(hsv), connectivity=8)
        graphic = np.zeros((self.ph, self.pw), np.uint8)
        for i in range(1, n):
            area = int(stats[i, 4])
            if area < 0.004 * self.pw * self.ph:
                continue
            comp = labels == i
            if np.count_nonzero(self.field_mask[comp]) < 0.5 * area:
                graphic[comp] = 255
        if graphic.any():
            graphic = cv2.dilate(graphic, np.ones((15, 15), np.uint8))
            self.occluder_mask = self.occluder_mask | graphic
            self._blockers = self.occluder_mask
        self.graphic = graphic

    def _foreground(self, small: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        bg = self.background
        # Compensate global exposure drift of broadcast video.
        g_bg = cv2.cvtColor(bg, cv2.COLOR_BGR2GRAY).reshape(-1)[::7][self._field_px]
        g_fr = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY).reshape(-1)[::7][self._field_px]
        gain = float(np.median(g_bg)) / max(1.0, float(np.median(g_fr)))
        if abs(gain - 1.0) > 0.03:
            small = cv2.convertScaleAbs(small, alpha=gain)
        diff = cv2.absdiff(small, bg).max(axis=2)
        fg = (diff > self.diff_threshold).astype(np.uint8) * 255
        fg &= self.field_mask
        hsv = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
        # Game pieces (yellow fuel) move constantly; they are not robots.
        yellow = cv2.inRange(hsv, (18, 110, 110), (40, 255, 255))
        fg &= cv2.bitwise_not(yellow)
        fg = cv2.morphologyEx(fg, cv2.MORPH_OPEN, self._k_open)
        fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, self._k_close)
        return fg, hsv

    def _person_mask(self, boxes: list[list[float]] | None) -> np.ndarray | None:
        if not boxes:
            return None
        mask = np.zeros((self.ph, self.pw), dtype=np.uint8)
        s = self.scale
        for x1, y1, x2, y2 in boxes:
            pad_x, pad_y = 0.12 * (x2 - x1), 0.04 * (y2 - y1)
            cv2.rectangle(
                mask,
                (int((x1 - pad_x) * s), int((y1 - pad_y) * s)),
                (int((x2 + pad_x) * s), int((y2 + pad_y) * s)),
                255,
                -1,
            )
        return mask

    def detect(self, frame: np.ndarray, person_boxes: list[list[float]] | None = None) -> list[dict]:
        if self.background is None:
            return []
        small = self._prep(frame)
        fg, hsv = self._foreground(small)
        # Hub/structure faces change with their lights; anything visible there is
        # either the structure or the top of a robot whose base is below it.
        fg &= cv2.bitwise_not(self.solid_mask)
        person = self._person_mask(person_boxes)
        self._blockers = self.occluder_mask if person is None else (self.occluder_mask | person)
        if person is not None:
            fg &= cv2.bitwise_not(person)
        n, labels, stats, _ = cv2.connectedComponentsWithStats(fg, connectivity=8)
        out: list[dict] = []
        for i in range(1, n):
            x, y, w, h, area = (int(v) for v in stats[i])
            if area < 80 or w < 6 or h < 6:
                continue
            comp = labels[y : y + h, x : x + w] == i
            trimmed = self._remove_tall_columns(comp, x, y)
            if trimmed is comp:
                out.extend(self._candidates(comp, x, y, hsv))
                continue
            m, sub_labels, sub_stats, _ = cv2.connectedComponentsWithStats(trimmed.astype(np.uint8), connectivity=8)
            for j in range(1, m):
                sx, sy, sw, sh, sa = (int(v) for v in sub_stats[j])
                if sa < 80 or sw < 6 or sh < 6:
                    continue
                sub = sub_labels[sy : sy + sh, sx : sx + sw] == j
                out.extend(self._candidates(sub, x + sx, y + sy, hsv))
        return self._suppress_duplicates(out)

    def detect_boxes(
        self,
        frame: np.ndarray,
        boxes: list[tuple[list[float], float]],
        person_boxes: list[list[float]] | None = None,
        bumpers: list[tuple[list[float], str, float]] | None = None,
    ) -> list[dict]:
        """Describe learned-detector boxes (full-res xyxy, confidence) with the field model.

        ``bumpers`` (xyxy, "red"|"blue", confidence) from a model trained with
        bumper classes back up the colour-strip measurement of the box they sit in.
        """
        small = self._prep(frame)
        if self.background is not None:
            fg, hsv = self._foreground(small)
        else:
            fg, hsv = None, cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
        person = self._person_mask(person_boxes)
        self._blockers = self.occluder_mask if person is None else (self.occluder_mask | person)
        s = self.scale
        out: list[dict] = []
        for (x1, y1, x2, y2), conf in boxes:
            area = max(1.0, (x2 - x1) * (y2 - y1))
            if any(
                max(0.0, min(x2, p[2]) - max(x1, p[0])) * max(0.0, min(y2, p[3]) - max(y1, p[1])) > 0.6 * area
                for p in person_boxes or []
            ):
                continue  # the box is (mostly) a referee or field staff
            x0, y0 = max(0, int(x1 * s)), max(0, int(y1 * s))
            xe, ye = min(self.pw, int(np.ceil(x2 * s))), min(self.ph, int(np.ceil(y2 * s)))
            if xe - x0 < 4 or ye - y0 < 4:
                continue
            if np.count_nonzero(self.solid_mask[y0:ye, x0:xe]) > 0.45 * (xe - x0) * (ye - y0):
                continue  # mostly a hub/field structure
            if fg is not None and np.count_nonzero(fg[y0:ye, x0:xe]) < 0.2 * (xe - x0) * (ye - y0):
                continue  # matches the long-term background: static field element, not a robot
            d = self._describe(np.ones((ye - y0, xe - x0), dtype=bool), x0, y0, hsv)
            if d is None or not d["valid"]:
                continue
            for bb, colour, bconf in bumpers or []:
                cx, cy = (bb[0] + bb[2]) / 2, (bb[1] + bb[3]) / 2
                if self.graphic is not None and self.graphic[min(self.ph - 1, int(cy * s)), min(self.pw - 1, int(cx * s))]:
                    continue  # on the score overlay, not a bumper
                if x1 <= cx <= x2 and y1 + 0.4 * (y2 - y1) <= cy <= y2 + 0.1 * (y2 - y1):
                    d["bumper"][colour] = max(d["bumper"][colour], min(1.0, 0.3 + 0.7 * bconf))
            if conf < 0.08 and max(d["bumper"]["red"], d["bumper"]["blue"]) < 0.3:
                continue  # weak box without a bumper strip
            d["det_conf"] = float(conf)
            d["quality"] *= 0.5 + 0.5 * float(conf)
            out.append(d)
        return self._suppress_duplicates(out)

    def _candidates(self, comp: np.ndarray, x0: int, y0: int, hsv: np.ndarray) -> list[dict]:
        first = self._describe(comp, x0, y0, hsv)
        if first is None:
            return []
        if first["size_ratio"] < 1.45 or first["width_ratio"] < 1.7:
            return [first] if first["valid"] else []
        # Merged robots: split the blob into robot-width columns.
        k = int(min(3, max(2, round(first["width_ratio"]))))
        cols = np.array_split(np.arange(comp.shape[1]), k)
        out = []
        for c in cols:
            sub = np.zeros_like(comp)
            sub[:, c] = comp[:, c]
            ys, xs = np.nonzero(sub)
            if len(xs) < 40:
                continue
            sub = sub[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1]
            d = self._describe(sub, x0 + int(xs.min()), y0 + int(ys.min()), hsv)
            if d is not None and d["valid"]:
                d["split"] = True
                out.append(d)
        return out

    def _describe(self, comp: np.ndarray, x0: int, y0: int, hsv: np.ndarray) -> dict | None:
        h, w = comp.shape
        s = self.scale
        ys, xs = np.nonzero(comp)
        if len(xs) == 0:
            return None
        bottom_rows = ys >= (h - max(2, int(0.15 * h)))
        fx, fy = x0 + int(xs[bottom_rows].mean()), min(self.ph - 1, y0 + h - 1)
        if self.solid_mask[fy, fx]:
            return None  # lowest visible point is on/behind a solid obstacle
        has = comp.any(axis=0)
        col_bottom = y0 + h - 1 - np.argmax(comp[::-1], axis=0)
        at_edge = col_bottom >= self._mask_bottom[x0 : x0 + w] - 2
        if np.count_nonzero(at_edge & has) > 0.3 * np.count_nonzero(has):
            return None  # continues below the near field edge: not on the field
        u = (fx + 0.5) / s
        v = (y0 + h) / s
        foot = self.terrain.ground_hit(self.camera, u, v)
        if foot is None or not self.terrain.in_field(foot[0], foot[1], margin=0.15):
            return None
        if self.terrain.is_hidden(foot[0], foot[1]):
            return None  # floor the camera cannot see behind a solid: not a robot's base

        # The blob's lowest point is the bumper edge nearest the camera; the
        # robot centre sits about half a robot further along the view ray.
        horiz = foot[:2] - self.camera.center[:2]
        horiz /= max(1e-9, float(np.linalg.norm(horiz)))
        center_xy = foot[:2] + horiz * (0.42 * self.terrain.robot_size[0])
        z = self.terrain.height(center_xy[0], center_xy[1])

        ew, eh = self.camera.box_extent_px(center_xy[0], center_xy[1], z, self.terrain.robot_size)
        bw, bh = w / s, h / s
        if ew <= 1 or eh <= 1:
            return None
        size_ratio = float(np.sqrt((bw * bh) / (ew * eh)))
        aspect_rel = (bh / bw) / (eh / ew)
        valid = 0.3 <= size_ratio <= 3.2 and aspect_rel <= 2.3 and len(xs) >= 0.12 * ew * eh * s * s

        crop = hsv[y0 : y0 + h, x0 : x0 + w]
        mask = comp.astype(np.uint8) * 255
        band = mask.copy()
        band[: int(h * 0.55)] = 0
        band_n = max(1, int(np.count_nonzero(band)))
        red, blue = _red_mask(crop), _blue_mask(crop)
        red_frac = float(np.count_nonzero(red & band)) / band_n
        blue_frac = float(np.count_nonzero(blue & band)) / band_n
        bumper = {"red": self._bumper_span(red, band, w), "blue": self._bumper_span(blue, band, w)}
        hist = cv2.calcHist([crop], [0, 1], mask, _HIST_BINS, [0, 180, 0, 256])
        hist = (hist / max(1.0, float(hist.sum()))).astype(np.float32)

        bottom = min(self.ph - 1, y0 + h + 2)
        truncated = bool(np.count_nonzero(self._blockers[bottom, x0 : x0 + w]) > 0.3 * w)

        sigma_u = max(3.0, 0.08 * bw)
        sigma_v = max(3.0, 0.06 * bh) * (6.0 if truncated else 1.0)
        J = self.camera.ground_jacobian(u, v, float(foot[2]))
        R = (J @ np.diag([sigma_u**2, sigma_v**2]) @ J.T if J is not None else np.eye(2) * 0.25) + np.eye(2) * 0.05**2

        quality = float(np.exp(-(np.log(size_ratio) ** 2) / (2 * 0.5**2)))
        quality *= 0.55 + 0.45 * min(1.0, 1.5 * max(bumper["red"], bumper["blue"]))
        quality *= 0.6 if truncated else 1.0
        return {
            "bbox": [x0 / s, y0 / s, (x0 + w) / s, (y0 + h) / s],
            "foot_px": [u, v],
            "foot_xyz": [float(foot[0]), float(foot[1]), float(foot[2])],
            "xy": [float(center_xy[0]), float(center_xy[1])],
            "z": float(z),
            "R": R,
            "size_ratio": size_ratio,
            "width_ratio": bw / ew,
            "red": red_frac,
            "blue": blue_frac,
            "bumper": bumper,
            "hist": hist,
            "truncated": truncated,
            "quality": quality,
            "valid": bool(valid),
            "split": False,
        }

    def _bumper_span(self, color: np.ndarray, band: np.ndarray, w: int) -> float:
        """Widest solid, horizontal strip of one colour in the blob's lower part (fraction of blob width).

        Every robot carries bumpers: one continuous band of a single alliance
        colour around its base. Lights, signs, field panels and game pieces
        are small or not strip-shaped, so they score low.
        """
        m = cv2.morphologyEx(color & band, cv2.MORPH_CLOSE, self._k_strip)
        n, _, st, _ = cv2.connectedComponentsWithStats(m, connectivity=8)
        best = 0
        for k in range(1, n):
            cw, ch, area = int(st[k, 2]), int(st[k, 3]), int(st[k, 4])
            if cw < 4 or cw < 1.5 * ch or area < 0.3 * cw * ch:
                continue
            best = max(best, cw)
        return min(1.0, best / max(1, w))

    @staticmethod
    def _suppress_duplicates(dets: list[dict]) -> list[dict]:
        dets = sorted(dets, key=lambda d: -d["quality"])
        kept: list[dict] = []
        for d in dets:
            if all(np.hypot(d["xy"][0] - k["xy"][0], d["xy"][1] - k["xy"][1]) > 0.45 for k in kept):
                kept.append(d)
        return kept
