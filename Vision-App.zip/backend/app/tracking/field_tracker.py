from __future__ import annotations

import math
from collections import deque

import numpy as np
from scipy.optimize import linear_sum_assignment

from app.tracking.camera import CameraModel
from app.tracking.detector import appearance_similarity
from app.tracking.terrain import FieldTerrain

VMAX = 5.5  # m/s, generous FRC top speed
A_MAX = 4.0  # m/s^2, sustained FRC acceleration
_MAX_TAIL_SIGMA_M = 1.5  # stop extrapolating past the last sighting beyond this uncertainty
_BIG = 1e6
_H = np.array([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0]])


def motion_model(dt: float, tau: float = 1.2, sigma_a: float = 3.0) -> tuple[np.ndarray, np.ndarray]:
    """Constant velocity with mild exponential velocity decay (robots stop when unseen)."""
    a = math.exp(-dt / tau)
    b = tau * (1.0 - a)
    F = np.array([[1, 0, b, 0], [0, 1, 0, b], [0, 0, a, 0], [0, 0, 0, a]], dtype=np.float64)
    q = sigma_a**2
    Q = q * np.array(
        [
            [dt**3 / 3, 0, dt**2 / 2, 0],
            [0, dt**3 / 3, 0, dt**2 / 2],
            [dt**2 / 2, 0, dt, 0],
            [0, dt**2 / 2, 0, dt],
        ]
    )
    return F, Q


def alliance_of(red: float, blue: float, min_score: float = 0.03) -> str:
    if red > max(min_score, 1.3 * blue):
        return "red"
    if blue > max(min_score, 1.3 * red):
        return "blue"
    return "unknown"


BUMPER_MIN_SPAN = 0.35  # solid colour strip at least this fraction of the blob width
BUMPER_PURITY = 0.8  # share of bumper sightings that must be the track's one colour


def det_bumper(det: dict) -> str:
    """Bumper colour seen in one detection: "red", "blue" or "unknown" (no solid bumper visible)."""
    b = det.get("bumper")
    if b is None:  # run saved before solid-bumper detection
        return alliance_of(det["red"], det["blue"], 0.15)
    r, bl = b["red"], b["blue"]
    if r >= BUMPER_MIN_SPAN and r >= 2.0 * bl:
        return "red"
    if bl >= BUMPER_MIN_SPAN and bl >= 2.0 * r:
        return "blue"
    return "unknown"


def det_bumper_hint(det: dict) -> str:
    """Weaker per-detection colour hint: some bumper of one colour and none of the other."""
    c = det_bumper(det)
    b = det.get("bumper")
    if c != "unknown" or b is None:
        return c
    if b["red"] >= 0.2 and b["blue"] < 0.1:
        return "red"
    if b["blue"] >= 0.2 and b["red"] < 0.1:
        return "blue"
    return "unknown"


def _det_alliance_factor(det: dict, want: str) -> float:
    if want not in {"red", "blue"}:
        return 1.0
    got = det_bumper(det)
    if got == "unknown":
        return 0.8
    return 1.0 if got == want else 0.25


def _clamp_speed(x: np.ndarray) -> None:
    sp = math.hypot(x[2], x[3])
    if sp > VMAX:
        x[2:] *= VMAX / sp


class Track:
    def __init__(self, tid: int, det: dict, t: float):
        self.id = tid
        self.x = np.array([det["xy"][0], det["xy"][1], 0.0, 0.0])
        self.P = np.diag([1.0, 1.0, 4.0, 4.0])
        self.P[:2, :2] = det["R"]
        self.state = "tentative"
        self.confirmed = False
        self.hits = 1
        self.age = 1
        self.misses = 0
        self.t = t
        self.first_t = t
        self.last_obs_t = t
        self.last_speed = 0.0
        self.hist = det["hist"].copy()
        self.red = det["red"] * det["quality"]
        self.blue = det["blue"] * det["quality"]
        self.wsum = det["quality"]
        self.bumps = {"red": 0, "blue": 0}
        self._count_bumper(det)
        self.obs: list[dict] = [{"t": t, "det": det, "p": 1.0, "d2": 0.0}]

    def _count_bumper(self, det: dict) -> None:
        c = det_bumper(det)
        if c != "unknown":
            self.bumps[c] += 1

    @property
    def bumper_counts(self) -> dict[str, int]:
        """Detections with a solid red / blue bumper strip."""
        if "bumps" not in self.__dict__:  # run saved before bumper counting
            self.bumps = {"red": 0, "blue": 0}
            for o in self.obs:
                self._count_bumper(o["det"])
        return self.bumps

    @property
    def live(self) -> bool:
        return self.state in {"tentative", "confirmed"}

    @property
    def red_score(self) -> float:
        return self.red / max(1e-6, self.wsum)

    @property
    def blue_score(self) -> float:
        return self.blue / max(1e-6, self.wsum)

    @property
    def alliance(self) -> str:
        """Bumper colour: a robot's bumpers are one solid colour, so mixed evidence stays unknown."""
        b = self.bumper_counts
        total = b["red"] + b["blue"]
        if total == 0:
            return "unknown"
        c = "red" if b["red"] >= b["blue"] else "blue"
        return c if b[c] >= BUMPER_PURITY * total else "unknown"

    def predict(self, t: float, terrain: FieldTerrain) -> None:
        dt = t - self.t
        if dt <= 0:
            return
        F, Q = motion_model(dt)
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + Q
        self.x[0], self.x[1] = terrain.constrain(self.x[0], self.x[1])
        self.t = t

    def innovation(self, det: dict) -> tuple[np.ndarray, np.ndarray, float]:
        S = self.P[:2, :2] + det["R"]
        r = np.asarray(det["xy"], dtype=np.float64) - self.x[:2]
        return r, S, float(r @ np.linalg.solve(S, r))

    def update(self, det: dict, t: float, p: float, d2: float) -> None:
        r, S, _ = self.innovation(det)
        K = self.P[:, :2] @ np.linalg.inv(S)
        self.x = self.x + K @ r
        IKH = np.eye(4) - K @ _H
        self.P = IKH @ self.P @ IKH.T + K @ det["R"] @ K.T
        _clamp_speed(self.x)
        self.hits += 1
        self.misses = 0
        self.last_obs_t = t
        self.last_speed = float(np.hypot(self.x[2], self.x[3]))
        q = det["quality"]
        self.red += det["red"] * q
        self.blue += det["blue"] * q
        self.wsum += q
        self._count_bumper(det)
        if p >= 0.6 and q >= 0.35:
            self.hist = (0.9 * self.hist + 0.1 * det["hist"]).astype(np.float32)
        self.obs.append({"t": t, "det": det, "p": p, "d2": d2})

    def reach(self, t: float) -> float:
        """Furthest a robot can plausibly be from its last sighting.

        Confirmed tracks know their speed, so a parked robot that is briefly
        hidden cannot be "moved" onto a robot driving past it.
        """
        gap = max(0.0, t - self.last_obs_t)
        if not self.confirmed:
            return max(1.0, VMAX * gap + 0.8)
        return min(VMAX * gap, self.last_speed * gap + 0.5 * A_MAX * gap**2) + 0.7

    def summary_stats(self) -> dict:
        xy = np.array([o["det"]["xy"] for o in self.obs])
        med = np.median(xy, axis=0)
        sizes = [o["det"]["size_ratio"] for o in self.obs]
        return {
            "extent_m": float(np.max(np.linalg.norm(xy - med, axis=1))) if len(xy) else 0.0,
            "median_size_ratio": float(np.median(sizes)) if sizes else 0.0,
            "bumper_score": max(self.red_score, self.blue_score),
        }

    def robot_like(self) -> bool:
        """A robot = robot-sized, with solid bumpers of one alliance colour seen repeatedly."""
        if not self.confirmed:
            return False
        s = self.summary_stats()
        if not 0.4 <= s["median_size_ratio"] <= 2.3:
            return False
        # Bumpers get hidden behind field elements and other robots, so they only
        # need to be seen in part of the sightings, but always in the same colour.
        if self.alliance == "unknown":
            return self.hint_alliance() != "unknown"
        seen = self.bumper_counts[self.alliance]
        # A long-parked robot facing away may only show its bumper now and then;
        # 8 single-colour sightings are enough on their own.
        if seen >= max(3, min(0.15 * len(self.obs), 8)):
            return True
        return self.hint_alliance() == self.alliance

    def hint_alliance(self) -> str:
        """Alliance of a long tracklet the learned detector is sure is a robot, from weak bumper hints.

        A parked robot with a ref or another robot in front of it may never show
        a full bumper strip, but the model still sees it plainly.
        """
        if len(self.obs) < HINT_MIN_OBS:
            return "unknown"
        conf = [o["det"].get("det_conf") for o in self.obs]
        if any(c is None for c in conf):
            return "unknown"
        med = float(np.median(conf))
        if med < HINT_MIN_CONF:
            return "unknown"
        hints = {"red": 0, "blue": 0}
        for o in self.obs:
            h = det_bumper_hint(o["det"])
            if h != "unknown":
                hints[h] += 1
        c = "red" if hints["red"] >= hints["blue"] else "blue"
        total = hints["red"] + hints["blue"]
        # A robot the model is very sure of (e.g. parked in the fuel with its bumpers
        # buried) only needs a few clean glimpses of its colour.
        need = 3 if med >= HINT_SURE_CONF else max(3, 0.1 * len(self.obs))
        return c if hints[c] >= need and hints[c] >= BUMPER_PURITY * total else "unknown"


HINT_MIN_OBS = 20  # ~3 s at 7.5 Hz
HINT_MIN_CONF = 0.6
HINT_SURE_CONF = 0.85
SPLIT_P = 0.3  # association this ambiguous ends the tracklet instead of extending it
SPLIT_MIN_OBS = 8


class MultiRobotTracker:
    """Field-space multi-robot tracker (Kalman filter per robot, Hungarian association)."""

    def __init__(self, terrain: FieldTerrain, max_coast_s: float = 1.5):
        # Short coasting on purpose: every continuous sighting becomes its own
        # tracklet, and link_tracklets() joins them across hides. Long coasting
        # let a lost track latch onto whatever showed up near its prediction.
        self.terrain = terrain
        self.max_coast_s = max_coast_s
        self.tracks: list[Track] = []
        self._next_id = 1

    def step(self, t: float, dets: list[dict]) -> None:
        live = [tr for tr in self.tracks if tr.live]
        for tr in live:
            tr.predict(t, self.terrain)
            tr.age += 1

        unassigned = set(range(len(dets)))
        likelihood: dict[tuple[int, int], float] = {}
        assigned: dict[Track, tuple[int, float]] = {}
        groups = (
            ([tr for tr in live if tr.state == "confirmed"], 16.0),
            ([tr for tr in live if tr.state == "tentative"], 11.0),
        )
        for group, gate in groups:
            cols = sorted(unassigned)
            if not group or not cols:
                continue
            C = np.full((len(group), len(cols)), _BIG)
            d2s = np.zeros_like(C)
            for i, tr in enumerate(group):
                reach = tr.reach(t)
                last_xy = tr.obs[-1]["det"]["xy"]
                for jj, j in enumerate(cols):
                    det = dets[j]
                    r, S, d2 = tr.innovation(det)
                    # reach is from the last sighting, not the prediction: one bad (merged) box
                    # can bend the predicted heading and push the true detection out of reach.
                    if d2 > gate or math.hypot(det["xy"][0] - last_xy[0], det["xy"][1] - last_xy[1]) > reach:
                        continue
                    app = appearance_similarity(tr.hist, det["hist"])
                    ta, da = tr.alliance, det_bumper(det)
                    hint = det_bumper_hint(det)
                    if tr.confirmed and ta != "unknown" and da != "unknown" and ta != da:
                        continue  # bumpers never change colour
                    if tr.confirmed and ta != "unknown" and hint not in {"unknown", ta} and tr.bumper_counts[ta] >= 6:
                        continue  # well-established colour vs. a hint of the other: another robot
                    clash = ta != "unknown" and da != "unknown" and ta != da
                    pen = 6.0 if clash else (-0.5 if ta != "unknown" and ta == da else 0.0)
                    nll = 0.5 * d2 + 0.5 * math.log(max(1e-12, np.linalg.det(2 * math.pi * S)))
                    C[i, jj] = nll + 4.0 * (1.0 - app) + pen
                    d2s[i, jj] = d2
                    likelihood[(tr.id, j)] = math.exp(-0.5 * d2) * max(0.05, app) * (0.2 if clash else 1.0)
            rows, cidx = linear_sum_assignment(C)
            for i, jj in zip(rows, cidx):
                if C[i, jj] >= _BIG:
                    continue
                assigned[group[i]] = (cols[jj], float(d2s[i, jj]))
                unassigned.discard(cols[jj])

        for tr in live:
            if tr in assigned:
                j, d2 = assigned[tr]
                lij = likelihood[(tr.id, j)]
                same_det = sum(v for (_, jj), v in likelihood.items() if jj == j)
                other_dets = sum(v for (ti, jj), v in likelihood.items() if ti == tr.id and jj != j)
                p = lij / (same_det + other_dets + 0.01)
                if tr.confirmed and p < SPLIT_P and len(tr.obs) >= SPLIT_MIN_OBS:
                    # Ambiguous step (robots crossing, or the box jumped to something else):
                    # don't guess who is who here. End this tracklet; the linker
                    # re-pairs the pieces with the whole picture.
                    tr.state = "lost"
                    unassigned.add(j)
                    continue
                tr.update(dets[j], t, p, d2)
                if tr.state == "tentative" and tr.hits >= 4 and tr.hits / tr.age >= 0.6:
                    tr.state = "confirmed"
                    tr.confirmed = True
            else:
                tr.misses += 1
                if tr.state == "tentative" and tr.misses >= 3:
                    tr.state = "deleted"
                elif tr.state == "confirmed" and t - tr.last_obs_t > self.max_coast_s:
                    tr.state = "lost"

        confirmed = [tr for tr in live if tr.state == "confirmed"]
        for j in sorted(unassigned):
            det = dets[j]
            if not det["valid"] or det["quality"] < 0.25:
                continue
            hint = det_bumper_hint(det)
            if any(
                np.hypot(*(np.asarray(det["xy"]) - tr.x[:2])) < 0.6
                and not (hint != "unknown" and tr.alliance not in {"unknown", hint} and tr.bumper_counts[tr.alliance] >= 6)
                for tr in confirmed
            ):
                continue  # same robot as a confirmed track (unless its bumpers say otherwise)
            self.tracks.append(Track(self._next_id, det, t))
            self._next_id += 1

    def track(self, tid: int) -> Track | None:
        return next((tr for tr in self.tracks if tr.id == tid), None)


# ---------------------------------------------------------------- target ---


def _first_px(tr: Track, t_lock_end: float) -> float:
    obs = [o for o in tr.obs if o["t"] <= t_lock_end] or tr.obs
    return float(obs[0]["det"]["foot_px"][0])


def select_target(
    tracks: list[Track],
    t_start: float,
    lock_window_s: float,
    alliance: str,
    position: int,
    forced_id: int | None,
    t_end: float,
) -> tuple[Track | None, float, list[Track], str]:
    """Pick the target robot. Returns (track, selection_confidence, candidates, reason)."""
    if forced_id is not None:
        tr = next((t for t in tracks if t.id == int(forced_id) and t.confirmed), None)
        if tr is not None:
            return tr, 1.0, [tr], "forced_track_id"

    window = lock_window_s
    cands: list[Track] = []
    while True:
        lock_end = t_start + window
        cands = [
            tr
            for tr in tracks
            if tr.robot_like() and sum(1 for o in tr.obs if o["t"] <= lock_end) >= 3
        ]
        if cands or lock_end >= t_end:
            break
        window *= 2.0

    want = (alliance or "").lower()
    matching = [tr for tr in cands if tr.alliance == want]
    if matching:
        pool, conf, reason = matching, 0.9, f"alliance={want}"
    else:
        unknown = [tr for tr in cands if tr.alliance == "unknown"]
        pool, conf, reason = (unknown or cands), 0.45, "alliance colour not confirmed"
    if not pool:
        return None, 0.0, cands, "no robot-like tracks"

    pool.sort(key=lambda tr: _first_px(tr, lock_end), reverse=(want == "red"))
    idx = max(0, min(int(position) - 1, len(pool) - 1))
    if position > len(pool):
        conf *= 0.5
        reason += f"; only {len(pool)} candidate(s) for position {position}"
    elif len(pool) > 3:
        conf *= 0.8
        reason += f"; {len(pool)} candidates (expected 3)"
    if window > lock_window_s:
        conf *= 0.8
        reason += f"; lock window widened to {window:.1f}s"
    return pool[idx], conf, pool, reason


def link_tracklets(
    tracks: list[Track], max_gap_s: float = 8.0, no_link_score: float = 0.05
) -> list[list[tuple[Track, float]]]:
    """Group tracklets (continuous sightings) into robots across hides.

    Globally optimal one-to-one successor linking (Hungarian with a "no link"
    option). A link a -> b needs b to start after a ends, a reachable distance,
    compatible bumper colour and similar appearance. Returns chains of
    ``(track, link_confidence)`` ordered by time; the first entry has 1.0.
    """
    tl = sorted((tr for tr in tracks if tr.robot_like()), key=lambda tr: tr.first_t)
    n = len(tl)
    if not n:
        return []
    score = np.zeros((n, n))
    for i, a in enumerate(tl):
        last_xy = np.asarray(a.obs[-1]["det"]["xy"])
        for j, b in enumerate(tl):
            if i == j or b.first_t < a.last_obs_t - 0.1:
                continue  # both seen at the same time -> different robots
            gap = max(0.0, b.first_t - a.last_obs_t)
            if gap > max_gap_s:
                continue
            dist = float(np.hypot(*(np.asarray(b.obs[0]["det"]["xy"]) - last_xy)))
            if dist > VMAX * gap + 1.0:
                continue
            aa, ba = a.alliance, b.alliance
            if "unknown" not in (aa, ba) and aa != ba:
                continue
            app = appearance_similarity(a.hist, b.hist)
            if app < 0.45:
                continue
            s = math.exp(-0.5 * (dist / (1.0 + 1.5 * gap)) ** 2) * app * math.exp(-gap / 6.0)
            score[i, j] = s * (0.7 if "unknown" in (aa, ba) else 1.0)

    half_nl = -0.5 * math.log(no_link_score)  # paid once per open end; link iff score > no_link_score
    C = np.full((2 * n, 2 * n), _BIG)
    with np.errstate(divide="ignore"):
        C[:n, :n] = np.where(score > 0, -np.log(np.maximum(score, 1e-300)), _BIG)
    C[np.arange(n), n + np.arange(n)] = half_nl
    C[n + np.arange(n), np.arange(n)] = half_nl
    C[n:, n:] = 0.0
    rows, cols = linear_sum_assignment(C)
    succ: dict[int, tuple[int, float]] = {}
    has_pred: set[int] = set()
    for i, j in zip(rows, cols):
        if i < n and j < n and score[i, j] > 0:
            rival = score[i].sum() + score[:, j].sum() - score[i, j]
            succ[i] = (j, float(score[i, j] / (rival + no_link_score)))
            has_pred.add(j)

    chains: list[list[tuple[Track, float]]] = []
    for h in range(n):
        if h in has_pred:
            continue
        chain = [(tl[h], 1.0)]
        k = h
        while k in succ:
            k, conf = succ[k]
            chain.append((tl[k], conf))
        chains.append(chain)
    chains.sort(key=lambda c: c[0][0].first_t)
    return chains


def chain_alliance(chain: list[tuple[Track, float]]) -> str:
    w = sum(tr.wsum for tr, _ in chain)
    return alliance_of(sum(tr.red for tr, _ in chain) / max(1e-6, w), sum(tr.blue for tr, _ in chain) / max(1e-6, w))


# ----------------------------------------------------------- robot slots ---


def pool_alliance(tr: Track) -> str:
    """Alliance a tracklet belongs to: its bumper colour (the stronger one if unclear)."""
    a = tr.alliance
    if a != "unknown":
        return a
    a = tr.hint_alliance()
    if a != "unknown":
        return a
    b = tr.bumper_counts
    if b["red"] != b["blue"]:
        return "red" if b["red"] > b["blue"] else "blue"
    return "red" if tr.red_score >= tr.blue_score else "blue"


def _common_dist(a: Track, b: Track) -> float | None:
    """Near-worst (90th percentile) distance between two tracklets over frames where both were seen."""
    pa = {round(o["t"], 4): o["det"]["xy"] for o in a.obs}
    d = [
        math.hypot(pa[k][0] - o["det"]["xy"][0], pa[k][1] - o["det"]["xy"][1])
        for o in b.obs
        if (k := round(o["t"], 4)) in pa
    ]
    return float(np.percentile(d, 90)) if len(d) >= 3 else None


def _link_logscore(a: Track, b: Track, terrain: FieldTerrain | None = None) -> float | None:
    """Log-likelihood that tracklet ``b`` (starting later) is the same robot as ``a``. None = impossible."""
    if b.first_t < a.last_obs_t - 0.1:
        # Seen at the same time: only possible as a duplicate tracklet on the same robot,
        # i.e. close together the whole time (two robots side by side are not duplicates).
        d = _common_dist(a, b)
        return 0.0 if d is not None and d < 0.9 else None
    gap = max(0.0, b.first_t - a.last_obs_t)
    end = a.obs[-1]["det"]["xy"]
    start = b.obs[0]["det"]["xy"]
    dist = float(np.hypot(start[0] - end[0], start[1] - end[1]))
    if dist > VMAX * gap + 1.0:
        return None
    app = appearance_similarity(a.hist, b.hist)
    if terrain is not None and terrain.near_hidden(end[0], end[1]) and terrain.near_hidden(start[0], start[1]):
        # Went out of view behind a field element and came back: the gap is expected.
        sigma = min(6.0, 1.0 + 1.5 * gap)
        return -0.5 * (dist / sigma) ** 2 + math.log(max(0.05, app))
    sigma = min(6.0, 0.7 + gap)  # a robot hidden longer can be anywhere it could drive to
    return -0.5 * (dist / sigma) ** 2 + math.log(max(0.05, app)) - 0.05 * gap


# ------------------------------------------------------ team number reads ---
# team_id.read_tracklet_numbers stores ``team_votes`` ({team_key: votes}) on each
# tracklet. Bumper numbers never change, so they say which pieces are one robot.
LABEL_MIN = 1.0  # votes (about two good reads) for a tracklet to have a known team...
LABEL_MARGIN = 2.0  # ...and this many times its next-best team
ID_BETA = 2.5  # votes -> team probability sharpness
ID_CAP = 6.0  # most a wrong-team placement costs (log-likelihood)


def team_label(tr: Track) -> str | None:
    """The team a tracklet's bumper reads clearly say it is, else None."""
    votes = getattr(tr, "team_votes", None) or {}
    if not votes:
        return None
    ranked = sorted(votes.items(), key=lambda kv: -kv[1])
    best, second = ranked[0][1], (ranked[1][1] if len(ranked) > 1 else 0.0)
    return ranked[0][0] if best >= LABEL_MIN and best >= LABEL_MARGIN * second else None


def _ident_terms(tr: Track, teams: list[str]) -> np.ndarray | None:
    """Log-likelihood bonus/penalty of the tracklet being each team (None = no reads)."""
    votes = getattr(tr, "team_votes", None) or {}
    v = np.array([float(votes.get(t, 0.0)) for t in teams])
    if not np.any(v > 0):
        return None
    z = ID_BETA * v
    p = np.exp(z - z.max())
    p /= p.sum()
    return np.maximum(np.log(len(teams) * np.maximum(p, 1e-12)), -ID_CAP)


def split_track(tr: Track, k: int, new_id: int) -> Track:
    """Cut ``tr`` before observation ``k``: ``tr`` keeps ``obs[:k]``, the returned tracklet the rest."""
    tail = Track.__new__(Track)
    tail.__dict__.update({key: v for key, v in tr.__dict__.items()})
    tail.id = new_id
    tail.x, tail.P = tr.x.copy(), tr.P.copy()
    tail.hist = tr.hist.copy()
    head_obs, tail_obs = tr.obs[:k], tr.obs[k:]
    tr.state = "lost"
    for piece, obs in ((tr, head_obs), (tail, tail_obs)):
        piece.obs = obs
        piece.hits = piece.age = len(obs)
        piece.first_t = obs[0]["t"]
        piece.last_obs_t = obs[-1]["t"]
        piece.red = sum(o["det"]["red"] * o["det"]["quality"] for o in obs)
        piece.blue = sum(o["det"]["blue"] * o["det"]["quality"] for o in obs)
        piece.wsum = sum(o["det"]["quality"] for o in obs)
        piece.bumps = {"red": 0, "blue": 0}
        for o in obs:
            piece._count_bumper(o["det"])
    return tail


def _beam_slots(
    tl: list[Track],
    k: int,
    beam_width: int,
    drop_cost_per_obs: float,
    terrain: FieldTerrain | None = None,
    obs_weight=None,
    open_cost: float = 0.0,
    teams: list[str] | None = None,
) -> tuple[list[list[tuple[Track, float]]], list[Track]]:
    """Split time-ordered tracklets into at most ``k`` robots (beam search over slot end states).

    Each tracklet either continues a robot (scored by ``_link_logscore``),
    starts one of the ``k`` robots (paying ``open_cost``), or is dropped (cost
    grows with its length, or with ``obs_weight(observation)`` summed over it,
    so short or weakly detected tracklets are dropped first). A robot parked
    out of view all match leaves its slot empty instead of taking a scrap.

    With ``teams`` (the alliance's ``k`` team keys) slot ``i`` is team ``i`` and
    each tracklet's bumper reads (``team_votes``) score which slot it fits, so
    a robot's pieces stay together and two robots' pieces aren't swapped.
    """
    cache: dict[tuple[int, int], float | None] = {}
    labelled = teams is not None and len(teams) == k
    ident = [_ident_terms(tr, teams) for tr in tl] if labelled else [None] * len(tl)
    if not any(v is not None for v in ident):
        labelled = False

    def score(i: int, j: int) -> float | None:
        if (i, j) not in cache:
            cache[(i, j)] = _link_logscore(tl[i], tl[j], terrain)
        return cache[(i, j)]

    # state: slots = sorted tuple of each robot's latest tracklet index (-1 = unused)
    beam: list[tuple[float, tuple[int, ...], tuple | None]] = [(0.0, (-1,) * k, None)]
    for j, b in enumerate(tl):
        best: dict[tuple[int, ...], tuple[float, tuple[int, ...], tuple]] = {}

        def push(s: float, slots: tuple[int, ...], hist: tuple) -> None:
            if slots not in best or best[slots][0] < s:
                best[slots] = (s, slots, hist)

        drop = drop_cost_per_obs * (sum(obs_weight(o) for o in b.obs) if obs_weight else len(b.obs))
        idj = ident[j]
        for s, slots, hist in beam:
            push(s - drop, slots, (j, -2, hist))
            tried_empty = False
            for si, last in enumerate(slots):
                if last == -1:
                    if tried_empty and not labelled:
                        continue
                    tried_empty = True
                    new_last, pred, gain = j, -1, -open_cost
                else:
                    g = score(last, j)
                    if g is None:
                        continue
                    new_last = last if tl[last].last_obs_t >= b.last_obs_t else j
                    pred, gain = last, g
                if labelled and idj is not None:
                    gain += float(idj[si])
                new_slots = slots[:si] + (new_last,) + slots[si + 1 :]
                push(s + gain, new_slots if labelled else tuple(sorted(new_slots)), (j, pred, hist))
        beam = sorted(best.values(), key=lambda st: -st[0])[:beam_width]

    pred_of: dict[int, int] = {}
    hist = beam[0][2] if beam else None
    while hist is not None:
        j, pred, hist = hist
        pred_of[j] = pred
    group: dict[int, int] = {}
    chains: list[list[tuple[Track, float]]] = []
    dropped: list[Track] = []
    for j in range(len(tl)):
        pred = pred_of.get(j, -2)
        if pred == -2:
            dropped.append(tl[j])
        elif pred == -1:
            group[j] = len(chains)
            chains.append([(tl[j], 1.0)])
        else:
            group[j] = group[pred]
            conf = min(1.0, max(0.3, math.exp(0.5 * (score(pred, j) or 0.0))))
            chains[group[j]].append((tl[j], conf))
    # Stable order on the field (by starting y); team numbers are assigned by the user.
    chains.sort(key=lambda c: float(c[0][0].obs[0]["det"]["xy"][1]))
    return chains + [[] for _ in range(k - len(chains))], dropped


def assign_slots(
    tracks: list[Track],
    per_alliance: int = 3,
    beam_width: int = 400,
    drop_cost_per_obs: float = 0.1,
    terrain: FieldTerrain | None = None,
    open_cost: float | None = None,
) -> tuple[dict[str, list[list[tuple[Track, float]]]], list[Track]]:
    """Group tracklets into exactly ``per_alliance`` robots per alliance (3 red, 3 blue).

    Returns ``({"red": [chain x3], "blue": [chain x3]}, dropped_tracklets)``;
    a chain is ``[(track, link_confidence)]`` and may be empty.
    """
    slots: dict[str, list[list[tuple[Track, float]]]] = {}
    dropped: list[Track] = []
    pools = {
        a: sorted((tr for tr in tracks if tr.robot_like() and pool_alliance(tr) == a), key=lambda tr: (tr.first_t, tr.id))
        for a in ("red", "blue")
    }
    dropped += _wrong_half_at_start(pools, terrain)
    # With a learned detector, sightings it never confirmed (background-subtraction
    # backups) are weak evidence: a long static false blob must not outweigh a real robot.
    model = any("det_conf" in o["det"] for tl in pools.values() for tr in tl for o in tr.obs)
    weight = _evidence_weight if model else None
    if open_cost is None:
        open_cost = SLOT_OPEN_COST if model else 0.0
    for alliance in ("red", "blue"):
        read_teams = sorted({t for tr in pools[alliance] for t in (getattr(tr, "team_votes", None) or {})})
        slots[alliance], d = _beam_slots(
            pools[alliance], per_alliance, beam_width, drop_cost_per_obs, terrain, weight, open_cost, read_teams or None
        )
        dropped += d
    return slots, sorted(dropped, key=lambda tr: tr.first_t)


SLOT_OPEN_COST = 0.8  # a new robot needs ~8 well-detected sightings; less stays "not detected"


def _evidence_weight(o: dict) -> float:
    c = o["det"].get("det_conf")
    return 0.35 if c is None else 0.5 + 0.5 * min(1.0, c / 0.5)


START_GRACE_S = 1.0  # no robot reaches the field centre line this soon after auto starts


def _wrong_half_at_start(pools: dict[str, list[Track]], terrain: FieldTerrain | None) -> list[Track]:
    """Remove (and return) tracklets first seen on the other alliance's half right at the start.

    Robots start auto in their own alliance zone, so a "blue" tracklet that is
    already deep in red's half in the first second is a false object (e.g. the
    score overlay) or a mis-coloured red robot. The sides are taken from where
    each alliance's tracklets start.
    """
    all_tl = pools["red"] + pools["blue"]
    if not all_tl:
        return []
    t_first = min(tr.first_t for tr in all_tl)

    def early(tl: list[Track]) -> list[Track]:
        return [tr for tr in tl if tr.first_t <= t_first + START_GRACE_S]

    start_x = {a: [float(tr.obs[0]["det"]["xy"][0]) for tr in early(tl)] for a, tl in pools.items()}
    if not start_x["red"] or not start_x["blue"]:
        return []
    rx, bx = float(np.median(start_x["red"])), float(np.median(start_x["blue"]))
    mid = terrain.length / 2 if terrain is not None else (rx + bx) / 2
    if abs(rx - bx) < 4.0 or (rx - mid) * (bx - mid) >= 0:
        return []  # sides unclear: not the start of a match
    side = {"red": math.copysign(1.0, rx - mid), "blue": math.copysign(1.0, bx - mid)}
    out = []
    for a, tl in pools.items():
        bad = [tr for tr in early(tl) if (float(tr.obs[0]["det"]["xy"][0]) - mid) * side[a] < -0.3]
        pools[a] = [tr for tr in tl if tr not in bad]
        out += bad
    return out


def _apply_climb(obs: list[dict], camera: CameraModel, terrain: FieldTerrain) -> dict:
    """Detect lifting inside climb zones; set per-observation z / measurement.

    A single camera cannot tell "lifting" from "driving away from the camera",
    so lift is only measured while the robot is anchored (stopped) in a climb
    zone, as the height of its foot ray above the anchor point.
    """
    stats = {"climb_samples": 0, "max_climb_z_m": 0.0}
    if not terrain.climb_zones:
        return stats
    anchor = None
    recent: deque = deque()
    for o in obs:
        d = o["det"]
        if anchor is not None:
            u, v = d["foot_px"]
            line = camera.hit_vertical_line(u, v, anchor["foot"][0], anchor["foot"][1])
            lift = float(line[2] - anchor["zg"])
            g = np.asarray(d["foot_xyz"][:2])
            lateral = abs(float((g - anchor["foot"]) @ anchor["perp"]))
            wr = (d["bbox"][2] - d["bbox"][0]) / anchor["w"]
            zone = anchor["zone"]
            if (
                lateral > 0.35
                or not 0.75 <= wr <= 1.33
                or lift < -0.1
                or lift > zone.height + 0.2
                or (lift < 0.07 and not zone.contains(g[0], g[1], margin=1.0))
            ):
                anchor = None
                recent.clear()
            elif lift >= 0.07:
                o["xy"] = anchor["xy"].tolist()
                o["R"] = np.eye(2) * 0.1**2
                o["z"] = min(lift, zone.height)
                o["z_source"] = "climb"
                stats["climb_samples"] += 1
                stats["max_climb_z_m"] = max(stats["max_climb_z_m"], o["z"])
                continue
        recent.append(o)
        while recent and o["t"] - recent[0]["t"] > 0.6:
            recent.popleft()
        if anchor is None and len(recent) >= 5 and o["t"] - recent[0]["t"] >= 0.4:
            pts = np.array([r["det"]["xy"] for r in recent])
            med = np.median(pts, axis=0)
            zone = terrain.climb_zone(med[0], med[1], margin=0.2)
            if zone is not None and float(np.max(np.linalg.norm(pts - med, axis=1))) < 0.25:
                foot = np.median(np.array([r["det"]["foot_xyz"][:2] for r in recent]), axis=0)
                view = foot - camera.center[:2]
                view /= max(1e-9, float(np.linalg.norm(view)))
                anchor = {
                    "xy": med,
                    "foot": foot,
                    "perp": np.array([-view[1], view[0]]),
                    "w": float(np.median([r["det"]["bbox"][2] - r["det"]["bbox"][0] for r in recent])),
                    "zg": terrain.height(foot[0], foot[1]),
                    "zone": zone,
                }
    # Median-filter climb heights to suppress foot-point jitter.
    idx = [i for i, o in enumerate(obs) if o.get("z_source") == "climb"]
    zs = {i: obs[i]["z"] for i in idx}
    for i in idx:
        win = [zs[j] for j in range(i - 2, i + 3) if j in zs]
        obs[i]["z"] = float(np.median(win))
    return stats


def _route_hidden_gaps(
    grid: np.ndarray, pos: np.ndarray, observed: np.ndarray, terrain: FieldTerrain, min_gap_s: float = 0.8
) -> dict[int, tuple[float, float]]:
    """Positions for unseen stretches that are best explained by the robot being out of view.

    The smoother draws a straight line between sightings, i.e. across floor the
    camera can see. When a robot vanishes for a while it was more likely behind
    a field element: route around solids through hidden floor, crossing visible
    floor quickly and spending the remaining time in the hidden part.
    """
    if terrain.hidden is None:
        return {}
    out: dict[int, tuple[float, float]] = {}
    seen = np.flatnonzero(observed)
    for ia, ib in zip(seen, seen[1:]):
        dt = float(grid[ib] - grid[ia])
        if ib - ia < 2 or dt < min_gap_s:
            continue
        a, b = tuple(pos[ia]), tuple(pos[ib])
        r = terrain.route(a, b)
        if r is None:
            continue
        pts, seg_hidden = r
        forced = False
        if not seg_hidden.any() and dt >= 1.5 and (
            terrain.near_hidden(*a, radius=1.5) or terrain.near_hidden(*b, radius=1.5)
        ):
            # Unseen for a long time right beside hidden floor: it went out of view there.
            r = terrain.route(a, b, via_hidden=True)
            if r is None:
                continue
            pts, seg_hidden = r
            forced = True
        lens = np.hypot(*np.diff(pts, axis=0).T)
        if not seg_hidden.any() or lens.sum() > VMAX * dt + 1.0:
            continue  # nowhere to hide on the way (or too far): keep the smoothed line
        l_vis = float(lens[~seg_hidden].sum())
        l_hid = float(lens[seg_hidden].sum())
        t_vis = l_vis / 3.0  # crossing visible floor at a brisk drive
        if forced and t_vis > 0.8 * dt:
            continue  # would have been seen getting there and back
        if t_vis > 0.8 * dt or l_hid < 1e-6:
            tau = lens * dt / max(1e-6, lens.sum())
        else:
            tau = np.where(seg_hidden, lens * (dt - t_vis) / l_hid, lens / 3.0)
        cum = np.concatenate([[0.0], np.cumsum(tau)])
        for i in range(ia + 1, ib):
            u = float(grid[i] - grid[ia])
            out[i] = (float(np.interp(u, cum, pts[:, 0])), float(np.interp(u, cum, pts[:, 1])))
    return out


def build_chain_trajectory(
    chain: list[tuple[Track, float]],
    selection_conf: float,
    grid_t: np.ndarray,
    camera: CameraModel,
    terrain: FieldTerrain,
    alliance: str,
) -> tuple[list[dict], dict]:
    """Merge a robot's tracklets, add z, then RTS-smooth over every processed frame.

    Frames without a detection (hidden between tracklets) are filled by the
    smoother, constrained to the field, with growing position uncertainty.
    """
    want = (alliance or "").lower()
    chain = sorted(chain, key=lambda c: c[0].first_t)
    by_time: dict[float, dict] = {}
    for k, (tr, link_conf) in enumerate(chain):
        for n_o, o in enumerate(tr.obs):
            key = round(o["t"], 4)
            prev = by_time.get(key)
            if prev is not None and prev["p"] * prev["det"]["quality"] >= o["p"] * o["det"]["quality"]:
                continue  # tracklets assigned by hand may overlap; keep the better one
            by_time[key] = {
                "t": o["t"],
                "det": o["det"],
                "p": o["p"],
                "track_id": tr.id,
                "stitch": link_conf if n_o == 0 and k > 0 else None,
                "xy": list(o["det"]["xy"]),
                "R": o["det"]["R"],
                "z": None,
                "z_source": None,
            }
    obs = [by_time[k] for k in sorted(by_time)]
    if not obs:
        return [], {"chain": []}
    climb_stats = _apply_climb(obs, camera, terrain)

    # Appearance template from the first confident observations.
    init = [o["det"]["hist"] for o in obs[:15] if o["det"]["quality"] >= 0.35] or [obs[0]["det"]["hist"]]
    template = (sum(init) / len(init)).astype(np.float32)

    grid = grid_t[grid_t >= obs[0]["t"] - 1e-6]
    by_t = {round(o["t"], 4): o for o in obs}
    n = len(grid)
    xf = np.zeros((n, 4))
    Pf = np.zeros((n, 4, 4))
    xp = np.zeros((n, 4))
    Pp = np.zeros((n, 4, 4))
    Fs = np.zeros((n, 4, 4))
    x = np.array([obs[0]["xy"][0], obs[0]["xy"][1], 0.0, 0.0])
    P = np.diag([0.25, 0.25, 4.0, 4.0])
    observed = np.zeros(n, dtype=bool)
    sample_obs: list[dict | None] = [None] * n
    for i, t in enumerate(grid):
        if i:
            F, Q = motion_model(float(t - grid[i - 1]))
            x = F @ x
            P = F @ P @ F.T + Q
        else:
            F = np.eye(4)
        xp[i], Pp[i], Fs[i] = x, P, F
        o = by_t.get(round(float(t), 4))
        if o is not None:
            R = np.asarray(o["R"], dtype=np.float64)
            r = np.asarray(o["xy"]) - x[:2]
            S = P[:2, :2] + R
            d2 = float(r @ np.linalg.solve(S, r))
            if d2 > 16.0:  # robust: soften outliers instead of trusting them
                R = R * (d2 / 9.0)
                S = P[:2, :2] + R
            K = P[:, :2] @ np.linalg.inv(S)
            x = x + K @ r
            IKH = np.eye(4) - K @ _H
            P = IKH @ P @ IKH.T + K @ R @ K.T
            _clamp_speed(x)
            observed[i] = True
            sample_obs[i] = o
        xf[i], Pf[i] = x, P

    xs = xf.copy()
    Ps = Pf.copy()
    for i in range(n - 2, -1, -1):
        C = Pf[i] @ Fs[i + 1].T @ np.linalg.inv(Pp[i + 1])
        xs[i] = xf[i] + C @ (xs[i + 1] - xp[i + 1])
        Ps[i] = Pf[i] + C @ (Ps[i + 1] - Pp[i + 1]) @ C.T

    samples: list[dict] = []
    identity = selection_conf
    cap = selection_conf
    hist = template.copy()
    last_obs_t = None
    climb_z = None
    climb_until = -1.0
    pos = np.array([terrain.constrain(xs[i, 0], xs[i, 1]) for i in range(n)])
    routed = _route_hidden_gaps(grid, pos, observed, terrain)
    if routed:
        idx = np.array(sorted(routed))
        pos[idx] = [routed[i] for i in idx]
        vel = np.gradient(pos, grid, axis=0) if n > 1 else np.zeros_like(pos)
        xs[idx, 2:] = vel[idx]
    for i, t in enumerate(grid):
        t = float(t)
        x, y = float(pos[i, 0]), float(pos[i, 1])
        var = 0.5 * float(Ps[i, 0, 0] + Ps[i, 1, 1])
        pos_conf = math.exp(-var / (2 * 0.3**2))
        o = sample_obs[i]
        if o is not None:
            d = o["det"]
            if o["stitch"] is not None:
                cap *= o["stitch"]
                identity *= o["stitch"]
            app = 0.5 * appearance_similarity(d["hist"], template) + 0.5 * appearance_similarity(d["hist"], hist)
            inst = math.sqrt(max(0.0, o["p"])) * (0.5 + 0.5 * app) * _det_alliance_factor(d, want)
            w = 0.5 if last_obs_t is None or t - last_obs_t > 1.0 else 0.2
            identity = min(cap, (1 - w) * identity + w * inst)
            if inst >= 0.6 and d["quality"] >= 0.35:
                hist = (0.9 * hist + 0.1 * d["hist"]).astype(np.float32)
            last_obs_t = t
            quality = float(d["quality"])
            if o["z_source"] == "climb":
                z, z_source = float(o["z"]), "climb"
                climb_z, climb_until = z, t + 3.0
            else:
                z = terrain.height(x, y)
                z_source = "terrain" if z > 0.01 else "floor"
                climb_z = None
            overall = identity * pos_conf * (0.7 + 0.3 * quality)
        else:
            quality = 0.0
            if climb_z is not None and t <= climb_until:
                z, z_source = climb_z, "climb_held"
            else:
                z = terrain.height(x, y)
                z_source = "terrain" if z > 0.01 else "floor"
            overall = identity * pos_conf * 0.85
        samples.append(
            {
                "t": t,
                "x_m": float(x),
                "y_m": float(y),
                "z_m": float(z),
                "vx": float(xs[i, 2]),
                "vy": float(xs[i, 3]),
                "sigma_m": math.sqrt(max(0.0, var)),
                "position_confidence": pos_conf,
                "identity_confidence": float(identity),
                "confidence": float(max(0.0, min(1.0, overall))),
                "observed": bool(o is not None),
                "occluded": terrain.is_hidden(x, y),
                "routed": i in routed,
                "quality": quality,
                "z_source": z_source,
                "track_id": int(o["track_id"]) if o is not None else None,
                "foot_px": list(o["det"]["foot_px"]) if o is not None else None,
            }
        )

    # After the final sighting, stop once the prediction is no longer useful.
    last_seen = max((i for i, s in enumerate(samples) if s["observed"]), default=-1)
    lost_at = None
    for i in range(last_seen + 1, len(samples)):
        if samples[i]["sigma_m"] > _MAX_TAIL_SIGMA_M:
            lost_at = samples[i]["t"]
            del samples[i:]
            break

    meta = {
        "chain": [{"track_id": tr.id, "stitch_confidence": round(c, 3), "first_t": tr.first_t, "last_t": tr.last_obs_t} for tr, c in chain],
        "observations": len(obs),
        "observed_fraction": float(observed.mean()) if n else 0.0,
        "lost_at_t": lost_at,
        **climb_stats,
    }
    return samples, meta
