from __future__ import annotations

import json
import logging
import math
import time
from pathlib import Path

import cv2
import numpy as np

from app.tracking.camera import CameraModel
from app.tracking.detector import BoxEnsemble, PersonDetector, RobotBoxModel, RobotDetector
from app.tracking.field_tracker import (
    MultiRobotTracker,
    Track,
    assign_slots,
    build_chain_trajectory,
    link_tracklets,
    pool_alliance,
    select_target,
)
from app.tracking.path_builder import build_path
from app.tracking.terrain import FieldTerrain

log = logging.getLogger(__name__)


def run_field_tracking(
    *,
    video_path: str,
    camera: CameraModel,
    terrain: FieldTerrain,
    tracking_start_sec: float,
    tracking_end_sec: float,
    target_alliance: str,
    target_robot_position: int,
    lock_window_sec: float,
    forced_track_id: int | None = None,
    process_hz: float = 15.0,
    person_model: str | None = None,
    robot_model: str | list[str] | None = None,
    save_run_to: Path | None = None,
    run_context: dict | None = None,
    team_lineup: dict[str, list[str]] | None = None,
    ocr_frames: int = 12,
    training_frames_dir: Path | None = None,
    team_gallery=None,
) -> dict:
    """Detect every robot, track them all on the 3D field, then follow the target.

    With ``team_lineup`` (``{"red": [...], "blue": [...]}`` team keys) each
    robot's team is read off its bumpers and stored as ``team_key``/``team_id``;
    ``team_gallery`` (a callable returning team key -> appearance embeddings)
    adds votes from how the robots looked in earlier good matches.

    Returns per-frame target samples (t relative to ``tracking_start_sec``), the
    node/segment path, every robot's path and tracking metadata. If
    ``save_run_to`` is given the tracklets are saved so they can be re-assigned
    to teams later without re-tracking.
    """
    run = track_all_robots(
        video_path=video_path,
        camera=camera,
        terrain=terrain,
        tracking_start_sec=tracking_start_sec,
        tracking_end_sec=tracking_end_sec,
        process_hz=process_hz,
        person_model=person_model,
        robot_model=robot_model,
    )
    if team_lineup:
        # Bumper numbers read all match long: keep each robot's pieces together
        # (assign_slots) and cut tracklets that jumped to another robot.
        from app.tracking.team_id import read_tracklet_numbers

        try:
            run["meta"]["number_reads"] = read_tracklet_numbers(run, video_path, team_lineup)
        except Exception as exc:  # reads only help; tracking stands without them
            log.warning("bumper number reads failed: %s", exc)
    if save_run_to is not None:
        save_run(run, save_run_to, run_context or {})
    result = follow_target(
        run,
        camera=camera,
        terrain=terrain,
        target_alliance=target_alliance,
        target_robot_position=target_robot_position,
        lock_window_sec=lock_window_sec,
        forced_track_id=forced_track_id,
    )
    result["robots"], result["tracklets"] = follow_all(run, camera=camera, terrain=terrain)
    if training_frames_dir is not None and (run_context or {}).get("match_key"):
        from app.tracking.training_data import save_frames

        try:
            result["meta"]["training_frames"] = save_frames(run, video_path, training_frames_dir, run_context["match_key"])
        except Exception as exc:  # training data is a by-product; never fail the match
            log.warning("saving training frames failed: %s", exc)
    result["team_identification"] = None
    if team_lineup:
        from app.tracking import appearance
        from app.tracking.team_id import identify_teams

        try:
            gallery = None
            if team_gallery is not None:
                try:
                    gallery = team_gallery()
                except Exception as exc:  # appearance only adds votes
                    log.warning("appearance gallery unavailable: %s", exc)
            ids = identify_teams(run, result["robots"], video_path, team_lineup, max_frames=ocr_frames, gallery=gallery)
        except Exception as exc:  # OCR is best-effort; tracking results still stand
            log.warning("team identification failed: %s", exc)
            result["team_identification"] = {"error": str(exc)}
        else:
            for r in result["robots"]:
                info = ids.get(r["robot_id"])
                if info:
                    r["team_key"] = info["team_key"]
                    r["team_id"] = {k: v for k, v in info.items() if k != "team_key"}
            result["team_identification"] = {
                "lineup": team_lineup,
                "identified": len(ids),
                "appearance_teams": len(gallery) if gallery else 0,
            }
        finally:
            appearance.release()
    return result


def track_all_robots(
    *,
    video_path: str,
    camera: CameraModel,
    terrain: FieldTerrain,
    tracking_start_sec: float,
    tracking_end_sec: float,
    process_hz: float = 15.0,
    person_model: str | None = None,
    robot_model: str | list[str] | None = None,
) -> dict:
    """Stage 1: track every robot in the window. Independent of the target.

    Several ``robot_model`` paths run together as a ``BoxEnsemble``.
    """
    started = time.time()
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    duration = total / fps if total else tracking_end_sec
    start_frame = max(0, int(round(tracking_start_sec * fps)))
    end_frame = max(start_frame + 1, int(round(tracking_end_sec * fps)))
    if total:
        end_frame = min(end_frame, total)
    step = max(1, int(round(fps / process_hz)))

    detector = RobotDetector(camera, terrain, (width, height))
    warnings: list[str] = []
    boxes_model: RobotBoxModel | BoxEnsemble | None = None
    if robot_model:
        try:
            boxes_model = BoxEnsemble(robot_model) if isinstance(robot_model, list) else RobotBoxModel(robot_model)
        except Exception as exc:  # missing weights/deps: fall back to background subtraction
            warnings.append(f"Robot detector model unavailable ({exc}); using background subtraction.")

    bg_lo = max(0.0, tracking_start_sec - 60.0)
    bg_hi = max(bg_lo + 1.0, min(duration - 0.2, tracking_end_sec + 120.0))
    bg_frames = detector.build_background(video_path, fps, bg_lo, bg_hi)
    people: PersonDetector | None = None
    if boxes_model is None or boxes_model.person_cls < 0:
        if person_model:
            try:
                people = PersonDetector(person_model)
            except Exception as exc:  # model missing/corrupt: track without the person veto
                warnings.append(f"Person detector unavailable ({exc}); referees may be confused with robots.")

    tracker = MultiRobotTracker(terrain)
    grid: list[float] = []
    det_counts: list[int] = []
    person_boxes: list[list[float]] = []
    prev_person_boxes: list[list[float]] = []
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    idx = start_frame
    n_proc = 0
    while idx < end_frame:
        if (idx - start_frame) % step == 0:
            ok, frame = cap.read()
            if not ok:
                break
            t = idx / fps
            if boxes_model is not None:
                # One pass gives robots and people; keep last frame's people (refs flicker).
                robot_boxes, found_people = boxes_model(frame)
                if people is not None:  # the robot model has no person class
                    found_people = people(frame)
                prev_person_boxes, person_boxes = person_boxes, found_people
                dets = detector.detect_boxes(frame, robot_boxes, person_boxes + prev_person_boxes, boxes_model.last_bumpers)
                # Recall backup: moving blobs with a clear bumper strip the model missed.
                for d in detector.detect(frame, person_boxes + prev_person_boxes):
                    if max(d["bumper"]["red"], d["bumper"]["blue"]) >= 0.5 and all(
                        np.hypot(d["xy"][0] - m["xy"][0], d["xy"][1] - m["xy"][1]) > 0.8 for m in dets
                    ):
                        d["quality"] *= 0.6
                        dets.append(d)
            else:
                if people is not None and n_proc % 2 == 0:
                    # Keep the previous result too: YOLO flickers on partly hidden refs.
                    prev_person_boxes, person_boxes = person_boxes, people(frame)
                dets = detector.detect(frame, person_boxes + prev_person_boxes)
            tracker.step(t, dets)
            grid.append(t)
            det_counts.append(len(dets))
            n_proc += 1
        elif not cap.grab():
            break
        idx += 1
    cap.release()

    t0 = start_frame / fps
    meta: dict = {
        "tracker": "field_3d",
        "fps": fps,
        "frames_processed": idx - start_frame,
        "process_hz": fps / step,
        "tracking_start_sec": tracking_start_sec,
        "tracking_end_sec": tracking_end_sec,
        "background_frames": bg_frames,
        "mean_detections_per_frame": round(float(np.mean(det_counts)), 2) if det_counts else 0.0,
        "track_count": sum(1 for tr in tracker.tracks if tr.confirmed),
        "terrain": terrain.summary(),
        "person_veto": people is not None or boxes_model is not None,
        "robot_detector": (
            " + ".join(robot_model) if isinstance(robot_model, list) else robot_model
        ) if boxes_model is not None else "background_subtraction",
        "device": boxes_model.device if boxes_model is not None else "cpu",
        "warnings": warnings,
    }
    if not terrain.climb_zones and not terrain.surfaces:
        meta["warnings"].append(
            "No terrain/climb zones for this season in data/fields/registry.json; z is reported as floor level."
        )

    robots = [tr for tr in tracker.tracks if tr.robot_like()]
    meta["track_candidates"] = [
        {
            "track_id": tr.id,
            "start_px": float(tr.obs[0]["det"]["foot_px"][0]),
            "start_py": float(tr.obs[0]["det"]["foot_px"][1]),
            "start_x_m": float(tr.obs[0]["det"]["xy"][0]),
            "start_y_m": float(tr.obs[0]["det"]["xy"][1]),
            "first_t_sec": round(tr.first_t - t0, 3),
            "last_t_sec": round(tr.last_obs_t - t0, 3),
            "alliance_guess": tr.alliance,
            "red_score": round(tr.red_score, 4),
            "blue_score": round(tr.blue_score, 4),
            "samples": len(tr.obs),
        }
        for tr in robots
    ]
    meta["tracking_elapsed_sec"] = round(time.time() - started, 1)
    return {"tracker": tracker, "grid": grid, "t0": t0, "meta": meta}


def follow_target(
    run: dict,
    *,
    camera: CameraModel,
    terrain: FieldTerrain,
    target_alliance: str,
    target_robot_position: int,
    lock_window_sec: float,
    forced_track_id: int | None = None,
) -> dict:
    """Stage 2: pick the target among all tracks and build its trajectory and path."""
    tracker: MultiRobotTracker = run["tracker"]
    grid: list[float] = run["grid"]
    t0: float = run["t0"]
    meta = {**run["meta"], "warnings": list(run["meta"]["warnings"])}
    meta.update(
        target_alliance=target_alliance,
        target_robot_position=target_robot_position,
        lock_window_sec=lock_window_sec,
        forced_track_id=forced_track_id,
    )

    if not grid:
        meta["selected_track_id"] = None
        meta["warnings"].append("No frames could be read in the tracking window.")
        return {"samples": [], "path": build_path([], camera, terrain), "meta": meta}

    target, sel_conf, pool, reason = select_target(
        tracker.tracks, t0, lock_window_sec, target_alliance, target_robot_position, forced_track_id, grid[-1]
    )
    meta["selected_track_id"] = target.id if target else None
    meta["selection_confidence"] = round(sel_conf, 3)
    meta["selection_reason"] = reason
    meta["selection_pool"] = [tr.id for tr in pool]
    if forced_track_id is not None and reason != "forced_track_id":
        meta["warnings"].append(f"forced_track_id {forced_track_id} is not a confirmed track; auto-selected instead.")
    if target is None:
        meta["warnings"].append("No robot-like track found for the target.")
        return {"samples": [], "path": build_path([], camera, terrain), "meta": meta}

    samples, target_meta = build_chain_trajectory(
        _chain_of(target, link_tracklets(tracker.tracks)), sel_conf, np.array(grid), camera, terrain, target_alliance
    )
    path = _finish(samples, camera, terrain, t0)
    meta["target"] = target_meta
    return {"samples": samples, "path": path, "meta": meta}


def _chain_of(target: Track, chains: list[list[tuple[Track, float]]]) -> list[tuple[Track, float]]:
    return next((c for c in chains if any(tr is target for tr, _ in c)), [(target, 1.0)])


def _finish(samples: list[dict], camera: CameraModel, terrain: FieldTerrain, t0: float) -> dict:
    """Build the path, add image coordinates and make times relative to the window start."""
    path = build_path(samples, camera, terrain)
    if samples:
        img = camera.project(np.array([[s["x_m"], s["y_m"], s["z_m"]] for s in samples]))
        for s, (u, v) in zip(samples, img):
            s["px"] = None if math.isnan(u) else float(u)
            s["py"] = None if math.isnan(v) else float(v)
    for s in samples:
        s["t_sec"] = round(s.pop("t") - t0, 4)
    for group in (path["nodes"], path["points"]):
        for p in group:
            p["t_sec"] = round(p["t_sec"] - t0, 4)
    return path


def _robot_entry(chain: list[tuple[Track, float]], run: dict, camera: CameraModel, terrain: FieldTerrain, alliance: str) -> dict:
    t0 = run["t0"]
    if not chain:
        return {
            "track_ids": [],
            "alliance": alliance,
            "first_t_sec": None,
            "last_t_sec": None,
            "observed_fraction": 0.0,
            "links": [],
            "samples": [],
            "path": build_path([], camera, terrain),
        }
    samples, cmeta = build_chain_trajectory(chain, 1.0, np.array(run["grid"]), camera, terrain, alliance)
    path = _finish(samples, camera, terrain, t0)
    return {
        "track_ids": [tr.id for tr, _ in sorted(chain, key=lambda c: c[0].first_t)],
        "alliance": alliance,
        "first_t_sec": round(min(tr.first_t for tr, _ in chain) - t0, 3),
        "last_t_sec": round(max(tr.last_obs_t for tr, _ in chain) - t0, 3),
        "observed_fraction": round(cmeta.get("observed_fraction", 0.0), 3),
        "links": [
            {"track_id": c["track_id"], "link_confidence": c["stitch_confidence"], "first_t_sec": round(c["first_t"] - t0, 3), "last_t_sec": round(c["last_t"] - t0, 3)}
            for c in cmeta.get("chain", [])
        ],
        "samples": samples,
        "path": path,
    }


def tracklet_summary(tr: Track, t0: float, robot_id: str | None) -> dict:
    """Compact tracklet summary for the UI: every 3rd sighting as [t, x_m, y_m, px, py]."""
    return {
        "track_id": tr.id,
        "alliance": pool_alliance(tr),
        "robot_id": robot_id,
        "first_t_sec": round(tr.first_t - t0, 3),
        "last_t_sec": round(tr.last_obs_t - t0, 3),
        "samples": len(tr.obs),
        "points": [
            [
                round(o["t"] - t0, 3),
                round(float(o["det"]["xy"][0]), 3),
                round(float(o["det"]["xy"][1]), 3),
                round(float(o["det"]["foot_px"][0]), 1),
                round(float(o["det"]["foot_px"][1]), 1),
            ]
            for o in tr.obs[::3]
        ],
    }


def follow_all(run: dict, *, camera: CameraModel, terrain: FieldTerrain) -> tuple[list[dict], list[dict]]:
    """The 6 robots (3 red, 3 blue) built from linked tracklets, plus every tracklet.

    Robot entries keep their per-frame ``samples`` (for the JSON export).
    """
    if not run["grid"]:
        return [], []
    slots, dropped = assign_slots(run["tracker"].tracks, terrain=terrain)
    t0 = run["t0"]
    robots, tracklets = [], []
    for alliance in ("red", "blue"):
        for k, chain in enumerate(slots[alliance]):
            rid = f"{alliance}{k + 1}"
            robots.append({"robot_id": rid, "team_key": None, **_robot_entry(chain, run, camera, terrain, alliance)})
            tracklets += [tracklet_summary(tr, t0, rid) for tr, _ in chain]
    tracklets += [tracklet_summary(tr, t0, None) for tr in dropped]
    tracklets.sort(key=lambda t: t["first_t_sec"])
    return robots, tracklets


def assign_tracklets(
    run: dict, *, camera: CameraModel, terrain: FieldTerrain, assignments: list[dict]
) -> tuple[list[dict], list[str]]:
    """Build each robot's trajectory from tracklets chosen by the user.

    ``assignments``: ``[{robot_id: "red1".."blue3", team_key: str|None, track_ids: [int]}]``.
    """
    by_id = {tr.id: tr for tr in run["tracker"].tracks if tr.confirmed}
    out, warnings = [], []
    if not run["grid"]:
        return out, ["Saved run has no frames."]
    for a in assignments:
        missing = [i for i in a["track_ids"] if i not in by_id]
        if missing:
            warnings.append(f"{a['robot_id']}: unknown tracklet id(s) {missing} ignored.")
        chain = [(by_id[i], 1.0) for i in dict.fromkeys(a["track_ids"]) if i in by_id]
        alliance = "red" if a["robot_id"].startswith("red") else "blue"
        # A robot's bumpers are one solid colour: tracklets with the other alliance's bumpers can't be it.
        wrong = [tr.id for tr, _ in chain if tr.alliance not in {alliance, "unknown"}]
        if wrong:
            warnings.append(
                f"{a['robot_id']}: tracklet(s) {wrong} have {('blue' if alliance == 'red' else 'red')} bumpers and were not added."
            )
            chain = [c for c in chain if c[0].id not in wrong]
        out.append(
            {"robot_id": a["robot_id"], "team_key": a.get("team_key"), **_robot_entry(chain, run, camera, terrain, alliance)}
        )
    return out, warnings


# ------------------------------------------------------------ persistence ---


def _encode(v):
    if isinstance(v, np.ndarray):
        return {"__nd__": v.tolist(), "dtype": str(v.dtype)}
    if isinstance(v, dict):
        return {k: _encode(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_encode(x) for x in v]
    if isinstance(v, np.generic):
        return v.item()
    return v


def _decode(v):
    if isinstance(v, dict):
        if "__nd__" in v:
            return np.asarray(v["__nd__"], dtype=v["dtype"])
        return {k: _decode(x) for k, x in v.items()}
    if isinstance(v, list):
        return [_decode(x) for x in v]
    return v


def save_run(run: dict, path: Path, context: dict) -> None:
    """Save confirmed tracklets (plain JSON, no pickle) for later team assignment."""
    tracks = [tr.__dict__ for tr in run["tracker"].tracks if tr.confirmed]
    payload = {"context": context, "grid": run["grid"], "t0": run["t0"], "meta": run["meta"], "tracks": tracks}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_encode(payload)), encoding="utf-8")


def load_run(path: Path, terrain: FieldTerrain) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    tracker = MultiRobotTracker(terrain)
    for raw in data["tracks"]:
        tr = Track.__new__(Track)
        tr.__dict__.update(_decode(raw))
        tracker.tracks.append(tr)
    return {"tracker": tracker, "grid": data["grid"], "t0": data["t0"], "meta": data["meta"]}


def read_run_context(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))["context"]
