"""Read team numbers off bumpers and match robots to the teams in the match.

Every FRC robot shows its team number in white (or black) digits on its
bumper, which is one solid alliance colour. Knowing the match line-up from
TBA turns OCR into a 3-way choice per alliance, so even partial or noisy reads
("642" for 6642) are enough when they agree over several frames.
"""

from __future__ import annotations

import logging
from functools import lru_cache
from threading import Lock

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment

from app.tracking.appearance import embed, robot_crop, team_votes
from app.tracking.field_tracker import Track, pool_alliance, split_track

log = logging.getLogger(__name__)

_reader = None
_reader_lock = Lock()

# Accept a team when its vote total reaches this (about two good reads) and
# clearly beats the robot's next-best team.
MIN_SCORE = 1.0
MIN_MARGIN = 1.5


def _get_reader():
    global _reader
    with _reader_lock:
        if _reader is None:
            import easyocr  # heavy import (torch); only when identification runs

            from app.core.gpu import torch_device

            device = torch_device()
            _reader = easyocr.Reader(["en"], gpu=device if device != "cpu" else False, verbose=False)
        return _reader


def release() -> None:
    """Drop the OCR reader so its GPU memory can be freed (it is rebuilt when needed)."""
    global _reader
    with _reader_lock:
        _reader = None

def _colour_mask(hsv: np.ndarray, alliance: str) -> np.ndarray:
    if alliance == "red":
        return cv2.inRange(hsv, (0, 100, 70), (10, 255, 255)) | cv2.inRange(hsv, (170, 100, 70), (180, 255, 255))
    return cv2.inRange(hsv, (100, 55, 45), (130, 255, 255))


def bumper_strip_box(frame: np.ndarray, bbox: list[float], alliance: str) -> tuple[int, int, int, int] | None:
    """The robot's bumper strip (solid alliance colour, digits bridged) as frame xyxy."""
    H, W = frame.shape[:2]
    x1, y1, x2, y2 = bbox
    w, h = x2 - x1, y2 - y1
    bx1, bx2 = int(max(0, x1 - 0.08 * w)), int(min(W, x2 + 0.08 * w))
    by1, by2 = int(max(0, y1 + 0.3 * h)), int(min(H, y2 + 0.1 * h))
    if bx2 - bx1 < 16 or by2 - by1 < 8:
        return None
    roi = frame[by1:by2, bx1:bx2]
    mask = _colour_mask(cv2.cvtColor(roi, cv2.COLOR_BGR2HSV), alliance)
    # Bridge the gaps the (white) digits cut into the colour strip.
    kw = max(5, int(0.12 * (bx2 - bx1)) | 1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (kw, 5)))
    n, _, st, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    best = None
    for k in range(1, n):
        cx, cy, cw, ch, area = (int(v) for v in st[k])
        if cw < 0.3 * (bx2 - bx1) or cw < 1.5 * ch or area < 0.3 * cw * ch:
            continue
        if best is None or cw * ch > best[2] * best[3]:
            best = (cx, cy, cw, ch)
    if best is None:
        return None
    cx, cy, cw, ch = best
    return bx1 + cx, by1 + cy, bx1 + cx + cw, by1 + cy + ch


def bumper_strip_crop(frame: np.ndarray, bbox: list[float], alliance: str) -> np.ndarray | None:
    """Crop the robot's bumper strip (where the number is) from a full-resolution frame."""
    box = bumper_strip_box(frame, bbox, alliance)
    if box is None:
        return None
    x1, y1, x2, y2 = box
    py = int(0.35 * (y2 - y1)) + 2
    # Digits often sit at the end of the bumper, where they can cut the colour strip short.
    px = int(0.15 * (x2 - x1)) + 4
    H, W = frame.shape[:2]
    return frame[max(0, y1 - py) : min(H, y2 + py), max(0, x1 - px) : min(W, x2 + px)]


def _sharpness(img: np.ndarray) -> float:
    return float(cv2.Laplacian(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.CV_64F).var())


def text_lines(strip: np.ndarray, alliance: str) -> list[np.ndarray]:
    """Deskewed, dark-on-light grey images of the digit groups on a bumper strip.

    Digits are the light, unsaturated blobs inside the colour strip. Small and
    seen at an angle they defeat a generic text detector, so they are found
    here and rotated level before recognition.
    """
    hsv = cv2.cvtColor(strip, cv2.COLOR_BGR2HSV)
    colour = _colour_mask(hsv, alliance)
    h, w = colour.shape
    k = cv2.getStructuringElement(cv2.MORPH_RECT, (max(5, int(0.15 * w) | 1), max(3, int(0.35 * h) | 1)))
    region = cv2.morphologyEx(colour, cv2.MORPH_CLOSE, k)
    if np.count_nonzero(region) < 40:
        return []
    whiteness = ((hsv[:, :, 2].astype(np.float32) / 255.0) * (1.0 - hsv[:, :, 1].astype(np.float32) / 255.0) * 255).astype(np.uint8)
    inside = (region > 0) & (colour == 0)
    vals = whiteness[region > 0]
    thr, _ = cv2.threshold(vals.reshape(-1, 1), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    text = ((whiteness > max(thr, 70)) & inside).astype(np.uint8)
    n, lab, st, cen = cv2.connectedComponentsWithStats(text, connectivity=8)
    comps = [
        k for k in range(1, n)
        if 4 <= st[k, 3] <= 0.95 * h and st[k, 4] >= 6 and st[k, 2] <= 2.5 * st[k, 3]
    ]
    # Group neighbouring blobs into number-sized lines.
    groups: list[list[int]] = []
    for k in sorted(comps, key=lambda k: cen[k][0]):
        for g in groups:
            j = g[-1]
            hh = max(st[j, 3], st[k, 3])
            if abs(cen[k][1] - cen[j][1]) < 0.7 * hh and st[k, 0] - (st[j, 0] + st[j, 2]) < 1.2 * hh:
                g.append(k)
                break
        else:
            groups.append([k])
    out: list[np.ndarray] = []
    grey = 255 - whiteness
    for g in groups:
        if len(g) > 6:
            continue
        pts = np.column_stack(np.nonzero(np.isin(lab, g)))[:, ::-1].astype(np.float32)
        if len(pts) < 12:
            continue
        (cx, cy), (rw, rh), ang = cv2.minAreaRect(pts)
        if rw < rh:
            rw, rh, ang = rh, rw, ang + 90
        if ang > 45:
            ang -= 180
        rh_pad, rw_pad = rh * 1.6 + 4, rw + rh * 0.8 + 4
        M = cv2.getRotationMatrix2D((cx, cy), ang, 1.0)
        rot = cv2.warpAffine(grey, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
        x0, y0 = int(max(0, cx - rw_pad / 2)), int(max(0, cy - rh_pad / 2))
        line = rot[y0 : int(cy + rh_pad / 2) + 1, x0 : int(cx + rw_pad / 2) + 1]
        if line.size == 0 or line.shape[0] < 4:
            continue
        scale = 64.0 / line.shape[0]
        line = cv2.resize(line, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        out.append(cv2.normalize(line, None, 0, 255, cv2.NORM_MINMAX))
    return out


def read_digits(
    strip: np.ndarray, alliance: str, lines: list[np.ndarray] | None = None
) -> list[tuple[str, float]]:
    """OCR digit strings from a bumper strip: per deskewed digit group, then the whole strip."""
    reader = _get_reader()
    out: list[tuple[str, float]] = []
    for line in text_lines(strip, alliance) if lines is None else lines:
        for _, text, conf in reader.recognize(line, allowlist="0123456789", detail=1):
            if text:
                out.append((text, float(conf)))
    scale = max(2.0, min(6.0, 96.0 / max(1, strip.shape[0])))
    big = cv2.resize(strip, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
    for _, text, conf in reader.readtext(
        big, allowlist="0123456789", detail=1, paragraph=False, min_size=10, text_threshold=0.5, low_text=0.3
    ):
        if text:
            out.append((text, float(conf)))
    return out


def _lev(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def read_similarity(read: str, number: str) -> float:
    """How well an OCR'd digit string supports a team number (0..1)."""
    if not read or not number:
        return 0.0
    if read == number:
        return 1.0
    if number in read:  # extra digits from neighbours/edges
        return 0.85
    if len(read) >= 2 and read in number:  # partly hidden number
        return 0.7 * len(read) / len(number)
    sim = 1.0 - _lev(read, number) / max(len(read), len(number))
    return sim if sim >= 0.5 else 0.0


def _sighting_score(obs: list[dict], j: int, alliance: str) -> float:
    """How readable sighting ``j`` should be: wide, clear bumper, slow (less motion blur). 0 = no bumper."""
    o = obs[j]
    bump = (o["det"].get("bumper") or {}).get(alliance, 0.0)
    if bump < 0.35:
        return 0.0
    x1, y1, x2, y2 = o["det"]["bbox"]
    w = max(1.0, x2 - x1)
    speed = 0.0  # bbox widths per second
    for q in (obs[k] for k in (j - 1, j + 1) if 0 <= k < len(obs)):
        dt = abs(o["t"] - q["t"])
        if dt > 1e-3:
            qx1, qy1, qx2, qy2 = q["det"]["bbox"]
            d = np.hypot((x1 + x2 - qx1 - qx2) / 2, (y1 + y2 - qy1 - qy2) / 2)
            speed = max(speed, d / dt / w)
    return w * bump / (1.0 + speed)


def _candidate_obs(tracks: list[Track], alliance: str, max_frames: int) -> list[dict]:
    """Sightings worth reading: big, clear bumper and the robot moving slowly (less motion blur)."""
    scored: list[tuple[float, dict]] = []
    for tr in tracks:
        for j, o in enumerate(tr.obs):
            s = _sighting_score(tr.obs, j, alliance)
            if s > 0:
                scored.append((s, o))
    scored.sort(key=lambda s: -s[0])
    picked: list[dict] = []
    for _, o in scored[: max_frames * 6]:
        if all(abs(o["t"] - p["t"]) >= 0.3 for p in picked):
            picked.append(o)
        if len(picked) >= max_frames * 2:
            break
    return picked


# ---------- rendered-number matching ----------
# Bumper numbers are big bold sans digits. Fitting each candidate number,
# rendered in a few bold fonts, to a digit line and comparing shapes still
# separates the 3 teams of an alliance when the digits are too blurry to OCR.
_FONTS = ("arialbd.ttf", "ariblk.ttf", "impact.ttf")
TEMPLATE_GAIN = 4.0  # correlation margin over the best rival/decoy -> vote
TEMPLATE_MAX_VOTE = 0.5  # shape alone is weaker evidence than a clean OCR read
# Some numbers' shapes fit most blurry digit lines, so the same wrong shape vote
# repeats in every view of a robot: cap a robot's summed shape votes per team
# below MIN_SCORE so shape alone only breaks ties and never outweighs real reads.
SHAPE_TOTAL_MAX = 0.8


@lru_cache(maxsize=256)
def _number_templates(num: str) -> tuple[np.ndarray, ...]:
    out = []
    try:
        from PIL import Image, ImageDraw, ImageFont

        for name in _FONTS:
            try:
                font = ImageFont.truetype(name, 64)
            except OSError:
                continue
            l, t, r, b = font.getbbox(num)
            im = Image.new("L", (r - l, b - t), 255)
            ImageDraw.Draw(im).text((-l, -t), num, font=font, fill=0)
            out.append(np.array(im))
    except ImportError:
        pass
    if not out:  # no TrueType fonts: OpenCV's built-in font
        (w, h), base = cv2.getTextSize(num, cv2.FONT_HERSHEY_DUPLEX, 2.0, 6)
        im = np.full((h + base + 8, w + 8), 255, np.uint8)
        cv2.putText(im, num, (4, h + 4), cv2.FONT_HERSHEY_DUPLEX, 2.0, 0, 6)
        ys, xs = np.nonzero(im < 128)
        out.append(im[ys.min() : ys.max() + 1, xs.min() : xs.max() + 1])
    return tuple(out)


def _text_box(line: np.ndarray) -> tuple[int, int, int, int] | None:
    _, ink = cv2.threshold(line, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    ys, xs = np.nonzero(ink)
    if len(xs) < 30:
        return None
    x0, x1 = np.percentile(xs, [1, 99])
    y0, y1 = np.percentile(ys, [2, 98])
    if x1 - x0 < 8 or y1 - y0 < 8:
        return None
    return int(x0), int(y0), int(x1) + 1, int(y1) + 1


def number_match(line: np.ndarray, numbers: list[str]) -> np.ndarray:
    """Shape correlation (-1..1) of a digit line with each number fitted to the line's text box."""
    out = np.full(len(numbers), -1.0)
    box = _text_box(line)
    if box is None:
        return out
    x0, y0, x1, y1 = box
    tw, th = x1 - x0, y1 - y0
    pad = max(3, int(0.15 * th))
    src = cv2.copyMakeBorder(line, pad, pad, pad, pad, cv2.BORDER_REPLICATE)[y0 : y1 + 2 * pad, x0 : x1 + 2 * pad]
    src = src.astype(np.float32)
    sigma = max(1.0, th / 14.0)
    for k, num in enumerate(numbers):
        for tpl0 in _number_templates(num):
            for sx in (0.9, 1.1):
                for sy in (0.95,):
                    w, h = int(tw * sx), int(th * sy)
                    if w < 4 or h < 4 or w > src.shape[1] or h > src.shape[0]:
                        continue
                    tpl = cv2.resize(tpl0, (w, h), interpolation=cv2.INTER_AREA).astype(np.float32)
                    tpl = cv2.GaussianBlur(tpl, (0, 0), sigma)
                    out[k] = max(out[k], float(cv2.matchTemplate(src, tpl, cv2.TM_CCOEFF_NORMED).max()))
    return out


def _template_votes(lines: list[np.ndarray], numbers: list[str]) -> np.ndarray:
    """A vote for the team whose number fits a digit line clearly better than
    the other teams *and* than random decoy numbers of the same lengths (some
    numbers' shapes fit any blob well; decoys cancel that bias)."""
    votes = np.zeros(len(numbers))
    if len(numbers) < 2 or not lines:
        return votes
    decoys = [d for d in _decoys(tuple(sorted({len(n) for n in numbers}))) if d not in numbers]
    best = None
    for line in lines:
        C = number_match(line, numbers + decoys)
        k = int(np.argmax(C[: len(numbers)]))
        margin = C[k] - np.max(np.delete(C, k))
        if C[k] >= 0.5 and margin > 0 and (best is None or margin > best[1]):
            best = (k, margin)
    if best is not None:
        votes[best[0]] = min(TEMPLATE_MAX_VOTE, best[1] * TEMPLATE_GAIN)
    return votes


@lru_cache(maxsize=16)
def _decoys(lengths: tuple[int, ...], per_length: int = 8) -> list[str]:
    rng = np.random.default_rng(1234)
    out = []
    for n in lengths:
        lo = 10 ** (n - 1) if n > 1 else 0
        out += [str(v) for v in rng.integers(lo, 10**n, size=per_length)]
    return out


def _view_votes(strip: np.ndarray, alliance: str, numbers: list[str]) -> tuple[np.ndarray, list[str]]:
    """Votes per team from one bumper image: best OCR read plus shape match."""
    ocr, tpl, reads = _view_votes_split(strip, alliance, numbers)
    return ocr + tpl, reads


def _view_votes_split(strip: np.ndarray, alliance: str, numbers: list[str]) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """(OCR votes, shape votes, reads) per team from one bumper image."""
    lines = text_lines(strip, alliance)
    found = read_digits(strip, alliance, lines)
    ocr = np.array([max((c * read_similarity(t, n) for t, c in found), default=0.0) for n in numbers])
    tpl = _template_votes(lines, numbers)
    reads = [f"{t}:{c:.2f}" for t, c in found]
    if tpl.any():
        reads.append(f"shape:{numbers[int(np.argmax(tpl))]}:{tpl.max():.2f}")
    return ocr, tpl, reads


# ---------- multi-frame fusion ----------
FUSE_RADIUS = 2  # frames either side of a sighting averaged with it
STILL_WEIGHT = 2.0  # a fused still window counts as this many sightings
STILL_MIN_FRAMES = 4


def _patch_box(bbox: list[float], shape: tuple[int, ...]) -> tuple[int, int, int, int]:
    """Region around a robot's bumper (covers what bumper_strip_crop looks at)."""
    H, W = shape[:2]
    x1, y1, x2, y2 = bbox
    w, h = x2 - x1, y2 - y1
    return int(max(0, x1 - 0.15 * w)), int(max(0, y1 + 0.15 * h)), int(min(W, x2 + 0.15 * w)), int(min(H, y2 + 0.25 * h))


def _local_bbox(bbox: list[float], box: tuple[int, int, int, int], scale: float = 1.0) -> list[float]:
    return [(bbox[0] - box[0]) * scale, (bbox[1] - box[1]) * scale, (bbox[2] - box[0]) * scale, (bbox[3] - box[1]) * scale]


def fuse_patches(patches: list[np.ndarray], upscale: int = 2) -> tuple[np.ndarray, int]:
    """Average copies of one region from several frames after sub-pixel alignment.

    Upscaling first lets small shifts between frames add real detail; averaging
    removes video compression noise. Returns (image at ``upscale``, frames used).
    """
    big = [cv2.resize(p, None, fx=upscale, fy=upscale, interpolation=cv2.INTER_CUBIC).astype(np.float32) for p in patches]
    mid = len(big) // 2
    ref = big[mid]
    g0 = cv2.cvtColor(ref, cv2.COLOR_BGR2GRAY)
    h, w = g0.shape
    win = cv2.createHanningWindow((w, h), cv2.CV_32F)
    acc, n = ref.copy(), 1
    for i, p in enumerate(big):
        if i == mid:
            continue
        (dx, dy), resp = cv2.phaseCorrelate(g0, cv2.cvtColor(p, cv2.COLOR_BGR2GRAY), win)
        if resp < 0.2 or abs(dx) > 0.1 * w or abs(dy) > 0.1 * h:
            continue  # moved too much or changed (occluded): would only blur
        M = np.float32([[1, 0, -dx], [0, 1, -dy]])
        acc += cv2.warpAffine(p, M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        n += 1
    return np.clip(acc / n, 0, 255).astype(np.uint8), n


def _thumb(frame: np.ndarray) -> np.ndarray:
    return cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (96, 54), interpolation=cv2.INTER_AREA).astype(np.float32)


def _still_window_patches(
    cap: cv2.VideoCapture,
    fps: float,
    t_lo: float,
    t_hi: float,
    t_ref: float,
    boxes: dict[str, tuple[int, int, int, int]],
    samples: int = 16,
) -> dict[str, list[np.ndarray]]:
    """Patches of each box over [t_lo, t_hi], skipping frames that don't show the tracked view (camera cuts, fades)."""
    f_lo, f_hi, f_ref = (int(round(t * fps)) for t in (t_lo, t_hi, t_ref))
    want = set(np.linspace(f_lo, f_hi, samples).round().astype(int).tolist())
    first, last = min(f_lo, f_ref), max(f_hi, f_ref)
    cap.set(cv2.CAP_PROP_POS_FRAMES, first)
    ref = None
    got: list[tuple[np.ndarray, dict[str, np.ndarray]]] = []
    for f in range(first, last + 1):
        if f not in want and f != f_ref:
            if not cap.grab():
                break
            continue
        ok, frame = cap.read()
        if not ok:
            break
        if f == f_ref:
            ref = _thumb(frame)
        if f in want and frame.mean() > 25:
            got.append((_thumb(frame), {rid: frame[y1:y2, x1:x2].copy() for rid, (x1, y1, x2, y2) in boxes.items()}))
    if ref is None:
        return {}
    keep = [p for th, p in got if float(np.abs(th - ref).mean()) < 20.0]
    return {rid: [p[rid] for p in keep] for rid in boxes} if len(keep) >= STILL_MIN_FRAMES else {}


# ---------- dense reads: every tracklet, all match long ----------
# Bumper numbers never change, so reading every tracklet every few frames tells
# which pieces are the same robot (slot assignment) and where a tracklet jumped
# from one robot to another (it is cut there).
DENSE_EVERY_S = 0.5  # read each tracklet about this often...
DENSE_MAX_READS = 240  # ...thinned to stay within this many reads per match
DENSE_MIN_WIDTH_PX = 40  # narrower robots' digits are unreadable
READ_MIN = 0.4  # one read names a team when its vote reaches this...
READ_MARGIN = 2.0  # ...and beats the team's alliance partners this many times
SWITCH_MIN_READS = 2  # reads of each team needed either side of a cut
SWITCH_PURITY = 0.8
DENSE_SHAPE_MAX = 0.4  # shape matches pick the wrong number ~half the time on moving robots


def _dense_obs(tr: Track, alliance: str, every_s: float) -> list[dict]:
    """The most readable sighting in each ``every_s`` stretch of a tracklet."""
    bins: dict[int, tuple[float, dict]] = {}
    for j, o in enumerate(tr.obs):
        x1, _, x2, _ = o["det"]["bbox"]
        if x2 - x1 < DENSE_MIN_WIDTH_PX or o["det"].get("split"):
            continue
        s = _sighting_score(tr.obs, j, alliance)
        b = int((o["t"] - tr.first_t) // every_s)
        if s > 0 and (b not in bins or bins[b][0] < s):
            bins[b] = (s, o)
    return sorted((o for _, o in bins.values()), key=lambda o: o["t"])


def _read_label(read: dict, teams: list[str]) -> str | None:
    """The team one read names (OCR only: digits actually read)."""
    v = np.asarray(read["ocr"])
    k = int(np.argmax(v))
    second = float(np.max(np.delete(v, k))) if len(v) > 1 else 0.0
    return teams[k] if v[k] >= READ_MIN and v[k] >= READ_MARGIN * second else None


def _set_votes(tr: Track, teams: list[str]) -> None:
    reads = tr.team_reads
    ocr = np.sum([r["ocr"] for r in reads], axis=0) if reads else np.zeros(len(teams))
    tpl = np.sum([r["tpl"] for r in reads], axis=0) if reads else np.zeros(len(teams))
    tr.team_votes = {t: round(float(v), 3) for t, v in zip(teams, ocr + np.minimum(tpl, DENSE_SHAPE_MAX))}


def _switch_cut(tr: Track, teams: list[str]) -> int | None:
    """Observation index where a tracklet's reads switch from one team to another for good."""
    labs = [(r["t"], lab) for r in tr.team_reads if (lab := _read_label(r, teams))]
    best = None
    for i in range(SWITCH_MIN_READS, len(labs) - SWITCH_MIN_READS + 1):
        before, after = [x[1] for x in labs[:i]], [x[1] for x in labs[i:]]
        a = max(set(before), key=before.count)
        b = max(set(after), key=after.count)
        na, nb = before.count(a), after.count(b)
        if a == b or min(na, nb) < SWITCH_MIN_READS:
            continue
        if na < SWITCH_PURITY * len(before) or nb < SWITCH_PURITY * len(after):
            continue
        if best is None or na + nb > best[0]:
            best = (na + nb, labs[i - 1][0], labs[i][0])
    if best is None:
        return None
    _, t_a, t_b = best
    # Cut at the least certain step between the two reads (where the boxes swapped).
    ks = [k for k, o in enumerate(tr.obs) if t_a < o["t"] <= t_b and k > 0]
    return min(ks, key=lambda k: tr.obs[k]["p"]) if ks else None


def read_tracklet_numbers(
    run: dict,
    video_path: str,
    lineup: dict[str, list[str]],
    every_s: float = DENSE_EVERY_S,
    max_reads: int = DENSE_MAX_READS,
) -> dict:
    """Read every robot tracklet's bumper number throughout the match and cut
    tracklets whose number changes (the tracker jumped to another robot).

    Each read is a 3-way choice among the tracklet's alliance teams (``lineup``),
    from the tracklet's most readable sighting every ``every_s``. Sets ``team_reads``
    and ``team_votes`` ({team key: votes}) on the tracklets, which
    ``assign_slots`` and ``identify_teams`` use. Returns counts for the run meta.
    """
    tracker = run["tracker"]
    jobs: list[tuple[Track, str, list[str]]] = []
    for tr in tracker.tracks:
        if not tr.robot_like():
            continue
        alliance = pool_alliance(tr)
        teams = [k for k in lineup.get(alliance) or [] if k.startswith("frc")]
        if len(teams) >= 2:
            jobs.append((tr, alliance, teams))
    picks: dict[int, list[dict]] = {}
    for _ in range(12):
        picks = {tr.id: _dense_obs(tr, a, every_s) for tr, a, _ in jobs}
        if sum(len(v) for v in picks.values()) <= max_reads:
            break
        every_s *= 1.3
    reqs: dict[int, list[tuple[Track, str, list[str], dict]]] = {}
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    for tr, a, teams in jobs:
        tr.team_reads = []
        for o in picks[tr.id]:
            reqs.setdefault(int(round(o["t"] * fps)), []).append((tr, a, teams, o))
    n_read = 0

    def process(c: int, frame: np.ndarray) -> None:
        # Single frames: fusing neighbours blurs a moving robot's digits
        # (shape matches then pick the wrong number).
        nonlocal n_read
        for tr, alliance, teams, o in reqs[c]:
            view = bumper_strip_crop(frame, o["det"]["bbox"], alliance)
            if view is None:
                continue
            ocr, tpl, _ = _view_votes_split(view, alliance, [k[3:] for k in teams])
            tr.team_reads.append({"t": o["t"], "ocr": np.round(ocr, 3).tolist(), "tpl": np.round(tpl, 3).tolist()})
            n_read += 1

    try:
        if reqs and width:
            cap.set(cv2.CAP_PROP_POS_FRAMES, min(reqs))
            for f in range(min(reqs), max(reqs) + 1):
                if f not in reqs:
                    if not cap.grab():
                        break
                    continue
                ok, frame = cap.read()
                if not ok:
                    break
                process(f, frame)
    finally:
        cap.release()

    cuts = 0
    queue = list(jobs)
    while queue:
        tr, alliance, teams = queue.pop()
        tr.team_reads.sort(key=lambda r: r["t"])
        k = _switch_cut(tr, teams)
        if k is not None and cuts < 20:
            tail = split_track(tr, k, max(t.id for t in tracker.tracks) + 1)
            t_cut = tail.first_t
            tail.team_reads = [r for r in tr.team_reads if r["t"] >= t_cut]
            tr.team_reads = [r for r in tr.team_reads if r["t"] < t_cut]
            tracker.tracks.append(tail)
            cuts += 1
            log.info("tracklet %d cut at %.2fs: bumper number changed (new tracklet %d)", tr.id, t_cut, tail.id)
            queue += [(tr, alliance, teams), (tail, alliance, teams)]
            continue
        _set_votes(tr, teams)
    tracker._next_id = max((t.id for t in tracker.tracks), default=0) + 1
    return {"reads": n_read, "tracklets": len(jobs), "every_s": round(every_s, 2), "cuts": cuts}


def identify_teams(
    run: dict,
    robots: list[dict],
    video_path: str,
    lineup: dict[str, list[str]],
    max_frames: int = 12,
    gallery: dict[str, np.ndarray] | None = None,
) -> dict[str, dict]:
    """Match robot slots to team keys by reading bumper numbers.

    Each robot is read in its best sightings (each fused with its neighbouring
    frames) and, with extra weight, in the still moments just before auto and
    just after it ends (robots are disabled), where many frames are fused.
    With a ``gallery`` (team key -> appearance embeddings from good matches)
    the robots' looks vote too (``tracking/appearance``).

    ``robots`` are follow_all entries (robot_id, alliance, track_ids);
    ``lineup`` is ``{"red": [team keys], "blue": [...]}`` from TBA.
    Returns ``{robot_id: {team_key, confidence, method, scores, reads}}`` for
    robots that could be identified.
    """
    by_id = {tr.id: tr for tr in run["tracker"].tracks}
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    duration = total / fps if total else float("inf")
    start = run["meta"].get("tracking_start_sec")
    end = run["meta"].get("tracking_end_sec")
    result: dict[str, dict] = {}
    try:
        # Still windows: robots stand still before auto and are disabled right after it.
        post: dict[str, tuple[int, int, int, int]] = {}
        pre: dict[str, tuple[int, int, int, int]] = {}
        bboxes: dict[str, tuple[list[float], list[float]]] = {}
        for r in robots:
            obs = [o for t in r.get("track_ids") or [] if t in by_id for o in by_id[t].obs]
            if not obs or not width:
                continue
            first, last = min(obs, key=lambda o: o["t"]), max(obs, key=lambda o: o["t"])
            if end is not None and last["t"] >= end - 1.0:
                post[r["robot_id"]] = _patch_box(last["det"]["bbox"], (height, width))
            if start is not None and first["t"] <= start + 0.6:
                pre[r["robot_id"]] = _patch_box(first["det"]["bbox"], (height, width))
            bboxes[r["robot_id"]] = (first["det"]["bbox"], last["det"]["bbox"])
        still: list[tuple[str, dict[str, list[np.ndarray]], dict]] = []
        if post and end + 2.6 < duration:
            still.append(("after_auto", _still_window_patches(cap, fps, end + 0.4, end + 2.6, end - 1.0 / fps, post), post))
        if pre and start + 0.25 - max(0.0, start - 2.5) >= 0.25:
            still.append(("before_auto", _still_window_patches(cap, fps, max(0.0, start - 2.5), start + 0.25, start + 0.25, pre), pre))

        for alliance in ("red", "blue"):
            teams = [k for k in lineup.get(alliance) or [] if k.startswith("frc")]
            slots = [r for r in robots if r["alliance"] == alliance and r.get("track_ids")]
            if not teams or not slots:
                continue
            numbers = [k[3:] for k in teams]
            S = np.zeros((len(slots), len(teams)))
            shape = np.zeros_like(S)
            reads_by_slot: list[list[str]] = []
            looks: list[list[np.ndarray]] = []
            for i, r in enumerate(slots):
                rid = r["robot_id"]
                tracks = [by_id[t] for t in r["track_ids"] if t in by_id]
                reads: list[str] = []
                # Reads of the robot's tracklets all match long (read_tracklet_numbers).
                dense = [tr for tr in tracks if getattr(tr, "team_votes", None)]
                if dense:
                    S[i] += [sum(tr.team_votes.get(t, 0.0) for tr in dense) for t in teams]
                    n_dense = sum(len(getattr(tr, "team_reads", None) or []) for tr in dense)
                    reads.append(f"dense:{n_dense} reads " + ",".join(f"{t[3:]}={S[i, k]:.1f}" for k, t in enumerate(teams)))
                for name, patches, boxes in still:
                    if len(patches.get(rid) or []) < STILL_MIN_FRAMES:
                        continue
                    fused, n = fuse_patches(patches[rid])
                    which = 1 if name == "after_auto" else 0
                    crop = bumper_strip_crop(fused, _local_bbox(bboxes[rid][which], boxes[rid], 2.0), alliance)
                    if n >= STILL_MIN_FRAMES and crop is not None:
                        v, tpl, found = _view_votes_split(crop, alliance, numbers)
                        S[i] += STILL_WEIGHT * v
                        shape[i] += STILL_WEIGHT * tpl
                        reads += [f"{name}:{s}" for s in found]
                views = []
                crops: list[np.ndarray] = []
                for o in _candidate_obs(tracks, alliance, max_frames):
                    box = _patch_box(o["det"]["bbox"], (height, width))
                    f0 = int(round(o["t"] * fps))
                    cap.set(cv2.CAP_PROP_POS_FRAMES, max(0, f0 - FUSE_RADIUS))
                    patches = []
                    for j in range(min(f0, FUSE_RADIUS) + FUSE_RADIUS + 1):
                        ok, frame = cap.read()
                        if not ok:
                            break
                        patches.append(frame[box[1] : box[3], box[0] : box[2]].copy())
                        if gallery and j == min(f0, FUSE_RADIUS) and len(crops) < max_frames:
                            c = robot_crop(frame, o["det"]["bbox"])
                            if c is not None:
                                crops.append(c)
                    if not patches:
                        continue
                    centre = patches[min(f0, FUSE_RADIUS)] if len(patches) > min(f0, FUSE_RADIUS) else patches[-1]
                    crop = bumper_strip_crop(centre, _local_bbox(o["det"]["bbox"], box), alliance)
                    if crop is not None:
                        views.append((_sharpness(crop), crop, patches, o, box))
                views.sort(key=lambda v: -v[0])
                for _, crop, patches, o, box in views[:max_frames]:
                    # Read the sighting fused with its neighbouring frames (less
                    # compression noise); the single frame if fusion failed.
                    view, tag = crop, ""
                    if len(patches) >= 3:
                        fused, n = fuse_patches(patches)
                        fcrop = bumper_strip_crop(fused, _local_bbox(o["det"]["bbox"], box, 2.0), alliance) if n >= 3 else None
                        if fcrop is not None:
                            view, tag = fcrop, "fused:"
                    v, tpl, found = _view_votes_split(view, alliance, numbers)
                    reads += [tag + s for s in found]
                    # One vote per sighting and team: the best supporting read.
                    S[i] += v
                    shape[i] += tpl
                S[i] += np.minimum(shape[i], SHAPE_TOTAL_MAX)
                reads_by_slot.append(reads)
                looks.append(crops)
            A = np.zeros_like(S)
            if gallery:
                A, _ = team_votes([embed(c) for c in looks], teams, gallery)
            ocr, S = S, S + A

            def clear_win(M: np.ndarray, i: int, k: int) -> bool:
                others = max([M[i, j] for j in range(len(teams)) if j != k] + [M[j, k] for j in range(len(slots)) if j != i] + [0.0])
                return M[i, k] >= MIN_SCORE and M[i, k] >= MIN_MARGIN * others

            rows, cols = linear_sum_assignment(-S)
            accepted: dict[int, int] = {i: k for i, k in zip(rows, cols) if clear_win(S, i, k)}
            # Everyone left over is one of the remaining teams: take the best joint
            # assignment, scored by how much it beats the best alternative.
            rest_i = [i for i in range(len(slots)) if i not in accepted]
            rest_k = [k for k in range(len(teams)) if k not in accepted.values()]
            if rest_i and rest_k:
                R = S[np.ix_(rest_i, rest_k)]
                rr, rc = linear_sum_assignment(-R)
                best = R[rr, rc].sum()
                for a, b in zip(rr, rc):
                    i, k = rest_i[a], rest_k[b]
                    if len(rest_i) == 1 and len(rest_k) == 1 and accepted:
                        method, conf = "elimination", 0.6
                    else:
                        alt = R.copy()
                        alt[a, b] = -1e6
                        ar, ac = linear_sum_assignment(-alt)
                        margin = best - alt[ar, ac].sum() if alt[ar, ac].min() > -1e5 else best
                        method, conf = "best_guess", min(0.5, 0.2 + float(margin))
                    result[slots[i]["robot_id"]] = {
                        "team_key": teams[k],
                        "confidence": round(conf, 2),
                        "method": method,
                        "needs_review": method == "best_guess",
                        "scores": dict(zip(teams, np.round(S[i], 2).tolist())),
                        "appearance": dict(zip(teams, np.round(A[i], 2).tolist())) if gallery else None,
                        "reads": reads_by_slot[i][:20],
                    }
            for i, k in accepted.items():
                others = sorted(S[i], reverse=True)
                second = others[1] if len(others) > 1 else 0.0
                result[slots[i]["robot_id"]] = {
                    "team_key": teams[k],
                    "confidence": round(float(min(1.0, S[i, k] / 3.0) * (1.0 - second / max(S[i, k], 1e-9) / 2)), 2),
                    "method": "bumper_ocr" if clear_win(ocr, i, k) else "appearance",
                    "needs_review": False,
                    "scores": dict(zip(teams, np.round(S[i], 2).tolist())),
                    "appearance": dict(zip(teams, np.round(A[i], 2).tolist())) if gallery else None,
                    "reads": reads_by_slot[i][:20],
                }
            for i, r in enumerate(slots):
                log.info("team-id %s scores %s reads %s", r["robot_id"], dict(zip(teams, np.round(S[i], 2))), reads_by_slot[i][:12])
    finally:
        cap.release()
    return result
