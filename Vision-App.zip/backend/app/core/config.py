from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    tba_auth_key: str = Field(default="", alias="TBA_AUTH_KEY")
    upload_dir: str = Field(default="uploads", alias="UPLOAD_DIR")
    output_dir: str = Field(default="outputs", alias="OUTPUT_DIR")
    default_tracker: str = Field(default="tracktrack.yaml", alias="DEFAULT_TRACKER")
    yolo_model: str = Field(default="yolo11n.pt", alias="YOLO_MODEL")
    # Learned robot detector (YOLO-World or a YOLO checkpoint fine-tuned on FRC robots).
    # Empty = background subtraction only (fast but far more false/missed robots).
    robot_model: str = Field(default="yolov8x-worldv2.pt", alias="ROBOT_MODEL")
    # Frames per second analysed; YOLO-World x is ~0.5 s/frame on a T1000 GPU.
    track_hz: float = Field(default=7.5, alias="TRACK_HZ")
    tracker_conf: float = Field(default=0.20, alias="TRACKER_CONF")
    tracker_iou: float = Field(default=0.45, alias="TRACKER_IOU")
    max_interp_gap_frames: int = Field(default=15, alias="MAX_INTERP_GAP_FRAMES")
    auto_seconds: float = Field(default=20.0, alias="AUTO_SECONDS")
    # Firestore: path to a Firebase service-account key JSON (keep it out of git).
    firebase_credentials: str = Field(default="secrets/firebase-service-account.json", alias="FIREBASE_CREDENTIALS")
    firebase_project_id: str = Field(default="auto-vision-drawing", alias="FIREBASE_PROJECT_ID")
    # Team cloud (Google sign-in; shared detector, calibrations, hand checks). These are the public
    # web-app values from Firebase console -> Project settings -> Your apps; not secrets.
    firebase_web_api_key: str = Field(default="", alias="FIREBASE_WEB_API_KEY")
    firebase_auth_domain: str = Field(default="", alias="FIREBASE_AUTH_DOMAIN")
    firebase_storage_bucket: str = Field(default="", alias="FIREBASE_STORAGE_BUCKET")
    firebase_app_id: str = Field(default="", alias="FIREBASE_APP_ID")
    # Max video height downloaded for batch scouting (match the calibration video).
    scout_video_height: int = Field(default=1080, alias="SCOUT_VIDEO_HEIGHT")
    # Netscape-format YouTube cookies (exported from a signed-in browser); used when the file
    # exists, to get past YouTube's "confirm you're not a bot" block.
    youtube_cookies_file: str = Field(default="youtube-cookies.txt", alias="YOUTUBE_COOKIES_FILE")
    # Part of the CUDA GPU's name to use when there are several (empty = most memory).
    gpu_name: str = Field(default="", alias="GPU_NAME")
    # Robot detector trained on frames of matches a scout marked good.
    collect_training_frames: bool = Field(default=True, alias="COLLECT_TRAINING_FRAMES")
    dataset_dir: str = Field(default="datasets/robot_detector", alias="DATASET_DIR")
    # Frames of matches never marked good are deleted after this many days.
    training_frames_keep_days: int = Field(default=30, alias="TRAINING_FRAMES_KEEP_DAYS")
    # YOLO-format exports of other labelled FRC robot pictures (e.g. Roboflow Universe), one folder each.
    external_dataset_dir: str = Field(default="datasets/external", alias="EXTERNAL_DATASET_DIR")
    external_max_images: int = Field(default=1500, alias="EXTERNAL_MAX_IMAGES")
    models_dir: str = Field(default="models/robot_detector", alias="MODELS_DIR")
    appearance_dir: str = Field(default="models/appearance", alias="APPEARANCE_DIR")
    # Empty = the biggest of yolo11s/m/l/x this computer's GPU can train (detector_training.base_for_gpu).
    detector_base_model: str = Field(default="", alias="DETECTOR_BASE_MODEL")
    # A trained detector is only used when its held-out AP50 reaches this (and YOLO-World's, less 0.02).
    detector_min_map50: float = Field(default=0.6, alias="DETECTOR_MIN_MAP50")
    # Retrain by itself (when idle) once this many new frames from good-marked matches exist.
    detector_auto_retrain_images: int = Field(default=24, alias="DETECTOR_AUTO_RETRAIN_IMAGES")
    # Continue training on the other team GPUs that are free too (team_training).
    detector_team_training: bool = Field(default=True, alias="DETECTOR_TEAM_TRAINING")
    # Web address: a second listener on 127.0.0.1:<port> for the tunnel that Vercel proxies to.
    # Everything arriving there needs a team sign-in. 0 = off.
    public_port: int = Field(default=0, alias="PUBLIC_PORT")


settings = Settings()
