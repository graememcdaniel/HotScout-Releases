"""Second listener for the web address (Vercel -> tunnel -> this computer).

Requests arriving here are never treated as local: every API call needs a team
sign-in. Responses are marked uncacheable so the proxy never shares them.

Vercel gives up on a proxied request after 120 s, and tracking a match can take
longer. If an API call has not started answering after WAIT_SEC, the caller gets
202 with an X-HotScout-Pending ticket and fetches the answer from
/api/pending/<ticket> (the frontend does this by itself).
"""

from __future__ import annotations

import asyncio
import contextlib
import hmac
import json
import logging
import secrets
import time
from http.cookies import SimpleCookie

import uvicorn

from app.core.access import COOKIE

PUBLIC_SCOPE_KEY = "hotscout.public"
WAIT_SEC = 90.0
TICKET_TTL_SEC = 3600.0
_PENDING_PREFIX = "/api/pending/"

_tickets: dict[str, "_Call"] = {}


class _Call:
    def __init__(self, session: str):
        self.session = session
        self.messages: list[dict] = []
        self.detached = False
        self.task: asyncio.Task | None = None
        self.created = time.monotonic()


def _session_cookie(scope) -> str:
    for name, value in scope.get("headers", []):
        if name == b"cookie":
            morsel = SimpleCookie(value.decode("latin-1")).get(COOKIE)
            if morsel:
                return morsel.value
    return ""


def _no_store(message: dict) -> dict:
    headers = list(message.get("headers", []))
    if not any(k.lower() == b"cache-control" for k, _ in headers):
        headers.append((b"cache-control", b"private, no-store"))
    return {**message, "headers": headers}


async def _send_json(send, status: int, body: dict, extra: list[tuple[bytes, bytes]] = ()) -> None:
    data = json.dumps(body).encode()
    headers = [
        (b"content-type", b"application/json"),
        (b"content-length", str(len(data)).encode()),
        (b"cache-control", b"private, no-store"),
        *extra,
    ]
    await send({"type": "http.response.start", "status": status, "headers": headers})
    await send({"type": "http.response.body", "body": data})


def _forget_old() -> None:
    now = time.monotonic()
    for t in [t for t, c in _tickets.items() if now - c.created > TICKET_TTL_SEC]:
        call = _tickets.pop(t)
        if call.task and not call.task.done():
            call.task.cancel()


class PublicGateway:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        scope = {**scope, PUBLIC_SCOPE_KEY: True}
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        path = scope.get("path", "")
        if path.startswith(_PENDING_PREFIX):
            return await self._pending(scope, path[len(_PENDING_PREFIX):], send)
        if not path.startswith("/api/"):
            return await self.app(scope, receive, lambda m: send(_no_store(m) if m["type"] == "http.response.start" else m))
        await self._api(scope, receive, send)

    async def _api(self, scope, receive, send):
        chunks = []
        while True:
            msg = await receive()
            if msg["type"] == "http.disconnect":
                return
            chunks.append(msg.get("body", b""))
            if not msg.get("more_body"):
                break
        body = b"".join(chunks)
        call = _Call(_session_cookie(scope))
        started = asyncio.Event()
        finished = asyncio.Event()
        body_given = False

        async def app_receive():
            nonlocal body_given
            if not body_given:
                body_given = True
                return {"type": "http.request", "body": body, "more_body": False}
            await finished.wait()
            return {"type": "http.disconnect"}

        async def app_send(message):
            if message["type"] == "http.response.start":
                message = _no_store(message)
                if not call.detached:
                    started.set()
            if call.detached:
                call.messages.append(message)
            else:
                await send(message)

        async def run():
            try:
                await self.app(scope, app_receive, app_send)
            finally:
                finished.set()

        call.task = asyncio.create_task(run())
        waiter = asyncio.create_task(started.wait())
        await asyncio.wait({call.task, waiter}, timeout=WAIT_SEC, return_when=asyncio.FIRST_COMPLETED)
        waiter.cancel()
        if started.is_set() or call.task.done():
            with contextlib.suppress(Exception):
                await call.task  # stream the rest of the answer straight through
            return
        # Still working: hand out a ticket and keep the work going.
        call.detached = True
        _forget_old()
        ticket = secrets.token_urlsafe(24)
        _tickets[ticket] = call
        await _send_json(send, 202, {"pending": ticket}, [(b"x-hotscout-pending", ticket.encode())])

    async def _pending(self, scope, ticket: str, send):
        call = _tickets.get(ticket)
        if call is None or not call.session or not hmac.compare_digest(call.session, _session_cookie(scope)):
            return await _send_json(send, 404, {"detail": "Unknown or expired request."})
        await asyncio.wait({call.task}, timeout=WAIT_SEC)
        if not call.task.done():
            return await _send_json(send, 202, {"pending": ticket}, [(b"x-hotscout-pending", ticket.encode())])
        _tickets.pop(ticket, None)
        if call.task.exception() is not None or not call.messages:
            logging.getLogger("uvicorn.error").error("Web request failed", exc_info=call.task.exception())
            return await _send_json(send, 500, {"detail": "Internal Server Error"})
        for message in call.messages:
            await send(message)


class _QuietServer(uvicorn.Server):
    """Runs beside the main server; the main server owns Ctrl+C handling."""

    @contextlib.contextmanager
    def capture_signals(self):
        yield


def start(app, port: int) -> tuple[uvicorn.Server, asyncio.Task]:
    config = uvicorn.Config(PublicGateway(app), host="127.0.0.1", port=port, lifespan="off", log_level="info")
    server = _QuietServer(config)

    async def serve():
        try:
            await server.serve()
        except SystemExit:  # e.g. the port is taken; keep the local app running
            logging.getLogger("uvicorn.error").error("Web address listener could not start on port %d", port)

    return server, asyncio.create_task(serve())
