"""Pick the compute device for every model: the discrete NVIDIA GPU.

CUDA only ever sees NVIDIA GPUs, so an integrated GPU can't be picked by
torch; with several NVIDIA GPUs the one with the most memory is used (or the
one whose name contains ``GPU_NAME``). Task Manager shows this work under the
NVIDIA GPU's "Cuda"/"Compute" graph, not "3D".
"""

from __future__ import annotations

from functools import lru_cache

from app.core.config import settings


@lru_cache(maxsize=1)
def gpu_info() -> dict:
    try:
        import torch
    except Exception as exc:  # torch missing or broken
        return {"device": "cpu", "name": None, "warning": f"PyTorch unavailable ({exc}); running on the CPU."}
    if not torch.cuda.is_available():
        return {
            "device": "cpu",
            "name": None,
            "torch": torch.__version__,
            "warning": "No CUDA GPU found (CPU-only PyTorch build or missing NVIDIA driver); running on the CPU.",
        }
    gpus = []
    for i in range(torch.cuda.device_count()):
        p = torch.cuda.get_device_properties(i)
        gpus.append({"index": i, "name": p.name, "memory_gb": round(p.total_memory / 2**30, 1)})
    want = (settings.gpu_name or "").strip().lower()
    match = [g for g in gpus if want and want in g["name"].lower()]
    pick = match[0] if match else max(gpus, key=lambda g: g["memory_gb"])
    torch.cuda.set_device(pick["index"])
    info = {"device": f"cuda:{pick['index']}", **pick, "torch": torch.__version__, "all": gpus}
    if want and not match:
        info["warning"] = f"No GPU named like '{settings.gpu_name}'; using {pick['name']}."
    return info


def torch_device() -> str:
    """``"cuda:N"`` for the chosen NVIDIA GPU, else ``"cpu"``."""
    return gpu_info()["device"]
