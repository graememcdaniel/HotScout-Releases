from __future__ import annotations

from app.core.config import settings
from app.models.schemas import RuntimeConfigUpdate

_runtime_config: dict[str, object] = {
    "tba_auth_key": settings.tba_auth_key,
    "default_tracker": settings.default_tracker,
    "yolo_model": settings.yolo_model,
    "tracker_conf": settings.tracker_conf,
    "tracker_iou": settings.tracker_iou,
    "max_interp_gap_frames": settings.max_interp_gap_frames,
    "auto_seconds": settings.auto_seconds,
}


def get_runtime_config() -> dict[str, object]:
    return dict(_runtime_config)


def update_runtime_config(update: RuntimeConfigUpdate) -> dict[str, object]:
    data = update.model_dump(exclude_none=True)
    for k, v in data.items():
        _runtime_config[k] = v
    return get_runtime_config()
