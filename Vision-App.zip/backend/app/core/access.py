"""Who may use the API.

This computer (loopback, addressed as localhost) always may. Anyone else on the
network must first sign in with a team Google account, which gives them an
HttpOnly session cookie. Cross-site browser requests are refused for everyone,
so other websites open on a team computer cannot drive the local API.
"""

from __future__ import annotations

import secrets
import time
from threading import Lock
from urllib.parse import urlsplit

from starlette.requests import Request

COOKIE = "hs_session"
SESSION_SEC = 12 * 3600
OPEN_PATHS = {"/api/cloud/status", "/api/cloud/session", "/api/health"}
_LOOPBACK_IPS = {"127.0.0.1", "::1"}
_LOOPBACK_HOSTS = {"localhost", "127.0.0.1", "[::1]"}

_sessions: dict[str, dict] = {}
_lock = Lock()


def _host_name(host: str) -> str:
    host = host.strip().lower()
    if host.startswith("["):
        return host[: host.find("]") + 1]
    return host.split(":", 1)[0]


def is_public(request: Request) -> bool:
    """Arrived on the web-address listener (Vercel -> tunnel), never trusted as local."""
    return bool(request.scope.get("hotscout.public"))


def is_local(request: Request) -> bool:
    """Request from this computer, addressed to it by a loopback name (blocks DNS rebinding)."""
    if is_public(request):
        return False
    client = request.client.host if request.client else ""
    return client in _LOOPBACK_IPS and _host_name(request.headers.get("host") or "") in _LOOPBACK_HOSTS


def same_origin(request: Request) -> bool:
    origin = request.headers.get("origin")
    if not origin:
        return request.headers.get("sec-fetch-site") in (None, "same-origin", "none")
    netloc = urlsplit(origin).netloc.lower()
    hosts = {(request.headers.get("host") or "").lower()}
    if is_public(request):
        # The proxy (Vercel) names the address the browser used; a page on another site
        # cannot set this header without a CORS preflight, which is never granted.
        hosts.add((request.headers.get("x-forwarded-host") or "").lower())
    hosts.discard("")
    return netloc in hosts


def new_session(email: str) -> str:
    token = secrets.token_urlsafe(32)
    now = time.time()
    with _lock:
        for k in [k for k, s in _sessions.items() if s["expires"] < now]:
            del _sessions[k]
        _sessions[token] = {"email": email, "expires": now + SESSION_SEC}
    return token


def end_session(request: Request) -> None:
    with _lock:
        _sessions.pop(request.cookies.get(COOKIE) or "", None)


def session_email(request: Request) -> str | None:
    token = request.cookies.get(COOKIE)
    if not token:
        return None
    with _lock:
        s = _sessions.get(token)
    return s["email"] if s and s["expires"] > time.time() else None


def allowed(request: Request) -> bool:
    return is_local(request) or session_email(request) is not None
