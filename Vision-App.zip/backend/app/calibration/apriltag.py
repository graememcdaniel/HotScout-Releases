from __future__ import annotations

import itertools
from functools import lru_cache

import cv2
import numpy as np


def _read_frame(video_path: str, frame_sec: float) -> tuple[np.ndarray | None, float]:
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    idx = max(0, int(frame_sec * fps))
    cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
    ok, frame = cap.read()
    cap.release()
    if not ok:
        return None, fps
    return frame, fps


def _read_frames_near_time(
    video_path: str,
    center_sec: float,
    offsets_sec: list[float],
) -> tuple[list[tuple[float, np.ndarray]], float]:
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    frames: list[tuple[float, np.ndarray]] = []

    seen = set()
    for off in offsets_sec:
        t = max(0.0, center_sec + float(off))
        idx = max(0, int(round(t * fps)))
        if total_frames > 0:
            idx = min(idx, total_frames - 1)
        if idx in seen:
            continue
        seen.add(idx)

        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, frame = cap.read()
        if ok and frame is not None:
            frames.append((idx / fps, frame))

    cap.release()
    return frames, fps


def _apply_homography(h: np.ndarray, x: float, y: float) -> tuple[float, float] | None:
    vec = np.array([x, y, 1.0], dtype=float)
    warped = h @ vec
    w = warped[2] if warped[2] else 0.0
    if abs(w) < 1e-9:
        return None
    return float(warped[0] / w), float(warped[1] / w)


def _estimate_camera_matrix(frame_width: int, frame_height: int, hfov_deg: float = 70.0) -> np.ndarray:
    hfov_rad = np.deg2rad(max(40.0, min(120.0, hfov_deg)))
    fx = (frame_width / 2.0) / np.tan(hfov_rad / 2.0)
    fy = fx
    cx = frame_width / 2.0
    cy = frame_height / 2.0
    return np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64)


def _build_aruco_detector() -> cv2.aruco.ArucoDetector:
    params = cv2.aruco.DetectorParameters()
    params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
    params.cornerRefinementWinSize = 7
    params.cornerRefinementMaxIterations = 50
    params.cornerRefinementMinAccuracy = 0.01
    params.minMarkerPerimeterRate = 0.01
    params.maxMarkerPerimeterRate = 2.5
    params.polygonalApproxAccuracyRate = 0.04
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_APRILTAG_36h11)
    return cv2.aruco.ArucoDetector(dictionary, params)


def _preprocess_detection_images(gray: np.ndarray) -> list[np.ndarray]:
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    g1 = clahe.apply(gray)
    g2 = cv2.GaussianBlur(g1, (0, 0), 1.2)
    sharpen = cv2.addWeighted(g1, 1.5, g2, -0.5, 0)
    adaptive = cv2.adaptiveThreshold(
        g1,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        5,
    )
    return [gray, g1, sharpen, adaptive]


def _polygon_area(corners: np.ndarray) -> float:
    pts = corners.astype(np.float32)
    return float(cv2.contourArea(pts))


def _detect_apriltags_multi_pass(
    gray: np.ndarray,
    valid_ids: set[int] | None = None,
) -> list[dict]:
    detector = _build_aruco_detector()
    best_by_id: dict[int, dict] = {}

    for scale in (1.0, 1.6):
        if scale == 1.0:
            scaled = gray
        else:
            scaled = cv2.resize(gray, dsize=None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

        for img in _preprocess_detection_images(scaled):
            corners, ids, _ = detector.detectMarkers(img)
            if ids is None:
                continue

            for marker_corners, marker_id in zip(corners, ids.flatten()):
                tag_id = int(marker_id)
                if valid_ids is not None and tag_id not in valid_ids:
                    continue

                pts = marker_corners[0] / scale
                area = _polygon_area(pts)
                if area < 8.0:
                    continue

                cx = float(np.mean(pts[:, 0]))
                cy = float(np.mean(pts[:, 1]))
                cand = {
                    "id": tag_id,
                    "center_x": cx,
                    "center_y": cy,
                    "corners": pts.tolist(),
                    "area_px2": area,
                }

                existing = best_by_id.get(tag_id)
                if existing is None or area > float(existing.get("area_px2", 0.0)):
                    best_by_id[tag_id] = cand

    detections = list(best_by_id.values())
    detections.sort(key=lambda d: d["id"])
    return detections


def _solve_camera_pose_from_tag_centers(
    detections: list[dict],
    tag_layout: dict[int, dict],
    camera_matrix: np.ndarray,
) -> tuple[dict | None, list[int]]:
    object_points: list[list[float]] = []
    image_points: list[list[float]] = []
    det_ids: list[int] = []

    for d in detections:
        tag_id = int(d["id"])
        layout = tag_layout.get(tag_id)
        if not layout:
            continue

        object_points.append(
            [
                float(layout.get("field_x_m", 0.0)),
                float(layout.get("field_y_m", 0.0)),
                float(layout.get("field_z_m", 0.0)),
            ]
        )
        image_points.append([float(d["center_x"]), float(d["center_y"])])
        det_ids.append(tag_id)

    if len(object_points) < 4:
        return None, []

    object_np = np.array(object_points, dtype=np.float64)
    image_np = np.array(image_points, dtype=np.float64)
    dist = np.zeros((4, 1), dtype=np.float64)

    ok, rvec, tvec, inliers = cv2.solvePnPRansac(
        objectPoints=object_np,
        imagePoints=image_np,
        cameraMatrix=camera_matrix,
        distCoeffs=dist,
        flags=cv2.SOLVEPNP_ITERATIVE,
        reprojectionError=8.0,
        iterationsCount=150,
        confidence=0.99,
    )
    if not ok:
        return None, []

    projected, _ = cv2.projectPoints(object_np, rvec, tvec, camera_matrix, dist)
    projected = projected.reshape((-1, 2))
    errors = np.linalg.norm(projected - image_np, axis=1)
    rmse = float(np.sqrt(np.mean(errors * errors))) if len(errors) else None

    inlier_ids: list[int] = []
    if inliers is not None:
        for idx in inliers.flatten().tolist():
            if 0 <= idx < len(det_ids):
                inlier_ids.append(det_ids[idx])

    pose = {
        "model": "solvepnp_3d",
        "camera_matrix": camera_matrix.tolist(),
        "dist_coeffs": dist.tolist(),
        "rvec": rvec.reshape(3).tolist(),
        "tvec": tvec.reshape(3).tolist(),
        "reprojection_rmse_px": rmse,
        "inlier_count": int(len(inliers)) if inliers is not None else len(det_ids),
    }
    return pose, inlier_ids


_TAG_SIZE_M = 0.1651  # FRC 2024+ 36h11 tag: outer black square edge (6.5 in)
# Tags needed to solve the lens and pose without field-corner clicks, and how well they must agree.
TAGS_ONLY_MIN = 5
TAGS_ONLY_MAX_RMSE_PX = 15.0


def _quat_to_mat(qw: float, qx: float, qy: float, qz: float) -> np.ndarray | None:
    q = np.array([qw, qx, qy, qz], dtype=np.float64)
    n = float(np.linalg.norm(q))
    if n < 1e-9:
        return None
    w, x, y, z = q / n
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def _mat_to_quat(r: np.ndarray) -> list[float]:
    tr = r[0, 0] + r[1, 1] + r[2, 2]
    if tr > 0:
        s = np.sqrt(tr + 1.0) * 2
        w, x, y, z = 0.25 * s, (r[2, 1] - r[1, 2]) / s, (r[0, 2] - r[2, 0]) / s, (r[1, 0] - r[0, 1]) / s
    elif r[0, 0] > r[1, 1] and r[0, 0] > r[2, 2]:
        s = np.sqrt(1.0 + r[0, 0] - r[1, 1] - r[2, 2]) * 2
        w, x, y, z = (r[2, 1] - r[1, 2]) / s, 0.25 * s, (r[0, 1] + r[1, 0]) / s, (r[0, 2] + r[2, 0]) / s
    elif r[1, 1] > r[2, 2]:
        s = np.sqrt(1.0 + r[1, 1] - r[0, 0] - r[2, 2]) * 2
        w, x, y, z = (r[0, 2] - r[2, 0]) / s, (r[0, 1] + r[1, 0]) / s, 0.25 * s, (r[1, 2] + r[2, 1]) / s
    else:
        s = np.sqrt(1.0 + r[2, 2] - r[0, 0] - r[1, 1]) * 2
        w, x, y, z = (r[1, 0] - r[0, 1]) / s, (r[0, 2] + r[2, 0]) / s, (r[1, 2] + r[2, 1]) / s, 0.25 * s
    return [float(w), float(x), float(y), float(z)]


def _tag_geometry_field(t: dict, tag_size_m: float) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None]:
    c = np.array(
        [float(t.get("field_x_m", 0.0)), float(t.get("field_y_m", 0.0)), float(t.get("field_z_m", 0.0))],
        dtype=np.float64,
    )
    r = _quat_to_mat(
        float(t.get("qw") or 0.0), float(t.get("qx") or 0.0), float(t.get("qy") or 0.0), float(t.get("qz") or 0.0)
    )
    if r is None:
        return c, None, None
    h = tag_size_m / 2.0
    # WPILib tag frame: +X points out of the printed face, +Z up, so a viewer
    # facing the tag sees +Y to their right. Order: TL, TR, BR, BL.
    local = np.array([[0.0, -h, h], [0.0, h, h], [0.0, h, -h], [0.0, -h, -h]], dtype=np.float64)
    return c, c + local @ r.T, r[:, 0]


def _project_layout_tags_to_image(
    tag_layout: dict[int, dict],
    pose: dict,
    tag_size_m: float = _TAG_SIZE_M,
) -> list[dict]:
    if not tag_layout:
        return []

    camera_matrix = np.array(pose["camera_matrix"], dtype=np.float64)
    dist = np.array(pose.get("dist_coeffs") or np.zeros((4, 1)), dtype=np.float64)
    rvec = np.array(pose["rvec"], dtype=np.float64).reshape(3, 1)
    tvec = np.array(pose["tvec"], dtype=np.float64).reshape(3, 1)
    rmat, _ = cv2.Rodrigues(rvec)
    cam_center = (-rmat.T @ tvec).reshape(3)
    mirror = bool(pose.get("ref_mirror_y"))
    r_lens = lens_max_radius(dist)

    out = []
    for tag_id, t in tag_layout.items():
        c, corners, normal = _tag_geometry_field(t, tag_size_m)
        c_p = np.array(_to_pose_frame(pose, *c.tolist()), dtype=np.float64)
        c_cam = rmat @ c_p + tvec.reshape(3)
        if float(c_cam[2]) <= 0.05:
            # Behind the camera; projecting would produce mirrored garbage.
            continue
        if float(np.hypot(c_cam[0], c_cam[1]) / c_cam[2]) > r_lens:
            # Outside the lens model's valid zone (would fold back into the image).
            continue
        img, _ = cv2.projectPoints(c_p.reshape(1, 3), rvec, tvec, camera_matrix, dist)
        px, py = img.reshape((-1, 2))[0].tolist()
        entry = {"id": int(tag_id), "center_x": float(px), "center_y": float(py)}

        if corners is not None:
            n_p = normal * np.array([1.0, -1.0, 1.0]) if mirror else normal
            view = cam_center - c_p
            facing_cos = float(n_p @ view / max(1e-9, float(np.linalg.norm(view))))
            if facing_cos <= 0.0:
                # Camera sees the back of this tag; it cannot be visible.
                continue
            corners_p = np.array([_to_pose_frame(pose, *k.tolist()) for k in corners], dtype=np.float64)
            if np.any((rmat @ corners_p.T + tvec)[2] <= 0.05):
                continue
            img_c, _ = cv2.projectPoints(corners_p, rvec, tvec, camera_matrix, dist)
            img_c = img_c.reshape((-1, 2))
            entry["corners"] = img_c.tolist()
            entry["facing_cos"] = facing_cos
            entry["side_px"] = float(np.sqrt(max(0.0, _polygon_area(img_c))))

        out.append(entry)

    return out


_CANON_CELL_CENTERS = np.array(
    [[j + 0.5, i + 0.5] for i in range(-1, 9) for j in range(-1, 9)], dtype=np.float64
)
_ring_i = np.array([i for i in range(-1, 9) for _j in range(-1, 9)])
_ring_j = np.array([j for _i in range(-1, 9) for j in range(-1, 9)])
_QUIET_MASK = (_ring_i == -1) | (_ring_i == 8) | (_ring_j == -1) | (_ring_j == 8)
_BORDER_MASK = ~_QUIET_MASK & ((_ring_i == 0) | (_ring_i == 7) | (_ring_j == 0) | (_ring_j == 7))
_DATA_MASK = ~_QUIET_MASK & ~_BORDER_MASK


@lru_cache(maxsize=1024)
def _tag_code_variants(tag_id: int) -> np.ndarray:
    # 36h11 payload for the expected ID in all 8 rotations/reflections, so the
    # decode is independent of how the tag happens to be mounted.
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_APRILTAG_36h11)
    img = cv2.aruco.generateImageMarker(dictionary, int(tag_id), 8, borderBits=1)
    bits = img[1:7, 1:7] > 127
    variants = []
    for flip in (False, True):
        b = np.fliplr(bits) if flip else bits
        for k in range(4):
            variants.append(np.rot90(b, k).reshape(-1))
    return np.array(variants, dtype=np.uint8)


def _search_tag_placement(
    gray: np.ndarray,
    h_cells_to_img: np.ndarray,
    cell_px: float,
    search_px: float,
    codes: np.ndarray,
    orient_ids: np.ndarray,
) -> dict | None:
    # Slide/scale the projected tag grid (in tag-cell units, so perspective
    # and rotation come from the 3D pose) and score how well the image matches
    # a white quiet zone + black border + the expected ID's bit payload.
    search_cells = search_px / max(cell_px, 1e-6)
    # Coarse grid: a 0.5-cell step keeps every sample within its cell
    # (max 0.25-cell misalignment), so bits still read correctly; the best
    # coarse hits are then polished on a fine grid.
    step = 0.5
    offs = np.arange(-search_cells, search_cells + 1e-9, step)
    sx, sy = np.meshgrid(offs, offs)
    coarse_shifts = np.column_stack([sx.ravel(), sy.ravel()])
    fine = np.arange(-step / 2.0, step / 2.0 + 1e-9, step / 4.0)
    fx, fy = np.meshgrid(fine, fine)
    fine_offsets = np.column_stack([fx.ravel(), fy.ravel()])

    # Only the region the search can touch needs blurring.
    reach = (search_cells + 8.0) * cell_px * 1.5 + 4.0
    c_img = h_cells_to_img @ np.array([4.0, 4.0, 1.0])
    if abs(c_img[2]) < 1e-9:
        return None
    cx, cy = c_img[0] / c_img[2], c_img[1] / c_img[2]
    hh, ww = gray.shape[:2]
    x0, x1 = int(max(0, cx - reach)), int(min(ww, cx + reach))
    y0, y1 = int(max(0, cy - reach)), int(min(hh, cy + reach))
    if x1 - x0 < 4 or y1 - y0 < 4:
        return None
    roi = gray[y0:y1, x0:x1]
    blur_k = int(round(cell_px * 0.6))
    src = (cv2.blur(roi, (blur_k, blur_k)) if blur_k >= 2 else roi).astype(np.float32)

    h32 = h_cells_to_img.astype(np.float32)
    center = np.array([4.0, 4.0])

    def evaluate(scale: float, shifts: np.ndarray) -> dict | None:
        grid = center + scale * (_CANON_CELL_CENTERS - center)
        # H [g + s; 1] = H [g; 1] + H [s; 0]
        a = np.column_stack([grid, np.ones(len(grid))]).astype(np.float32) @ h32.T
        b = np.column_stack([shifts, np.zeros(len(shifts))]).astype(np.float32) @ h32.T
        hom = a[None, :, :] + b[:, None, :]
        w = hom[..., 2]
        if np.any(np.abs(w) < 1e-6):
            return None
        mx = hom[..., 0] / w - x0
        my = hom[..., 1] / w - y0
        samples = cv2.remap(src, mx, my, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=-1.0)
        valid = np.all(samples >= 0.0, axis=1)
        if not np.any(valid):
            return None
        q = samples[:, _QUIET_MASK]
        bb = samples[:, _BORDER_MASK]
        d = samples[:, _DATA_MASK]
        qm = q.mean(axis=1)
        bm = bb.mean(axis=1)
        contrast = qm - bm
        thr = ((qm + bm) / 2.0)[:, None]
        border_err = (bb > thr).sum(axis=1)
        quiet_err = (q < thr).sum(axis=1)
        bits = d > thr
        ham_all = (bits[:, None, :] != codes[None, :, :].astype(bool)).sum(axis=2)
        orient_idx = ham_all.argmin(axis=1)
        data_ham = ham_all.min(axis=1)
        total = data_ham + border_err + quiet_err
        total = np.where(valid & (contrast >= 20.0), total, 10_000)
        return {
            "total": total, "data_ham": data_ham, "border_err": border_err, "quiet_err": quiet_err,
            "contrast": contrast, "bits": bits, "orient_idx": orient_idx,
        }

    scales = (0.8, 0.9, 1.0, 1.12, 1.25)
    candidates: list[tuple[int, float, np.ndarray]] = []
    for scale in scales:
        ev = evaluate(scale, coarse_shifts)
        if ev is None:
            continue
        order = np.argsort(ev["total"], kind="stable")[:4]
        for i in order:
            if ev["total"][i] < 10_000:
                candidates.append((int(ev["total"][i]), scale, coarse_shifts[i]))
    candidates.sort(key=lambda c: c[0])

    best: dict | None = None
    for _t, scale, shift in candidates[:8]:
        shifts = shift[None, :] + fine_offsets
        ev = evaluate(scale, shifts)
        if ev is None:
            continue
        i = int(np.argmin(ev["total"]))
        if ev["total"][i] >= 10_000:
            continue
        if best is None or int(ev["total"][i]) < best["total"]:
            corners_cells = center + scale * (np.array([[0, 0], [8, 0], [8, 8], [0, 8]], dtype=np.float64) - center)
            corners_cells = corners_cells + shifts[i]
            ch = np.column_stack([corners_cells, np.ones(4)]) @ h_cells_to_img.T
            corners_img = ch[:, :2] / ch[:, 2:3]
            best = {
                "total": int(ev["total"][i]),
                "data_ham": int(ev["data_ham"][i]),
                "border_err": int(ev["border_err"][i]),
                "quiet_err": int(ev["quiet_err"][i]),
                "contrast": float(ev["contrast"][i]),
                "ones": int(ev["bits"][i].sum()),
                "orientation": int(orient_ids[ev["orient_idx"][i]]),
                "corners": corners_img,
            }
    return best


def _verify_tags_with_pose(
    gray_frames: list[np.ndarray],
    tag_layout: dict[int, dict],
    pose: dict,
    detections: list[dict],
    tag_size_m: float = _TAG_SIZE_M,
) -> tuple[list[dict], dict]:
    projected = _project_layout_tags_to_image(tag_layout=tag_layout, pose=pose, tag_size_m=tag_size_m)
    h_img, w_img = gray_frames[0].shape[:2]
    rmse = float(pose.get("reprojection_rmse_px") or 30.0)

    in_frame: dict[int, dict] = {}
    for p in projected:
        m = float(p.get("side_px") or 0.0)
        if -m <= p["center_x"] <= w_img + m and -m <= p["center_y"] <= h_img + m:
            in_frame[int(p["id"])] = p

    canon_unit = np.array([[0, 0], [8, 0], [8, 8], [0, 8]], dtype=np.float32)

    def search(tid: int, p: dict, orient_filter: int | None) -> dict | None:
        side = float(p["side_px"])
        cell_px = side / 8.0
        h = cv2.getPerspectiveTransform(canon_unit, np.array(p["corners"], dtype=np.float32))
        search_px = min(90.0, max(10.0, 2.0 * rmse, 1.5 * side))
        if orient_filter is not None:
            # A single expected code makes false matches far less likely,
            # so the search window can be wider.
            search_px = min(90.0, max(search_px, 15.0, 3.0 * side))
        codes = _tag_code_variants(tid)
        orient_ids = np.arange(8)
        if orient_filter is not None:
            codes = codes[orient_filter:orient_filter + 1]
            orient_ids = orient_ids[orient_filter:orient_filter + 1]
        best = None
        for g in gray_frames:
            cand = _search_tag_placement(g, h, cell_px, search_px, codes, orient_ids)
            if cand is not None and (best is None or cand["total"] < best["total"]):
                best = cand
        return best

    def classify(r: dict | None, data_limit: int) -> str:
        if r is None:
            return "not_found"
        if r["data_ham"] <= data_limit and r["border_err"] <= 3 and r["quiet_err"] <= 5:
            return "decoded"
        # Too blurry to fully decode, but the bit pattern still clearly
        # favors the expected ID (random content averages ~18/36 wrong).
        if (
            r["border_err"] <= 2 and r["quiet_err"] <= 3 and r["contrast"] >= 35.0
            and 8 <= r["ones"] <= 28 and r["data_ham"] <= 8
        ):
            return "structural"
        return "not_found"

    results: dict[int, dict] = {}
    status: dict[int, str] = {}
    for tid, p in in_frame.items():
        if "corners" not in p:
            status[tid] = "no_orientation"
            continue
        if float(p["side_px"]) < 8.0:
            status[tid] = "too_small"
            continue
        r = search(tid, p, None)
        status[tid] = classify(r, 5)
        if r is not None:
            results[tid] = r

    # All tags are mounted upright, so confident decodes agree on one grid
    # orientation. Reuse it to re-search the rest with a single code (fewer
    # false matches, so a slightly looser bit tolerance is safe).
    confident = [results[t]["orientation"] for t, s in status.items() if s == "decoded" and results[t]["data_ham"] <= 3]
    majority = None
    if confident:
        vals, counts = np.unique(confident, return_counts=True)
        if counts.max() >= 2 or len(confident) == 1:
            majority = int(vals[np.argmax(counts)])
    if majority is not None:
        for tid, s in list(status.items()):
            if s in ("decoded",) and results[tid]["orientation"] == majority:
                continue
            if s in ("too_small", "no_orientation"):
                continue
            r = search(tid, in_frame[tid], majority)
            s2 = classify(r, 7)
            if r is not None and (s2 == "decoded" or (s2 == "structural" and s != "decoded")):
                results[tid] = r
                status[tid] = s2
            elif s == "decoded":
                status[tid] = "structural" if classify(results[tid], -1) == "structural" else "not_found"

    verified: list[dict] = []
    for tid, s in status.items():
        if s not in ("decoded", "structural"):
            continue
        r = results[tid]
        corners = r["corners"]
        p = in_frame[tid]
        cx, cy = float(np.mean(corners[:, 0])), float(np.mean(corners[:, 1]))
        verified.append({
            "id": tid,
            "center_x": cx,
            "center_y": cy,
            "corners": corners.tolist(),
            "area_px2": _polygon_area(corners),
            "source": "pose_verified" if s == "decoded" else "pose_structural",
            "data_hamming": r["data_ham"],
            "orientation": r["orientation"],
            "shift_px": float(np.hypot(cx - p["center_x"], cy - p["center_y"])),
        })
    verified_by_id = {int(v["id"]): v for v in verified}

    kept: list[dict] = []
    rejected: list[dict] = []
    for d in detections:
        tid = int(d.get("id", -1))
        if str(d.get("source") or "") == "manual_click":
            kept.append(d)
            continue
        if str(d.get("source") or "") in ("pose_verified", "pose_structural"):
            # From an earlier verify pass; re-verified below against this pose.
            continue
        p = in_frame.get(tid)
        if p is None:
            rejected.append({"id": tid, "reason": "not_visible_from_pose"})
            continue
        if not (isinstance(d.get("corners"), list) and len(d["corners"]) >= 4):
            rejected.append({"id": tid, "reason": "undecoded_fallback"})
            continue
        dist = float(np.hypot(d["center_x"] - p["center_x"], d["center_y"] - p["center_y"]))
        gate = max(30.0, 2.0 * rmse, 3.0 * float(p.get("side_px") or 10.0))
        if dist > gate:
            rejected.append({"id": tid, "reason": "far_from_projection", "distance_px": dist})
            continue
        kept.append(d)

    kept_ids = {int(d["id"]) for d in kept}
    for tid, v in verified_by_id.items():
        if tid not in kept_ids:
            kept.append(v)
    kept.sort(key=lambda d: int(d["id"]))

    diag = {
        "majority_orientation": majority,
        "visible_projected_ids": sorted(in_frame.keys()),
        "tag_status": {str(t): s for t, s in sorted(status.items())},
        "verified": [
            {k: v[k] for k in ("id", "source", "data_hamming", "orientation", "shift_px")} for v in verified
        ],
        "rejected": rejected,
    }
    return kept, diag


def _align_projected_points_to_observations(
    projected_layout_points: list[dict],
    detections: list[dict],
) -> tuple[list[dict], dict | None]:
    if not projected_layout_points or not detections:
        return projected_layout_points, None

    projected_by_id: dict[int, dict] = {int(p["id"]): p for p in projected_layout_points}
    residuals_x: list[float] = []
    residuals_y: list[float] = []
    matched_projected_points: list[tuple[float, float]] = []
    matched_observed_points: list[tuple[float, float]] = []

    for d in detections:
        try:
            tag_id = int(d["id"])
        except (TypeError, ValueError, KeyError):
            continue

        p = projected_by_id.get(tag_id)
        if p is None:
            continue

        dx = float(d.get("center_x", 0.0)) - float(p.get("center_x", 0.0))
        dy = float(d.get("center_y", 0.0)) - float(p.get("center_y", 0.0))
        residuals_x.append(dx)
        residuals_y.append(dy)
        matched_projected_points.append((float(p.get("center_x", 0.0)), float(p.get("center_y", 0.0))))
        matched_observed_points.append((float(d.get("center_x", 0.0)), float(d.get("center_y", 0.0))))

    if not residuals_x:
        return projected_layout_points, None

    shift_x = float(np.median(np.array(residuals_x, dtype=np.float64)))
    shift_y = float(np.median(np.array(residuals_y, dtype=np.float64)))

    matched_count = len(residuals_x)
    spread_px = 0.0
    spread_x = 0.0
    spread_y = 0.0
    if matched_projected_points:
        pts = np.array(matched_projected_points, dtype=np.float64)
        spread_x = float(np.max(pts[:, 0]) - np.min(pts[:, 0]))
        spread_y = float(np.max(pts[:, 1]) - np.min(pts[:, 1]))
        spread_px = max(spread_x, spread_y)

    # Avoid global correction when constraints are weak (few tags or mostly
    # one-dimensional spread).
    if matched_count < 3 or spread_x < 220.0 or spread_y < 80.0:
        diag = {
            "matched_count": matched_count,
            "shift_x_px": shift_x,
            "shift_y_px": shift_y,
            "matched_spread_px": spread_px,
            "matched_spread_x_px": spread_x,
            "matched_spread_y_px": spread_y,
            "applied": False,
            "reason": "insufficient_2d_spread_or_count",
        }
        return projected_layout_points, diag

    src = np.array(matched_projected_points, dtype=np.float64).reshape((-1, 1, 2))
    dst = np.array(matched_observed_points, dtype=np.float64).reshape((-1, 1, 2))

    affine, inliers = cv2.estimateAffinePartial2D(
        src,
        dst,
        method=cv2.RANSAC,
        ransacReprojThreshold=14.0,
        maxIters=2500,
        confidence=0.995,
    )

    if affine is None:
        diag = {
            "matched_count": matched_count,
            "shift_x_px": shift_x,
            "shift_y_px": shift_y,
            "matched_spread_px": spread_px,
            "matched_spread_x_px": spread_x,
            "matched_spread_y_px": spread_y,
            "applied": False,
            "reason": "affine_fit_failed",
        }
        return projected_layout_points, diag

    # Validate that correction improves matched-point RMSE; otherwise avoid
    # harming tags that were already close.
    src_pts = np.array(matched_projected_points, dtype=np.float64)
    dst_pts = np.array(matched_observed_points, dtype=np.float64)
    before_rmse = float(np.sqrt(np.mean(np.sum((src_pts - dst_pts) ** 2, axis=1))))

    a = np.array(affine, dtype=np.float64)
    src_h = np.hstack([src_pts, np.ones((src_pts.shape[0], 1), dtype=np.float64)])
    pred = (a @ src_h.T).T
    after_rmse = float(np.sqrt(np.mean(np.sum((pred - dst_pts) ** 2, axis=1))))

    if not np.isfinite(after_rmse) or after_rmse >= (before_rmse * 0.92):
        diag = {
            "matched_count": matched_count,
            "shift_x_px": shift_x,
            "shift_y_px": shift_y,
            "matched_spread_px": spread_px,
            "matched_spread_x_px": spread_x,
            "matched_spread_y_px": spread_y,
            "before_rmse_px": before_rmse,
            "after_rmse_px": after_rmse,
            "applied": False,
            "reason": "insufficient_rmse_improvement",
        }
        return projected_layout_points, diag

    aligned = []
    for p in projected_layout_points:
        x = float(p.get("center_x", 0.0))
        y = float(p.get("center_y", 0.0))
        v = np.array([x, y, 1.0], dtype=np.float64)
        x2, y2 = (a @ v).tolist()
        q = {**p, "center_x": float(x2), "center_y": float(y2)}
        if p.get("corners"):
            q["corners"] = [(a @ np.array([cx, cy, 1.0])).tolist() for cx, cy in p["corners"]]
        aligned.append(q)

    diag = {
        "matched_count": matched_count,
        "shift_x_px": shift_x,
        "shift_y_px": shift_y,
        "matched_spread_px": spread_px,
        "matched_spread_x_px": spread_x,
        "matched_spread_y_px": spread_y,
        "before_rmse_px": before_rmse,
        "after_rmse_px": after_rmse,
        "mode": "affine_partial_2d",
        "inliers": int(np.sum(inliers)) if inliers is not None else matched_count,
        "applied": True,
    }
    return aligned, diag


def _solve_camera_pose_from_manual_refs(
    manual_references: list[dict],
    camera_matrix: np.ndarray,
) -> dict | None:
    if not manual_references or len(manual_references) < 4:
        return None

    object_points: list[list[float]] = []
    image_points: list[list[float]] = []
    z_values: list[float] = []

    for r in manual_references:
        ix = r.get("image_x")
        iy = r.get("image_y")
        fx = r.get("field_x_m")
        fy = r.get("field_y_m")
        fz = r.get("field_z_m", 0.0)
        if None in (ix, iy, fx, fy):
            continue

        fz = float(fz)
        object_points.append([float(fx), float(fy), fz])
        image_points.append([float(ix), float(iy)])
        z_values.append(fz)

    if len(object_points) < 4:
        return None

    object_np = np.array(object_points, dtype=np.float64)
    image_np = np.array(image_points, dtype=np.float64)
    dist = np.zeros((4, 1), dtype=np.float64)
    cx = float(camera_matrix[0, 2])
    cy = float(camera_matrix[1, 2])

    z_arr = np.array(z_values, dtype=np.float64)
    ground_idx = np.where(np.abs(z_arr) < 0.05)[0]
    elevated_idx = np.where(np.abs(z_arr) >= 0.05)[0]
    mirror_h = float(np.max(object_np[:, 1]))

    # Try both the given corner order and its mirror image. A mirrored click
    # order has no physically valid pose (camera ends up under the floor), so
    # the validity check in _solve_manual_subset resolves handedness.
    candidates: list[dict] = []
    for mirror in (False, True):
        obj = object_np.copy()
        if mirror:
            obj[:, 1] = mirror_h - obj[:, 1]
        if len(ground_idx) >= 4:
            c = _solve_manual_subset(obj[ground_idx], image_np[ground_idx], cx, cy, planar=True)
            if c is not None:
                c.update(subset="ground_only", mirror=mirror, obj=obj)
                candidates.append(c)
        if len(elevated_idx) > 0:
            c = _solve_manual_subset(obj, image_np, cx, cy, planar=False)
            if c is not None:
                c.update(subset="all", mirror=mirror, obj=obj)
                candidates.append(c)

    if not candidates:
        return None

    best_all = min((c for c in candidates if c["subset"] == "all"), key=lambda c: c["rmse"], default=None)
    best_ground = min((c for c in candidates if c["subset"] == "ground_only"), key=lambda c: c["rmse"], default=None)
    if best_all is not None and (best_all["rmse"] <= 25.0 or best_ground is None):
        chosen = best_all
    else:
        chosen = best_ground

    obj = chosen["obj"]
    rvec, tvec, cam = chosen["rvec"], chosen["tvec"], chosen["cam"]
    proj_all, _ = cv2.projectPoints(obj, rvec, tvec, cam, dist)
    err_all = np.linalg.norm(proj_all.reshape((-1, 2)) - image_np, axis=1)

    ref_diag: list[dict] = []
    z_sweep = np.linspace(0.0, 6.0, 301)
    for i in range(len(obj)):
        item = {
            "index": int(i),
            "kind": "ground" if i in ground_idx else "elevated",
            "field_m": [float(v) for v in object_np[i]],
            "residual_px": float(err_all[i]),
        }
        if i in elevated_idx:
            # Height that best explains this click under the solved pose; a
            # large gap vs the entered height means the height input is wrong.
            pts = np.column_stack([
                np.full_like(z_sweep, obj[i, 0]),
                np.full_like(z_sweep, obj[i, 1]),
                z_sweep,
            ])
            proj_z, _ = cv2.projectPoints(pts, rvec, tvec, cam, dist)
            err_z = np.linalg.norm(proj_z.reshape((-1, 2)) - image_np[i], axis=1)
            k = int(np.argmin(err_z))
            item["implied_z_m"] = float(z_sweep[k])
            item["implied_z_residual_px"] = float(err_z[k])
        ref_diag.append(item)

    center = chosen["center"].copy()
    if chosen["mirror"]:
        center[1] = mirror_h - center[1]

    return {
        "model": "solvepnp_manual_3d",
        "camera_matrix": cam.tolist(),
        "dist_coeffs": dist.tolist(),
        "rvec": rvec.reshape(3).tolist(),
        "tvec": tvec.reshape(3).tolist(),
        "reprojection_rmse_px": float(chosen["rmse"]),
        "rmse_all_refs_px": float(np.sqrt(np.mean(err_all * err_all))),
        "inlier_count": len(object_points),
        "hfov_deg": float(chosen["hfov_deg"]),
        "ref_solve_subset": chosen["subset"],
        "ref_mirror_y": bool(chosen["mirror"]),
        "ref_mirror_field_height_m": mirror_h,
        "camera_position_m": [float(v) for v in center],
        "manual_ref_diagnostics": ref_diag,
    }


def _manual_pose_candidate(
    object_np: np.ndarray,
    image_np: np.ndarray,
    hfov_deg: float,
    cx: float,
    cy: float,
    planar: bool,
) -> dict | None:
    fx = cx / np.tan(np.deg2rad(hfov_deg) / 2.0)
    cam = np.array([[fx, 0.0, cx], [0.0, fx, cy], [0.0, 0.0, 1.0]], dtype=np.float64)
    dist = np.zeros((4, 1), dtype=np.float64)
    flags = [cv2.SOLVEPNP_IPPE] if planar else [cv2.SOLVEPNP_SQPNP, cv2.SOLVEPNP_EPNP]

    best: dict | None = None
    for flag in flags:
        try:
            _n, rvecs, tvecs, _e = cv2.solvePnPGeneric(object_np, image_np, cam, dist, flags=flag)
        except cv2.error:
            continue
        for rv, tv in zip(rvecs, tvecs):
            rv = np.asarray(rv, dtype=np.float64).reshape(3, 1)
            tv = np.asarray(tv, dtype=np.float64).reshape(3, 1)
            try:
                rv, tv = cv2.solvePnPRefineLM(object_np, image_np, cam, dist, rv, tv)
            except cv2.error:
                pass
            rmat, _ = cv2.Rodrigues(rv)
            depths = (rmat @ object_np.T + tv)[2]
            center = (-rmat.T @ tv).reshape(3)
            # Physically valid only if every point is in front of the camera
            # and the camera is above the floor.
            if np.any(depths <= 0.05) or center[2] < 0.3:
                continue
            proj, _ = cv2.projectPoints(object_np, rv, tv, cam, dist)
            err = np.linalg.norm(proj.reshape((-1, 2)) - image_np, axis=1)
            rmse = float(np.sqrt(np.mean(err * err)))
            if best is None or rmse < best["rmse"]:
                best = {"rmse": rmse, "rvec": rv, "tvec": tv, "cam": cam, "hfov_deg": float(hfov_deg), "center": center}
    return best


def _solve_manual_subset(
    object_np: np.ndarray,
    image_np: np.ndarray,
    cx: float,
    cy: float,
    planar: bool,
) -> dict | None:
    # Broadcast/phone FOV is unknown; coarse sweep then refine around the best.
    best: dict | None = None
    for hfov in np.geomspace(12.0, 110.0, 40):
        c = _manual_pose_candidate(object_np, image_np, float(hfov), cx, cy, planar)
        if c is not None and (best is None or c["rmse"] < best["rmse"]):
            best = c
    if best is None:
        return None
    base = best["hfov_deg"]
    for hfov in np.linspace(base * 0.94, base * 1.06, 13):
        c = _manual_pose_candidate(object_np, image_np, float(hfov), cx, cy, planar)
        if c is not None and c["rmse"] < best["rmse"]:
            best = c
    return best


def _to_pose_frame(pose: dict, x: float, y: float, z: float) -> list[float]:
    # Manual poses solved from a mirrored corner order live in a y-reflected
    # frame; map field coordinates into that frame before projecting.
    if pose.get("ref_mirror_y"):
        return [x, float(pose.get("ref_mirror_field_height_m", 0.0)) - y, z]
    return [x, y, z]


def _refine_manual_pose_with_tag_centers(
    pose: dict,
    manual_references: list[dict],
    detections: list[dict],
    tag_layout: dict[int, dict],
    camera_matrix: np.ndarray,
) -> dict:
    object_points: list[list[float]] = []
    image_points: list[list[float]] = []
    accepted_tag_count = 0
    # Refine with the intrinsics the manual pose was solved with.
    camera_matrix = np.array(pose.get("camera_matrix", camera_matrix), dtype=np.float64)

    for r in manual_references or []:
        ix = r.get("image_x")
        iy = r.get("image_y")
        fx = r.get("field_x_m")
        fy = r.get("field_y_m")
        fz = r.get("field_z_m", 0.0)
        if None in (ix, iy, fx, fy):
            continue
        object_points.append(_to_pose_frame(pose, float(fx), float(fy), float(fz)))
        image_points.append([float(ix), float(iy)])

    projected_by_id: dict[int, tuple[float, float]] = {}
    try:
        base_projected = _project_layout_tags_to_image(tag_layout=tag_layout, pose=pose)
        projected_by_id = {
            int(p.get("id")): (float(p.get("center_x", 0.0)), float(p.get("center_y", 0.0)))
            for p in base_projected
        }
    except Exception:
        projected_by_id = {}

    for d in detections or []:
        tid = int(d.get("id") or -1)
        t = tag_layout.get(tid)
        if t is None:
            continue

        # Guard against wrong-ID matches by requiring consistency with the
        # current manual projection before using a detection to refine pose.
        pred = projected_by_id.get(tid)
        if pred is not None:
            dx = float(d.get("center_x", 0.0)) - float(pred[0])
            dy = float(d.get("center_y", 0.0)) - float(pred[1])
            if ((dx * dx) + (dy * dy)) ** 0.5 > 80.0:
                continue

        object_points.append(
            _to_pose_frame(
                pose,
                float(t.get("field_x_m", 0.0)),
                float(t.get("field_y_m", 0.0)),
                float(t.get("field_z_m", 0.0)),
            )
        )
        image_points.append([float(d.get("center_x", 0.0)), float(d.get("center_y", 0.0))])
        accepted_tag_count += 1

    if len(object_points) < 4:
        return pose

    # Require at least two trusted detected tags before refinement; otherwise
    # keep the manual pose to avoid drifting from sparse/ambiguous IDs.
    if accepted_tag_count < 2:
        return pose

    object_np = np.array(object_points, dtype=np.float64)
    image_np = np.array(image_points, dtype=np.float64)
    dist = np.zeros((4, 1), dtype=np.float64)

    rvec0 = np.array(pose.get("rvec") or [0.0, 0.0, 0.0], dtype=np.float64).reshape(3, 1)
    tvec0 = np.array(pose.get("tvec") or [0.0, 0.0, 0.0], dtype=np.float64).reshape(3, 1)

    ok, rvec, tvec, inliers = cv2.solvePnPRansac(
        objectPoints=object_np,
        imagePoints=image_np,
        cameraMatrix=camera_matrix,
        distCoeffs=dist,
        rvec=rvec0.copy(),
        tvec=tvec0.copy(),
        useExtrinsicGuess=True,
        flags=cv2.SOLVEPNP_ITERATIVE,
        reprojectionError=11.0,
        iterationsCount=250,
        confidence=0.99,
    )
    if not ok:
        return pose

    try:
        rvec, tvec = cv2.solvePnPRefineLM(
            objectPoints=object_np,
            imagePoints=image_np,
            cameraMatrix=camera_matrix,
            distCoeffs=dist,
            rvec=rvec,
            tvec=tvec,
        )
    except Exception:
        pass

    proj_new, _ = cv2.projectPoints(object_np, rvec, tvec, camera_matrix, dist)
    proj_new = proj_new.reshape((-1, 2))
    err_new = np.linalg.norm(proj_new - image_np, axis=1)
    rmse_new = float(np.sqrt(np.mean(err_new * err_new))) if len(err_new) else None

    # Compare old vs new pose on the same point set (refs + tags); comparing
    # against the refs-only RMSE would reject every refinement.
    if rmse_new is None:
        return pose
    proj_old, _ = cv2.projectPoints(object_np, rvec0, tvec0, camera_matrix, dist)
    err_old = np.linalg.norm(proj_old.reshape((-1, 2)) - image_np, axis=1)
    rmse_old_all = float(np.sqrt(np.mean(err_old * err_old)))
    if float(rmse_new) >= rmse_old_all * 0.96:
        return pose
    if float(rmse_new) > 70.0:
        return pose
    # The manual references must stay well fit; tags only nudge the pose.
    n_refs = len(object_points) - accepted_tag_count
    if n_refs > 0:
        ref_err = err_new[:n_refs]
        ref_rmse_new = float(np.sqrt(np.mean(ref_err * ref_err)))
        ref_rmse_old = float(np.sqrt(np.mean(err_old[:n_refs] ** 2)))
        if ref_rmse_new > max(2.0 * ref_rmse_old, ref_rmse_old + 4.0):
            return pose

    refined = dict(pose)
    refined["rvec"] = rvec.reshape(3).tolist()
    refined["tvec"] = tvec.reshape(3).tolist()
    refined["reprojection_rmse_px"] = rmse_new
    refined["inlier_count"] = int(len(inliers)) if inliers is not None else len(object_points)
    refined["quality"] = "manual_refined"
    return refined


def _refine_pose_trusting_tags(
    pose: dict,
    manual_references: list[dict],
    detections: list[dict],
    tag_layout: dict[int, dict],
) -> dict:
    # Once tags are decoded, they are more reliable than hand clicks (which
    # can sit on an off-screen or occluded corner). Fit the pose and focal
    # length with tags weighted above refs, using a robust loss so a bad
    # click is down-weighted, then drop refs that disagree with the tags.
    from scipy.optimize import least_squares

    tag_obj: list[list[float]] = []
    tag_img: list[list[float]] = []
    tag_w: list[float] = []
    confident = 0
    for d in detections or []:
        tid = int(d.get("id", -1))
        t = tag_layout.get(tid)
        if t is None:
            continue
        src = str(d.get("source") or "")
        if (src == "pose_verified" and int(d.get("data_hamming", 99)) <= 3) or src == "manual_click":
            w = 3.0
            confident += 1
        elif src in ("pose_verified", "pose_structural"):
            w = 1.5
        elif isinstance(d.get("corners"), list):
            w = 1.0
        else:
            continue
        tag_obj.append(_to_pose_frame(pose, float(t["field_x_m"]), float(t["field_y_m"]), float(t.get("field_z_m", 0.0))))
        tag_img.append([float(d["center_x"]), float(d["center_y"])])
        tag_w.append(w)
    if confident < 3 or len(tag_obj) < 4:
        return pose

    ref_obj: list[list[float]] = []
    ref_img: list[list[float]] = []
    ref_idx: list[int] = []
    for i, r in enumerate(manual_references or []):
        if None in (r.get("image_x"), r.get("image_y"), r.get("field_x_m"), r.get("field_y_m")):
            continue
        ref_obj.append(_to_pose_frame(pose, float(r["field_x_m"]), float(r["field_y_m"]), float(r.get("field_z_m") or 0.0)))
        ref_img.append([float(r["image_x"]), float(r["image_y"])])
        ref_idx.append(i)

    tag_obj_np = np.array(tag_obj, dtype=np.float64)
    tag_img_np = np.array(tag_img, dtype=np.float64)
    tag_w_np = np.array(tag_w, dtype=np.float64)
    ref_obj_np = np.array(ref_obj, dtype=np.float64).reshape(-1, 3)
    ref_img_np = np.array(ref_img, dtype=np.float64).reshape(-1, 2)

    cam0 = np.array(pose["camera_matrix"], dtype=np.float64)
    dist = np.zeros((4, 1), dtype=np.float64)
    x0 = np.concatenate([
        np.array(pose["rvec"], dtype=np.float64).reshape(3),
        np.array(pose["tvec"], dtype=np.float64).reshape(3),
        [0.0],
    ])

    def project(x: np.ndarray, obj: np.ndarray) -> np.ndarray:
        if len(obj) == 0:
            return np.zeros((0, 2))
        cam = cam0.copy()
        cam[0, 0] *= np.exp(x[6])
        cam[1, 1] *= np.exp(x[6])
        p, _ = cv2.projectPoints(obj, x[:3], x[3:6], cam, dist)
        return p.reshape(-1, 2)

    def solve(ref_mask: np.ndarray) -> np.ndarray:
        def resid(x: np.ndarray) -> np.ndarray:
            rt = ((project(x, tag_obj_np) - tag_img_np) * tag_w_np[:, None]).ravel()
            rr = (project(x, ref_obj_np[ref_mask]) - ref_img_np[ref_mask]).ravel()
            # Weak prior keeps focal length near the manual solve.
            return np.concatenate([rt, rr, [x[6] * 40.0]])

        return least_squares(resid, x0, loss="soft_l1", f_scale=3.0, method="trf", max_nfev=400).x

    all_refs = np.ones(len(ref_obj_np), dtype=bool)
    x = solve(all_refs)
    tag_err = np.linalg.norm(project(x, tag_obj_np) - tag_img_np, axis=1)
    ref_err = np.linalg.norm(project(x, ref_obj_np) - ref_img_np, axis=1)
    tag_rmse = float(np.sqrt(np.mean(tag_err ** 2)))
    trusted = ref_err <= max(10.0, 3.0 * tag_rmse)
    if not np.all(trusted) and np.sum(trusted) >= 3:
        x = solve(trusted)
        tag_err = np.linalg.norm(project(x, tag_obj_np) - tag_img_np, axis=1)
        ref_err = np.linalg.norm(project(x, ref_obj_np) - ref_img_np, axis=1)
        tag_rmse = float(np.sqrt(np.mean(tag_err ** 2)))
        trusted = ref_err <= max(10.0, 3.0 * tag_rmse)

    old_tag_err = np.linalg.norm(project(x0, tag_obj_np) - tag_img_np, axis=1)
    old_tag_rmse = float(np.sqrt(np.mean(old_tag_err ** 2)))
    trusted_ref_rmse = float(np.sqrt(np.mean(ref_err[trusted] ** 2))) if np.any(trusted) else 0.0
    if tag_rmse > old_tag_rmse or trusted_ref_rmse > 12.0 or np.sum(trusted) < min(3, len(ref_err)):
        return pose

    cam = cam0.copy()
    cam[0, 0] *= np.exp(x[6])
    cam[1, 1] *= np.exp(x[6])
    rmat, _ = cv2.Rodrigues(x[:3])
    center = (-rmat.T @ x[3:6].reshape(3, 1)).reshape(3)
    if pose.get("ref_mirror_y"):
        center[1] = float(pose.get("ref_mirror_field_height_m", 0.0)) - center[1]
    combined = np.concatenate([tag_err, ref_err[trusted]])

    refined = dict(pose)
    refined["rvec"] = x[:3].tolist()
    refined["tvec"] = x[3:6].tolist()
    refined["camera_matrix"] = cam.tolist()
    refined["hfov_deg"] = float(np.rad2deg(2.0 * np.arctan(cam[0, 2] / cam[0, 0])))
    refined["camera_position_m"] = [float(v) for v in center]
    refined["reprojection_rmse_px"] = float(np.sqrt(np.mean(combined ** 2)))
    refined["tag_rmse_px"] = tag_rmse
    refined["inlier_count"] = int(len(combined))
    refined["quality"] = "manual_refined"
    refined["refine_mode"] = "tag_trusted"
    refined["ref_trust"] = [
        {"index": int(i), "residual_px": float(e), "trusted": bool(t)}
        for i, e, t in zip(ref_idx, ref_err, trusted)
    ]
    return refined


_UNDISTORT_CRITERIA = (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 40, 1e-9)


def undistort_pixels(pts: np.ndarray, camera_matrix: np.ndarray, dist: np.ndarray) -> np.ndarray:
    """Normalized camera coordinates (Nx2) of pixels; iterates enough for strong (fisheye-like) distortion."""
    pts = np.asarray(pts, dtype=np.float64).reshape(-1, 1, 2)
    dist = np.asarray(dist, dtype=np.float64).reshape(-1)
    if not np.any(dist):
        k = np.asarray(camera_matrix, dtype=np.float64)
        return np.column_stack([(pts[:, 0, 0] - k[0, 2]) / k[0, 0], (pts[:, 0, 1] - k[1, 2]) / k[1, 1]])
    return cv2.undistortPointsIter(pts, camera_matrix, dist, None, None, _UNDISTORT_CRITERIA).reshape(-1, 2)


def lens_max_radius(dist) -> float:
    """Largest undistorted normalized radius the radial model maps one-to-one (inf without distortion).

    Beyond it a barrel model folds back, projecting far-off points into the image.
    """
    d = np.asarray(dist if dist is not None else [], dtype=np.float64).reshape(-1)
    k1 = float(d[0]) if len(d) else 0.0
    k2 = float(d[1]) if len(d) > 1 else 0.0
    if k1 >= 0.0 and k2 >= 0.0:
        return float("inf")
    r = np.linspace(0.0, 5.0, 1000)
    bad = np.flatnonzero(1.0 + 3.0 * k1 * r**2 + 5.0 * k2 * r**4 <= 0.0)
    return float(r[bad[0]]) if len(bad) else float("inf")


def _radial_ok(k1: float, k2: float, rd_max: float) -> bool:
    """The radial model stays one-to-one (no fold-back) out to distorted normalized radius rd_max."""
    r = np.linspace(0.0, 3.0, 600)
    slope = 1.0 + 3.0 * k1 * r**2 + 5.0 * k2 * r**4
    bad = np.flatnonzero(slope <= 0.0)
    if not len(bad):
        return True
    i = int(bad[0])
    return float(r[i] * (1.0 + k1 * r[i] ** 2 + k2 * r[i] ** 4)) > rd_max


def _fit_lens_distortion(
    pose: dict,
    manual_references: list[dict],
    detections: list[dict],
    tag_layout: dict[int, dict] | None,
    straight_lines: list[list[dict]] | None,
    image_size: tuple[int, int],
) -> dict:
    """Fit radial lens distortion (k1, k2) and the principal point together with the pose.

    Wide/fisheye broadcast cameras (often shown in a split screen, so the lens
    centre is not the frame centre) bend straight field edges. The pinhole
    pose can only fit such views by spreading the error over every point.
    Uses the clicked references, matched tag centres and any clicked straight
    lines (points along one straight real-world edge, which must come out
    collinear once undistorted). Returns the pose unchanged unless the lens
    model fits clearly better.
    """
    from scipy.optimize import least_squares

    w_img, h_img = image_size
    obj: list[list[float]] = []
    img: list[list[float]] = []
    wts: list[float] = []
    n_ref = 0
    for r in manual_references or []:
        if None in (r.get("image_x"), r.get("image_y"), r.get("field_x_m"), r.get("field_y_m")):
            continue
        obj.append(_to_pose_frame(pose, float(r["field_x_m"]), float(r["field_y_m"]), float(r.get("field_z_m") or 0.0)))
        img.append([float(r["image_x"]), float(r["image_y"])])
        wts.append(1.0)
        n_ref += 1
    for d in detections or []:
        t = (tag_layout or {}).get(int(d.get("id", -1)))
        if t is None:
            continue
        src = str(d.get("source") or "")
        if src == "manual_click" or (src == "pose_verified" and int(d.get("data_hamming", 99)) <= 3):
            w = 2.0
        elif src in ("pose_verified", "pose_structural") or isinstance(d.get("corners"), list):
            w = 1.0
        else:
            continue
        obj.append(_to_pose_frame(pose, float(t["field_x_m"]), float(t["field_y_m"]), float(t.get("field_z_m", 0.0))))
        img.append([float(d["center_x"]), float(d["center_y"])])
        wts.append(w)
    lines = [
        np.array([[float(p["image_x"]), float(p["image_y"])] for p in ln], dtype=np.float64)
        for ln in straight_lines or []
        if len(ln) >= 3
    ]
    if len(obj) < 6 or len(obj) + sum(len(ln) - 2 for ln in lines) < 9:
        return pose
    obj_np = np.array(obj, dtype=np.float64)
    img_np = np.array(img, dtype=np.float64)
    w_np = np.array(wts, dtype=np.float64)

    k0 = np.array(pose["camera_matrix"], dtype=np.float64)
    f0 = float(k0[0, 0])
    aspect = float(k0[1, 1]) / f0
    d0 = np.array(pose.get("dist_coeffs") or np.zeros(4), dtype=np.float64).reshape(-1)
    x_in = np.concatenate([
        np.array(pose["rvec"], dtype=np.float64).reshape(3),
        np.array(pose["tvec"], dtype=np.float64).reshape(3),
        [0.0, d0[0] if len(d0) else 0.0, d0[1] if len(d0) > 1 else 0.0,
         (k0[0, 2] - w_img / 2) / w_img, (k0[1, 2] - h_img / 2) / h_img],
    ])
    # Every clicked/tagged pixel (the part of the frame this camera covers;
    # split screens show other cameras elsewhere) must be inside the one-to-one zone.
    data_px = np.vstack([img_np, *lines]) if lines else img_np
    line_w = [1.5 * float(np.sqrt(min(len(ln), 8) / len(ln))) for ln in lines]

    def unpack(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        f = f0 * np.exp(x[6])
        k = np.array([[f, 0.0, w_img / 2 + x[9] * w_img], [0.0, f * aspect, h_img / 2 + x[10] * h_img], [0.0, 0.0, 1.0]])
        return k, np.array([x[7], x[8], 0.0, 0.0])

    def point_err(x: np.ndarray) -> np.ndarray:
        k, dist = unpack(x)
        p, _ = cv2.projectPoints(obj_np, x[:3], x[3:6], k, dist)
        return p.reshape(-1, 2) - img_np

    def line_err(x: np.ndarray) -> list[np.ndarray]:
        k, dist = unpack(x)
        out = []
        for ln in lines:
            u = undistort_pixels(ln, k, dist)
            c = u - u.mean(axis=0)
            _, _, vt = np.linalg.svd(c, full_matrices=False)
            out.append((c @ vt[1]) * k[0, 0])
        return out

    def score(x: np.ndarray) -> tuple[float, float, float]:
        # Errors capped so one wild click can't decide the comparison; a line
        # counts like at most 8 points however densely it was sampled.
        e = np.minimum(np.linalg.norm(point_err(x), axis=1), 40.0)
        le = [np.minimum(np.abs(v), 40.0) for v in line_err(x)]
        sq = float(np.sum(e**2)) + sum(min(len(v), 8) * float(np.mean(v**2)) for v in le)
        n = len(e) + sum(min(len(v), 8) for v in le)
        return (
            float(np.sqrt(sq / max(n, 1))),
            float(np.sqrt(np.mean(e**2))),
            float(np.sqrt(np.mean(np.concatenate(le) ** 2))) if le else 0.0,
        )

    def valid(x: np.ndarray) -> bool:
        k, dist = unpack(x)
        rmat, _ = cv2.Rodrigues(x[:3])
        if np.any((rmat @ obj_np.T + x[3:6].reshape(3, 1))[2] <= 0.05):
            return False
        if (-rmat.T @ x[3:6])[2] < 0.3:
            return False
        if abs(x[7]) > 1.5 or abs(x[8]) > 1.5 or abs(x[9]) > 0.3 or abs(x[10]) > 0.35:
            return False
        rd_max = float(np.max(np.linalg.norm(undistort_pixels(data_px, k, np.zeros(4)), axis=1)))
        return _radial_ok(x[7], x[8], rd_max)

    def fit(x_start: np.ndarray, free_idx: list[int]) -> np.ndarray:
        free = np.zeros(11, dtype=bool)
        free[free_idx] = True

        def resid(z: np.ndarray) -> np.ndarray:
            x = x_start.copy()
            x[free] = z
            parts = [(point_err(x) * w_np[:, None]).ravel()]
            parts += [e * lw for e, lw in zip(line_err(x), line_w)]
            # Weak priors: no distortion, centred lens, focal near the input.
            parts.append(np.array([x[7] * 2.0, x[8] * 2.0, x[9] * 20.0, x[10] * 20.0, x[6] * 5.0]))
            return np.concatenate(parts)

        try:
            sol = least_squares(resid, x_start[free], loss="soft_l1", f_scale=3.0, method="trf", max_nfev=1500)
        except (ValueError, cv2.error):
            return x_start
        x = x_start.copy()
        x[free] = sol.x
        return x

    base = score(x_in)
    has_lens = bool(np.any(x_in[7:9]))
    pin = fit(x_in, list(range(7)))
    k1 = fit(pin, list(range(8)))
    # Split screens put the lens centre far from the frame centre: also start
    # from the centre of the clicked/tagged points.
    full = None
    cy_opts = {round(float(x_in[10]), 3), round(float((np.mean(img_np[:, 1]) - h_img / 2) / h_img), 3)}
    starts = [fit(x_in, list(range(11)))] if has_lens else []
    for seed in (pin, k1) if valid(k1) else (pin,):
        for cy0 in cy_opts:
            start = seed.copy()
            start[10] = cy0
            # Lens centre + k1 first, then everything.
            starts.append(fit(fit(start, [*range(8), 10]), list(range(11))))
    for cand in starts:
        if valid(cand) and (full is None or score(cand)[0] < score(full)[0]):
            full = cand
    ref_rmse = min(base[0], score(pin)[0])
    best = None
    for name, x in ((() if has_lens else (("k1", k1),)) + (("k1k2_center", full),)):
        if x is None or not valid(x):
            continue
        s = score(x)
        # A richer model has to earn its parameters.
        if best is None or s[0] < 0.85 * best[1][0]:
            best = (name, s, x)
    if best is None:
        return pose
    name, s, x = best
    if has_lens:
        # Re-fit of an existing lens (e.g. with newly found lines): any real
        # improvement that doesn't hurt the anchored points.
        if not (s[0] < base[0] - 0.3 and s[1] <= base[1] + 1.0):
            return pose
    elif not (s[0] <= 0.8 * ref_rmse and (ref_rmse - s[0] >= 1.5 or s[1] <= 0.6 * score(pin)[1])):
        # Either a clear overall gain, or the anchored points (clicks/tags)
        # fit far better while the lines (few/short ones) stay straight.
        return pose

    k, dist = unpack(x)
    e_pts = np.linalg.norm(point_err(x), axis=1)
    rmat, _ = cv2.Rodrigues(x[:3])
    center = (-rmat.T @ x[3:6].reshape(3, 1)).reshape(3)
    if pose.get("ref_mirror_y"):
        center[1] = float(pose.get("ref_mirror_field_height_m", 0.0)) - center[1]
    out = dict(pose)
    out.update({
        "rvec": x[:3].tolist(),
        "tvec": x[3:6].tolist(),
        "camera_matrix": k.tolist(),
        "dist_coeffs": dist.reshape(4, 1).tolist(),
        "hfov_deg": float(np.rad2deg(2.0 * np.arctan(k[0, 2] / k[0, 0]))),
        "camera_position_m": [float(v) for v in center],
        "reprojection_rmse_px": float(np.sqrt(np.mean(e_pts**2))),
        "inlier_count": int(len(e_pts)),
        "quality": "manual_refined" if str(pose.get("quality", "")).startswith("manual") else pose.get("quality"),
        "refine_mode": "lens",
        "lens": {
            "model": name,
            "k1": float(x[7]),
            "k2": float(x[8]),
            "principal_point": [float(k[0, 2]), float(k[1, 2])],
            "rmse_before_px": base[0],
            "rmse_after_px": s[0],
            "ref_rmse_px": float(np.sqrt(np.mean(e_pts[:n_ref] ** 2))) if n_ref else None,
            "tag_rmse_px": float(np.sqrt(np.mean(e_pts[n_ref:] ** 2))) if len(e_pts) > n_ref else None,
            "line_rmse_px": s[2] if lines else None,
            "lines": len(lines),
        },
    })
    if len(e_pts) > n_ref:
        out["tag_rmse_px"] = out["lens"]["tag_rmse_px"]
    return out


def _tag_only_lens_pose(
    detections: list[dict],
    tag_layout: dict[int, dict],
    camera_matrix: np.ndarray,
    image_size: tuple[int, int],
) -> dict | None:
    """Rough pinhole pose from tag centres alone, as a seed for the lens fit.

    Only used when nothing else produced a pose; the caller drops it unless
    the lens fit then explains the tags well.
    """
    obj, img, ids = [], [], []
    for d in detections:
        t = tag_layout.get(int(d.get("id", -1)))
        if t is None:
            continue
        obj.append([float(t["field_x_m"]), float(t["field_y_m"]), float(t.get("field_z_m", 0.0))])
        img.append([float(d["center_x"]), float(d["center_y"])])
        ids.append(int(d["id"]))
    n = len(obj)
    if n < 6:
        return None
    obj_np = np.array(obj, dtype=np.float64)
    img_np = np.array(img, dtype=np.float64)
    w_img, _h_img = image_size
    # A flipped layout is a mirror image of the real field: solve it in a
    # mirrored frame (same convention as the manual-reference pose).
    mirror_h = max(float(t["field_y_m"]) for t in tag_layout.values())
    frames = {False: obj_np, True: obj_np * np.array([1.0, -1.0, 1.0]) + np.array([0.0, mirror_h, 0.0])}
    # Tags from another split-screen pane (or misreads) can't fit one camera:
    # solve from 6-tag subsets and keep the one most tags agree with.
    gate = 0.05 * w_img
    subsets = list(itertools.combinations(range(n), 6))
    if len(subsets) > 300:
        rng = np.random.default_rng(0)
        subsets = [subsets[i] for i in rng.choice(len(subsets), 300, replace=False)]
    best = None
    # A few focal guesses: wide lenses sit far from the default.
    for (mirror, o_np), hfov in itertools.product(frames.items(), (55.0, 70.0, 85.0)):
        k = np.array(camera_matrix, dtype=np.float64).copy()
        k[0, 0] = k[1, 1] = (w_img / 2.0) / np.tan(np.deg2rad(hfov / 2.0))
        for sub in subsets:
            idx = list(sub)
            try:
                ok, rvec, tvec = cv2.solvePnP(o_np[idx], img_np[idx], k, np.zeros(4), flags=cv2.SOLVEPNP_SQPNP)
            except cv2.error:
                continue
            if not ok:
                continue
            rmat, _ = cv2.Rodrigues(rvec)
            if (-rmat.T @ tvec).reshape(3)[2] < 0.3 or np.any((rmat @ o_np.T + tvec.reshape(3, 1))[2] <= 0):
                continue
            proj, _ = cv2.projectPoints(o_np, rvec, tvec, k, np.zeros(4))
            err = np.linalg.norm(proj.reshape(-1, 2) - img_np, axis=1)
            inl = np.flatnonzero(err < gate)
            if len(inl) < 6:
                continue
            key = (len(inl), -float(np.sqrt(np.mean(err[inl] ** 2))))
            if best is None or key > best[0]:
                best = (key, k, rvec, tvec, inl, mirror)
    if best is None:
        return None
    _key, k, rvec, tvec, inl, mirror = best
    o_np = frames[mirror]
    rvec, tvec = cv2.solvePnPRefineLM(o_np[inl], img_np[inl], k, np.zeros(4), rvec, tvec)
    proj, _ = cv2.projectPoints(o_np[inl], rvec, tvec, k, np.zeros(4))
    rmse = float(np.sqrt(np.mean(np.sum((proj.reshape(-1, 2) - img_np[inl]) ** 2, axis=1))))
    if rmse > gate:
        return None
    rmat, _ = cv2.Rodrigues(rvec)
    center = (-rmat.T @ tvec).reshape(3)
    if mirror:
        center[1] = mirror_h - center[1]
    return {
        "tag_ids": [ids[i] for i in inl],
        "ref_mirror_y": bool(mirror),
        "ref_mirror_field_height_m": mirror_h,
        "camera_position_m": [float(v) for v in center],
        "model": "solvepnp_3d",
        "camera_matrix": k.tolist(),
        "dist_coeffs": np.zeros((4, 1)).tolist(),
        "rvec": rvec.reshape(3).tolist(),
        "tvec": tvec.reshape(3).tolist(),
        "reprojection_rmse_px": rmse,
        "inlier_count": len(inl),
        "quality": "tags_lens",
    }


def _tags_lens_leave_one_out(
    frame: np.ndarray,
    detections: list[dict],
    tag_layout: dict[int, dict],
    camera_matrix: np.ndarray,
    image_size: tuple[int, int],
    pose: dict,
    manual_references: list[dict],
) -> dict:
    """Return the tag-only pose, leaving out one tag if the full set can't share a lens.

    The first estimate has no lens, so a fisheye bends edge tags past the
    outlier gate check; a single mislabelled click then still gets in and
    makes every lens fit fail. If so, try each tag left out and keep the best.
    """
    lines = _lines_near_anchors(detect_straight_lines(frame, pose), manual_references, detections, image_size)

    def lens_rmse(p: dict, dets: list[dict]) -> float | None:
        fit = _fit_lens_distortion(p, manual_references, dets, tag_layout, lines, image_size)
        if fit is p or not fit.get("lens"):
            return None
        return float(fit.get("tag_rmse_px") or 99.0)

    ids = list(pose["tag_ids"])
    used = [d for d in detections if int(d.get("id", -1)) in set(ids)]
    r = lens_rmse(pose, used)
    if (r is not None and r <= 8.0) or len(ids) < 7:
        return pose
    best: tuple[float, dict] | None = None
    for drop in ids:
        rest = [d for d in used if int(d.get("id", -1)) != drop]
        p = _tag_only_lens_pose(rest, tag_layout, camera_matrix, image_size)
        if p is None:
            continue
        r = lens_rmse(p, [d for d in rest if int(d.get("id", -1)) in set(p["tag_ids"])])
        if r is not None and r <= 8.0 and (best is None or r < best[0]):
            best = (r, p)
    return pose if best is None else best[1]


def _lines_near_anchors(
    lines: list[list[dict]],
    manual_references: list[dict],
    detections: list[dict],
    image_size: tuple[int, int],
) -> list[list[dict]]:
    """Keep detected lines in the part of the frame the anchors cover (skips other split-screen panes)."""
    pts = [[float(r["image_x"]), float(r["image_y"])] for r in manual_references or [] if r.get("image_x") is not None]
    pts += [[float(d["center_x"]), float(d["center_y"])] for d in detections or []]
    if len(pts) < 3 or not lines:
        return []
    p = np.array(pts)
    w, h = image_size
    x0, y0 = p.min(axis=0) - [0.15 * w, 0.15 * h]
    x1, y1 = p.max(axis=0) + [0.15 * w, 0.15 * h]
    out = []
    for ln in lines:
        q = np.array([[a["image_x"], a["image_y"]] for a in ln])
        inside = (q[:, 0] >= x0) & (q[:, 0] <= x1) & (q[:, 1] >= y0) & (q[:, 1] <= y1)
        if inside.mean() >= 0.8:
            out.append([a for a, keep in zip(ln, inside) if keep])
    return out


def detect_straight_lines(frame: np.ndarray, pose: dict, max_lines: int = 10) -> list[list[dict]]:
    """Find long bright straight edges (tape lines, rails, wall tops, truss) in the frame.

    They are searched for in a lens-corrected copy of the frame (so a bent
    fisheye edge can still be found when the current lens model is roughly
    right), then snapped back onto the real ridge in the original pixels.
    Returns point lists in the same form as clicked straight lines.
    """
    h, w = frame.shape[:2]
    k = np.array(pose["camera_matrix"], dtype=np.float64)
    dist = np.array(pose.get("dist_coeffs") or np.zeros(4), dtype=np.float64).reshape(-1)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) if frame.ndim == 3 else frame
    # Thin bright features stand out of a white top-hat.
    tophat = cv2.morphologyEx(gray, cv2.MORPH_TOPHAT, cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15)))
    ridge = ((tophat > 35).astype(np.uint8)) * 255

    # Undistorted view with a smaller focal length so the stretched edges stay in frame.
    k_view = k.copy()
    k_view[0, 0] *= 0.7
    k_view[1, 1] *= 0.7
    if np.any(dist):
        m1, m2 = cv2.initUndistortRectifyMap(k, dist, None, k_view, (w, h), cv2.CV_32FC1)
        view = cv2.remap(ridge, m1, m2, cv2.INTER_NEAREST, borderValue=0)
        # Outside the lens model's one-to-one zone the map wraps around: blank it.
        yy, xx = np.mgrid[0:h, 0:w]
        rn = np.hypot((xx - k_view[0, 2]) / k_view[0, 0], (yy - k_view[1, 2]) / k_view[1, 1])
        view[rn > 0.95 * lens_max_radius(dist)] = 0
    else:
        k_view = k
        view = ridge
    segs = cv2.HoughLinesP(view, 1, np.pi / 360, threshold=90, minLineLength=int(0.12 * w), maxLineGap=14)
    if segs is None:
        return []
    segs = sorted((s.reshape(4).astype(np.float64) for s in segs), key=lambda s: -np.hypot(s[2] - s[0], s[3] - s[1]))

    kept: list[np.ndarray] = []
    for s in segs:
        d = np.array([s[2] - s[0], s[3] - s[1]])
        d /= max(np.linalg.norm(d), 1e-9)
        n = np.array([-d[1], d[0]])
        dup = False
        for o in kept:
            od = np.array([o[2] - o[0], o[3] - o[1]])
            od /= max(np.linalg.norm(od), 1e-9)
            if abs(float(d @ od)) > np.cos(np.deg2rad(2.0)) and abs(float((o[:2] - s[:2]) @ n)) < 8.0:
                dup = True
                break
        if not dup:
            kept.append(s)
        if len(kept) >= max_lines * 2:
            break

    out: list[list[dict]] = []
    for s in kept:
        length = float(np.hypot(s[2] - s[0], s[3] - s[1]))
        t = np.linspace(0.0, 1.0, int(np.clip(length / 30.0, 6, 30)))
        u = s[0] + (s[2] - s[0]) * t
        v = s[1] + (s[3] - s[1]) * t
        rays = np.column_stack([(u - k_view[0, 2]) / k_view[0, 0], (v - k_view[1, 2]) / k_view[1, 1], np.ones_like(u)])
        px, _ = cv2.projectPoints(rays, np.zeros(3), np.zeros(3), k, dist)
        px = px.reshape(-1, 2)
        # Snap each sample onto the ridge peak along the local normal.
        snapped = []
        for i in range(len(px)):
            a, b = px[max(0, i - 1)], px[min(len(px) - 1, i + 1)]
            tan = b - a
            tan /= max(np.linalg.norm(tan), 1e-9)
            nrm = np.array([-tan[1], tan[0]])
            offs = np.arange(-6, 7)
            cand = px[i] + offs[:, None] * nrm
            xi = np.round(cand[:, 0]).astype(int)
            yi = np.round(cand[:, 1]).astype(int)
            ok = (xi >= 0) & (xi < w) & (yi >= 0) & (yi < h)
            if not np.any(ok):
                continue
            vals = np.zeros(len(offs))
            vals[ok] = tophat[yi[ok], xi[ok]]
            j = int(np.argmax(vals))
            if vals[j] > 35:
                # Parabolic peak for sub-pixel position.
                sub = 0.0
                if 0 < j < len(offs) - 1:
                    den = vals[j - 1] - 2.0 * vals[j] + vals[j + 1]
                    if den < 0:
                        sub = float(np.clip(0.5 * (vals[j - 1] - vals[j + 1]) / den, -0.5, 0.5))
                q = px[i] + (offs[j] + sub) * nrm
                snapped.append({"image_x": round(float(q[0]), 2), "image_y": round(float(q[1]), 2)})
        if len(snapped) < 6:
            continue
        p = np.array([[q["image_x"], q["image_y"]] for q in snapped])
        if np.ptp(p[:, 0]) + np.ptp(p[:, 1]) < 0.1 * w:
            continue
        # Perfectly straight axis-aligned edges in raw pixels are overlay
        # graphics / split-screen borders, not part of the scene.
        c = p - p.mean(axis=0)
        _, sv, vt = np.linalg.svd(c, full_matrices=False)
        raw_rms = float(sv[1] / np.sqrt(len(p)))
        ang = np.rad2deg(np.arctan2(vt[0, 1], vt[0, 0])) % 90.0
        if raw_rms < 0.8 and min(ang, 90.0 - ang) < 1.0:
            continue
        # The snapped ridge must still be (nearly) straight under the current
        # lens and smooth: textured beams/crowd edges wiggle point to point.
        un = undistort_pixels(p, k, dist) * k[0, 0]
        cu = un - un.mean(axis=0)
        _, _, vt_u = np.linalg.svd(cu, full_matrices=False)
        off = cu @ vt_u[1]
        if float(np.sqrt(np.mean(off**2))) > 4.0 or float(np.median(np.abs(np.diff(off, 2)))) > 3.0:
            continue
        out.append(snapped)
        if len(out) >= max_lines:
            break
    return out


def project_field_outline(pose: dict, length_m: float, width_m: float, samples: int = 48) -> list[list[list[float]]]:
    """The four floor edges of the field as image polylines (curved when the lens distorts)."""
    k = np.array(pose["camera_matrix"], dtype=np.float64)
    dist = np.array(pose.get("dist_coeffs") or np.zeros(4), dtype=np.float64).reshape(-1)
    rvec = np.array(pose["rvec"], dtype=np.float64).reshape(3, 1)
    tvec = np.array(pose["tvec"], dtype=np.float64).reshape(3, 1)
    rmat, _ = cv2.Rodrigues(rvec)
    r_lens = lens_max_radius(dist)
    s = np.linspace(0.0, 1.0, samples)
    corners = [(0.0, 0.0), (length_m, 0.0), (length_m, width_m), (0.0, width_m), (0.0, 0.0)]
    out = []
    for (x0, y0), (x1, y1) in zip(corners, corners[1:]):
        pts = np.array([_to_pose_frame(pose, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, 0.0) for t in s])
        cam = rmat @ pts.T + tvec
        front = (cam[2] > 0.05) & (np.hypot(cam[0], cam[1]) / np.maximum(cam[2], 1e-9) <= r_lens)
        if not np.any(front):
            continue
        img, _ = cv2.projectPoints(pts[front], rvec, tvec, k, dist)
        out.append([[round(float(u), 1), round(float(v), 1)] for u, v in img.reshape(-1, 2)])
    return out


def _seeded_white_box_tag_detection(
    frame: np.ndarray,
    tag_layout: dict[int, dict],
    seed_homography_image_to_field_cm: np.ndarray,
    candidate_ids: set[int] | None = None,
    seed_points_override: dict[int, tuple[float, float]] | None = None,
    window_radius_px: int = 72,
) -> list[dict]:
    def is_tag_like_patch(patch_gray: np.ndarray) -> bool:
        h, w = patch_gray.shape[:2]
        if h < 10 or w < 10:
            return False

        # A valid AprilTag center should not be plain white; it must contain
        # both dark and bright modules.
        center_y1 = int(h * 0.22)
        center_y2 = int(h * 0.78)
        center_x1 = int(w * 0.22)
        center_x2 = int(w * 0.78)
        center = patch_gray[center_y1:center_y2, center_x1:center_x2]
        if center.size == 0:
            return False

        cmean = float(np.mean(center))
        cstd = float(np.std(center))
        dark_ratio = float(np.mean(center < 95))
        bright_ratio = float(np.mean(center > 170))

        # Expect mixed black/white content, not a flat solid block.
        if cstd < 24.0:
            return False
        if dark_ratio < 0.10 or bright_ratio < 0.10:
            return False

        # Border ring should be brighter than center on average.
        bw = max(1, int(min(h, w) * 0.16))
        top = patch_gray[:bw, :]
        bottom = patch_gray[-bw:, :]
        left = patch_gray[:, :bw]
        right = patch_gray[:, -bw:]
        border = np.concatenate([top.ravel(), bottom.ravel(), left.ravel(), right.ravel()])
        bmean = float(np.mean(border)) if border.size else cmean

        if (bmean - cmean) < 18.0:
            return False

        return True

    try:
        inv = np.linalg.inv(seed_homography_image_to_field_cm)
    except np.linalg.LinAlgError:
        return []

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    h_frame, w_frame = gray.shape[:2]
    out: list[dict] = []

    for tag_id, t in tag_layout.items():
        if candidate_ids is not None and int(tag_id) not in candidate_ids:
            continue
        if seed_points_override is not None and int(tag_id) in seed_points_override:
            seed = seed_points_override[int(tag_id)]
        else:
            fx_m = float(t.get("field_x_m", 0.0))
            fy_m = float(t.get("field_y_m", 0.0))
            seed = _apply_homography(inv, fx_m * 100.0, fy_m * 100.0)
            if seed is None:
                continue

        sx, sy = seed
        x1 = max(0, int(sx - window_radius_px))
        x2 = min(w_frame, int(sx + window_radius_px))
        y1 = max(0, int(sy - window_radius_px))
        y2 = min(h_frame, int(sy + window_radius_px))
        if x2 <= x1 or y2 <= y1:
            continue

        best_center = None
        best_dist = float("inf")
        roi = gray[y1:y2, x1:x2]
        for thresh in (210, 195, 180):
            # Keep only bright blobs, then validate with tag-like texture checks.
            bw = cv2.threshold(roi, thresh, 255, cv2.THRESH_BINARY)[1]
            contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for c in contours:
                area = cv2.contourArea(c)
                if area < 28 or area > 7000:
                    continue

                bx, by, bwid, bhei = cv2.boundingRect(c)
                if bhei <= 0:
                    continue
                aspect = bwid / float(bhei)
                if aspect < 0.50 or aspect > 2.0:
                    continue

                # Reject plain white objects; require AprilTag-like inner structure.
                px1 = max(0, bx)
                py1 = max(0, by)
                px2 = min(roi.shape[1], bx + bwid)
                py2 = min(roi.shape[0], by + bhei)
                patch = roi[py1:py2, px1:px2]
                if patch.size == 0:
                    continue
                if not is_tag_like_patch(patch):
                    continue

                cx = x1 + bx + (bwid / 2.0)
                cy = y1 + by + (bhei / 2.0)
                dist = ((cx - sx) ** 2 + (cy - sy) ** 2) ** 0.5
                if dist < best_dist and dist <= (window_radius_px * 0.72):
                    best_dist = dist
                    best_center = (float(cx), float(cy))

        if best_center is None:
            continue

        cx, cy = best_center
        out.append(
            {
                "id": int(tag_id),
                "center_x": cx,
                "center_y": cy,
                "corners": [],
                "seed_x": float(sx),
                "seed_y": float(sy),
                "seed_distance_px": float(best_dist),
                "fallback": "white_box_seeded",
            }
        )

    # Prevent one bright object from being assigned to many tag IDs.
    deduped: list[dict] = []
    for cand in sorted(out, key=lambda d: float(d.get("seed_distance_px", 1e9))):
        cx = float(cand.get("center_x", 0.0))
        cy = float(cand.get("center_y", 0.0))
        too_close = False
        for kept in deduped:
            kx = float(kept.get("center_x", 0.0))
            ky = float(kept.get("center_y", 0.0))
            if ((cx - kx) ** 2 + (cy - ky) ** 2) ** 0.5 < 24.0:
                too_close = True
                break
        if not too_close:
            deduped.append(cand)

    return deduped


def _seeded_roi_apriltag_decode(
    frame: np.ndarray,
    tag_layout: dict[int, dict],
    seed_homography_image_to_field_cm: np.ndarray,
    candidate_ids: set[int] | None = None,
    seed_points_override: dict[int, tuple[float, float]] | None = None,
    window_radius_px: int = 108,
) -> list[dict]:
    try:
        inv = np.linalg.inv(seed_homography_image_to_field_cm)
    except np.linalg.LinAlgError:
        return []

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    h_frame, w_frame = gray.shape[:2]

    detector = _build_aruco_detector()
    out: list[dict] = []

    for tag_id, t in tag_layout.items():
        if candidate_ids is not None and int(tag_id) not in candidate_ids:
            continue
        if seed_points_override is not None and int(tag_id) in seed_points_override:
            seed = seed_points_override[int(tag_id)]
        else:
            fx_m = float(t.get("field_x_m", 0.0))
            fy_m = float(t.get("field_y_m", 0.0))
            seed = _apply_homography(inv, fx_m * 100.0, fy_m * 100.0)
            if seed is None:
                continue

        sx, sy = seed
        x1 = max(0, int(sx - window_radius_px))
        x2 = min(w_frame, int(sx + window_radius_px))
        y1 = max(0, int(sy - window_radius_px))
        y2 = min(h_frame, int(sy + window_radius_px))
        if x2 <= x1 or y2 <= y1:
            continue

        roi = gray[y1:y2, x1:x2]
        best = None

        for scale in (1.0, 1.8, 2.2):
            scaled = (
                roi
                if scale == 1.0
                else cv2.resize(roi, dsize=None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
            )
            sh, sw = scaled.shape[:2]
            cxy = (sw / 2.0, sh / 2.0)

            # Tags may be strongly rotated relative to camera; scan multiple
            # ROI rotations and un-rotate detections back to original ROI space.
            for angle_deg in (0.0, -30.0, -20.0, -10.0, 10.0, 20.0, 30.0):
                if angle_deg == 0.0:
                    rotated = scaled
                    inv_rot = None
                else:
                    rot = cv2.getRotationMatrix2D(cxy, angle_deg, 1.0)
                    rotated = cv2.warpAffine(
                        scaled,
                        rot,
                        (sw, sh),
                        flags=cv2.INTER_CUBIC,
                        borderMode=cv2.BORDER_REPLICATE,
                    )
                    inv_rot = cv2.invertAffineTransform(rot)

                for prep in _preprocess_detection_images(rotated):
                    corners, ids, _ = detector.detectMarkers(prep)
                    if ids is None:
                        continue

                    for marker_corners, marker_id in zip(corners, ids.flatten()):
                        if int(marker_id) != int(tag_id):
                            continue

                        pts_rot = marker_corners[0].astype(np.float32)
                        if inv_rot is not None:
                            pts_scaled = cv2.transform(pts_rot.reshape((1, -1, 2)), inv_rot).reshape((-1, 2))
                        else:
                            pts_scaled = pts_rot

                        pts = pts_scaled / scale
                        area = _polygon_area(pts)
                        if area < 14.0:
                            continue

                        cx = float(np.mean(pts[:, 0])) + float(x1)
                        cy = float(np.mean(pts[:, 1])) + float(y1)
                        dist = ((cx - sx) ** 2 + (cy - sy) ** 2) ** 0.5
                        max_seed_dist = min(58.0, window_radius_px * 0.55)
                        if dist > max_seed_dist:
                            continue

                        cand = {
                            "id": int(tag_id),
                            "center_x": cx,
                            "center_y": cy,
                            "corners": (pts + np.array([x1, y1], dtype=np.float32)).tolist(),
                            "area_px2": area,
                            "seed_x": float(sx),
                            "seed_y": float(sy),
                            "seed_distance_px": float(dist),
                            "seed_angle_deg": float(angle_deg),
                            "fallback": "seeded_roi_decode",
                        }
                        if best is None or float(cand["area_px2"]) > float(best.get("area_px2", 0.0)):
                            best = cand

        if best is not None:
            out.append(best)

    # If multiple IDs collapse onto the same small image region, keep only the
    # strongest/local-best candidate to avoid duplicate false IDs.
    deduped: list[dict] = []
    for cand in sorted(out, key=lambda d: (float(d.get("seed_distance_px", 1e9)), -float(d.get("area_px2", 0.0)))):
        cx = float(cand.get("center_x", 0.0))
        cy = float(cand.get("center_y", 0.0))
        too_close = False
        for kept in deduped:
            kx = float(kept.get("center_x", 0.0))
            ky = float(kept.get("center_y", 0.0))
            if ((cx - kx) ** 2 + (cy - ky) ** 2) ** 0.5 < 22.0:
                too_close = True
                break
        if not too_close:
            deduped.append(cand)

    return deduped


def _select_seed_candidate_ids(
    tag_layout: dict[int, dict],
    detections: list[dict],
    max_candidates: int = 14,
    neighbor_radius_m: float = 4.0,
) -> set[int] | None:
    if not tag_layout:
        return None

    present_ids = [int(d.get("id")) for d in detections if int(d.get("id")) in tag_layout]
    if not present_ids:
        return None

    # Sparse detections benefit from a tighter local-neighborhood prior.
    if len(present_ids) <= 2:
        max_candidates = min(max_candidates, 10)
        neighbor_radius_m = min(neighbor_radius_m, 2.2)

    # Rank tags by nearest field-distance to any currently detected tag ID.
    ranked: list[tuple[int, float]] = []
    anchor_z_vals: list[float] = []
    for pid in present_ids:
        p = tag_layout.get(pid)
        if p is not None:
            anchor_z_vals.append(float(p.get("field_z_m", 0.0)))
    anchor_z = float(np.median(np.array(anchor_z_vals, dtype=np.float64))) if anchor_z_vals else 0.0

    for tid, t in tag_layout.items():
        tx = float(t.get("field_x_m", 0.0))
        ty = float(t.get("field_y_m", 0.0))
        tz = float(t.get("field_z_m", 0.0))
        best = float("inf")
        for pid in present_ids:
            p = tag_layout.get(pid)
            if p is None:
                continue
            px = float(p.get("field_x_m", 0.0))
            py = float(p.get("field_y_m", 0.0))
            dist = ((tx - px) ** 2 + (ty - py) ** 2) ** 0.5
            if dist < best:
                best = dist
        z_penalty = abs(tz - anchor_z)
        score = float(best + (z_penalty * 1.2))
        ranked.append((int(tid), score))

    ranked.sort(key=lambda x: x[1])
    out: list[int] = []
    for tid, dist in ranked:
        if dist <= neighbor_radius_m or tid in present_ids:
            out.append(tid)
        if len(out) >= max_candidates:
            break

    if not out:
        out = [tid for tid, _ in ranked[:max_candidates]]

    return set(out)


def _build_seed_points_from_homography(
    tag_layout: dict[int, dict],
    seed_homography_image_to_field_cm: np.ndarray,
) -> dict[int, tuple[float, float]]:
    out: dict[int, tuple[float, float]] = {}
    try:
        inv = np.linalg.inv(seed_homography_image_to_field_cm)
    except np.linalg.LinAlgError:
        return out

    for tag_id, t in tag_layout.items():
        fx_m = float(t.get("field_x_m", 0.0))
        fy_m = float(t.get("field_y_m", 0.0))
        seed = _apply_homography(inv, fx_m * 100.0, fy_m * 100.0)
        if seed is None:
            continue
        out[int(tag_id)] = (float(seed[0]), float(seed[1]))
    return out


def _select_visible_seed_candidate_ids(
    seed_points: dict[int, tuple[float, float]],
    frame_width: int,
    frame_height: int,
    max_candidates: int = 16,
    margin_px: float = 96.0,
) -> set[int] | None:
    if not seed_points:
        return None

    # Keep tags whose predicted centers are realistically inside or near frame.
    visible: list[tuple[int, float]] = []
    cx = frame_width / 2.0
    cy = frame_height / 2.0
    for tid, (x, y) in seed_points.items():
        if x < -margin_px or x > (frame_width + margin_px):
            continue
        if y < -margin_px or y > (frame_height + margin_px):
            continue
        # Prioritize tags nearer image center for robustness.
        score = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
        visible.append((int(tid), float(score)))

    if not visible:
        return None

    visible.sort(key=lambda t: t[1])
    return set(tid for tid, _ in visible[:max_candidates])


def _build_similarity_seed_points_from_two_tags(
    detections: list[dict],
    tag_layout: dict[int, dict],
) -> dict[int, tuple[float, float]] | None:
    matched: list[tuple[int, tuple[float, float], tuple[float, float]]] = []
    for d in detections:
        try:
            tid = int(d.get("id"))
            ix = float(d.get("center_x"))
            iy = float(d.get("center_y"))
        except (TypeError, ValueError):
            continue
        t = tag_layout.get(tid)
        if t is None:
            continue
        fx = float(t.get("field_x_m", 0.0))
        fy = float(t.get("field_y_m", 0.0))
        matched.append((tid, (fx, fy), (ix, iy)))

    if len(matched) < 2:
        return None

    # Use farthest pair for best numerical stability.
    best = None
    best_dist = -1.0
    for i in range(len(matched)):
        for j in range(i + 1, len(matched)):
            (_, (ax, ay), (aix, aiy)) = matched[i]
            (_, (bx, by), (bix, biy)) = matched[j]
            fdist = ((bx - ax) ** 2 + (by - ay) ** 2) ** 0.5
            if fdist > best_dist:
                best_dist = fdist
                best = ((ax, ay), (bx, by), (aix, aiy), (bix, biy))

    if best is None or best_dist < 1e-4:
        return None

    (ax, ay), (bx, by), (aix, aiy), (bix, biy) = best
    fx = bx - ax
    fy = by - ay
    ix = bix - aix
    iy = biy - aiy

    fmag = (fx * fx + fy * fy) ** 0.5
    imag = (ix * ix + iy * iy) ** 0.5
    if fmag < 1e-6 or imag < 1e-6:
        return None

    scale = imag / fmag
    ux = fx / fmag
    uy = fy / fmag
    vx = -uy
    vy = ux

    Ux = ix / fmag
    Uy = iy / fmag
    Vx = -Uy
    Vy = Ux

    out: dict[int, tuple[float, float]] = {}
    for tid, t in tag_layout.items():
        px = float(t.get("field_x_m", 0.0)) - ax
        py = float(t.get("field_y_m", 0.0)) - ay
        du = (px * ux + py * uy)
        dv = (px * vx + py * vy)
        sx = aix + (du * Ux) + (dv * Vx)
        sy = aiy + (du * Uy) + (dv * Vy)
        out[int(tid)] = (float(sx), float(sy))

    return out


def _build_shifted_projected_seed_points(
    projected_layout_points: list[dict],
    detections: list[dict],
) -> dict[int, tuple[float, float]] | None:
    if not projected_layout_points or not detections:
        return None

    projected_by_id = {int(p["id"]): p for p in projected_layout_points}
    residuals_x: list[float] = []
    residuals_y: list[float] = []
    for d in detections:
        try:
            tid = int(d["id"])
        except (TypeError, ValueError, KeyError):
            continue
        p = projected_by_id.get(tid)
        if p is None:
            continue
        residuals_x.append(float(d.get("center_x", 0.0)) - float(p.get("center_x", 0.0)))
        residuals_y.append(float(d.get("center_y", 0.0)) - float(p.get("center_y", 0.0)))

    if not residuals_x:
        return None

    dx = float(np.median(np.array(residuals_x, dtype=np.float64)))
    dy = float(np.median(np.array(residuals_y, dtype=np.float64)))
    out: dict[int, tuple[float, float]] = {}
    for p in projected_layout_points:
        tid = int(p["id"])
        out[tid] = (
            float(p.get("center_x", 0.0)) + dx,
            float(p.get("center_y", 0.0)) + dy,
        )
    return out


def _is_strong_detection(d: dict) -> bool:
    corners = d.get("corners")
    area = float(d.get("area_px2", 0.0) or 0.0)
    source = str(d.get("source") or "")
    # Manual clicks are trusted anchors by user intent; pose-verified tags
    # were already checked against the 3D projection and tag pattern.
    if source in ("manual_click", "pose_verified", "pose_structural"):
        return True
    if isinstance(corners, list) and len(corners) >= 4 and area >= 80.0:
        return True
    return False


def _strong_detections(detections: list[dict]) -> list[dict]:
    return [d for d in detections if _is_strong_detection(d)]


def _scope_projected_points_for_weak_pose(
    projected_layout_points: list[dict],
    detections: list[dict],
    tag_layout: dict[int, dict],
    pose: dict | None,
) -> tuple[list[dict], dict | None]:
    if not projected_layout_points or not detections or not tag_layout or not pose:
        return projected_layout_points, None

    rmse = pose.get("reprojection_rmse_px")
    if rmse is None:
        return projected_layout_points, None

    projected_by_id: dict[int, dict] = {int(p.get("id", -1)): p for p in projected_layout_points}
    anchor_ids: list[int] = []
    for d in detections:
        tid = int(d.get("id", -1))
        if tid not in tag_layout:
            continue
        p = projected_by_id.get(tid)
        if p is None:
            continue
        dx = float(d.get("center_x", 0.0)) - float(p.get("center_x", 0.0))
        dy = float(d.get("center_y", 0.0)) - float(p.get("center_y", 0.0))
        # Exclude anchors that disagree strongly with current projection.
        if ((dx * dx) + (dy * dy)) ** 0.5 > 95.0:
            continue
        anchor_ids.append(tid)
    anchor_ids = sorted(set(anchor_ids))
    if not anchor_ids:
        if float(rmse) > 85.0:
            return [], {
                "mode": "anchor_only",
                "applied": True,
                "rmse_px": float(rmse),
                "anchor_count": 0,
                "anchor_ids": [],
                "kept_count": 0,
                "reason": "no_consistent_anchors",
            }
        return projected_layout_points, None

    # Keep full-field projection only when we have enough anchors and reasonable fit.
    if len(anchor_ids) >= 3 and float(rmse) <= 70.0:
        return projected_layout_points, {"mode": "full", "applied": False}

    # Very weak poses should only show the anchored IDs themselves.
    if float(rmse) > 85.0:
        scoped_anchor_only = [p for p in projected_layout_points if int(p.get("id", -1)) in set(anchor_ids)]
        return scoped_anchor_only, {
            "mode": "anchor_only",
            "applied": True,
            "rmse_px": float(rmse),
            "anchor_count": len(anchor_ids),
            "anchor_ids": anchor_ids,
            "kept_count": len(scoped_anchor_only),
            "radius_m": 0.0,
        }

    # Weak pose: only show tags near anchored IDs to avoid global warped overlays.
    radius_m = 2.2
    keep_ids: set[int] = set(anchor_ids)
    for tid, t in tag_layout.items():
        tx = float(t.get("field_x_m", 0.0))
        ty = float(t.get("field_y_m", 0.0))
        for aid in anchor_ids:
            a = tag_layout.get(aid)
            if a is None:
                continue
            ax = float(a.get("field_x_m", 0.0))
            ay = float(a.get("field_y_m", 0.0))
            if ((tx - ax) ** 2 + (ty - ay) ** 2) ** 0.5 <= radius_m:
                keep_ids.add(int(tid))
                break

    scoped = [p for p in projected_layout_points if int(p.get("id", -1)) in keep_ids]
    diag = {
        "mode": "local_scope",
        "applied": True,
        "rmse_px": float(rmse),
        "anchor_count": len(anchor_ids),
        "anchor_ids": anchor_ids,
        "kept_count": len(scoped),
        "radius_m": radius_m,
    }
    return scoped, diag


def _merge_detections_by_id(primary: list[dict], supplemental: list[dict]) -> list[dict]:
    merged: dict[int, dict] = {}
    for d in primary:
        merged[int(d["id"])] = d
    for d in supplemental:
        tid = int(d["id"])
        if tid not in merged:
            merged[tid] = d
    return sorted(merged.values(), key=lambda d: int(d["id"]))


def _merge_with_manual_tag_observations(
    detections: list[dict],
    manual_tag_observations: list[dict] | None,
) -> list[dict]:
    if not manual_tag_observations:
        return detections

    merged: dict[int, dict] = {int(d["id"]): d for d in detections}
    for obs in manual_tag_observations:
        try:
            tag_id = int(obs["id"])
            image_x = float(obs["image_x"])
            image_y = float(obs["image_y"])
        except (KeyError, TypeError, ValueError):
            continue

        merged[tag_id] = {
            "id": tag_id,
            "center_x": image_x,
            "center_y": image_y,
            "corners": [],
            "area_px2": 999999.0,
            "source": "manual_click",
        }

    return sorted(merged.values(), key=lambda d: int(d["id"]))


def estimate_camera_pose_from_apriltags(
    video_path: str,
    season: int,
    frame_sec: float = 0.0,
    tag_layout: dict[int, dict] | None = None,
    seed_homography_image_to_field_cm: np.ndarray | None = None,
    manual_references: list[dict] | None = None,
    manual_tag_observations: list[dict] | None = None,
    straight_lines: list[list[dict]] | None = None,
) -> dict:
    frame_samples, fps = _read_frames_near_time(
        video_path=video_path,
        center_sec=frame_sec,
        offsets_sec=[-0.45, -0.30, -0.15, 0.0, 0.15, 0.30, 0.45],
    )
    if not frame_samples:
        return {
            "season": season,
            "method": "apriltag_failed",
            "reason": "Could not read frame",
            "frame_sec": frame_sec,
            "fps": fps,
            "detected_tags": [],
            "confidence": 0.0,
        }

    frame = frame_samples[len(frame_samples) // 2][1]

    if not hasattr(cv2, "aruco"):
        return {
            "season": season,
            "method": "apriltag_unavailable",
            "reason": "OpenCV build does not include aruco module",
            "frame_sec": frame_sec,
            "fps": fps,
            "detected_tags": [],
            "confidence": 0.0,
        }

    best_by_id: dict[int, dict] = {}
    valid_ids = set(tag_layout.keys()) if tag_layout else None
    for sample_t, sample_frame in frame_samples:
        gray = cv2.cvtColor(sample_frame, cv2.COLOR_BGR2GRAY)
        dets = _detect_apriltags_multi_pass(gray=gray, valid_ids=valid_ids)
        for d in dets:
            d = dict(d)
            d["sample_t_sec"] = float(sample_t)
            existing = best_by_id.get(int(d["id"]))
            if existing is None or float(d.get("area_px2", 0.0)) > float(existing.get("area_px2", 0.0)):
                best_by_id[int(d["id"])] = d
    detections = sorted(best_by_id.values(), key=lambda d: int(d["id"]))
    detections = _merge_with_manual_tag_observations(detections, manual_tag_observations)
    strong = _strong_detections(detections)

    camera_pose = None
    projected_layout_points: list[dict] = []
    h_frame, w_frame = frame.shape[:2]
    camera_matrix = _estimate_camera_matrix(frame_width=w_frame, frame_height=h_frame)
    tag_size_m = 0.1524 if int(season) < 2024 else _TAG_SIZE_M

    # Tags first: their centres stand in for field-corner clicks (fields aren't always
    # rectangles), so the lens and a mirrored layout are solved instead of assuming 70 deg.
    tag_refs = [
        {
            "image_x": float(d["center_x"]),
            "image_y": float(d["center_y"]),
            "field_x_m": float(tag_layout[int(d["id"])]["field_x_m"]),
            "field_y_m": float(tag_layout[int(d["id"])]["field_y_m"]),
            "field_z_m": float(tag_layout[int(d["id"])].get("field_z_m") or 0.0),
        }
        for d in strong
        if tag_layout and int(d["id"]) in tag_layout
    ]
    tag_pose = (
        _solve_camera_pose_from_manual_refs(manual_references=tag_refs, camera_matrix=camera_matrix)
        if len(tag_refs) >= TAGS_ONLY_MIN
        else None
    )
    tags_only = tag_pose is not None and float(tag_pose.get("reprojection_rmse_px") or 1e9) <= TAGS_ONLY_MAX_RMSE_PX
    pose_refs = tag_refs if tags_only else (manual_references or [])
    # Field-corner clicks only count when the tags couldn't place the camera.
    fit_refs = [] if tags_only else (manual_references or [])

    if tag_layout and strong and not tags_only:
        camera_pose, inlier_ids = _solve_camera_pose_from_tag_centers(
            detections=strong,
            tag_layout=tag_layout,
            camera_matrix=camera_matrix,
        )
        if camera_pose:
            rmse = camera_pose.get("reprojection_rmse_px")
            inlier_count = int(camera_pose.get("inlier_count") or 0)
            if rmse is None or rmse > 14.0 or inlier_count < 4:
                camera_pose = None
            else:
                camera_pose["quality"] = "good"

        if camera_pose:
            projected_layout_points = _project_layout_tags_to_image(tag_layout=tag_layout, pose=camera_pose)
            for d in strong:
                d["inlier"] = int(d["id"]) in set(inlier_ids)

    manual_pose_used = False
    if camera_pose is None and pose_refs:
        manual_pose = tag_pose if tags_only else _solve_camera_pose_from_manual_refs(
            manual_references=pose_refs,
            camera_matrix=camera_matrix,
        )
        if manual_pose is not None:
            manual_rmse = manual_pose.get("reprojection_rmse_px")
            if manual_rmse is None or float(manual_rmse) > 140.0:
                manual_pose = None
        if manual_pose is not None:
            camera_pose = manual_pose
            manual_pose_used = True
            camera_matrix = np.array(manual_pose["camera_matrix"], dtype=np.float64)
            base_rmse = float(camera_pose.get("reprojection_rmse_px") or 1e9)
            camera_pose["quality"] = "manual_weak" if base_rmse > 85.0 else "manual"
            if tag_layout:
                projected_layout_points = _project_layout_tags_to_image(tag_layout=tag_layout, pose=camera_pose)
                if camera_pose.get("quality") == "manual_weak":
                    anchor_ids = {
                        int(d.get("id", -1))
                        for d in strong
                        if int(d.get("id", -1)) in tag_layout
                    }
                    projected_layout_points = [
                        p for p in projected_layout_points if int(p.get("id", -1)) in anchor_ids
                    ]

                # Refine the manual pose using any matched tag centers that were
                # detected to improve 3D projection fidelity.
                refined_pose = _refine_manual_pose_with_tag_centers(
                    pose=camera_pose,
                    manual_references=pose_refs,
                    detections=strong,
                    tag_layout=tag_layout,
                    camera_matrix=camera_matrix,
                )
                if refined_pose is not camera_pose:
                    camera_pose = refined_pose
                    projected_layout_points = _project_layout_tags_to_image(tag_layout=tag_layout, pose=camera_pose)
                    if camera_pose.get("quality") == "manual_weak":
                        anchor_ids = {
                            int(d.get("id", -1))
                            for d in strong
                            if int(d.get("id", -1)) in tag_layout
                        }
                        projected_layout_points = [
                            p for p in projected_layout_points if int(p.get("id", -1)) in anchor_ids
                        ]

    homography = None
    if tag_layout and strong:
        img_points: list[list[float]] = []
        field_points: list[list[float]] = []
        for d in strong:
            if d["id"] in tag_layout:
                img_points.append([d["center_x"], d["center_y"]])
                t = tag_layout[d["id"]]
                fx = float(t.get("field_x_m", 0.0))
                fy = float(t.get("field_y_m", 0.0))
                field_points.append([fx * 100.0, fy * 100.0])
        if len(img_points) >= 4:
            h, _ = cv2.findHomography(
                np.array(img_points, dtype=np.float32),
                np.array(field_points, dtype=np.float32),
                cv2.RANSAC,
                3.0,
            )
            if h is not None:
                homography = h.tolist()

    fallback_used = False
    shifted_seed_points = None
    # The 2D-seeded/white-box passes guess IDs from planar seeds; once a 3D pose
    # exists, pose-guided verification below replaces them.
    if camera_pose is None and tag_layout and seed_homography_image_to_field_cm is not None and len(detections) < 10:
        similarity_seed_points = _build_similarity_seed_points_from_two_tags(
            detections=strong,
            tag_layout=tag_layout,
        )
        homography_seed_points = _build_seed_points_from_homography(
            tag_layout=tag_layout,
            seed_homography_image_to_field_cm=seed_homography_image_to_field_cm,
        )
        candidate_seed_points = similarity_seed_points or homography_seed_points
        candidate_ids = _select_visible_seed_candidate_ids(
            seed_points=candidate_seed_points,
            frame_width=w_frame,
            frame_height=h_frame,
            max_candidates=16,
        )
        # Ensure existing detections remain in the candidate set.
        if candidate_ids is not None:
            for d in strong:
                candidate_ids.add(int(d.get("id", -1)))
        seeded_samples = sorted(frame_samples, key=lambda p: abs(float(p[0]) - float(frame_sec)))[:3]
        seeded_best_by_id: dict[int, dict] = {}
        for _sample_t, sample_frame in seeded_samples:
            seeded_decoded = _seeded_roi_apriltag_decode(
                frame=sample_frame,
                tag_layout=tag_layout,
                seed_homography_image_to_field_cm=seed_homography_image_to_field_cm,
                candidate_ids=candidate_ids,
                seed_points_override=candidate_seed_points,
            )
            for d in seeded_decoded:
                tid = int(d["id"])
                existing = seeded_best_by_id.get(tid)
                if existing is None or float(d.get("area_px2", 0.0)) > float(existing.get("area_px2", 0.0)):
                    seeded_best_by_id[tid] = d

        # Second pass: if we already have a 3D projection, shift its projected
        # tag centers by matched residual and re-seed local decode from that map.
        if camera_pose is not None and projected_layout_points:
            shifted_seed_points = _build_shifted_projected_seed_points(
                projected_layout_points=projected_layout_points,
                detections=strong,
            )
            if shifted_seed_points:
                for _sample_t, sample_frame in seeded_samples:
                    seeded_decoded_3d = _seeded_roi_apriltag_decode(
                        frame=sample_frame,
                        tag_layout=tag_layout,
                        seed_homography_image_to_field_cm=seed_homography_image_to_field_cm,
                        candidate_ids=candidate_ids,
                        seed_points_override=shifted_seed_points,
                        window_radius_px=92,
                    )
                    for d in seeded_decoded_3d:
                        tid = int(d["id"])
                        existing = seeded_best_by_id.get(tid)
                        if existing is None or float(d.get("area_px2", 0.0)) > float(existing.get("area_px2", 0.0)):
                            seeded_best_by_id[tid] = d
        elif similarity_seed_points:
            for _sample_t, sample_frame in seeded_samples:
                seeded_decoded_sim = _seeded_roi_apriltag_decode(
                    frame=sample_frame,
                    tag_layout=tag_layout,
                    seed_homography_image_to_field_cm=seed_homography_image_to_field_cm,
                    candidate_ids=candidate_ids,
                    seed_points_override=similarity_seed_points,
                    window_radius_px=96,
                )
                for d in seeded_decoded_sim:
                    tid = int(d["id"])
                    existing = seeded_best_by_id.get(tid)
                    if existing is None or float(d.get("area_px2", 0.0)) > float(existing.get("area_px2", 0.0)):
                        seeded_best_by_id[tid] = d

        # Third pass: structural white-border/black-center detection within the
        # same neighborhood-prior windows to recover additional anchors even
        # when full decode fails on oblique/blurred visible tags.
        for _sample_t, sample_frame in seeded_samples:
            structural = _seeded_white_box_tag_detection(
                frame=sample_frame,
                tag_layout=tag_layout,
                seed_homography_image_to_field_cm=seed_homography_image_to_field_cm,
                candidate_ids=candidate_ids,
                seed_points_override=shifted_seed_points or similarity_seed_points or candidate_seed_points,
                window_radius_px=84,
            )
            for d in structural:
                tid = int(d["id"])
                existing = seeded_best_by_id.get(tid)
                if existing is None or float(d.get("seed_distance_px", 1e9)) < float(existing.get("seed_distance_px", 1e9)):
                    seeded_best_by_id[tid] = d

        merged_decoded = _merge_detections_by_id(detections, list(seeded_best_by_id.values()))
        if len(merged_decoded) > len(detections):
            detections = merged_decoded
            strong = _strong_detections(detections)
            fallback_used = True

    pose_verification = None
    if tag_layout and camera_pose is not None:
        near = sorted(frame_samples, key=lambda p: abs(float(p[0]) - float(frame_sec)))[:3]
        grays = [cv2.cvtColor(f, cv2.COLOR_BGR2GRAY) for _t, f in near]
        detections, pose_verification = _verify_tags_with_pose(
            grays, tag_layout, camera_pose, detections, tag_size_m
        )
        strong = _strong_detections(detections)
        # Each refinement can bring more tags inside the search window, so
        # alternate verify/refine while the pose keeps improving.
        for _ in range(4 if manual_pose_used else 0):
            refined_pose = _refine_pose_trusting_tags(
                pose=camera_pose,
                manual_references=fit_refs,
                detections=strong,
                tag_layout=tag_layout,
            )
            if refined_pose is camera_pose:
                refined_pose = _refine_manual_pose_with_tag_centers(
                    pose=camera_pose,
                    manual_references=fit_refs,
                    detections=strong,
                    tag_layout=tag_layout,
                    camera_matrix=camera_matrix,
                )
            if refined_pose is camera_pose:
                break
            camera_pose = refined_pose
            prev_ids = {int(d["id"]) for d in strong}
            detections, pose_verification = _verify_tags_with_pose(
                grays, tag_layout, camera_pose, detections, tag_size_m
            )
            strong = _strong_detections(detections)
            if {int(d["id"]) for d in strong} == prev_ids and camera_pose.get("refine_mode") == "tag_trusted":
                break
        projected_layout_points = _project_layout_tags_to_image(
            tag_layout=tag_layout, pose=camera_pose, tag_size_m=tag_size_m
        )
        if camera_pose.get("quality") == "manual_weak":
            anchor_ids = {int(d.get("id", -1)) for d in strong}
            projected_layout_points = [p for p in projected_layout_points if int(p["id"]) in anchor_ids]

    # With verified detections available, try to upgrade a manual pose to a
    # tag-derived pose when enough IDs are present.
    if (
        tag_layout and strong
        and not tags_only
        and (camera_pose is None or camera_pose.get("quality") in ("manual", "manual_refined"))
        and (camera_pose is None or camera_pose.get("refine_mode") != "tag_trusted")
    ):
        upgraded_pose, _ = _solve_camera_pose_from_tag_centers(
            detections=strong,
            tag_layout=tag_layout,
            camera_matrix=camera_matrix,
        )
        if upgraded_pose:
            rmse = upgraded_pose.get("reprojection_rmse_px")
            inlier_count = int(upgraded_pose.get("inlier_count") or 0)
            if rmse is not None and rmse <= 16.0 and inlier_count >= 4:
                upgraded_pose["quality"] = "seeded"
                camera_pose = upgraded_pose
                projected_layout_points = _project_layout_tags_to_image(
                    tag_layout=tag_layout, pose=camera_pose, tag_size_m=tag_size_m
                )

    # Wide/fisheye lenses: fit radial distortion + principal point when the
    # pinhole pose can't explain the clicks/tags/straight edges.
    if camera_pose is None and tag_layout:
        # No usable pinhole pose (a strongly bent view defeats it): try the
        # tags alone with a lens model, so off-screen corners aren't needed.
        camera_pose = _tag_only_lens_pose(strong, tag_layout, camera_matrix, (w_frame, h_frame))
        if camera_pose is not None:
            camera_pose = _tags_lens_leave_one_out(
                frame, strong, tag_layout, camera_matrix, (w_frame, h_frame), camera_pose, fit_refs
            )
            agree = set(camera_pose["tag_ids"])
            ignored = sorted({int(d.get("id", -1)) for d in strong} - agree)
            if ignored:
                camera_pose["ignored_tag_ids"] = ignored
                # Keep later passes from re-adding them (manual clicks are always kept).
                detections = [d for d in detections if int(d.get("id", -1)) not in ignored]
            strong = [d for d in strong if int(d.get("id", -1)) in agree]
            projected_layout_points = _project_layout_tags_to_image(
                tag_layout=tag_layout, pose=camera_pose, tag_size_m=tag_size_m
            )
    auto_lines: list[list[dict]] = []
    if camera_pose is not None:
        user_lines = list(straight_lines or [])
        lens_pose = _fit_lens_distortion(
            camera_pose, fit_refs, strong, tag_layout, user_lines, (w_frame, h_frame)
        )
        # Straight edges found in the picture (tape lines, rails, wall tops)
        # pin down the lens bend; each improved lens finds more of them.
        for _ in range(3):
            found = _lines_near_anchors(
                detect_straight_lines(frame, lens_pose), fit_refs, strong, (w_frame, h_frame)
            )
            if not found:
                break
            auto_lines = found
            refit = _fit_lens_distortion(
                lens_pose, fit_refs, strong, tag_layout, user_lines + found, (w_frame, h_frame)
            )
            if refit is lens_pose:
                break
            lens_pose = refit
        if lens_pose is not camera_pose:
            camera_pose = lens_pose
            if auto_lines:
                camera_pose["lens"]["auto_lines"] = len(auto_lines)
            if tag_layout:
                near = sorted(frame_samples, key=lambda p: abs(float(p[0]) - float(frame_sec)))[:3]
                grays = [cv2.cvtColor(f, cv2.COLOR_BGR2GRAY) for _t, f in near]
                detections, pose_verification = _verify_tags_with_pose(
                    grays, tag_layout, camera_pose, detections, tag_size_m
                )
                strong = _strong_detections(detections)
                lens_pose = _fit_lens_distortion(
                    camera_pose, fit_refs, strong, tag_layout, user_lines + auto_lines, (w_frame, h_frame)
                )
                if lens_pose is not camera_pose:
                    lens_pose["lens"]["auto_lines"] = len(auto_lines)
                    camera_pose = lens_pose
                projected_layout_points = _project_layout_tags_to_image(
                    tag_layout=tag_layout, pose=camera_pose, tag_size_m=tag_size_m
                )
        if camera_pose.get("quality") == "tags_lens":
            if camera_pose.get("lens") and float(camera_pose.get("tag_rmse_px") or 99.0) <= 8.0:
                camera_pose["quality"] = "seeded"
            else:
                camera_pose = None
                projected_layout_points = []
                auto_lines = []

    if (
        camera_pose is None
        and tag_layout
        and seed_homography_image_to_field_cm is not None
        and len(detections) < 4
    ):

        seeded_detections = _seeded_white_box_tag_detection(
            frame=frame,
            tag_layout=tag_layout,
            seed_homography_image_to_field_cm=seed_homography_image_to_field_cm,
            candidate_ids=_select_seed_candidate_ids(tag_layout=tag_layout, detections=strong),
            seed_points_override=shifted_seed_points,
        )
        merged_detections = _merge_detections_by_id(detections, seeded_detections)
        if len(merged_detections) > len(detections):
            detections = merged_detections
            strong = _strong_detections(detections)
            fallback_used = True

        if len(strong) >= 4:
            img_points: list[list[float]] = []
            field_points: list[list[float]] = []
            for d in strong:
                if d["id"] in tag_layout:
                    img_points.append([d["center_x"], d["center_y"]])
                    t = tag_layout[d["id"]]
                    fx = float(t.get("field_x_m", 0.0))
                    fy = float(t.get("field_y_m", 0.0))
                    field_points.append([fx * 100.0, fy * 100.0])
            if len(img_points) >= 4:
                h, _ = cv2.findHomography(
                    np.array(img_points, dtype=np.float32),
                    np.array(field_points, dtype=np.float32),
                    cv2.RANSAC,
                    4.0,
                )
                if h is not None:
                    homography = h.tolist()

            seeded_pose, _ = _solve_camera_pose_from_tag_centers(
                detections=strong,
                tag_layout=tag_layout,
                camera_matrix=camera_matrix,
            )
            if seeded_pose:
                rmse = seeded_pose.get("reprojection_rmse_px")
                inlier_count = int(seeded_pose.get("inlier_count") or 0)
                if rmse is None or rmse > 16.0 or inlier_count < 4:
                    seeded_pose = None
                else:
                    seeded_pose["quality"] = "seeded"

            if seeded_pose:
                camera_pose = seeded_pose
                projected_layout_points = _project_layout_tags_to_image(tag_layout=tag_layout, pose=camera_pose)

    method = "apriltag_detect" if not fallback_used else "apriltag_seeded_white_box"
    if manual_pose_used:
        method = "apriltag_tags_only" if tags_only else "manual_3d_refs"

    projection_alignment = None
    if camera_pose and projected_layout_points:
        projected_layout_points, projection_alignment = _align_projected_points_to_observations(
            projected_layout_points=projected_layout_points,
            detections=strong,
        )

    projection_scope = None
    if camera_pose and projected_layout_points and tag_layout:
        projected_layout_points, projection_scope = _scope_projected_points_for_weak_pose(
            projected_layout_points=projected_layout_points,
            detections=strong,
            tag_layout=tag_layout,
            pose=camera_pose,
        )

    detected_ids = [int(d["id"]) for d in detections]
    matched_layout_count = 0
    if tag_layout:
        valid = set(tag_layout.keys())
        matched_layout_count = sum(1 for tid in detected_ids if tid in valid)

    return {
        "season": season,
        "method": method,
        "frame_sec": frame_sec,
        "fps": fps,
        "detected_tags": detections,
        "tag_count": len(detections),
        "detected_ids": detected_ids,
        "matched_layout_tag_count": matched_layout_count,
        "confidence": min(1.0, len(detections) / 6.0),
        "homography": homography,
        "camera_pose": camera_pose,
        "projected_layout_points": projected_layout_points,
        "projection_alignment": projection_alignment,
        "projection_scope": projection_scope,
        "pose_verification": pose_verification,
        "auto_straight_lines": auto_lines,
        "fallback_used": fallback_used,
    }
