import numpy as np
import cv2


def build_manual_homography(manual_references: list[dict] | None, season: int) -> tuple[np.ndarray, dict]:
    _ = season
    ground_refs = [
        p
        for p in (manual_references or [])
        if abs(float(p.get("field_z_m", 0.0))) <= 0.05
    ]

    if not ground_refs or len(ground_refs) < 4:
        return np.eye(3, dtype=float), {
            "method": "identity_fallback",
            "reason": "Need at least 4 near-ground manual reference points",
            "used_points": len(ground_refs),
        }

    img_points = np.array(
        [[p["image_x"], p["image_y"]] for p in ground_refs],
        dtype=np.float32,
    )
    field_points_m = np.array(
        [[p["field_x_m"], p["field_y_m"]] for p in ground_refs],
        dtype=np.float32,
    )
    field_points_px = field_points_m * 100.0

    homography, mask = cv2.findHomography(img_points, field_points_px, cv2.RANSAC, 3.0)
    if homography is None:
        return np.eye(3, dtype=float), {
            "method": "identity_fallback",
            "reason": "cv2.findHomography failed",
            "used_points": len(ground_refs),
        }

    inliers = int(mask.sum()) if mask is not None else len(ground_refs)
    return homography, {
        "method": "manual_homography",
        "used_points": len(ground_refs),
        "total_points": len(manual_references or []),
        "inliers": inliers,
    }
