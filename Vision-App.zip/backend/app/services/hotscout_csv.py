"""Tracked autos as a CSV for the HotScout (Ignis) app's CSV Import.

One ``match-scouting`` row per team per match with the team's path document in a
``visionTracker`` JSON column, the same record the app makes when it pulls vision
autos from Firebase (same id and submitter, so the two never double up).
"""

from __future__ import annotations

import csv
import io
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings
from app.services.firebase_store import _clean

COLUMNS = [
    "id", "game", "eventKey", "eventName", "formType", "submittedBy", "submittedByUsername",
    "date", "uploadedAt", "matchNumber", "teamNumber", "visionTracker",
]
SUBMITTER = "vision-firebase"  # the app de-duplicates vision rows by this submitter


def _match_number(match_key: str) -> str:
    """Same rule as the app's _visionMatchNumberFromTracker (qm12 -> 12, sf3m1 -> 3)."""
    mk = (match_key or "").strip().lower()
    m = re.search(r"(?:^|_)[a-z]+(\d+)(?:\D.*)?$", mk)
    if m and int(m.group(1)) > 0:
        return str(int(m.group(1)))
    digits = re.findall(r"\d{1,4}", mk)
    return str(int(digits[-1])) if digits and int(digits[-1]) > 0 else ""


def _team_number(doc: dict) -> str:
    raw = str(doc.get("team_number") or doc.get("team_key") or "")
    m = re.search(r"\d+", raw.lower().removeprefix("frc"))
    return str(int(m.group())) if m else ""


def team_docs(event_key: str | None = None) -> list[tuple[Path, dict]]:
    """Saved per-team match documents (only robots that were found), oldest match first."""
    out = []
    for f in sorted(Path(settings.output_dir).glob("*/teams/*.json")):
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if not isinstance(doc, dict) or not doc.get("match_key") or doc.get("detected") is False:
            continue
        if event_key and str(doc.get("event_key") or "").lower() != event_key.lower():
            continue
        out.append((f, doc))
    return out


def build_csv(event_key: str | None = None) -> tuple[str, int]:
    """(CSV text, row count)."""
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(COLUMNS)
    rows = 0
    for f, doc in team_docs(event_key):
        team, match_key = _team_number(doc), str(doc["match_key"])
        event = str(doc.get("event_key") or match_key.split("_")[0]).lower()
        number = _match_number(match_key)
        if not team:
            continue
        payload = dict(doc)
        if payload.get("path_points"):
            payload.pop("trajectory", None)  # the app draws path_points; the per-frame copy only doubles the size
        stamp = datetime.fromtimestamp(f.stat().st_mtime, timezone.utc).isoformat().replace("+00:00", "Z")
        payload["uploaded_at"] = stamp
        w.writerow([
            f"vision_{event}_{team}_{number}_{match_key}", "", event, "", "match-scouting", SUBMITTER, SUBMITTER,
            stamp, stamp, number, team, json.dumps(_clean(payload), separators=(",", ":"), default=str),
        ])
        rows += 1
    return buf.getvalue(), rows
