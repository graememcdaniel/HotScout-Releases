import re
from pathlib import Path

import cv2
import numpy as np
from fastapi import UploadFile

from app.core.config import settings

VIDEO_TYPES = (".mp4", ".mov", ".mkv", ".webm", ".avi")
IMAGE_TYPES = (".jpg", ".jpeg", ".png", ".bmp", ".webp")
MAX_IMAGE_BYTES = 50 * 1024 * 1024
MAX_IMAGE_SIDE = 8192


def _safe_name(filename: str | None) -> str:
    # Keep only the base name so an upload can't write outside upload_dir.
    name = re.sub(r"[^A-Za-z0-9._ -]", "_", Path(filename or "").name).strip(" .")
    return name or "upload"


async def save_uploaded_video(file: UploadFile) -> str:
    out_dir = Path(settings.upload_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / _safe_name(file.filename)

    with out_path.open("wb") as f:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            f.write(chunk)

    return str(out_path.resolve())


async def save_uploaded_image(file: UploadFile) -> str:
    """Save a still picture as a tiny video so calibration can use it like any match video."""
    data = await file.read(MAX_IMAGE_BYTES + 1)
    if len(data) > MAX_IMAGE_BYTES:
        raise ValueError("Picture is too large (max 50 MB)")
    img = cv2.imdecode(np.frombuffer(data, dtype=np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not read that picture")
    h, w = img.shape[:2]
    if max(h, w) > MAX_IMAGE_SIDE:
        raise ValueError(f"Picture is too big ({w}x{h}); max side is {MAX_IMAGE_SIDE} px")

    out_dir = Path(settings.upload_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{Path(_safe_name(file.filename)).stem}_still.avi"
    # Lossless FFV1 keeps AprilTag edges sharp; MJPG is the fallback.
    writer = cv2.VideoWriter(str(out_path), cv2.CAP_FFMPEG, cv2.VideoWriter_fourcc(*"FFV1"), 30.0, (w, h))
    if not writer.isOpened():
        writer = cv2.VideoWriter(str(out_path), cv2.VideoWriter_fourcc(*"MJPG"), 30.0, (w, h))
    if not writer.isOpened():
        raise ValueError("Could not convert the picture")
    writer.set(cv2.VIDEOWRITER_PROP_QUALITY, 100)
    for _ in range(2):
        writer.write(img)
    writer.release()
    return str(out_path.resolve())
