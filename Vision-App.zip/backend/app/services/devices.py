"""Team computers: which are on, what each is doing, and scout runs sent to
another computer's GPU.

Every HotScout signed in to the team cloud writes a heartbeat to ``devices/{id}``:
its GPU and current load (any program's, from nvidia-smi), its scout run and its
detector training. A computer that allows it ("Let other team computers use this
GPU") also picks up scout runs queued for it in ``remote_jobs/{id}``, runs them
exactly like a local run and mirrors their progress back to that document. The
autos reach everyone the usual way: uploaded to the team cloud match by match.
It also helps other computers train the robot detector (``team_training``,
remote jobs of kind "train").

Layout::

    Firestore devices/{device_id}    name, version, email, gpu, load, accept_remote,
                                     scout, training, remote_job, updated_at, stopped_at
    Firestore remote_jobs/{job_id}   target, target_name, request (scout settings), status,
                                     created_by, created_by_name, created_by_email,
                                     claimed_at, local_job_id, job (progress), error,
                                     cancel_requested, created_at, updated_at
"""

from __future__ import annotations

import asyncio
import json
import logging
import shutil
import socket
import subprocess
import time
import uuid
from pathlib import Path
from typing import Awaitable, Callable

from fastapi.concurrency import run_in_threadpool

from app.core.gpu import gpu_info
from app.services import cloud, detector_training, scout_jobs

log = logging.getLogger(__name__)

TICK_SEC = 20  # remote-job check and heartbeat while busy
IDLE_BEAT_SEC = 60  # heartbeat while idle
ONLINE_SEC = 150  # no heartbeat for this long = offline
KEEP_JOBS_SEC = 7 * 86400  # finished remote jobs are deleted after this

_ACTIVE = {"queued", "running", "watching"}
# Remote job document statuses: queued (nobody took it yet), then claimed, waiting
# (for the GPU, e.g. detector training), running, watching, done, failed, cancelled.
REMOTE_ACTIVE = {"claimed", "waiting", "running", "watching"}
_CODE_ROOT = Path(__file__).resolve().parents[3]
_STARTED_AT = time.time()

_remote: dict[str, str] = {}  # remote job id -> local scout job id
_remote_for: dict[str, str] = {}  # local scout job id -> requesting computer's name
_starter: Callable[[dict], Awaitable[dict]] | None = None
_wake: asyncio.Event | None = None
_state = {"last_beat": 0.0, "was_busy": False, "recovered": False}


# ---------------------------------------------------------------- identity


def _settings_file() -> Path:
    return cloud.local_dir() / "device.json"


def _settings() -> dict:
    f = _settings_file()
    try:
        data = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    if not data.get("id"):
        data = {"id": uuid.uuid4().hex, "accept_remote": False, **data}
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps(data), encoding="utf-8")
    return data


def device_id() -> str:
    return _settings()["id"]


def device_name() -> str:
    return socket.gethostname()


def accepts_remote() -> bool:
    return bool(_settings().get("accept_remote"))


def set_accept_remote(on: bool) -> None:
    data = {**_settings(), "accept_remote": bool(on)}
    _settings_file().write_text(json.dumps(data), encoding="utf-8")
    _state["last_beat"] = 0.0  # tell the other computers now, not at the next idle heartbeat
    wake()


def _version() -> str:
    try:
        return (_CODE_ROOT / "VERSION").read_text(encoding="utf-8").strip()
    except OSError:
        return "dev"


# ---------------------------------------------------------------- what this computer is doing


def gpu_load(name: str | None) -> dict | None:
    """Current load of the GPU (all programs, not only HotScout)."""
    exe = shutil.which("nvidia-smi")
    if not exe:
        return None
    try:
        out = subprocess.run(
            [exe, "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu", "--format=csv,noheader,nounits"],
            capture_output=True,
            text=True,
            timeout=5,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        ).stdout
    except (OSError, subprocess.SubprocessError):
        return None
    rows = [[c.strip() for c in line.split(",")] for line in out.splitlines() if line.count(",") >= 4]
    row = next((r for r in rows if name and r[0] == name), rows[0] if rows else None)
    if row is None:
        return None

    def num(s: str) -> float | None:
        try:
            return float(s)
        except ValueError:  # "[N/A]"
            return None

    used, total = num(row[2]), num(row[3])
    return {
        "util_pct": num(row[1]),
        "mem_used_gb": round(used / 1024, 1) if used is not None else None,
        "mem_total_gb": round(total / 1024, 1) if total is not None else None,
        "temp_c": num(row[4]),
    }


def _scout_summary() -> dict | None:
    job = scout_jobs.active_job()
    if job is None:
        return None
    remote_id = next((r for r, local in _remote.items() if local == job["job_id"]), None)
    return {
        "status": job["status"],
        "event_key": job["event_key"],
        "team_key": job["team_key"],
        "live": job["live"],
        "completed": job["completed"],
        "total": job["total"],
        "current": job["current"],
        "remote_job": remote_id,
        "remote_for": _remote_for.get(job["job_id"]),
    }


def _training_summary() -> dict | None:
    from app.services import team_training

    keys = ("status", "season", "phase", "message", "progress", "auto")
    helping = team_training.helping()
    if helping:
        return {k: helping.get(k) for k in keys}
    job = detector_training._job
    if not detector_training.busy() or job is None:
        return None
    return {k: job.get(k) for k in keys}


def snapshot() -> dict:
    gpu = gpu_info()
    return {
        "name": device_name(),
        "version": _version(),
        "email": cloud.status()["email"],
        "gpu": {k: gpu.get(k) for k in ("device", "name", "memory_gb")},
        "load": gpu_load(gpu.get("name")),
        "accept_remote": accepts_remote(),
        "can_train": True,  # helps other computers train the detector (team_training)
        "scout": _scout_summary(),
        "training": _training_summary(),
        "started_at": _STARTED_AT,
        "updated_at": time.time(),
        "stopped_at": None,
    }


# ---------------------------------------------------------------- other computers


def list_devices() -> tuple[list[dict], str | None]:
    """(every computer that ever sent a heartbeat, this one live and first; cloud problem)."""
    me = device_id()
    found, error = {}, None
    if cloud.signed_in():
        try:
            found = cloud.list_docs("devices")
        except Exception as exc:  # offline, or the Firestore rules lack ``devices``
            error = str(exc)
    found[me] = snapshot()
    now = time.time()
    out = []
    for did, d in found.items():
        updated = float(d.get("updated_at") or 0)
        stopped = float(d.get("stopped_at") or 0)
        online = did == me or (now - updated < ONLINE_SEC and stopped < updated)
        out.append({**d, "id": did, "this": did == me, "online": online, "age_sec": max(0.0, now - updated)})
    out.sort(key=lambda d: (not d["this"], not d["online"], d["age_sec"]))
    return out, error


def get_device(did: str) -> dict | None:
    return next((d for d in list_devices()[0] if d["id"] == did), None)


def queue_remote(target: dict, request: dict) -> str:
    """Ask another computer to run a scout job. Returns the remote job id."""
    jid = uuid.uuid4().hex
    now = time.time()
    s = cloud.status()
    cloud.set_doc(
        f"remote_jobs/{jid}",
        {
            "target": target["id"],
            "target_name": target.get("name"),
            "request": request,
            "status": "queued",
            "created_by": device_id(),
            "created_by_name": device_name(),
            "created_by_email": s["email"],
            "created_at": now,
            "updated_at": now,
            "claimed_at": None,
            "local_job_id": None,
            "job": None,
            "error": None,
            "cancel_requested": False,
        },
    )
    return jid


def remote_job(jid: str) -> dict | None:
    doc = cloud.get_doc(f"remote_jobs/{jid}")
    if doc is None:
        return None
    return {**doc, "id": jid, "stale": doc.get("status") in REMOTE_ACTIVE and time.time() - float(doc.get("updated_at") or 0) > ONLINE_SEC}


def my_remote_jobs(limit: int = 10) -> list[dict]:
    """Scout runs this computer sent elsewhere, newest first."""
    rows = cloud.query_docs("remote_jobs", {"created_by": device_id()}, limit=100)
    rows = [r for r in rows if r[1].get("kind") != "train"]
    rows.sort(key=lambda r: -float(r[1].get("created_at") or 0))
    keys = ("target", "target_name", "status", "cancel_requested", "created_at", "updated_at")
    return [{"id": jid, **{k: d.get(k) for k in keys}, "event_key": (d.get("request") or {}).get("event_key")} for jid, d in rows[:limit]]


def cancel_remote(jid: str) -> bool:
    """The running computer stops it on its next check; a queued one is never started."""
    path = f"remote_jobs/{jid}"
    if cloud.get_doc(path) is None:
        return False
    cloud.set_doc(path, {"cancel_requested": True}, merge=True)
    return True


# ---------------------------------------------------------------- worker loop


def set_scout_starter(fn: Callable[[dict], Awaitable[dict]]) -> None:
    """``fn(request_dict)`` starts a local scout job like the Start button does (raises if it can't)."""
    global _starter
    _starter = fn


async def start_scout(request: dict) -> dict:
    """Start a scout job on this computer (raises like the Start button would)."""
    return await _starter(request)


def wake() -> None:
    if _wake is not None:
        _wake.set()


def _compact(job: dict) -> dict:
    """The scout job, small enough for a Firestore document."""
    keys = ("status", "event_key", "team_key", "live", "total", "completed", "current", "next_check_at",
            "retry_round", "rescout_round", "error", "started_at", "finished_at")
    out = {k: job.get(k) for k in keys}
    team_keys = ("team_key", "detected", "method", "needs_review")
    out["matches"] = [
        {
            "match_key": e["match_key"],
            "status": e["status"],
            "message": e.get("message"),
            "attempts": e.get("attempts", 0),
            "rev": e.get("rev", 0),
            "rescout": bool(e.get("rescout")),
            "rescout_tag": {"reason": (e.get("rescout_tag") or {}).get("reason")} if e.get("rescout_tag") else None,
            "teams": [{k: t.get(k) for k in team_keys} for t in e.get("teams") or []],
        }
        for e in job.get("matches") or []
    ]
    return out


def _doc_status(job: dict) -> str:
    return "waiting" if job["status"] == "queued" else job["status"]


def _error_text(exc: Exception) -> str:
    detail = getattr(exc, "detail", None)
    return detail if isinstance(detail, str) else str(exc)


async def _recover() -> None:
    """After a restart: fail remote runs this computer had claimed, drop old finished ones."""
    rows = await run_in_threadpool(cloud.query_docs, "remote_jobs", {"target": device_id()}, 200)
    now = time.time()
    for jid, d, _ in rows:
        path = f"remote_jobs/{jid}"
        if d.get("status") in REMOTE_ACTIVE and jid not in _remote:
            await run_in_threadpool(
                cloud.set_doc, path, {"status": "failed", "error": f"HotScout restarted on {device_name()}", "updated_at": now}, True
            )
        elif d.get("status") not in {"queued", *REMOTE_ACTIVE} and now - float(d.get("updated_at") or 0) > KEEP_JOBS_SEC:
            await run_in_threadpool(cloud.delete_doc, path)


async def _claim_next() -> None:
    from app.services import team_training

    rows = await run_in_threadpool(cloud.query_docs, "remote_jobs", {"target": device_id(), "status": "queued"}, 10)
    rows.sort(key=lambda r: float(r[1].get("created_at") or 0))
    for jid, d, update_time in rows:
        path = f"remote_jobs/{jid}"
        now = time.time()
        if d.get("cancel_requested") or d.get("finish"):
            await run_in_threadpool(cloud.set_doc, path, {"status": "cancelled", "updated_at": now}, True, update_time)
            continue
        if d.get("kind") == "train":  # help another computer train the detector
            if detector_training.busy() or team_training.helping():
                continue  # its computer gives up on this one after a minute or two
            team_training.start_helping(jid, d, update_time)
            return
        claimed = await run_in_threadpool(
            cloud.set_doc, path, {"status": "claimed", "claimed_at": now, "updated_at": now}, True, update_time
        )
        if not claimed:
            continue  # changed meanwhile (cancelled?); look again next tick
        try:
            job = await _starter(d.get("request") or {})
        except Exception as exc:
            log.warning("remote scout job %s from %s refused: %s", jid, d.get("created_by_name"), exc)
            await run_in_threadpool(
                cloud.set_doc, path, {"status": "failed", "error": _error_text(exc), "updated_at": time.time()}, True
            )
            continue
        _remote[jid] = job["job_id"]
        _remote_for[job["job_id"]] = d.get("created_by_name") or "another computer"
        log.info("running scout job %s for %s (%s)", jid, d.get("created_by_name"), job["event_key"])
        await run_in_threadpool(
            cloud.set_doc, path, {"local_job_id": job["job_id"], "status": _doc_status(job), "job": _compact(job), "updated_at": time.time()}, True
        )
        return  # one run at a time


async def _mirror() -> None:
    """Copy progress of remote runs to their documents; stop them when asked."""
    for jid, local_id in list(_remote.items()):
        path = f"remote_jobs/{jid}"
        job = scout_jobs.get_job(local_id)
        if job is None:
            _remote.pop(jid, None)
            continue
        try:
            doc = await run_in_threadpool(cloud.get_doc, path)
        except Exception as exc:
            log.warning("remote job %s: %s", jid, exc)
            continue
        if doc is None:  # deleted by its sender
            scout_jobs.cancel_job(local_id)
        elif doc.get("cancel_requested"):
            scout_jobs.cancel_job(local_id)
        if doc is not None:
            await run_in_threadpool(
                cloud.set_doc, path, {"status": _doc_status(job), "job": _compact(job), "error": job.get("error"), "updated_at": time.time()}, True
            )
        if job["status"] not in _ACTIVE:
            _remote.pop(jid, None)


async def _tick() -> bool:
    from app.services import team_training

    if not _state["recovered"]:
        await _recover()
        _state["recovered"] = True
    await _mirror()
    if accepts_remote() and _starter is not None and not _remote and scout_jobs.active_job() is None and not team_training.helping():
        await _claim_next()
    snap = await run_in_threadpool(snapshot)
    busy = bool(snap["scout"] or snap["training"] or _remote)
    if busy or _state["was_busy"] or time.time() - _state["last_beat"] >= IDLE_BEAT_SEC:
        await run_in_threadpool(cloud.set_doc, f"devices/{device_id()}", snap)
        _state["last_beat"] = time.time()
    _state["was_busy"] = busy
    return busy


async def run_forever() -> None:
    """Heartbeat and remote-job loop; started with the server."""
    global _wake
    _wake = asyncio.Event()
    last_error = None
    while True:
        if cloud.signed_in():
            try:
                await _tick()
                last_error = None
            except Exception as exc:  # network trouble: try again next tick (log each new problem once)
                if str(exc) != last_error:
                    log.warning("team computers update failed: %s", exc)
                last_error = str(exc)
        try:
            await asyncio.wait_for(_wake.wait(), timeout=TICK_SEC)
        except asyncio.TimeoutError:
            pass
        _wake.clear()


def mark_stopped() -> None:
    """Server shutting down: show this computer as off right away."""
    cloud.quietly(cloud.set_doc, f"devices/{device_id()}", {"stopped_at": time.time()}, True)
