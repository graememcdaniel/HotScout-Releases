def build_quality_report(points: list[dict], track_meta: dict, path_summary: dict | None = None) -> dict:
    total = len(points)
    inferred = sum(1 for p in points if p.get("inferred"))
    avg_conf = sum(p.get("confidence", 0.0) for p in points) / total if total else 0.0
    ids = [p["identity_confidence"] for p in points if p.get("identity_confidence") is not None]

    report = {
        "frames_total": total,
        "frames_inferred": inferred,
        "inferred_ratio": (inferred / total) if total else 0.0,
        "avg_confidence": avg_conf,
        "avg_identity_confidence": (sum(ids) / len(ids)) if ids else None,
        "min_identity_confidence": min(ids) if ids else None,
        "max_z_m": max((p.get("z_m") or 0.0 for p in points), default=0.0),
        "track_meta": track_meta,
        "notes": list(track_meta.get("warnings", [])),
    }
    if path_summary is not None:
        report["path"] = path_summary
    return report
