"""Team cloud on Firebase: Google sign-in, and the robot detector, team appearance
gallery, event calibrations and hand checks shared by every team computer.

Each computer signs in once with a team Google account (button at the top of the
app). Firebase security rules (``firebase/*.rules``) only let e-mails listed in the
Firestore document ``config/access`` (field ``emails``) read or write, so no admin
key has to be copied around. The account's refresh token is kept outside the
project folder (``%LOCALAPPDATA%/HotScout``) so scout runs can sync unattended.

Layout::

    Firestore detectors/{season}        trained_at, sha256, map50, meta (JSON), updated_by
    Storage   detectors/{season}/best.pt
    Firestore galleries/{season}        sha256, matches, rows, updated_by
    Storage   galleries/{season}.npz     rows of (match, team, embedding)
    Firestore calibrations/{event_key}  calibrated_at, season, record (JSON)
    Firestore ground_truth/{match_key}  saved_at, complete, doc (JSON)

Scouted matches (autos, good marks, re-scout tags) are shared by ``shared_matches``
(Firestore ``scouted``, Storage ``scouted/`` and ``scouted_runs/``).

Newest wins: the detector by ``trained_at``, calibrations by ``calibrated_at``,
hand checks by ``saved_at``. Gallery rows are merged per match.
"""

from __future__ import annotations

import hashlib
import io
import json
import logging
import math
import os
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock
from urllib.parse import quote

import httpx
import numpy as np

from app.core.config import settings

log = logging.getLogger(__name__)

FIRESTORE = "https://firestore.googleapis.com/v1"
STORAGE = "https://firebasestorage.googleapis.com/v0"
TOKEN_URL = "https://securetoken.googleapis.com/v1/token"
TIMEOUT = httpx.Timeout(30.0, read=600.0)

_lock = Lock()  # session file and token cache
_sync_lock = Lock()  # one sync at a time
_token: dict = {"id_token": None, "expires": 0.0}
_last: dict = {"at": None, "synced": [], "errors": []}


class NotAllowed(Exception):
    """Valid Google account, but not on the team list."""


# ---------------------------------------------------------------- session


def local_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home() / ".local" / "share")
    return Path(base) / "HotScout"


def _session_file() -> Path:
    return local_dir() / "cloud_session.json"


def _bucket() -> str:
    return settings.firebase_storage_bucket or f"{settings.firebase_project_id}.firebasestorage.app"


def web_config() -> dict | None:
    """Public Firebase web-app config for the sign-in page (not secret)."""
    if not settings.firebase_web_api_key:
        return None
    project = settings.firebase_project_id
    cfg = {
        "apiKey": settings.firebase_web_api_key,
        "authDomain": settings.firebase_auth_domain or f"{project}.firebaseapp.com",
        "projectId": project,
        "storageBucket": _bucket(),
    }
    if settings.firebase_app_id:
        cfg["appId"] = settings.firebase_app_id
    return cfg


def _session() -> dict | None:
    try:
        return json.loads(_session_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _write_session(data: dict) -> None:
    f = _session_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    tmp = f.with_suffix(".tmp")
    tmp.write_text(json.dumps(data), encoding="utf-8")
    tmp.replace(f)


def signed_in() -> bool:
    return web_config() is not None and _session() is not None


def status() -> dict:
    s = _session() if web_config() else None
    return {
        "configured": web_config() is not None,
        "signed_in": bool(s),
        "email": (s or {}).get("email"),
        "web_config": web_config(),
        "last_sync": _last,
    }


def verify_user(id_token: str) -> dict:
    """Claims of a Firebase ID token from the browser; must be a verified Google account."""
    from google.auth.transport import requests as google_requests
    from google.oauth2 import id_token as google_id_token

    claims = google_id_token.verify_firebase_token(
        id_token, google_requests.Request(), audience=settings.firebase_project_id
    )
    if not claims or not claims.get("email") or not claims.get("email_verified"):
        raise ValueError("Sign in with a verified Google account")
    return claims


def check_member(id_token: str) -> None:
    """The security rules decide: only listed team members may read ``config/access``."""
    r = httpx.get(_doc_url("config/access"), headers={"Authorization": f"Bearer {id_token}"}, timeout=TIMEOUT)
    if r.status_code in (401, 403, 404):
        raise NotAllowed("This Google account is not on the team list (Firestore config/access, field emails).")
    r.raise_for_status()


def sign_in(id_token: str, refresh_token: str) -> dict:
    """Make this computer sync as the given account."""
    if web_config() is None:
        raise ValueError("Team cloud is not set up on this computer (FIREBASE_WEB_API_KEY in .env)")
    claims = verify_user(id_token)
    check_member(id_token)
    with _lock:
        _write_session(
            {"uid": claims.get("user_id") or claims.get("sub"), "email": claims["email"], "refresh_token": refresh_token, "signed_in_at": time.time()}
        )
        _token.update(id_token=id_token, expires=float(claims["exp"]) - 120)
    return status()


def sign_out() -> dict:
    with _lock:
        _session_file().unlink(missing_ok=True)
        _token.update(id_token=None, expires=0.0)
    return status()


def _id_token() -> str:
    with _lock:
        if _token["id_token"] and time.time() < _token["expires"]:
            return _token["id_token"]
        s = _session()
        if not s or not settings.firebase_web_api_key:
            raise RuntimeError("Not signed in to the team cloud")
        r = httpx.post(
            TOKEN_URL,
            params={"key": settings.firebase_web_api_key},
            data={"grant_type": "refresh_token", "refresh_token": s["refresh_token"]},
            timeout=TIMEOUT,
        )
        if r.status_code == 400:
            raise RuntimeError("Team cloud sign-in expired; sign in again")
        r.raise_for_status()
        j = r.json()
        if j.get("refresh_token") and j["refresh_token"] != s["refresh_token"]:
            _write_session({**s, "refresh_token": j["refresh_token"]})
        _token.update(id_token=j["id_token"], expires=time.time() + int(j.get("expires_in", 3600)) - 120)
        return _token["id_token"]


def _who() -> str | None:
    return (_session() or {}).get("email")


# ---------------------------------------------------------------- Firestore REST


def _enc(v) -> dict:
    if v is None:
        return {"nullValue": "NULL_VALUE"}
    if isinstance(v, bool):
        return {"booleanValue": v}
    if isinstance(v, (int, np.integer)):
        return {"integerValue": str(int(v))}
    if isinstance(v, (float, np.floating)):
        return {"doubleValue": float(v)} if math.isfinite(v) else {"nullValue": "NULL_VALUE"}
    if isinstance(v, str):
        return {"stringValue": v}
    if isinstance(v, datetime):
        return {"timestampValue": v.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")}
    if isinstance(v, dict):
        return {"mapValue": {"fields": {str(k): _enc(x) for k, x in v.items()}}}
    if isinstance(v, (list, tuple)):
        return {"arrayValue": {"values": [_enc(x) for x in v]}}
    raise TypeError(f"cannot store {type(v).__name__} in Firestore")


def _dec(v: dict):
    (kind, x), = v.items()
    if kind == "nullValue":
        return None
    if kind == "integerValue":
        return int(x)
    if kind == "doubleValue":
        return float(x)
    if kind == "mapValue":
        return {k: _dec(i) for k, i in (x.get("fields") or {}).items()}
    if kind == "arrayValue":
        return [_dec(i) for i in x.get("values") or []]
    return x  # boolean, string, timestamp (ISO text), reference, bytes (base64)


def _doc_url(path: str) -> str:
    return f"{FIRESTORE}/projects/{settings.firebase_project_id}/databases/(default)/documents/{path}"


def _bearer() -> dict:
    return {"Authorization": f"Bearer {_id_token()}"}


def get_doc(path: str) -> dict | None:
    got = get_doc_meta(path)
    return got[0] if got else None


def get_doc_meta(path: str) -> tuple[dict, str] | None:
    """(fields, update time) of a document, or None if there is none."""
    r = httpx.get(_doc_url(path), headers=_bearer(), timeout=TIMEOUT)
    if r.status_code == 404:
        return None
    r.raise_for_status()
    j = r.json()
    return {k: _dec(v) for k, v in (j.get("fields") or {}).items()}, j.get("updateTime", "")


def set_doc(path: str, fields: dict, merge: bool = False, if_update_time: str | None = None, if_missing: bool = False) -> bool:
    """Write a document; ``merge`` keeps fields not given (like ``set(..., merge=True)``).

    With ``if_update_time`` the write only happens if nobody changed the document since,
    with ``if_missing`` only if it does not exist yet (returns False otherwise), so two
    computers can't both claim the same thing.
    """
    params = [("updateMask.fieldPaths", f"`{k}`") for k in fields] if merge else []
    if if_update_time:
        params.append(("currentDocument.updateTime", if_update_time))
    elif if_missing:
        params.append(("currentDocument.exists", "false"))
    r = httpx.patch(_doc_url(path), params=params or None, headers=_bearer(), json={"fields": {k: _enc(v) for k, v in fields.items()}}, timeout=TIMEOUT)
    if (if_update_time or if_missing) and r.status_code in (400, 409, 412) and any(
        s in r.text for s in ("FAILED_PRECONDITION", "ABORTED", "ALREADY_EXISTS")
    ):
        return False
    r.raise_for_status()
    return True


_OPS = {"==": "EQUAL", ">": "GREATER_THAN", ">=": "GREATER_THAN_OR_EQUAL", "<": "LESS_THAN", "<=": "LESS_THAN_OR_EQUAL"}


def query_docs(collection: str, where: dict, limit: int = 50, order_by: str | None = None) -> list[tuple[str, dict, str]]:
    """(id, fields, update time) of a top-level collection's documents matching ``where``:
    ``{field: value}`` for equal, or ``{field: (">", value)}`` for other comparisons."""
    filters = []
    for k, v in where.items():
        op, value = v if isinstance(v, tuple) else ("==", v)
        filters.append({"fieldFilter": {"field": {"fieldPath": k}, "op": _OPS[op], "value": _enc(value)}})
    query = {"from": [{"collectionId": collection}], "limit": limit}
    if filters:
        query["where"] = filters[0] if len(filters) == 1 else {"compositeFilter": {"op": "AND", "filters": filters}}
    if order_by:
        query["orderBy"] = [{"field": {"fieldPath": order_by}, "direction": "ASCENDING"}]
    r = httpx.post(_doc_url("").rstrip("/") + ":runQuery", headers=_bearer(), json={"structuredQuery": query}, timeout=TIMEOUT)
    r.raise_for_status()
    out = []
    for row in r.json():
        d = row.get("document")
        if d:
            fields = {k: _dec(v) for k, v in (d.get("fields") or {}).items()}
            out.append((d["name"].rsplit("/", 1)[1], fields, d.get("updateTime", "")))
    return out


def delete_doc(path: str) -> None:
    r = httpx.delete(_doc_url(path), headers=_bearer(), timeout=TIMEOUT)
    if r.status_code != 404:
        r.raise_for_status()


def list_docs(collection: str) -> dict[str, dict]:
    out: dict[str, dict] = {}
    token = None
    while True:
        params = {"pageSize": 300, **({"pageToken": token} if token else {})}
        r = httpx.get(_doc_url(collection), params=params, headers=_bearer(), timeout=TIMEOUT)
        r.raise_for_status()
        j = r.json()
        for d in j.get("documents") or []:
            out[d["name"].rsplit("/", 1)[1]] = {k: _dec(v) for k, v in (d.get("fields") or {}).items()}
        token = j.get("nextPageToken")
        if not token:
            return out


# ---------------------------------------------------------------- Storage REST


def upload(name: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    r = httpx.post(
        f"{STORAGE}/b/{_bucket()}/o",
        params={"name": name},
        headers={"Authorization": f"Firebase {_id_token()}", "Content-Type": content_type},
        content=data,
        timeout=TIMEOUT,
    )
    r.raise_for_status()


def download(name: str) -> bytes:
    r = httpx.get(
        f"{STORAGE}/b/{_bucket()}/o/{quote(name, safe='')}",
        params={"alt": "media"},
        headers={"Authorization": f"Firebase {_id_token()}"},
        timeout=TIMEOUT,
    )
    r.raise_for_status()
    return r.content


def delete_file(name: str) -> None:
    r = httpx.delete(
        f"{STORAGE}/b/{_bucket()}/o/{quote(name, safe='')}",
        headers={"Authorization": f"Firebase {_id_token()}"},
        timeout=TIMEOUT,
    )
    if r.status_code != 404:
        r.raise_for_status()


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    tmp.write_bytes(data)
    tmp.replace(path)


# ---------------------------------------------------------------- robot detector


def pull_detector(season: int) -> list[str]:
    from app.services import detector_training as dt

    if dt.busy():  # never swap the model under a training run
        return []
    remote = get_doc(f"detectors/{season}")
    local = dt._meta(season) or {}
    if not remote or float(remote.get("trained_at") or 0) <= float(local.get("trained_at") or 0):
        return []
    data = download(f"detectors/{season}/best.pt")
    if _sha(data) != remote.get("sha256"):
        raise RuntimeError("downloaded detector is damaged (checksum mismatch)")
    meta = json.loads(remote["meta"])
    if "enabled" in local:  # switching the trained model off is this computer's choice
        meta["enabled"] = local["enabled"]
    _write_bytes(dt.model_dir(season) / "best.pt", data)
    dt._write_meta(season, meta)
    return [f"detector {season} from {remote.get('updated_by') or 'the team'}"]


def push_detector(season: int) -> list[str]:
    from app.services import detector_training as dt

    local = dt._meta(season)
    weights = dt.model_dir(season) / "best.pt"
    if not local or not local.get("trained_at") or not weights.is_file():
        return []
    remote = get_doc(f"detectors/{season}") or {}
    if float(local["trained_at"]) <= float(remote.get("trained_at") or 0):
        return []
    data = weights.read_bytes()
    upload(f"detectors/{season}/best.pt", data)
    set_doc(
        f"detectors/{season}",
        {
            "season": season,
            "trained_at": float(local["trained_at"]),
            "sha256": _sha(data),
            "map50": local.get("map50"),
            "active": bool(local.get("active")),
            "meta": json.dumps(local),
            "updated_by": _who(),
            "updated_at": datetime.now(timezone.utc),
        },
    )
    return [f"detector {season} shared"]


# ---------------------------------------------------------------- appearance gallery


def _gallery_file(season: int) -> Path:
    return Path(settings.appearance_dir) / str(season) / "_team_cloud.npz"


def _rows_hash(matches: np.ndarray, teams: np.ndarray, emb: np.ndarray) -> str:
    h = hashlib.sha256(json.dumps([matches.tolist(), teams.tolist()]).encode())
    h.update(np.ascontiguousarray(emb, dtype=np.float32).tobytes())
    return h.hexdigest()


def _pack(matches: np.ndarray, teams: np.ndarray, emb: np.ndarray) -> bytes:
    buf = io.BytesIO()
    np.savez_compressed(buf, matches=matches, teams=teams, emb=np.asarray(emb, dtype=np.float32))
    return buf.getvalue()


def _unpack(src) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    with np.load(src, allow_pickle=False) as data:
        return data["matches"].astype(str), data["teams"].astype(str), data["emb"].astype(np.float32)


_EMPTY = (np.zeros(0, dtype=str), np.zeros(0, dtype=str), np.zeros((0, 0), dtype=np.float32))


def cached_gallery(season: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(match, team, embedding) rows from the whole team, as of the last sync."""
    f = _gallery_file(season)
    if not f.is_file():
        return _EMPTY
    try:
        return _unpack(f)
    except (OSError, ValueError, KeyError):
        return _EMPTY


def pull_gallery(season: int) -> list[str]:
    remote = get_doc(f"galleries/{season}")
    if not remote or remote.get("sha256") == _rows_hash(*cached_gallery(season)):
        return []
    data = download(f"galleries/{season}.npz")
    rows = _unpack(io.BytesIO(data))
    if _rows_hash(*rows) != remote["sha256"]:
        raise RuntimeError("downloaded team gallery is damaged (checksum mismatch)")
    _write_bytes(_gallery_file(season), data)
    return [f"team looks {season} ({len(set(rows[0]))} matches)"]


def push_gallery(season: int) -> list[str]:
    """Add this computer's good matches to the team gallery (theirs replace older rows)."""
    from app.services import detector_training as dt

    pull_gallery(season)
    l_matches, l_teams, l_emb = dt.local_gallery_rows(season)
    if not len(l_matches):
        return []
    c_matches, c_teams, c_emb = cached_gallery(season)
    keep = ~np.isin(c_matches, l_matches) if len(c_matches) and c_emb.shape[1:] == l_emb.shape[1:] else np.zeros(len(c_matches), dtype=bool)
    rows = (
        np.concatenate([c_matches[keep], l_matches]),
        np.concatenate([c_teams[keep], l_teams]),
        np.concatenate([c_emb[keep], l_emb]) if keep.any() else l_emb,
    )
    sha = _rows_hash(*rows)
    if sha == _rows_hash(c_matches, c_teams, c_emb):
        return []
    data = _pack(*rows)
    upload(f"galleries/{season}.npz", data)
    set_doc(
        f"galleries/{season}",
        {"season": season, "sha256": sha, "matches": len(set(rows[0])), "rows": len(rows[0]), "updated_by": _who(), "updated_at": datetime.now(timezone.utc)},
    )
    _write_bytes(_gallery_file(season), data)
    return [f"team looks {season} shared ({len(set(l_matches))} matches from here)"]


# ---------------------------------------------------------------- calibrations


def push_calibration(record: dict) -> None:
    set_doc(
        f"calibrations/{record['event_key']}",
        {
            "event_key": record["event_key"],
            "season": record.get("season"),
            "calibrated_at": record.get("calibrated_at") or "",
            "record": json.dumps(record),
            "updated_by": _who(),
            "updated_at": datetime.now(timezone.utc),
        },
    )


def delete_calibration(event_key: str) -> None:
    delete_doc(f"calibrations/{event_key}")


def pull_calibration(event_key: str) -> dict | None:
    from app.services import event_calibration_store as store

    remote = get_doc(f"calibrations/{event_key}")
    if not remote:
        return None
    record = json.loads(remote["record"])
    store.write_record(record)
    return record


def sync_calibrations() -> list[str]:
    from app.services import event_calibration_store as store

    remote = list_docs("calibrations")
    done = []
    local = {c["event_key"]: c.get("calibrated_at") or "" for c in store.list_event_calibrations() if c.get("event_key")}
    for key, doc in remote.items():
        if (doc.get("calibrated_at") or "") > local.get(key, ""):
            store.write_record(json.loads(doc["record"]))
            done.append(f"calibration {key}")
    for key, at in local.items():
        if at > (remote.get(key) or {}).get("calibrated_at", ""):
            push_calibration(store.load_event_calibration(key))
            done.append(f"calibration {key} shared")
    return done


# ---------------------------------------------------------------- hand checks


def push_ground_truth(doc: dict) -> None:
    set_doc(
        f"ground_truth/{doc['match_key']}",
        {
            "match_key": doc["match_key"],
            "saved_at": float(doc.get("saved_at") or 0),
            "complete": bool(doc.get("complete")),
            "doc": json.dumps(doc),
            "updated_by": _who(),
        },
    )


def pull_ground_truth(match_key: str) -> dict | None:
    from app.services import ground_truth as gt

    remote = get_doc(f"ground_truth/{match_key}")
    if not remote:
        return None
    doc = json.loads(remote["doc"])
    gt.write(match_key, doc)
    return doc


def sync_ground_truth() -> list[str]:
    from app.services import ground_truth as gt

    remote = list_docs("ground_truth")
    local = {mk: float((gt.load(mk) or {}).get("saved_at") or 0) for mk in gt.labelled_matches(complete_only=False)}
    done = []
    for mk, doc in remote.items():
        if float(doc.get("saved_at") or 0) > local.get(mk, -1):
            gt.write(mk, json.loads(doc["doc"]))
            done.append(f"hand check {mk}")
    for mk, at in local.items():
        if at > float((remote.get(mk) or {}).get("saved_at") or -1):
            push_ground_truth(gt.load(mk))
            done.append(f"hand check {mk} shared")
    for mk in gt.labelled_matches():  # finished checks (incl. ones from other computers) are the autos
        files = gt.apply_to_autos(mk)
        if files:
            _share_hand_autos(mk, files)
            done.append(f"hand-checked autos {mk}")
    return done


def _share_hand_autos(match_key: str, files: list[str]) -> None:
    from app.services import firebase_store, scout_jobs
    from app.services.trajectory_export import parse_match_key, team_paths_dir

    if firebase_store.status()["configured"]:
        firebase_store.upload_team_files(files, team_paths_dir(match_key).parent / "firebase_docs.json")
    event_key = parse_match_key(match_key)["event_key"]
    if event_key:
        matches = [d.name for d in Path(settings.output_dir).glob(f"{event_key}_*") if (d / "teams").is_dir()]
        scout_jobs.compile_team_autos(event_key, matches)


# ---------------------------------------------------------------- sync


def sync(season: int | None, *, push: bool = True) -> dict:
    """Bring this computer and the team cloud up to date. Never raises."""
    if not signed_in():
        return {"skipped": "not signed in", "synced": [], "errors": []}
    steps = [("calibrations", sync_calibrations), ("hand checks", sync_ground_truth)]
    if season:
        steps += [("detector", lambda: pull_detector(season)), ("team looks", lambda: pull_gallery(season))]
        if push:
            steps += [("detector", lambda: push_detector(season)), ("team looks", lambda: push_gallery(season))]
    synced, errors = [], []
    with _sync_lock:
        for name, fn in steps:
            try:
                synced += fn()
            except Exception as exc:
                log.warning("team cloud %s sync failed: %s", name, exc)
                errors.append(f"{name}: {exc}")
    _last.update(at=time.time(), synced=synced, errors=errors)
    if synced:
        log.info("team cloud: %s", ", ".join(synced))
    return {"synced": synced, "errors": errors}


def pull_quietly(season: int | None) -> dict:
    return sync(season, push=False)


def push_quietly(season: int) -> dict:
    return sync(season, push=True)


def quietly(fn, *args):
    """Run one cloud call without letting a network problem reach the caller."""
    if not signed_in():
        return None
    try:
        return fn(*args)
    except Exception as exc:
        log.warning("team cloud %s failed: %s", getattr(fn, "__name__", "call"), exc)
        _last["errors"] = [f"{getattr(fn, '__name__', 'call')}: {exc}"]
        return None


_background = ThreadPoolExecutor(max_workers=1, thread_name_prefix="team-cloud")


def in_background(fn, *args) -> None:
    """Share a change without making the user wait for the upload."""
    if signed_in():
        _background.submit(quietly, fn, *args)
