"""Hand-checked robot positions ("ground truth") and tracking accuracy against them.

A person places every robot on video keyframes (``GT_HZ`` per second over the
auto window), starting from the tracker's own positions as suggestions. Labels
are stored per team in ``outputs/<match>/ground_truth.json`` with absolute video
times, so they stay valid when the match is re-scouted.

Accuracy = share of labelled (visible) robot-keyframes where the output puts
that robot within ``MATCH_RADIUS_M`` of where the person clicked:
- ``tracking``: robots matched to labelled robots one-to-one over the whole
  auto (identity must hold for the full auto, team numbers ignored);
- ``end_to_end``: the robot the output gives that *team number* - what scouts get.

Keyframes the person had to correct (scored as misses, see ``corrected_keyframes``)
also become training pictures for the robot detector (``save_training_frames``).

A finished check also replaces the match's saved autos (``apply_to_autos``): each
checked team's path is its clicks, and the team is taken as known.
"""

from __future__ import annotations

import json
import math
import shutil
import tempfile
import threading
import time
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment

from app.core.config import settings
from app.services.trajectory_export import FIELD_FRAME, not_detected_doc, team_path_file, to_wpilib_points
from app.tracking import training_data as td
from app.tracking.camera import CameraModel
from app.tracking.terrain import FieldTerrain

GT_HZ = 2.0
MATCH_RADIUS_M = 0.75
PASS_SHARE = 0.99
STATES = {"pos", "hidden", "absent"}
DET_MAX_DT = 0.08  # a run detection this close to a keyframe can give a checked robot its box
HIDDEN_REACH = 2  # checked keyframes either side used to place a hidden robot (to mask it)
HAND_METHOD = "hand_check"  # team_id method / path_source of autos taken from a check
HAND_ID_SHARE = 0.5  # a tracked robot is a checked team's when within MATCH_RADIUS_M of this share of its clicks
_frames_lock = threading.Lock()
_apply_lock = threading.Lock()


def match_dir(match_key: str) -> Path:
    return Path(settings.output_dir) / match_key


def gt_path(match_key: str) -> Path:
    return match_dir(match_key) / "ground_truth.json"


def video_dir() -> Path:
    # Kept for re-tracking labelled matches; outside the (synced) workspace, re-downloaded if cleaned up.
    return Path(tempfile.gettempdir()) / "vision-tracker" / "ground-truth-videos"


def find_video(match_key: str) -> Path | None:
    return next(iter(sorted(video_dir().glob(f"{match_key}.*"))), None)


def ensure_video(match_key: str, tba_match: dict) -> Path:
    """Keep a copy of the match video for labelling (scouting deletes its copies)."""
    from app.services import scout_jobs

    found = find_video(match_key)
    if found is not None:
        return found
    video = scout_jobs.youtube_video(tba_match)
    if video is None:
        raise FileNotFoundError(f"The Blue Alliance has no YouTube video for {match_key}")
    downloaded = Path(scout_jobs.download_video(video[0], f"{match_key}_gt"))
    video_dir().mkdir(parents=True, exist_ok=True)
    target = video_dir() / f"{match_key}{downloaded.suffix}"
    shutil.move(str(downloaded), str(target))
    return target


def _read_json(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def load_output(match_key: str) -> dict:
    robots = _read_json(match_dir(match_key) / "robots.json")
    if not robots:
        raise FileNotFoundError(f"No tracked robots saved for {match_key}")
    return robots


def geometry(robots_doc: dict) -> tuple[CameraModel, FieldTerrain]:
    run = _read_json(Path(settings.output_dir) / "runs" / f"{robots_doc.get('run_id')}.json") or {}
    ctx = run.get("context") or {}
    camera = CameraModel.from_run_context(ctx)
    if camera is None:
        raise ValueError("The match's tracking run has no 3D camera calibration")
    dims = ctx.get("field_dims") or robots_doc.get("field_dims_m") or (16.54, 8.21)
    season = int(ctx.get("season") or str(robots_doc.get("match_key", "0"))[:4])
    terrain = FieldTerrain.from_registry(season, str(ctx.get("tag_layout_transform") or "none"), float(dims[0]), float(dims[1]))
    return camera, terrain


def keyframe_times(start: float, end: float) -> list[float]:
    n = int(math.floor((end - start) * GT_HZ + 1e-6)) + 1
    return [round(start + k / GT_HZ, 3) for k in range(n)]


def position_at(traj: list[dict], t_rel: float) -> tuple[float, float] | None:
    """Robot centre at ``t_rel`` (seconds from the output's start), linearly interpolated."""
    if not traj:
        return None
    ts = [s["t_sec"] for s in traj]
    i = int(np.searchsorted(ts, t_rel))
    if i < len(ts) and abs(ts[i] - t_rel) < 1e-6:
        return traj[i]["x_m"], traj[i]["y_m"]
    if 0 < i < len(ts) and ts[i] - ts[i - 1] <= 0.6:
        a, b = traj[i - 1], traj[i]
        w = (t_rel - a["t_sec"]) / max(1e-9, b["t_sec"] - a["t_sec"])
        return a["x_m"] + w * (b["x_m"] - a["x_m"]), a["y_m"] + w * (b["y_m"] - a["y_m"])
    near = min((j for j in (i - 1, i) if 0 <= j < len(ts)), key=lambda j: abs(ts[j] - t_rel))
    if abs(ts[near] - t_rel) <= 0.2:
        return traj[near]["x_m"], traj[near]["y_m"]
    return None


def _to_px(camera: CameraModel, terrain: FieldTerrain, xy: tuple[float, float] | None) -> list[float] | None:
    if xy is None:
        return None
    z = terrain.height(*xy) + 0.5 * terrain.robot_size[2]
    px = camera.project(np.array([[xy[0], xy[1], z]]))[0]
    return None if np.isnan(px).any() else [round(float(px[0]), 1), round(float(px[1]), 1)]


def _to_field(camera: CameraModel, terrain: FieldTerrain, u: float, v: float) -> tuple[float, float] | None:
    """Field centre of a robot whose middle was clicked at (u, v)."""
    half_h = 0.5 * terrain.robot_size[2]
    p = camera.hit_plane(u, v, half_h)
    for _ in range(2):  # settle onto bumps/platforms
        if p is None:
            return None
        p = camera.hit_plane(u, v, terrain.height(p[0], p[1]) + half_h)
    return None if p is None else (float(p[0]), float(p[1]))


def _teams(robots_doc: dict) -> list[dict]:
    teams = [
        {"team_key": r["team_key"], "alliance": r.get("alliance")} for r in robots_doc.get("robots", []) if r.get("team_key")
    ]
    seen = {t["team_key"] for t in teams}
    for m in robots_doc.get("missing_teams") or []:
        if m.get("team_key") and m["team_key"] not in seen:
            teams.append({"team_key": m["team_key"], "alliance": m.get("alliance")})
            seen.add(m["team_key"])
    order = {"red": 0, "blue": 1}
    return sorted(teams, key=lambda t: (order.get(t["alliance"], 2), t["team_key"]))


def session(match_key: str, video_path: Path) -> dict:
    """Everything the labelling screen needs: keyframes, suggestions and saved labels."""
    doc = load_output(match_key)
    camera, terrain = geometry(doc)
    saved = _read_json(gt_path(match_key)) or {}
    start = float(saved.get("start_sec", doc.get("tracking_start_sec") or 0.0))
    end = float(saved.get("end_sec", doc.get("tracking_end_sec") or start + 20.0))
    times = keyframe_times(start, end)
    out_start = float(doc.get("tracking_start_sec") or 0.0)
    suggest: dict[str, list] = {}
    others: list[list] = []
    for r in doc.get("robots", []):
        traj = sorted(r.get("trajectory") or [], key=lambda s: s["t_sec"])
        pts = [_to_px(camera, terrain, position_at(traj, t - out_start)) for t in times]
        if r.get("team_key"):
            suggest[r["team_key"]] = pts
        elif any(pts):
            others.append(pts)
    cap = cv2.VideoCapture(str(video_path))
    size = [int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)]
    cap.release()
    return {
        "match_key": match_key,
        "start_sec": start,
        "end_sec": end,
        "times": times,
        "video_size": size,
        "teams": saved.get("teams") or _teams(doc),
        "suggest": suggest,
        "others": others,
        "labels": saved.get("labels") or {},
        "complete": bool(saved.get("complete")),
        "match_radius_m": MATCH_RADIUS_M,
    }


def frame_jpeg(video_path: Path, t_sec: float) -> bytes:
    cap = cv2.VideoCapture(str(video_path))
    try:
        cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, t_sec) * 1000.0)
        ok, frame = cap.read()
    finally:
        cap.release()
    if not ok:
        raise ValueError(f"No video frame at {t_sec:.2f}s")
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return buf.tobytes()


def save(match_key: str, payload: dict) -> dict:
    """Store labels; clicked pixels are turned into field positions here."""
    doc = load_output(match_key)
    camera, terrain = geometry(doc)
    start = float(payload["start_sec"])
    end = float(payload["end_sec"])
    times = keyframe_times(start, end)
    teams = [
        {"team_key": str(t["team_key"]), "alliance": t.get("alliance")} for t in payload.get("teams") or [] if t.get("team_key")
    ]
    labels: dict[str, list] = {}
    for t in teams:
        raw = (payload.get("labels") or {}).get(t["team_key"]) or []
        row: list = []
        for k in range(len(times)):
            item = raw[k] if k < len(raw) else None
            state = (item or {}).get("s")
            if state not in STATES:
                row.append(None)
                continue
            entry: dict = {"s": state}
            if state == "pos":
                u, v = (float(c) for c in item["px"])
                xy = _to_field(camera, terrain, u, v)
                if xy is None:
                    row.append(None)
                    continue
                entry["px"] = [round(u, 1), round(v, 1)]
                entry["xy"] = [round(xy[0], 3), round(xy[1], 3)]
            row.append(entry)
        labels[t["team_key"]] = row
    data = {
        "match_key": match_key,
        "start_sec": start,
        "end_sec": end,
        "hz": GT_HZ,
        "times": times,
        "teams": teams,
        "labels": labels,
        "complete": bool(payload.get("complete")),
        "saved_at": time.time(),
    }
    write(match_key, data)
    return data


def write(match_key: str, data: dict) -> None:
    path = gt_path(match_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    tmp.replace(path)


def load(match_key: str) -> dict | None:
    return _read_json(gt_path(match_key))


# ------------------------------------------------------- training pictures ---


def _label(gt: dict, tk: str, k: int) -> dict | None:
    row = gt["labels"].get(tk) or []
    return row[k] if k < len(row) else None


def _tracked_team(robot: dict) -> str | None:
    """The team tracking gave a saved robot, not the one a finished check set (``apply_to_autos``)."""
    return robot["tracker_team_key"] if "tracker_team_key" in robot else robot.get("team_key")


def _guesses(gt: dict, doc: dict) -> dict[str, list]:
    """Each checked team's tracked position at every keyframe (the check screen's suggestion)."""
    out_start = float(doc.get("tracking_start_sec") or 0.0)
    trajs = {
        tk: sorted(r.get("trajectory") or [], key=lambda s: s["t_sec"])
        for r in doc.get("robots", [])
        if (tk := _tracked_team(r))
    }
    return {
        t["team_key"]: [position_at(trajs.get(t["team_key"]) or [], tt - out_start) for tt in gt["times"]]
        for t in gt["teams"]
    }


def corrected_keyframes(gt: dict, doc: dict) -> list[int]:
    """Keyframes where the check disagrees with the saved autos - the ones scored as misses:
    a robot placed more than ``MATCH_RADIUS_M`` from its tracked spot (or one the autos lost),
    or a robot marked not on the field that the autos still show."""
    guess = _guesses(gt, doc)
    out = []
    for k in range(len(gt["times"])):
        for tk, row in guess.items():
            lab = _label(gt, tk, k)
            if not lab:
                continue
            g = row[k]
            moved = lab["s"] == "pos" and (g is None or math.dist(g, lab["xy"]) > MATCH_RADIUS_M)
            if moved or (lab["s"] == "absent" and g is not None):
                out.append(k)
                break
    return out


def _training_keyframes(gt: dict, doc: dict) -> tuple[list[int], list[int]]:
    """(corrected keyframes, those with every team checked - only these become pictures)."""
    teams = [t["team_key"] for t in gt["teams"]]
    corrected = corrected_keyframes(gt, doc)
    ready = [k for k in corrected if len(teams) == 6 and all(_label(gt, tk, k) for tk in teams)]
    return corrected, ready


def training_status(match_key: str, dataset_root: Path) -> dict:
    """How a match's check feeds the robot detector."""
    gt = load(match_key)
    corrected, ready = _training_keyframes(gt, load_output(match_key)) if gt else ([], [])
    return {
        "corrected": len(corrected),
        "ready": len(ready),
        "pictures": len(list(td.checked_dir(dataset_root).glob(f"{td.safe_name(match_key)}__*.jpg"))),
        "collecting": settings.collect_training_frames,
    }


def _hidden_xy(gt: dict, guess: dict[str, list], tk: str, k: int) -> tuple[float, float] | None:
    """Where a robot marked hidden probably is: between its nearest checked positions."""
    n = len(gt["times"])
    near = [
        (j, lab["xy"])
        for j in range(max(0, k - HIDDEN_REACH), min(n, k + HIDDEN_REACH + 1))
        if (lab := _label(gt, tk, j)) and lab["s"] == "pos"
    ]
    before = [p for p in near if p[0] < k]
    after = [p for p in near if p[0] > k]
    if before and after:
        (ja, a), (jb, b) = before[-1], after[0]
        w = (k - ja) / (jb - ja)
        return a[0] + w * (b[0] - a[0]), a[1] + w * (b[1] - a[1])
    if near:
        return tuple(min(near, key=lambda p: abs(p[0] - k))[1])
    return guess[tk][k]


def _cuboid_box(camera: CameraModel, terrain: FieldTerrain, xy) -> list[float] | None:
    """Pixel box around a standard robot standing at ``xy``."""
    length, width, height = terrain.robot_size
    x, y = xy
    z = terrain.height(x, y)
    corners = np.array(
        [[x + dx, y + dy, z + dz] for dx in (-length / 2, length / 2) for dy in (-width / 2, width / 2) for dz in (0.0, height)]
    )
    img = camera.project(corners)
    if np.isnan(img).any():
        return None
    return [float(img[:, 0].min()), float(img[:, 1].min()), float(img[:, 0].max()), float(img[:, 1].max())]


def _scaled(box: list[float], ratio: tuple[float, float]) -> list[float]:
    """``box`` resized to real robot proportions, keeping its bottom centre on the floor."""
    cx = (box[0] + box[2]) / 2
    w, h = (box[2] - box[0]) * ratio[0], (box[3] - box[1]) * ratio[1]
    return [cx - w / 2, box[3] - h, cx + w / 2, box[3]]


def _run_detections(doc: dict, terrain: FieldTerrain) -> dict[float, list[list[float]]]:
    """Robot boxes the tracking run saw, by video time."""
    from app.tracking.pipeline import load_run

    run_file = Path(settings.output_dir) / "runs" / f"{doc.get('run_id')}.json"
    if not run_file.is_file():
        return {}
    out: dict[float, list[list[float]]] = defaultdict(list)
    for tr in load_run(run_file, terrain)["tracker"].tracks:
        for o in tr.obs:
            det = o.get("det") or {}
            if det.get("bbox") is not None and not det.get("split"):
                out[round(float(o["t"]), 3)].append([float(v) for v in det["bbox"]])
    return out


def _dets_at(dets: dict[float, list], t: float) -> list[list[float]]:
    if not dets:
        return []
    near = min(dets, key=lambda s: abs(s - t))
    return dets[near] if abs(near - t) <= DET_MAX_DT else []


def _detected_boxes(boxes: list[list[float]], clicks: dict[str, tuple]) -> dict[str, list[float]]:
    """Run detection of each clicked robot: a box around its click and no other click, and
    of a plausible size for a robot there (``clicks``: team -> (pixel, projected box))."""
    out: dict[str, list[float]] = {}

    def off(b: list[float], px) -> float:
        return math.dist(px, ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2))

    for b in boxes:
        inside = [tk for tk, (px, _) in clicks.items() if b[0] <= px[0] <= b[2] and b[1] <= px[1] <= b[3]]
        if len(inside) != 1:
            continue  # nothing checked there, or two robots in one box
        tk = inside[0]
        px, cub = clicks[tk]
        if cub is None or not 0.4 <= (b[2] - b[0]) / max(1.0, cub[2] - cub[0]) <= 3.0:
            continue
        if tk not in out or off(b, px) < off(out[tk], px):
            out[tk] = b
    return out


def save_training_frames(match_key: str, video_path: Path, dataset_root: Path) -> int:
    """Turn the keyframes a check corrected into robot detector training pictures.

    Only keyframes where every team was checked are used. Each robot on the field
    gets a box (the run's detection around the click when there is exactly one,
    otherwise a robot-sized box at the clicked spot), hidden robots are masked, and
    anything else the tracker saw stays background, so wrongly found things are
    trained away. Pictures go to ``checked/`` (``frames/`` belongs to scouting).
    Returns the number of pictures saved.
    """
    from app.tracking.team_id import bumper_strip_box

    with _frames_lock:
        folder = td.checked_dir(dataset_root)
        name = td.safe_name(match_key)
        for old in folder.glob(f"{name}__*.jpg"):
            old.unlink(missing_ok=True)
        (folder / f"{name}.json").unlink(missing_ok=True)
        gt = load(match_key)
        if not gt:
            return 0
        doc = load_output(match_key)
        teams = {t["team_key"]: t.get("alliance") for t in gt["teams"]}
        _, keys = _training_keyframes(gt, doc)
        if not keys:
            return 0
        camera, terrain = geometry(doc)
        guess = _guesses(gt, doc)
        dets = _run_detections(doc, terrain)

        # Detections of checked robots tell how much bigger real robots look than the standard box.
        per_k: dict[int, tuple[dict, dict]] = {}
        rw, rh = [], []
        for k, t in enumerate(gt["times"]):
            clicks = {
                tk: (lab["px"], _cuboid_box(camera, terrain, lab["xy"]))
                for tk in teams
                if (lab := _label(gt, tk, k)) and lab["s"] == "pos"
            }
            found = _detected_boxes(_dets_at(dets, t), clicks)
            per_k[k] = (clicks, found)
            for tk, b in found.items():
                cub = clicks[tk][1]
                rw.append((b[2] - b[0]) / max(1.0, cub[2] - cub[0]))
                rh.append((b[3] - b[1]) / max(1.0, cub[3] - cub[1]))
        ratio = (float(np.clip(np.median(rw), 0.5, 3.0)), float(np.clip(np.median(rh), 0.5, 3.0))) if rw else (1.0, 1.0)

        folder.mkdir(parents=True, exist_ok=True)
        items = []
        cap = cv2.VideoCapture(str(video_path))
        try:
            for k in keys:
                t = gt["times"][k]
                cap.set(cv2.CAP_PROP_POS_MSEC, max(0.0, t) * 1000.0)
                ok, img = cap.read()
                if not ok:
                    continue
                H, W = img.shape[:2]
                clicks, found = per_k[k]
                robots, bumpers, masks, usable = [], [], [], True
                for tk, alliance in teams.items():
                    lab = _label(gt, tk, k)
                    if lab["s"] == "absent":
                        continue
                    if lab["s"] == "hidden":
                        xy = _hidden_xy(gt, guess, tk, k)
                        cub = _cuboid_box(camera, terrain, xy) if xy is not None else None
                        if cub is None:
                            usable = False  # can't say what to hide
                            break
                        masks.append(td._grow(_scaled(cub, ratio), 0.3))
                        continue
                    box = found.get(tk) or (_scaled(clicks[tk][1], ratio) if clicks[tk][1] else None)
                    b = td._clip(box, W, H) if box else None
                    if b is None:
                        usable = False
                        break
                    robots.append({"box": b, "robot_id": tk, "team_key": tk, "alliance": alliance})
                    strip = bumper_strip_box(img, b, alliance) if alliance in ("red", "blue") else None
                    if strip is not None:
                        bumpers.append({"box": [float(v) for v in strip], "cls": 1 if alliance == "red" else 2})
                out_masks = [m for m in (td._clip(m, W, H) for m in masks) if m is not None]
                if not usable or any(td._overlap(r["box"], m) > 0.25 for r in robots for m in out_masks):
                    continue  # a mask would erase part of a labelled robot
                fname = f"{name}__gt{int(round(t * 1000)):07d}.jpg"
                cv2.imwrite(str(folder / fname), img, [cv2.IMWRITE_JPEG_QUALITY, 88])
                items.append(
                    {
                        "image": f"../{folder.name}/{fname}",  # relative to the frames folder
                        "width": W,
                        "height": H,
                        "robots": robots,
                        "bumpers": bumpers,
                        "masks": out_masks,
                    }
                )
        finally:
            cap.release()
        if items:
            payload = {"match_key": match_key, "saved_at": gt.get("saved_at"), "items": items}
            (folder / f"{name}.json").write_text(json.dumps(payload), encoding="utf-8")
        return len(items)


def score(gt: dict, robots: list[dict], out_start: float) -> dict:
    """Compare tracked robots (``trajectory`` with t from ``out_start``) to labels."""
    times = gt["times"]
    teams = [t["team_key"] for t in gt["teams"]]
    tracks = [
        (_tracked_team(r), sorted(r.get("trajectory") or [], key=lambda s: s["t_sec"]))
        for r in robots
        if r.get("trajectory")
    ]
    pos = {
        tk: [(k, lab["xy"]) for k, lab in enumerate(gt["labels"].get(tk) or []) if lab and lab.get("s") == "pos"]
        for tk in teams
    }
    absent = {
        tk: [k for k, lab in enumerate(gt["labels"].get(tk) or []) if lab and lab.get("s") == "absent"] for tk in teams
    }
    pred = [[position_at(traj, t - out_start) for t in times] for _, traj in tracks]

    def hits(tk: str, j: int) -> int:
        return sum(
            1 for k, xy in pos[tk] if pred[j][k] is not None and math.dist(pred[j][k], xy) <= MATCH_RADIUS_M
        )

    hit = np.array([[hits(tk, j) for j in range(len(tracks))] for tk in teams], dtype=float).reshape(len(teams), len(tracks))
    pairs = dict(zip(*linear_sum_assignment(-hit))) if hit.size else {}
    per_team = []
    for i, tk in enumerate(teams):
        n = len(pos[tk])
        j_team = next((j for j, (key, _) in enumerate(tracks) if key == tk), None)
        tracked = int(hit[i, pairs[i]]) if i in pairs else 0
        e2e = int(hit[i, j_team]) if j_team is not None else 0
        ghost = sum(1 for k in absent[tk] if j_team is not None and pred[j_team][k] is not None)
        per_team.append(
            {
                "team_key": tk,
                "labelled": n,
                "hidden": sum(1 for lab in gt["labels"].get(tk) or [] if lab and lab.get("s") == "hidden"),
                "tracking_hits": tracked,
                "end_to_end_hits": e2e,
                "ghost_points": ghost,
                "tracking": tracked / n if n else None,
                "end_to_end": e2e / n if n else None,
            }
        )
    return summarize(per_team)


def summarize(per_team: list[dict]) -> dict:
    n = sum(t["labelled"] for t in per_team)
    scored = [t for t in per_team if t["labelled"]]
    return {
        "labelled": n,
        "tracking": sum(t["tracking_hits"] for t in per_team) / n if n else None,
        "end_to_end": sum(t["end_to_end_hits"] for t in per_team) / n if n else None,
        "robot_autos": len(scored),
        "robot_autos_passing": sum(1 for t in scored if t["end_to_end"] >= PASS_SHARE),
        "ghost_points": sum(t["ghost_points"] for t in per_team),
        "teams": per_team,
    }


def score_saved(match_key: str) -> dict:
    gt = _read_json(gt_path(match_key))
    if not gt:
        raise FileNotFoundError(f"No checked robot positions for {match_key}")
    doc = load_output(match_key)
    result = score(gt, doc.get("robots", []), float(doc.get("tracking_start_sec") or 0.0))
    return {"match_key": match_key, "complete": bool(gt.get("complete")), **result}


def labelled_matches(season: int | None = None, complete_only: bool = True) -> list[str]:
    keys = []
    for p in sorted(Path(settings.output_dir).glob("*/ground_truth.json")):
        mk = p.parent.name
        if season is not None and not mk.startswith(str(season)):
            continue
        gt = _read_json(p) or {}
        if gt.get("complete") or not complete_only:
            keys.append(mk)
    return keys


# ------------------------------------------------------ checks as the autos ---


def _hand_robots(gt: dict, doc: dict) -> dict[str, int]:
    """Which saved tracked robot (index in robots.json) each checked team is, from the clicks."""
    out_start = float(doc.get("tracking_start_sec") or 0.0)
    robots = doc.get("robots", [])
    teams = gt["teams"]
    preds = [
        [position_at(sorted(r.get("trajectory") or [], key=lambda s: s["t_sec"]), t - out_start) for t in gt["times"]]
        for r in robots
    ]
    hit = np.zeros((len(teams), len(robots)))
    need = []
    for i, t in enumerate(teams):
        pos = [(k, lab["xy"]) for k, lab in enumerate(gt["labels"].get(t["team_key"]) or []) if lab and lab.get("s") == "pos"]
        need.append(max(2.0, HAND_ID_SHARE * len(pos)))
        for j, r in enumerate(robots):
            if t.get("alliance") and r.get("alliance") and t["alliance"] != r["alliance"]:
                continue
            hit[i, j] = sum(1 for k, xy in pos if preds[j][k] is not None and math.dist(preds[j][k], xy) <= MATCH_RADIUS_M)
    if not hit.size:
        return {}
    rows, cols = linear_sum_assignment(-hit)
    return {teams[i]["team_key"]: int(j) for i, j in zip(rows, cols) if hit[i, j] >= need[i]}


def _hand_path(gt: dict, team_key: str, out_start: float, terrain: FieldTerrain) -> list[dict]:
    """A checked team's auto from the clicks (calibration frame). Robots marked hidden are
    placed between the clicks either side; time marked not on the field starts a new segment."""
    row = gt["labels"].get(team_key) or []
    labs = [row[k] if k < len(row) else None for k in range(len(gt["times"]))]
    clicked = [k for k, lab in enumerate(labs) if lab and lab.get("s") == "pos"]
    if not clicked:
        return []
    pts: list[dict] = []
    seg = 0
    for k, (t, lab) in enumerate(zip(gt["times"], labs)):
        if not lab:
            continue
        if lab["s"] == "absent":
            if pts and pts[-1]["segment"] == seg:
                seg += 1
            continue
        hidden = lab["s"] == "hidden"
        extra = {}
        if hidden:
            before = [j for j in clicked if j < k]
            after = [j for j in clicked if j > k]
            if before and after:
                ja, jb = before[-1], after[0]
                a, b, w = labs[ja]["xy"], labs[jb]["xy"], (k - ja) / (jb - ja)
                xy = (a[0] + w * (b[0] - a[0]), a[1] + w * (b[1] - a[1]))
            else:
                xy = labs[before[-1] if before else after[0]]["xy"]
        else:
            xy = lab["xy"]
            extra = {"px": lab["px"][0], "py": lab["px"][1]}
        x, y = float(xy[0]), float(xy[1])
        pts.append(
            {
                "t_sec": round(t - out_start, 3),
                "x_m": x,
                "y_m": y,
                "z_m": round(float(terrain.height(x, y)), 3),
                "confidence": 0.5 if hidden else 1.0,
                "inferred": hidden,
                "occluded": hidden,
                "segment": seg,
                "kind": "drive",
                **extra,
            }
        )
    return pts


def swap_teams(match_key: str, team_a: str, team_b: str) -> list[str]:
    """Swap two teams' clicks in a finished check (mixed up while checking) and
    rebuild the match's autos from it. Returns the rewritten team files."""
    gt = load(match_key)
    if not gt or not gt.get("complete"):
        raise ValueError(f"{match_key} has no finished hand check")
    alliance = {t["team_key"]: t.get("alliance") for t in gt.get("teams") or []}
    for tk in (team_a, team_b):
        if tk not in alliance:
            raise ValueError(f"{tk[3:]} is not in the hand check of {match_key}")
    if alliance[team_a] != alliance[team_b]:
        raise ValueError("Only teams on the same alliance can be swapped")
    try:
        geometry(load_output(match_key))  # the autos can be rebuilt
    except (FileNotFoundError, ValueError) as exc:
        raise ValueError(f"Can't rebuild the autos of {match_key}: {exc}") from exc
    labels = gt.setdefault("labels", {})
    labels[team_a], labels[team_b] = labels.get(team_b) or [], labels.get(team_a) or []
    gt["saved_at"] = time.time()
    write(match_key, gt)
    return apply_to_autos(match_key)


def apply_to_autos(match_key: str) -> list[str]:
    """Make a finished check the match's saved autos.

    Every checked team's path becomes its clicks and its team counts as known
    (``team_history`` never changes it). In robots.json the tracked robot that
    follows a team's clicks gets that team, so team-look training learns the
    right robots; ``tracker_team_key`` keeps tracking's own answer for scoring.
    Returns the rewritten team files ([] when not finished or already applied).
    """
    with _apply_lock:
        gt = load(match_key)
        if not gt or not gt.get("complete"):
            return []
        try:
            doc = load_output(match_key)
            _, terrain = geometry(doc)
        except (FileNotFoundError, ValueError):
            return []
        stamp = gt.get("saved_at")
        files = {t["team_key"]: team_path_file(match_key, t["team_key"]) for t in gt["teams"]}
        files = {tk: p for tk, p in files.items() if p is not None}
        current = {tk: _read_json(p) or {} for tk, p in files.items()}
        if all(c.get("hand_check_saved_at") == stamp for c in current.values()):
            return []

        robots = doc.get("robots", [])
        robot_of = _hand_robots(gt, doc)
        team_of = {j: tk for tk, j in robot_of.items()}
        tid = {"method": HAND_METHOD, "confidence": 1.0, "needs_review": False}
        for j, r in enumerate(robots):
            r.setdefault("tracker_team_key", r.get("team_key"))
            if j in team_of:
                r["team_key"], r["team_id"] = team_of[j], dict(tid)
            elif r.get("team_key") in files:
                r["team_key"], r["team_id"] = None, None  # that team is another robot (or none)
        assigned = {r.get("team_key") for r in robots if r.get("team_key")}
        lineup = doc.get("lineup") or {c: [t["team_key"] for t in gt["teams"] if t.get("alliance") == c] for c in ("red", "blue")}
        doc["missing_teams"] = [
            {"team_key": t, "alliance": c} for c in ("red", "blue") for t in lineup.get(c) or [] if t and t not in assigned
        ]
        write_path = match_dir(match_key) / "robots.json"
        tmp = write_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(doc, indent=1), encoding="utf-8")
        tmp.replace(write_path)

        out_start = float(doc.get("tracking_start_sec") or 0.0)
        transform, dims = doc.get("field_transform"), doc.get("field_dims_m")
        written = []
        for t in gt["teams"]:
            tk = t["team_key"]
            if tk not in files:
                continue
            base = current[tk] if current[tk].get("team_key") else not_detected_doc(match_key, tk, t.get("alliance"), doc)
            pts = to_wpilib_points(_hand_path(gt, tk, out_start, terrain), transform, dims)
            clicked = [p for p in pts if not p["inferred"]]
            old = base.get("team_id") or {}
            team_id = {**tid, "previous": old.get("previous")} if old.get("method") == HAND_METHOD else {
                **tid,
                "previous": {"team_key": tk, "method": old.get("method"), "confidence": old.get("confidence")},
            }
            j = robot_of.get(tk)
            length = sum(
                math.dist((a["x_m"], a["y_m"]), (b["x_m"], b["y_m"])) for a, b in zip(pts, pts[1:]) if a["segment"] == b["segment"]
            )
            new = {
                **base,
                "alliance": t.get("alliance") or base.get("alliance"),
                # a robot tracking never followed still needs a slot to count as seen
                "robot_slot": (robots[j].get("robot_id") if j is not None else f"hand_{tk[3:]}") if pts else None,
                "team_id": team_id,
                "field_frame": FIELD_FRAME,
                "first_t_sec": pts[0]["t_sec"] if pts else None,
                "last_t_sec": pts[-1]["t_sec"] if pts else None,
                "observed_fraction": round(len(clicked) / max(1, len(gt["times"])), 3),
                "detected": bool(pts),
                "path_summary": {
                    "source": HAND_METHOD,
                    "node_count": len(clicked),
                    "hide_count": len(pts) - len(clicked),
                    "path_length_m": round(length, 2),
                    "mean_confidence": round(float(np.mean([p["confidence"] for p in pts])), 3) if pts else 0.0,
                    "inferred_fraction": round(1 - len(clicked) / len(pts), 3) if pts else 0.0,
                    "max_z_m": max((p["z_m"] for p in pts), default=0.0),
                },
                "path_nodes": [
                    {
                        **{k: p[k] for k in ("t_sec", "x_m", "y_m", "z_m", "confidence")},
                        "kind": "start" if i == 0 else "end" if i == len(clicked) - 1 else "observed",
                        "z_source": HAND_METHOD,
                    }
                    for i, p in enumerate(clicked)
                ],
                "path_points": pts,
                "trajectory": [
                    {
                        **{k: p[k] for k in ("t_sec", "x_m", "y_m", "confidence", "inferred", "z_m")},
                        "sigma_m": 0.3 if p["inferred"] else 0.1,
                        "position_confidence": p["confidence"],
                        "identity_confidence": 1.0,
                        "z_source": HAND_METHOD,
                        "track_id": None,
                    }
                    for p in pts
                ],
                "path_source": HAND_METHOD,
                "hand_check_saved_at": stamp,
            }
            path = files[tk]
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(new, indent=1), encoding="utf-8")
            written.append(str(path.resolve()))
        return written


def season_score(season: int) -> dict:
    matches = []
    for mk in labelled_matches(season):
        try:
            matches.append(score_saved(mk))
        except (FileNotFoundError, ValueError):
            continue
    total = summarize([t for m in matches for t in m["teams"]])
    total.pop("teams")
    return {"season": season, "matches": matches, "total": total, "match_radius_m": MATCH_RADIUS_M, "pass_share": PASS_SHARE}
