"""Re-track hand-checked matches and score them, to compare tracking settings.

    python -m app.services.track_eval --season 2026              # current settings
    python -m app.services.track_eval --season 2026 --hz 15      # another frame rate
    python -m app.services.track_eval --season 2026 --saved      # just score the saved autos

Nothing is written to the match outputs. Matches must be checked by hand
first (Autos gallery -> Check); their videos are kept for this.
"""

from __future__ import annotations

import argparse
import asyncio
import json
import time

from app.core.config import settings
from app.core.runtime_config import get_runtime_config
from app.services import detector_training, ground_truth, rescout
from app.services.tba_client import get_event_matches
from app.services.trajectory_export import parse_match_key
from app.tracking.pipeline import follow_all, track_all_robots


def _video(match_key: str):
    found = ground_truth.find_video(match_key)
    if found is not None:
        return found
    key = str(get_runtime_config().get("tba_auth_key") or settings.tba_auth_key or "").strip()
    matches = asyncio.run(get_event_matches(parse_match_key(match_key)["event_key"], key))
    match = next(m for m in matches if m.get("key") == match_key)
    return ground_truth.ensure_video(match_key, match)


def retrack(match_key: str, season: int, hz: float, models, teams: bool, dense: bool = True) -> tuple[dict, float]:
    gt = json.loads(ground_truth.gt_path(match_key).read_text(encoding="utf-8"))
    doc = ground_truth.load_output(match_key)
    camera, terrain = ground_truth.geometry(doc)
    terrain.build_visibility(camera)
    video = str(_video(match_key))
    lineup = {c: [t["team_key"] for t in gt["teams"] if t["alliance"] == c] for c in ("red", "blue")}
    started = time.time()
    run = track_all_robots(
        video_path=video,
        camera=camera,
        terrain=terrain,
        tracking_start_sec=gt["start_sec"],
        tracking_end_sec=gt["end_sec"],
        process_hz=hz,
        robot_model=models,
    )
    if teams and dense:
        from app.tracking.team_id import read_tracklet_numbers

        read_tracklet_numbers(run, video, lineup)
    robots, _ = follow_all(run, camera=camera, terrain=terrain)
    if teams:
        from app.tracking import appearance
        from app.tracking.team_id import identify_teams

        try:
            ids = identify_teams(
                run, robots, video, lineup, max_frames=12, gallery=detector_training.team_gallery(season, match_key)
            )
        finally:
            appearance.release()
        for r in robots:
            if ids.get(r["robot_id"]):
                r["team_key"] = ids[r["robot_id"]]["team_key"]
    for r in robots:
        r["trajectory"] = r.get("samples") or []
    result = ground_truth.score(gt, robots, gt["start_sec"])
    return result, time.time() - started


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--season", type=int, required=True)
    ap.add_argument("--hz", type=float, default=settings.track_hz)
    ap.add_argument("--models", choices=["current", "trained", "world"], default="current")
    ap.add_argument("--no-teams", action="store_true", help="skip team identification (tracking score only)")
    ap.add_argument("--no-dense", action="store_true", help="skip the all-match bumper number reads")
    ap.add_argument("--saved", action="store_true", help="score the saved autos instead of re-tracking")
    ap.add_argument("--matches", nargs="*", help="only these match keys")
    args = ap.parse_args()

    keys = [k for k in ground_truth.labelled_matches(args.season) if not args.matches or k in args.matches]
    if not keys:
        raise SystemExit("No hand-checked matches (tick 'Every frame checked' in the Check screen).")
    models = {
        "current": detector_training.tracking_models(args.season),
        "trained": detector_training.active_model(args.season),
        "world": settings.robot_model,
    }[args.models]
    good = rescout.season_good_matches(args.season)
    per_team = []
    print(f"{'match':24} {'track':>7} {'team':>7} {'n':>5} {'sec':>6}  worst robots")
    for mk in keys:
        if args.saved:
            res, secs = ground_truth.score_saved(mk), 0.0
        else:
            res, secs = retrack(mk, args.season, args.hz, models, not args.no_teams, not args.no_dense)
        per_team += res["teams"]
        worst = sorted((t for t in res["teams"] if t["labelled"]), key=lambda t: t["end_to_end"])[:2]
        note = " (detector trained on it)" if mk in good else ""
        print(
            f"{mk:24} {100 * (res['tracking'] or 0):6.1f}% {100 * (res['end_to_end'] or 0):6.1f}% {res['labelled']:5d} {secs:6.0f}  "
            + ", ".join(f"{t['team_key'][3:]} {100 * t['end_to_end']:.0f}%" for t in worst)
            + note
        )
    total = ground_truth.summarize(per_team)
    print(
        f"\nTOTAL tracking {100 * (total['tracking'] or 0):.1f}%  with team {100 * (total['end_to_end'] or 0):.1f}%  "
        f"robot autos >= {100 * ground_truth.PASS_SHARE:.0f}%: {total['robot_autos_passing']}/{total['robot_autos']}  "
        f"ghost points {total['ghost_points']}  ({'saved autos' if args.saved else f'{args.hz} Hz, {args.models} models'})"
    )


if __name__ == "__main__":
    main()
