"""Robot detector training, run in its own process by ``detector_training``.

A separate process starts with an empty GPU (the server keeps OCR and tracking
models loaded) and gives all of its memory back when it ends, even after an
out-of-memory error. After training, the new model, the current one and the
YOLO-World baseline are scored on the same held-out full frames
(``evaluation.detector_eval``). Progress and the result are printed as marked
JSON lines; exit code 3 means it ran out of GPU memory.

Training on several team GPUs (``team_training``) uses three more modes:
``round`` trains a few epochs on one computer's share of the tiles and saves the
weights (a plain state dict), ``average`` averages those into a model and scores
it on the held-out tiles, ``eval`` only runs the held-out frame test.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

MARK = "@@HS "
OOM_EXIT = 3


def _emit(**kw) -> None:
    print(MARK + json.dumps(kw), flush=True)


def _state_dict(model) -> dict:
    """Weights only (half precision): safe to load with ``weights_only=True``."""
    import torch

    return {k: v.detach().half() if v.is_floating_point() else v.detach() for k, v in model.state_dict().items()}


def _average(base: str, parts: list, out: str) -> None:
    """Average state dicts ``[[file, weight], ...]`` into a copy of the ``base`` checkpoint."""
    import torch

    ckpt = torch.load(base, map_location="cpu", weights_only=False)  # this computer's own model file
    model = (ckpt.get("ema") or ckpt["model"]).float()
    total = float(sum(w for _, w in parts))
    avg: dict = {}
    for f, w in parts:
        sd = torch.load(f, map_location="cpu", weights_only=True)
        for k, v in sd.items():
            if v.is_floating_point():
                avg[k] = avg.get(k, 0) + v.float() * (w / total)
            else:
                avg.setdefault(k, v)
    model.load_state_dict(avg)
    ckpt.update(model=model.half(), ema=None, optimizer=None, epoch=-1)
    torch.save(ckpt, out)


def _evaluate(a, best: str) -> dict:
    from app.services.evaluation import detector_eval

    with open(a.eval, encoding="utf-8") as f:
        items = json.load(f)
    _emit(phase="testing")
    ev = {"new": detector_eval(best, items, a.infer_imgsz)}
    for name, path in (("current", a.current), ("baseline", a.baseline)):
        if path:
            try:
                ev[name] = detector_eval(path, items)
            except Exception as exc:  # a broken old model must not lose the new one
                ev[name] = {"error": str(exc)}
    return ev


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--mode", default="train", choices=["train", "round", "average", "eval"])
    p.add_argument("--data", default="")
    p.add_argument("--base", default="")
    p.add_argument("--project", default="")
    p.add_argument("--epochs", type=int, default=0)
    p.add_argument("--imgsz", type=int, default=640)
    p.add_argument("--batch", type=int, default=8)
    p.add_argument("--device", default="cpu")
    p.add_argument("--eval", default="", help="JSON list of held-out labelled frames")
    p.add_argument("--infer-imgsz", type=int, default=0, help="inference size of the new model (frame width)")
    p.add_argument("--current", default="", help="current model, scored on the same frames")
    p.add_argument("--baseline", default="", help="generic model (YOLO-World), scored on the same frames")
    # round mode
    p.add_argument("--weights", default="", help="state dict to start from instead of --base's weights")
    p.add_argument("--out", default="", help="round: state dict written here; average: model written here")
    p.add_argument("--lr0", type=float, default=0.0)
    p.add_argument("--lrf", type=float, default=1.0)
    p.add_argument("--mosaic", type=float, default=1.0)
    p.add_argument("--epoch-offset", type=int, default=0, help="epochs before this round (for progress)")
    p.add_argument("--epochs-total", type=int, default=0, help="epochs of the whole run (for progress)")
    # average mode
    p.add_argument("--parts", default="", help='JSON [[state dict file, weight], ...]')
    a = p.parse_args()

    import torch
    from ultralytics import YOLO

    if a.mode == "eval":
        _emit(done=True, best=a.base, eval=_evaluate(a, a.base))
        return 0

    if a.device.startswith("cuda"):
        dev = torch.device(a.device)
        free, total = torch.cuda.mem_get_info(dev)
        # Windows lets CUDA spill into shared system RAM, which makes training crawl.
        # Stay inside the VRAM that is actually free so it fails fast and steps down.
        torch.cuda.set_per_process_memory_fraction(max(0.25, (free - 300 * 2**20) / total), dev)

    if a.mode == "average":
        try:
            _average(a.base, json.loads(a.parts), a.out)
            m = YOLO(a.out).val(data=a.data, imgsz=a.imgsz, batch=a.batch, device=a.device, plots=False, verbose=False, workers=0)
        except torch.cuda.OutOfMemoryError:
            _emit(oom=True)
            return OOM_EXIT
        _emit(done=True, map50=float(m.box.map50), map=float(m.box.map))
        return 0

    try:
        model = YOLO(a.base)
        if a.weights:
            model.model.load_state_dict(torch.load(a.weights, map_location="cpu", weights_only=True))
        off = a.epoch_offset
        total = a.epochs_total or a.epochs

        def on_epoch(trainer) -> None:
            m = trainer.metrics or {}
            _emit(epoch=trainer.epoch + 1, epochs=trainer.epochs, map50=float(m.get("metrics/mAP50(B)", 0.0)))

        step = {"n": 0, "at": 0.0}

        def on_epoch_start(trainer) -> None:
            step["n"] = 0

        def on_batch(trainer) -> None:  # an epoch can take many minutes: show it moving
            step["n"] += 1
            now = time.monotonic()
            if now - step["at"] >= 5.0:
                step["at"] = now
                _emit(step=step["n"], steps=len(trainer.train_loader), epoch_now=off + trainer.epoch + 1, epochs=total)

        if a.mode == "train":  # a round's own test tiles are only a token few
            model.add_callback("on_fit_epoch_end", on_epoch)
        model.add_callback("on_train_epoch_start", on_epoch_start)
        model.add_callback("on_train_batch_end", on_batch)
        # A round continues a schedule spread over all rounds: fixed optimizer and learning
        # rate (the same AdamW "auto" picks for a short run), no warmup, no mosaic switch-off.
        extra = (
            dict(optimizer="AdamW", lr0=a.lr0, lrf=a.lrf, momentum=0.9, warmup_epochs=0, close_mosaic=0, mosaic=a.mosaic, val=False)
            if a.mode == "round"
            else dict(patience=15)
        )
        started = time.monotonic()
        model.train(
            data=a.data,
            epochs=a.epochs,
            imgsz=a.imgsz,
            batch=a.batch,
            # Parallel image loading keeps a fast GPU fed; 0 = load in this process.
            workers=min(4, (os.cpu_count() or 2) // 2) if a.device.startswith("cuda") else 0,
            device=a.device,
            project=a.project,
            name="run",
            exist_ok=True,
            plots=False,
            verbose=False,
            **extra,
        )
        trainer = model.trainer
        if a.mode == "round":
            ckpt = torch.load(trainer.last, map_location="cpu", weights_only=False)  # written just now
            torch.save(_state_dict(ckpt.get("ema") or ckpt["model"]), a.out)
            _emit(done=True, out=a.out, epochs_run=trainer.epoch + 1, seconds=time.monotonic() - started)
            return 0
        result = {
            "best": str(trainer.best),
            "epochs_run": trainer.epoch + 1,
            "metrics": {k: float(v) for k, v in (trainer.metrics or {}).items() if isinstance(v, (int, float))},
        }
        del model, trainer
        torch.cuda.empty_cache()
    except torch.cuda.OutOfMemoryError:
        _emit(oom=True)
        return OOM_EXIT

    result["eval"] = _evaluate(a, result["best"])
    _emit(done=True, **result)
    return 0


if __name__ == "__main__":
    sys.exit(main())
