"""Scouted matches shared by every team computer.

Each computer uploads the autos of the matches it scouted, and every later change
to them (team swaps, team-history fixes, hand checks), and downloads the ones the
other computers scouted. So every computer shows the same autos and can mark them
good, swap teams, tag them for re-scouting, check them by hand and train on them.
The tracking run goes along, so training pictures and hand checks work anywhere.

Layout::

    Firestore scouted/{match_key}                     event_key, season, version, sha256, bundle,
                                                      run_id, good, tag (JSON), state_at, stamp,
                                                      updated_by, device
    Storage   scouted/{event_key}/{match_key}.json.gz robots.json + teams/*.json
    Storage   scouted_runs/{run_id}.json.gz           the tracking run
    Local     outputs/<match>/shared.json             what this computer last shared or took
              outputs/shared_matches.json             newest ``stamp`` seen

Newest wins: the autos by ``version`` (when they last changed), the good mark and
re-scout tag by ``state_at``. ``stamp`` (time of the last write) lets each computer
ask only for documents changed since it last looked.
"""

from __future__ import annotations

import asyncio
import gzip
import hashlib
import json
import logging
import re
import socket
import time
from pathlib import Path

from fastapi.concurrency import run_in_threadpool

from app.core.config import settings
from app.services import cloud, rescout, scout_jobs
from app.services.trajectory_export import parse_match_key

log = logging.getLogger(__name__)

TICK_SEC = 45
DEBOUNCE_SEC = 3
OVERLAP_SEC = 300  # computers' clocks differ a little: re-read the last few minutes
PAGE = 200
_MATCH_RE = re.compile(r"[0-9]{4}[a-z0-9]+_(?:qm|ef|qf|sf|f)[0-9]+(?:m[0-9]+)?")
_RUN_RE = re.compile(r"[0-9a-f]{32}")

_wake: asyncio.Event | None = None
_loop: asyncio.AbstractEventLoop | None = None
_last: dict = {"at": None, "pulled": [], "pushed": [], "error": None}


def _out() -> Path:
    return Path(settings.output_dir)


def _read_json(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _write_json(path: Path, data: dict, indent: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".part")
    tmp.write_text(json.dumps(data, indent=indent), encoding="utf-8")
    tmp.replace(path)


def _team_files(mk: str) -> list[Path]:
    return sorted((_out() / mk / "teams").glob("*.json"))


def _mtime(mk: str) -> float:
    files = [_out() / mk / "robots.json", *_team_files(mk)]
    return max((f.stat().st_mtime for f in files if f.is_file()), default=0.0)


def _bundle(mk: str) -> dict:
    robots = _read_json(_out() / mk / "robots.json")
    teams = {f.name: _read_json(f) for f in _team_files(mk)}
    if robots is None or not teams or any(d is None for d in teams.values()):
        raise ValueError(f"{mk} autos are incomplete or being written")
    return {"robots": robots, "teams": teams}


def _bundle_sha(bundle: dict) -> str:
    return hashlib.sha256(json.dumps(bundle, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _manifest(mk: str) -> dict | None:
    return _read_json(_out() / mk / "shared.json")


def _set_manifest(mk: str, **fields) -> None:
    _write_json(_out() / mk / "shared.json", {**(_manifest(mk) or {}), **fields})


def _busy_match() -> str | None:
    job = scout_jobs.active_job()
    return job.get("current") if job else None


def local_matches() -> list[str]:
    return sorted(
        d.name for d in _out().glob("*_*") if _MATCH_RE.fullmatch(d.name) and (d / "robots.json").is_file() and _team_files(d.name)
    )


def _locally_changed(mk: str) -> bool:
    man = _manifest(mk)
    return man is None or _mtime(mk) > float(man.get("mtime") or 0) + 1


def versions(match_keys: list[str]) -> dict[str, str]:
    """A token per match that changes whenever its autos or marks change (for the app to refresh)."""
    out = {}
    for mk in match_keys:
        out[mk] = f"{_mtime(mk):.0f}:{rescout.shared_state(mk)['at']:.0f}"
    return out


# ---------------------------------------------------------------- pull


def _take_autos(mk: str, doc: dict) -> None:
    bundle = json.loads(gzip.decompress(cloud.download(doc["bundle"])))
    robots, teams = bundle.get("robots"), bundle.get("teams")
    if not isinstance(robots, dict) or not isinstance(teams, dict) or not teams:
        raise ValueError(f"{mk}: bad shared autos")
    name_re = re.compile(re.escape(mk) + r"_[0-9]{1,5}\.json")
    if not all(name_re.fullmatch(n) and isinstance(d, dict) for n, d in teams.items()):
        raise ValueError(f"{mk}: bad shared team file names")
    run_id = str(doc.get("run_id") or "")
    run_file = _out() / "runs" / f"{run_id}.json"
    if _RUN_RE.fullmatch(run_id) and not run_file.is_file():
        cloud._write_bytes(run_file, gzip.decompress(cloud.download(f"scouted_runs/{run_id}.json.gz")))
    team_dir = _out() / mk / "teams"
    _write_json(_out() / mk / "robots.json", robots, indent=1)
    for name, d in teams.items():
        _write_json(team_dir / name, d, indent=1)
    for f in team_dir.glob("*.json"):
        if f.name not in teams:
            f.unlink()
    _set_manifest(
        mk,
        version=float(doc["version"]),
        sha=doc["sha256"],
        mtime=_mtime(mk),
        run_shared=run_id if _RUN_RE.fullmatch(run_id) else None,
    )


def _pull_one(mk: str, doc: dict) -> list[str]:
    done = []
    man = _manifest(mk) or {}
    if doc.get("bundle") and float(doc.get("version") or 0) > float(man.get("version") or 0):
        if doc.get("sha256") == man.get("sha") and not _locally_changed(mk):
            _set_manifest(mk, version=float(doc["version"]))
        elif _locally_changed(mk) and _mtime(mk) > float(doc["version"]):
            pass  # changed here after that: ours is newer and gets shared next
        elif (_out() / mk / "robots.json").is_file() and _team_files(mk) and _bundle_sha(_bundle(mk)) == doc.get("sha256"):
            _set_manifest(mk, version=float(doc["version"]), sha=doc["sha256"], mtime=_mtime(mk))
        else:
            _take_autos(mk, doc)
            done.append(f"autos {mk}")
    state_at = float(doc.get("state_at") or 0)
    if state_at > max(rescout.shared_state(mk)["at"], float((_manifest(mk) or {}).get("state_at") or 0)):
        tag = json.loads(doc["tag"]) if doc.get("tag") else None
        rescout.apply_shared_state(mk, bool(doc.get("good")), tag, state_at)
        if (_out() / mk).is_dir():
            _set_manifest(mk, state_at=state_at)
        done.append(f"marks {mk}")
    return done


def _seen_file() -> Path:
    return _out() / "shared_matches.json"


def pull() -> list[str]:
    seen = float((_read_json(_seen_file()) or {}).get("seen") or 0)
    cursor, newest, done, events = max(0.0, seen - OVERLAP_SEC), seen, [], set()
    failed = None  # oldest stamp not taken: look again from there next time
    busy = _busy_match()
    while True:
        rows = cloud.query_docs("scouted", {"stamp": (">", cursor)}, limit=PAGE, order_by="stamp")
        for mk, doc, _ in rows:
            stamp = float(doc.get("stamp") or 0)
            cursor = max(cursor, stamp)
            if not _MATCH_RE.fullmatch(mk):
                continue
            if mk == busy:  # being scouted here right now: look again later
                failed = min(failed or stamp, stamp)
                continue
            try:
                got = _pull_one(mk, doc)
            except Exception as exc:  # one bad match must not stop the rest
                log.warning("shared match %s not taken: %s", mk, exc)
                failed = min(failed or stamp, stamp)
                continue
            newest = max(newest, stamp)
            done += got
            if any(g.startswith("autos") for g in got):
                events.add(parse_match_key(mk)["event_key"])
        if len(rows) < PAGE:
            break
    if failed is not None:
        newest = min(newest, failed)
    if newest != seen:
        _write_json(_seen_file(), {"seen": newest})
    for ev in filter(None, events):
        scout_jobs.compile_team_autos(ev, [mk for mk in local_matches() if mk.startswith(ev + "_")])
    return done


# ---------------------------------------------------------------- push


def _push_one(mk: str) -> list[str]:
    man = _manifest(mk) or {}
    fields: dict = {}
    done = []
    if _locally_changed(mk):
        mtime = _mtime(mk)
        bundle = _bundle(mk)
        sha = _bundle_sha(bundle)
        if sha == man.get("sha"):
            _set_manifest(mk, mtime=mtime)
        else:
            event_key = parse_match_key(mk)["event_key"]
            name = f"scouted/{event_key}/{mk}.json.gz"
            run_id = str(bundle["robots"].get("run_id") or "")
            run_file = _out() / "runs" / f"{run_id}.json"
            shared_run = None
            if _RUN_RE.fullmatch(run_id) and run_file.is_file():
                if man.get("run_shared") != run_id:
                    cloud.upload(f"scouted_runs/{run_id}.json.gz", gzip.compress(run_file.read_bytes(), 6), "application/gzip")
                shared_run = run_id
            cloud.upload(name, gzip.compress(json.dumps(bundle).encode(), 6), "application/gzip")
            fields.update(
                event_key=event_key,
                season=int(mk[:4]),
                version=mtime,
                sha256=sha,
                bundle=name,
                run_id=shared_run or "",
            )
            man = {**man, "version": mtime, "sha": sha, "mtime": mtime, "run_shared": shared_run}
            done.append(f"autos {mk} shared")
    state = rescout.shared_state(mk)
    if state["at"] > float(man.get("state_at") or 0):
        fields.update(good=state["good"], tag=json.dumps(state["tag"]) if state["tag"] else "", state_at=state["at"])
        man["state_at"] = state["at"]
        done.append(f"marks {mk} shared")
    if fields:
        fields.update(stamp=time.time(), updated_by=cloud._who(), device=socket.gethostname())
        cloud.set_doc(f"scouted/{mk}", fields, merge=True)
        _set_manifest(mk, **man)
    return done


def push() -> list[str]:
    busy = _busy_match()
    done = []
    for mk in local_matches():
        if mk == busy:
            continue
        try:
            done += _push_one(mk)
        except ValueError as exc:  # half-written files: next time
            log.debug("shared match %s not sent yet: %s", mk, exc)
    return done


# ---------------------------------------------------------------- loop


def sync() -> dict:
    """Pull, then push. Never raises."""
    if not cloud.signed_in():
        return {"skipped": "not signed in"}
    pulled, pushed, error = [], [], None
    try:
        pulled = pull()
        pushed = push()
    except Exception as exc:  # offline etc.: next tick
        error = str(exc)
        if error != _last.get("error"):
            log.warning("shared matches sync failed: %s", exc)
    _last.update(at=time.time(), pulled=pulled, pushed=pushed, error=error)
    if pulled or pushed:
        log.info("shared matches: %s", ", ".join(pulled + pushed))
    return dict(_last)


def status() -> dict:
    return dict(_last)


def wake() -> None:
    """Share soon (something changed). Safe to call from any thread."""
    if _wake is not None and _loop is not None and not _loop.is_closed():
        _loop.call_soon_threadsafe(_wake.set)


async def run_forever() -> None:
    """Share scouted matches with the team; started with the server."""
    global _wake, _loop
    _wake = asyncio.Event()
    _loop = asyncio.get_running_loop()
    while True:
        await run_in_threadpool(sync)
        try:
            await asyncio.wait_for(_wake.wait(), timeout=TICK_SEC)
            await asyncio.sleep(DEBOUNCE_SEC)  # let a burst of changes land first
        except asyncio.TimeoutError:
            pass
        _wake.clear()
