from __future__ import annotations

import cv2
from collections import defaultdict

from ultralytics import YOLO

from app.core.config import settings
from app.core.gpu import torch_device



def _get_yolo_device() -> str:
    return torch_device()


def _classify_alliance_from_box(frame, box: list[float]) -> tuple[str | None, float]:
    x, y, w, h = box
    h_frame, w_frame = frame.shape[:2]
    x1 = max(0, int(x - (w / 2.0)))
    x2 = min(w_frame, int(x + (w / 2.0)))
    y1 = max(0, int(y))
    y2 = min(h_frame, int(y + (h / 2.0)))
    if x2 <= x1 or y2 <= y1:
        return None, 0.0

    roi = frame[y1:y2, x1:x2]
    if roi.size == 0:
        return None, 0.0

    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    red_mask_1 = cv2.inRange(hsv, (0, 70, 50), (12, 255, 255))
    red_mask_2 = cv2.inRange(hsv, (170, 70, 50), (180, 255, 255))
    red_mask = cv2.bitwise_or(red_mask_1, red_mask_2)
    blue_mask = cv2.inRange(hsv, (90, 70, 40), (135, 255, 255))

    red_score = float(cv2.countNonZero(red_mask))
    blue_score = float(cv2.countNonZero(blue_mask))
    if max(red_score, blue_score) < 30.0:
        return None, 0.0

    if red_score >= blue_score:
        return "red", red_score
    return "blue", blue_score


def _resolve_target_track_id(
    tracks: dict[int, list[dict]],
    target_alliance: str,
    target_robot_position: int,
    lock_window_sec: float,
    color_votes: dict[int, dict[str, float]] | None = None,
) -> int | None:
    candidates: list[tuple[int, float]] = []
    for track_id, obs in tracks.items():
        first = next((p for p in obs if p["t_sec"] <= lock_window_sec), obs[0] if obs else None)
        if first is not None:
            candidates.append((track_id, first["px"]))

    if not candidates:
        return None

    preferred = candidates
    if color_votes:
        alliance = target_alliance.lower()
        color_filtered: list[tuple[int, float]] = []
        for track_id, px in candidates:
            votes = color_votes.get(track_id, {})
            want = float(votes.get(alliance, 0.0))
            other = float(votes.get("blue" if alliance == "red" else "red", 0.0))
            if want > max(20.0, other * 1.1):
                color_filtered.append((track_id, px))
        if color_filtered:
            preferred = color_filtered

    preferred.sort(key=lambda x: x[1], reverse=(target_alliance.lower() == "red"))
    idx = max(0, min(target_robot_position - 1, len(preferred) - 1))
    return preferred[idx][0]


def _interpolate_track(points: list[dict], fps: float, max_interp_gap_frames: int) -> list[dict]:
    if len(points) < 2:
        return points

    out: list[dict] = [points[0]]
    for prev, nxt in zip(points, points[1:]):
        frame_gap = int(round((nxt["t_sec"] - prev["t_sec"]) * fps))
        if frame_gap > 1 and frame_gap <= max_interp_gap_frames:
            for k in range(1, frame_gap):
                alpha = k / frame_gap
                out.append(
                    {
                        "t_sec": prev["t_sec"] + (nxt["t_sec"] - prev["t_sec"]) * alpha,
                        "px": prev["px"] + (nxt["px"] - prev["px"]) * alpha,
                        "py": prev["py"] + (nxt["py"] - prev["py"]) * alpha,
                        "confidence": min(prev["confidence"], nxt["confidence"]) * 0.7,
                        "inferred": True,
                    }
                )
        out.append(nxt)
    return out


def _fallback_motion_track(video_path: str, start_frame: int, end_frame: int, fps: float) -> list[dict]:
    cap = cv2.VideoCapture(video_path)
    bg = cv2.createBackgroundSubtractorMOG2(history=120, varThreshold=20, detectShadows=False)
    points: list[dict] = []

    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    idx = start_frame
    while idx < end_frame:
        ok, frame = cap.read()
        if not ok:
            break
        fg = bg.apply(frame)
        _, fg = cv2.threshold(fg, 200, 255, cv2.THRESH_BINARY)
        cnts, _ = cv2.findContours(fg, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = [c for c in cnts if cv2.contourArea(c) > 250]
        if cnts:
            c = max(cnts, key=cv2.contourArea)
            x, y, w, h = cv2.boundingRect(c)
            points.append(
                {
                    "t_sec": (idx - start_frame) / fps,
                    "px": x + (w / 2.0),
                    "py": y + h,
                    "confidence": 0.45,
                    "inferred": False,
                }
            )
        idx += 1

    cap.release()
    return points


def run_tracking_pipeline(
    video_path: str,
    auto_seconds: float,
    tracking_start_sec: float,
    tracking_end_sec: float | None,
    target_alliance: str,
    target_robot_position: int,
    tracker_config: str,
    lock_window_sec: float = 2.0,
    yolo_model: str | None = None,
    tracker_conf: float | None = None,
    tracker_iou: float | None = None,
    max_interp_gap_frames: int | None = None,
    forced_track_id: int | None = None,
) -> dict:
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    cap.release()

    start_frame = max(0, int(tracking_start_sec * fps))
    if tracking_end_sec is not None:
        end_frame = max(start_frame + 1, int(tracking_end_sec * fps))
    else:
        end_frame = start_frame + int(auto_seconds * fps)
    if total_frames > 0:
        end_frame = min(end_frame, total_frames)

    if end_frame <= start_frame:
        end_frame = start_frame + 1

    tracks: dict[int, list[dict]] = defaultdict(list)
    track_color_votes: dict[int, dict[str, float]] = defaultdict(
        lambda: {"red": 0.0, "blue": 0.0}
    )
    selected_track_id = None
    fallback_used = False
    yolo_model_name = yolo_model or settings.yolo_model
    conf = tracker_conf if tracker_conf is not None else settings.tracker_conf
    iou = tracker_iou if tracker_iou is not None else settings.tracker_iou
    interp_gap = (
        max_interp_gap_frames
        if max_interp_gap_frames is not None
        else settings.max_interp_gap_frames
    )
    yolo_device = _get_yolo_device()

    try:
        model = YOLO(yolo_model_name)
        frame_index = 0
        for result in model.track(
            source=video_path,
            stream=True,
            persist=True,
            tracker=tracker_config,
            device=yolo_device,
            conf=conf,
            iou=iou,
            verbose=False,
        ):
            if frame_index >= end_frame:
                break

            if frame_index < start_frame:
                frame_index += 1
                continue

            if result.boxes is not None and result.boxes.id is not None:
                ids = result.boxes.id.int().cpu().tolist()
                xywh = result.boxes.xywh.cpu().tolist()
                confs = (
                    result.boxes.conf.cpu().tolist()
                    if result.boxes.conf is not None
                    else [0.6 for _ in ids]
                )
                for tid, box, conf in zip(ids, xywh, confs):
                    x, y, w, h = box
                    frame = getattr(result, "orig_img", None)
                    if frame is not None:
                        alliance_guess, score = _classify_alliance_from_box(frame, box)
                        if alliance_guess is not None:
                            track_color_votes[tid][alliance_guess] += score * float(conf)

                    tracks[tid].append(
                        {
                            "t_sec": (frame_index - start_frame) / fps,
                            "px": float(x),
                            "py": float(y + (h / 2.0)),
                            "confidence": float(conf),
                            "inferred": False,
                        }
                    )

            frame_index += 1
    except Exception:
        pass

    if tracks:
        if forced_track_id is not None and forced_track_id in tracks:
            selected_track_id = int(forced_track_id)
        else:
            selected_track_id = _resolve_target_track_id(
                tracks=tracks,
                target_alliance=target_alliance,
                target_robot_position=target_robot_position,
                lock_window_sec=lock_window_sec,
                color_votes=track_color_votes,
            )

    if tracks and selected_track_id is None:
        selected_track_id = _resolve_target_track_id(
            tracks=tracks,
            target_alliance=target_alliance,
            target_robot_position=target_robot_position,
            lock_window_sec=lock_window_sec,
            color_votes=track_color_votes,
        )

    if selected_track_id is not None:
        points = sorted(tracks[selected_track_id], key=lambda p: p["t_sec"])
    else:
        fallback_used = True
        points = _fallback_motion_track(
            video_path=video_path,
            start_frame=start_frame,
            end_frame=end_frame,
            fps=fps,
        )

    points = _interpolate_track(
        points=points,
        fps=fps,
        max_interp_gap_frames=interp_gap,
    )

    return {
        "points": points,
        "meta": {
            "fps": fps,
            "frames_processed": max(0, end_frame - start_frame),
            "tracking_start_sec": tracking_start_sec,
            "tracking_end_sec": tracking_end_sec,
            "target_alliance": target_alliance,
            "target_robot_position": target_robot_position,
            "tracker_config": tracker_config,
            "selected_track_id": selected_track_id,
            "forced_track_id": forced_track_id,
            "fallback_used": fallback_used,
            "track_count": len(tracks),
            "track_candidates": [
                {
                    "track_id": int(track_id),
                    "start_px": float(obs[0]["px"]),
                    "start_py": float(obs[0]["py"]),
                    "alliance_guess": (
                        "red"
                        if track_color_votes.get(track_id, {}).get("red", 0.0)
                        >= track_color_votes.get(track_id, {}).get("blue", 0.0)
                        else "blue"
                    ),
                    "red_score": float(track_color_votes.get(track_id, {}).get("red", 0.0)),
                    "blue_score": float(track_color_votes.get(track_id, {}).get("blue", 0.0)),
                    "samples": len(obs),
                }
                for track_id, obs in tracks.items()
                if obs
            ],
            "lock_window_sec": lock_window_sec,
            "yolo_model": yolo_model_name,
            "yolo_device": yolo_device,
            "tracker_conf": conf,
            "tracker_iou": iou,
            "max_interp_gap_frames": interp_gap,
        },
    }
