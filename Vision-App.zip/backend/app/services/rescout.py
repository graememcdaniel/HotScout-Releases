"""Re-scout tags: matches whose autos look wrong and should be tracked again.

Tags live in ``outputs/<event>/rescout.json``. Scouts can tag a match by hand;
``auto_tag`` also tags matches whose saved autos fail simple quality checks
(a robot not found, starting on the wrong side, picked up late, mostly hidden
or of uncertain identity).

Scouts can also mark a match's autos as good (same file, ``good``). Good
matches are never auto-tagged, keep their team labels, and are the only
matches the robot detector trains on.

``changed`` holds when each match's mark or tag last really changed, so team
computers can share them (``shared_matches``; newest wins).
"""

from __future__ import annotations

import json
import re
import statistics
import threading
import time
from pathlib import Path

from app.core.config import settings
from app.services.trajectory_export import team_paths_dir

_lock = threading.Lock()
_EVENT_OF = re.compile(r"^(\d{4}[a-z0-9]+)_")

LATE_START_SEC = 3.0
MISSED_START_SEC = 8.0
SHORT_TRACK_SEC = 4.0
LOW_OBSERVED = 0.35
LOW_ID_CONFIDENCE = 0.35
SIDE_TOLERANCE_M = 0.5


def event_of(match_key: str) -> str:
    m = _EVENT_OF.match(match_key)
    if not m:
        raise ValueError(f"bad match key {match_key!r}")
    return m.group(1)


def _store(event_key: str) -> Path:
    return Path(settings.output_dir) / event_key / "rescout.json"


def _read(event_key: str) -> dict:
    try:
        data = json.loads(_store(event_key).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        data = {}
    data.setdefault("matches", {})
    return data


def _write(event_key: str, data: dict) -> None:
    path = _store(event_key)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=1), encoding="utf-8")


def _state(data: dict, match_key: str) -> tuple:
    tag = data["matches"].get(match_key) or {}
    return (match_key in (data.get("good") or {}), bool(tag.get("tagged")), tag.get("reason"), tag.get("source"))


def _touch(data: dict, match_key: str, before: tuple) -> None:
    if _state(data, match_key) != before:
        data.setdefault("changed", {})[match_key] = time.time()


def shared_state(match_key: str) -> dict:
    """A match's good mark and re-scout tag, and when they last changed (0 = never)."""
    with _lock:
        data = _read(event_of(match_key))
        tag = data["matches"].get(match_key)
        mark = (data.get("good") or {}).get(match_key)
        at = (data.get("changed") or {}).get(match_key)
        if at is None:  # set before changes were recorded
            at = max(float((mark or {}).get("marked_at") or 0), float((tag or {}).get("tagged_at") or (tag or {}).get("cleared_at") or 0))
        return {"good": mark is not None, "tag": tag, "at": float(at)}


def changed_times(event_key: str) -> dict[str, float]:
    with _lock:
        return {k: float(v) for k, v in (_read(event_key).get("changed") or {}).items()}


def apply_shared_state(match_key: str, good: bool, tag: dict | None, at: float) -> None:
    """Take another team computer's newer good mark / re-scout tag."""
    ev = event_of(match_key)
    with _lock:
        data = _read(ev)
        marks = data.setdefault("good", {})
        if good:
            marks.setdefault(match_key, {"marked_at": at})
        else:
            marks.pop(match_key, None)
        if tag:
            data["matches"][match_key] = tag
        else:
            data["matches"].pop(match_key, None)
        data.setdefault("changed", {})[match_key] = at
        _write(ev, data)


def list_tags(event_key: str) -> dict[str, dict]:
    with _lock:
        return {k: v for k, v in _read(event_key)["matches"].items() if v.get("tagged")}


def get_tag(match_key: str) -> dict | None:
    return list_tags(event_of(match_key)).get(match_key)


def is_good(match_key: str) -> bool:
    with _lock:
        return match_key in (_read(event_of(match_key)).get("good") or {})


def good_matches(event_key: str) -> set[str]:
    with _lock:
        return set(_read(event_key).get("good") or {})


def season_good_matches(season: int) -> set[str]:
    """Good matches of every event of the season."""
    out: set[str] = set()
    for f in Path(settings.output_dir).glob(f"{int(season)}*/rescout.json"):
        out |= good_matches(f.parent.name)
    return out


def set_good(match_key: str, good: bool) -> bool:
    """Mark (or unmark) a match's autos as checked and right. Marking clears its re-scout tag."""
    ev = event_of(match_key)
    with _lock:
        data = _read(ev)
        before = _state(data, match_key)
        marks = data.setdefault("good", {})
        if good:
            marks[match_key] = {"marked_at": time.time()}
            prev = data["matches"].get(match_key)
            if prev and prev.get("tagged"):
                data["matches"][match_key] = {
                    "tagged": False,
                    "rescouts": int(prev.get("rescouts") or 0),
                    "last_reason": prev.get("reason"),
                    "cleared_at": time.time(),
                }
        elif marks.pop(match_key, None) is None:
            return False
        _touch(data, match_key, before)
        _write(ev, data)
        return good


def set_tag(match_key: str, reason: str | None = None, source: str = "manual", issues: list | None = None) -> dict:
    ev = event_of(match_key)
    with _lock:
        data = _read(ev)
        prev = data["matches"].get(match_key) or {}
        before = _state(data, match_key)
        if source == "manual":
            (data.get("good") or {}).pop(match_key, None)
        tag = {
            "tagged": True,
            "reason": (reason or "").strip()[:200] or ("Tagged by a scout" if source == "manual" else "Autos look wrong"),
            "source": source,
            "issues": issues or [],
            "tagged_at": time.time(),
            "rescouts": int(prev.get("rescouts") or 0),
        }
        data["matches"][match_key] = tag
        _touch(data, match_key, before)
        _write(ev, data)
        return tag


def clear_tag(match_key: str, rescouted: bool = False) -> None:
    ev = event_of(match_key)
    with _lock:
        data = _read(ev)
        prev = data["matches"].get(match_key)
        if prev is None and not rescouted:
            return
        prev = prev or {}
        before = _state(data, match_key)
        data["matches"][match_key] = {
            "tagged": False,
            "rescouts": int(prev.get("rescouts") or 0) + (1 if rescouted else 0),
            "last_reason": prev.get("reason") or prev.get("last_reason"),
            "cleared_at": time.time(),
        }
        _touch(data, match_key, before)
        _write(ev, data)


def rescout_count(match_key: str) -> int:
    with _lock:
        return int((_read(event_of(match_key))["matches"].get(match_key) or {}).get("rescouts") or 0)


def _load_docs(match_key: str) -> list[dict]:
    docs = []
    for f in team_paths_dir(match_key).glob("*.json"):
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if doc.get("team_key"):
            docs.append(doc)
    return docs


def _start_x(doc: dict) -> float | None:
    for p in doc.get("trajectory") or []:
        if p.get("x_m") is not None:
            return float(p["x_m"])
    return None


def match_issues(match_key: str) -> list[dict]:
    """Quality problems in a match's saved autos: ``[{team_key, kind, severe, text}]``."""
    docs = _load_docs(match_key)
    # Files without team_id were assigned and checked by hand.
    if not docs or any(d.get("team_id") is None for d in docs):
        return []
    length = float((next((d["field_dims_m"] for d in docs if d.get("field_dims_m")), None) or [16.54])[0])
    starts = {c: [x for d in docs if d.get("alliance") == c and (x := _start_x(d)) is not None] for c in ("red", "blue")}
    red_left = True
    if starts["red"] and starts["blue"]:
        red_left = statistics.median(starts["red"]) < statistics.median(starts["blue"])
    issues = []

    def add(doc, kind, severe, text):
        issues.append({"team_key": doc["team_key"], "kind": kind, "severe": severe, "text": text})

    for d in sorted(docs, key=lambda d: d["team_key"]):
        num = d["team_key"][3:]
        tid = d.get("team_id")
        if d.get("detected") is False or not d.get("trajectory"):
            add(d, "not_found", True, f"{num} not found")
            continue
        x = _start_x(d)
        own_left = (d.get("alliance") == "red") == red_left
        if x is not None and (x > length / 2 + SIDE_TOLERANCE_M if own_left else x < length / 2 - SIDE_TOLERANCE_M):
            add(d, "wrong_side", True, f"{num} starts on the wrong side")
        first, last = d.get("first_t_sec"), d.get("last_t_sec")
        if first is not None and first > MISSED_START_SEC:
            add(d, "missed_start", True, f"{num} only found {first:.0f}s in")
        elif first is not None and first > LATE_START_SEC:
            add(d, "late", False, f"{num} picked up {first:.0f}s late")
        if first is not None and last is not None and last - first < SHORT_TRACK_SEC:
            add(d, "short", True, f"{num} lost after {last - first:.0f}s")
        elif (d.get("observed_fraction") or 0) < LOW_OBSERVED:
            add(d, "hidden", False, f"{num} mostly hidden")
        if tid is not None and tid.get("needs_review") and float(tid.get("confidence") or 0) < LOW_ID_CONFIDENCE:
            add(d, "identity", False, f"not sure which robot is {num}")
    return issues


def needs_rescout(issues: list[dict]) -> bool:
    if any(i["severe"] for i in issues):
        return True
    mild = {i["kind"] if i["kind"] == "identity" else (i["team_key"], i["kind"]) for i in issues if not i["severe"]}
    return len(mild) >= 2


def _summary(issues: list[dict]) -> str:
    ordered = sorted(issues, key=lambda i: not i["severe"])
    text = "; ".join(i["text"] for i in ordered[:3])
    return text + (f" (+{len(ordered) - 3} more)" if len(ordered) > 3 else "")


def auto_tag(match_key: str) -> dict | None:
    """Tag (or untag) a match from its quality checks. Manual tags are left alone."""
    tag = get_tag(match_key)
    if tag and tag.get("source") == "manual":
        return tag
    if is_good(match_key):
        return None
    issues = match_issues(match_key)
    if issues and needs_rescout(issues):
        return set_tag(match_key, _summary(issues), source="auto", issues=issues)
    if tag:
        clear_tag(match_key)
    return None


def auto_tag_event(event_key: str) -> dict[str, dict]:
    """Run ``auto_tag`` over every scouted match of the event."""
    for d in sorted(Path(settings.output_dir).glob(f"{event_key}_*/teams")):
        doc_match = None
        for f in d.glob("*.json"):
            try:
                doc_match = json.loads(f.read_text(encoding="utf-8")).get("match_key")
            except (OSError, ValueError):
                continue
            if doc_match:
                break
        if doc_match:
            auto_tag(doc_match)
    return list_tags(event_key)
