"""Store per-team auto paths in Cloud Firestore.

Layout (one document per drawn auto)::

    seasons/{year}/events/{event_key}/teams/{team_key}/autos/{match_key}

Parent documents get small summary fields so they can be listed. Writing uses
the team Google sign-in (``cloud``), or a service-account key referenced by
FIREBASE_CREDENTIALS when one is present.
"""

from __future__ import annotations

import json
import logging
import math
from datetime import datetime, timezone
from pathlib import Path
from threading import Lock

from app.core.config import settings

log = logging.getLogger(__name__)

_db = None
_lock = Lock()


def _admin_status() -> dict:
    path = (settings.firebase_credentials or "").strip()
    if not path:
        return {"configured": False, "project_id": settings.firebase_project_id, "reason": "FIREBASE_CREDENTIALS is not set"}
    if not Path(path).is_file():
        return {"configured": False, "project_id": settings.firebase_project_id, "reason": "Credentials file not found"}
    return {"configured": True, "project_id": settings.firebase_project_id, "via": "service account"}


def status() -> dict:
    st = _admin_status()
    if st["configured"]:
        return st
    from app.services import cloud

    if cloud.signed_in():
        return {"configured": True, "project_id": settings.firebase_project_id, "via": cloud.status()["email"]}
    return {"configured": False, "project_id": settings.firebase_project_id, "reason": "Sign in with Google (top right) to upload"}


def _client():
    global _db
    with _lock:
        if _db is None:
            st = _admin_status()
            if not st["configured"]:
                raise RuntimeError(f"Firebase not configured: {st['reason']}")
            import firebase_admin
            from firebase_admin import credentials, firestore

            name = "vision-tracker"
            try:
                app = firebase_admin.get_app(name)
            except ValueError:
                app = firebase_admin.initialize_app(
                    credentials.Certificate(settings.firebase_credentials),
                    {"projectId": settings.firebase_project_id},
                    name=name,
                )
            _db = firestore.client(app)
        return _db


def _clean(value):
    """Make a JSON value Firestore-safe (no nested arrays, no NaN/inf)."""
    if isinstance(value, dict):
        return {str(k): _clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [{"values": _clean(v)} if isinstance(v, (list, tuple)) else _clean(v) for v in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def upload_team_doc(doc: dict) -> str:
    """Write one team's auto path doc; returns its Firestore path."""
    event_key, team_key, match_key = doc.get("event_key"), doc.get("team_key"), doc.get("match_key")
    if not (event_key and team_key and match_key):
        raise ValueError("Doc needs event_key, team_key and match_key")
    year = str(event_key)[:4]
    if not _admin_status()["configured"]:
        return _upload_rest(doc, year, event_key, team_key, match_key)
    from firebase_admin import firestore

    db = _client()
    season_ref = db.collection("seasons").document(year)
    event_ref = season_ref.collection("events").document(event_key)
    team_ref = event_ref.collection("teams").document(team_key)
    auto_ref = team_ref.collection("autos").document(match_key)

    now = firestore.SERVER_TIMESTAMP
    batch = db.batch()
    batch.set(season_ref, {"year": int(year), "updated_at": now}, merge=True)
    batch.set(event_ref, {"event_key": event_key, "year": int(year), "updated_at": now}, merge=True)
    batch.set(
        team_ref,
        {"team_key": team_key, "team_number": doc.get("team_number"), "event_key": event_key, "updated_at": now},
        merge=True,
    )
    batch.set(auto_ref, {**_clean(doc), "uploaded_at": now})
    batch.commit()
    return auto_ref.path


def _upload_rest(doc: dict, year: str, event_key: str, team_key: str, match_key: str) -> str:
    """Same documents as the admin path, written as the signed-in team member."""
    from app.services import cloud

    now = datetime.now(timezone.utc)
    team_path = f"seasons/{year}/events/{event_key}/teams/{team_key}"
    cloud.set_doc(f"seasons/{year}", {"year": int(year), "updated_at": now}, merge=True)
    cloud.set_doc(f"seasons/{year}/events/{event_key}", {"event_key": event_key, "year": int(year), "updated_at": now}, merge=True)
    cloud.set_doc(
        team_path,
        {"team_key": team_key, "team_number": doc.get("team_number"), "event_key": event_key, "updated_at": now},
        merge=True,
    )
    path = f"{team_path}/autos/{match_key}"
    cloud.set_doc(path, {**_clean(doc), "uploaded_at": now})
    return path


def _delete(doc_path: str) -> None:
    if _admin_status()["configured"]:
        _client().document(doc_path).delete()
    else:
        from app.services import cloud

        cloud.delete_doc(doc_path)


def upload_team_files(paths: list[str], manifest: Path) -> dict:
    """Upload exported team path JSON files for one match; never raises.

    ``manifest`` remembers which docs this match wrote last time, so a team
    that was re-assigned (e.g. a corrected OCR guess) loses its stale doc.
    """
    st = status()
    if not st["configured"]:
        return {"uploaded": [], "errors": [], "skipped": st["reason"]}
    uploaded, errors = [], []
    for p in paths:
        try:
            doc = json.loads(Path(p).read_text(encoding="utf-8"))
            uploaded.append(upload_team_doc(doc))
        except Exception as exc:  # report and continue with the other teams
            log.warning("firebase upload failed for %s: %s", p, exc)
            errors.append(f"{Path(p).name}: {exc}")
    if not uploaded:
        return {"uploaded": [], "removed": [], "errors": errors}
    removed = []
    try:
        previous = json.loads(manifest.read_text(encoding="utf-8")) if manifest.is_file() else []
    except (OSError, ValueError):
        previous = []
    for doc_path in previous:
        if doc_path not in uploaded and isinstance(doc_path, str) and doc_path.startswith("seasons/"):
            try:
                _delete(doc_path)
                removed.append(doc_path)
            except Exception as exc:
                errors.append(f"delete {doc_path}: {exc}")
    manifest.parent.mkdir(parents=True, exist_ok=True)
    manifest.write_text(json.dumps(uploaded + [p for p in previous if p not in uploaded and p not in removed]), encoding="utf-8")
    return {"uploaded": uploaded, "removed": removed, "errors": errors}
