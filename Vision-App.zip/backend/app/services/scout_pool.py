"""Scouting one event on every team GPU at once ("All team GPUs").

This computer and every team computer that shares its GPU run the same scout job
(same ``pool_id``). Before downloading a match, a computer claims it in the team
cloud, so each match is downloaded and scouted once, by whichever computer gets
to it first: a faster GPU simply takes more matches. The autos reach everyone
through shared matches. A match whose computer went off, or failed it, is taken
over by another one.

Layout::

    Firestore scouted/{match_key}   pool_claim: {pool, device, name, status, at}
                                    status: scouting, done or failed
"""

from __future__ import annotations

import time

from app.services import cloud, devices

STALE_SEC = 30 * 60  # one match never takes this long: its computer is stuck


def _claim(pool_id: str, status: str) -> dict:
    return {"pool": pool_id, "device": devices.device_id(), "name": devices.device_name(), "status": status, "at": time.time()}


def _offline(device: dict | None) -> bool:
    if device is None:
        return True
    updated = float(device.get("updated_at") or 0)
    return time.time() - updated > devices.ONLINE_SEC or float(device.get("stopped_at") or 0) >= updated


def _gone(c: dict, device: dict | None) -> bool:
    """The claim's computer will not finish the match."""
    return c.get("status") == "failed" or time.time() - float(c.get("at") or 0) > STALE_SEC or _offline(device)


def claim(pool_id: str, match_key: str) -> dict | None:
    """Claim ``match_key`` for this computer. None = ours to scout; otherwise the
    other computer's claim (``name``, ``status``)."""
    me = devices.device_id()
    path = f"scouted/{match_key}"
    for _ in range(5):
        got = cloud.get_doc_meta(path)
        doc, when = got if got else ({}, None)
        c = doc.get("pool_claim") or {}
        if c.get("pool") == pool_id and c.get("device") != me:
            if c.get("status") == "done":
                return c
            if not _gone(c, cloud.get_doc(f"devices/{c.get('device')}")):
                return c
        if cloud.set_doc(path, {"pool_claim": _claim(pool_id, "scouting")}, merge=True, if_update_time=when, if_missing=when is None):
            return None
    raise RuntimeError(f"{match_key} kept changing in the team cloud")


def release(pool_id: str, match_key: str, ok: bool) -> None:
    """Mark this computer's claim done (or failed, so another computer may take it)."""
    path = f"scouted/{match_key}"
    for _ in range(3):
        got = cloud.get_doc_meta(path)
        if got is None:
            return
        c = got[0].get("pool_claim") or {}
        if c.get("pool") != pool_id or c.get("device") != devices.device_id():
            return
        if cloud.set_doc(path, {"pool_claim": _claim(pool_id, "done" if ok else "failed")}, merge=True, if_update_time=got[1]):
            return


def states(pool_id: str) -> dict[str, tuple[str, str]]:
    """{match key: (done | busy | free, computer name)} of the pool's claims by other computers."""
    me = devices.device_id()
    rows = cloud.query_docs("scouted", {"pool_claim.pool": pool_id}, limit=1000)
    others = {c.get("device") for _, d, _ in rows if (c := d.get("pool_claim") or {}).get("device") != me}
    found = cloud.list_docs("devices") if others else {}
    out = {}
    for mk, d, _ in rows:
        c = d.get("pool_claim") or {}
        if c.get("device") == me:
            continue
        name = c.get("name") or "another computer"
        if c.get("status") == "done":
            out[mk] = ("done", name)
        else:
            out[mk] = ("free" if _gone(c, found.get(c.get("device"))) else "busy", name)
    return out
