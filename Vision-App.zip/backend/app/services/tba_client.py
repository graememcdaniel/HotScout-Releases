import httpx


BASE_URL = "https://www.thebluealliance.com/api/v3"


async def get_team_events(team_key: str, season: int, tba_auth_key: str) -> list[dict]:
    headers = {"X-TBA-Auth-Key": tba_auth_key}
    url = f"{BASE_URL}/team/{team_key}/events/{season}/simple"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()

    events = resp.json()
    events.sort(key=lambda e: (e.get("start_date", ""), e.get("key", "")))
    return events


async def get_team_event_matches(event_key: str, team_key: str, tba_auth_key: str) -> list[dict]:
    headers = {"X-TBA-Auth-Key": tba_auth_key}
    url = f"{BASE_URL}/team/{team_key}/event/{event_key}/matches"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()

    matches = resp.json()
    matches.sort(key=lambda m: (m.get("comp_level", ""), m.get("match_number", 0), m.get("set_number", 0)))
    return matches


async def get_match_simple(match_key: str, tba_auth_key: str) -> dict:
    headers = {"X-TBA-Auth-Key": tba_auth_key}
    url = f"{BASE_URL}/match/{match_key}/simple"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()
    return resp.json()


async def get_event_matches(event_key: str, tba_auth_key: str) -> list[dict]:
    """All matches of an event (full model, includes ``videos``)."""
    headers = {"X-TBA-Auth-Key": tba_auth_key}
    url = f"{BASE_URL}/event/{event_key}/matches"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()
    return resp.json()


async def get_event_simple(event_key: str, tba_auth_key: str) -> dict:
    headers = {"X-TBA-Auth-Key": tba_auth_key}
    url = f"{BASE_URL}/event/{event_key}/simple"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()
    return resp.json()


async def get_season_events(season: int, tba_auth_key: str) -> list[dict]:
    headers = {"X-TBA-Auth-Key": tba_auth_key}
    url = f"{BASE_URL}/events/{season}/simple"

    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(url, headers=headers)
        resp.raise_for_status()

    events = resp.json()
    events.sort(key=lambda e: (e.get("start_date", ""), e.get("name", "")))
    return events
