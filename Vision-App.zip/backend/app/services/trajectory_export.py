import csv
import json
import re
from pathlib import Path

from app.core.config import settings

_CSV_FIELDS = [
    "t_sec",
    "x_m",
    "y_m",
    "z_m",
    "confidence",
    "position_confidence",
    "identity_confidence",
    "sigma_m",
    "inferred",
    "z_source",
    "track_id",
]


def _safe_dir_name(match_key: str) -> str:
    # match_key comes from the client; never let it escape the output dir.
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", match_key or "").strip("_")
    return name or "match"


def export_csv_json(
    match_key: str, points: list[dict], path: dict | None = None, team_key: str | None = None
) -> dict[str, str]:
    out_dir = Path(settings.output_dir) / _safe_dir_name(match_key)
    if team_key:
        out_dir = out_dir / _safe_dir_name(team_key)
    out_dir.mkdir(parents=True, exist_ok=True)

    csv_path = out_dir / "trajectory.csv"
    json_path = out_dir / "trajectory.json"

    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=_CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(points)

    with json_path.open("w", encoding="utf-8") as f:
        json.dump(points, f, indent=2)

    files = {
        "csv": str(csv_path.resolve()),
        "json": str(json_path.resolve()),
    }
    if path is not None:
        path_file = out_dir / "path.json"
        with path_file.open("w", encoding="utf-8") as f:
            json.dump(path, f, indent=2)
        files["path"] = str(path_file.resolve())
    return files


def export_robots_json(match_key: str, payload: dict) -> str:
    """Write the match's 6-robot result to ``outputs/<match>/robots.json``."""
    out_dir = Path(settings.output_dir) / _safe_dir_name(match_key)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "robots.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, indent=1)
    return str(path.resolve())


_MATCH_KEY_RE = re.compile(r"(?P<event>[0-9]{4}[a-z0-9]+)_(?P<level>qm|ef|qf|sf|f)(?:(?P<set>[0-9]+)m)?(?P<num>[0-9]+)")
_TEAM_KEY_RE = re.compile(r"frc([0-9]{1,5})")


def parse_match_key(match_key: str) -> dict:
    """TBA match key -> event / comp level / set / match number (None when not a TBA key)."""
    m = _MATCH_KEY_RE.fullmatch((match_key or "").strip().lower())
    if not m:
        return {"event_key": None, "comp_level": None, "set_number": None, "match_number": None}
    return {
        "event_key": m["event"],
        "comp_level": m["level"],
        "set_number": int(m["set"]) if m["set"] else None,
        "match_number": int(m["num"]),
    }


# Team files use the official WPILib field frame: blue alliance wall at x=0,
# red at x=length. Tracking runs in the calibration frame, which is the
# official frame with the calibration's tag layout transform applied (e.g.
# "flip_x" when the reference points were clicked from the red end).
FIELD_FRAME = "wpilib"
_LAYOUT_TRANSFORMS = {"none", "flip_x", "flip_y", "rotate_180"}
_DEFAULT_DIMS = (16.54, 8.21)


def to_wpilib_points(points: list[dict], transform: str | None, dims) -> list[dict]:
    """Calibration-frame points -> official field frame (every transform is its own inverse)."""
    mode = (transform or "none").strip().lower()
    if mode not in _LAYOUT_TRANSFORMS or mode == "none":
        return list(points)
    length, width = (float(v) for v in (dims or _DEFAULT_DIMS)[:2])
    out = []
    for p in points:
        q = dict(p)
        if mode in {"flip_x", "rotate_180"} and q.get("x_m") is not None:
            q["x_m"] = length - float(q["x_m"])
        if mode in {"flip_y", "rotate_180"} and q.get("y_m") is not None:
            q["y_m"] = width - float(q["y_m"])
        out.append(q)
    return out


def team_paths_dir(match_key: str) -> Path:
    return Path(settings.output_dir) / _safe_dir_name(match_key) / "teams"


def team_path_file(match_key: str, team_key: str) -> Path | None:
    m = _TEAM_KEY_RE.fullmatch(team_key or "")
    if not m:
        return None
    return team_paths_dir(match_key) / f"{_safe_dir_name(match_key)}_{m[1]}.json"


def export_team_paths(match_key: str, payload: dict) -> list[str]:
    """Write one JSON per assigned team: ``outputs/<match>/teams/<match>_<team>.json``.

    ``payload`` is the robots.json payload; robots without a team are skipped.
    Files of teams no longer assigned in this match are removed.
    """
    out_dir = team_paths_dir(match_key)
    out_dir.mkdir(parents=True, exist_ok=True)
    match_info = parse_match_key(match_key)
    transform = payload.get("field_transform")
    dims = payload.get("field_dims_m")
    written: list[Path] = []
    for r in payload.get("robots", []):
        path = team_path_file(match_key, r.get("team_key") or "")
        if path is None:
            continue
        doc = {
            **match_info,
            "match_key": match_key,
            "team_key": r["team_key"],
            "team_number": int(r["team_key"][3:]),
            "alliance": r.get("alliance"),
            "robot_slot": r.get("robot_id"),
            "team_id": r.get("team_id") or {"method": "manual"},
            "run_id": payload.get("run_id"),
            "time_reference": payload.get("time_reference"),
            "tracking_start_sec": payload.get("tracking_start_sec"),
            "tracking_end_sec": payload.get("tracking_end_sec"),
            "field_dims_m": payload.get("field_dims_m"),
            "field_frame": FIELD_FRAME,
            "first_t_sec": r.get("first_t_sec"),
            "last_t_sec": r.get("last_t_sec"),
            "observed_fraction": r.get("observed_fraction"),
            "detected": bool(r.get("path_points")),
            "path_summary": r.get("path_summary", {}),
            "path_nodes": to_wpilib_points(r.get("path_nodes", []), transform, dims),
            "path_points": to_wpilib_points(r.get("path_points", []), transform, dims),
            "trajectory": to_wpilib_points(r.get("trajectory", []), transform, dims),
        }
        with path.open("w", encoding="utf-8") as f:
            json.dump(doc, f, indent=1)
        written.append(path)
    # Teams in the TBA lineup that were never matched to a tracked robot still
    # get a file, so every match always has all six teams.
    for miss in payload.get("missing_teams", []):
        path = team_path_file(match_key, miss.get("team_key") or "")
        if path is None or path in written:
            continue
        with path.open("w", encoding="utf-8") as f:
            json.dump(not_detected_doc(match_key, miss["team_key"], miss.get("alliance"), payload), f, indent=1)
        written.append(path)
    for old in out_dir.glob("*.json"):
        if old not in written:
            old.unlink()
    return [str(p.resolve()) for p in written]


def not_detected_doc(match_key: str, team_key: str, alliance: str | None, meta: dict) -> dict:
    return {
        **parse_match_key(match_key),
        "match_key": match_key,
        "team_key": team_key,
        "team_number": int(team_key[3:]),
        "alliance": alliance,
        "robot_slot": None,
        "team_id": {"method": "not_detected", "confidence": 0.0, "needs_review": True},
        "run_id": meta.get("run_id"),
        "time_reference": meta.get("time_reference"),
        "tracking_start_sec": meta.get("tracking_start_sec"),
        "tracking_end_sec": meta.get("tracking_end_sec"),
        "field_dims_m": meta.get("field_dims_m"),
        "field_frame": FIELD_FRAME,
        "first_t_sec": None,
        "last_t_sec": None,
        "observed_fraction": 0.0,
        "detected": False,
        "path_summary": {},
        "path_nodes": [],
        "path_points": [],
        "trajectory": [],
    }


def fill_missing_team_files(match_key: str, lineup: dict) -> list[str]:
    """Add "not detected" files for lineup teams that have no file yet (older runs)."""
    out_dir = team_paths_dir(match_key)
    meta: dict = {}
    for f in out_dir.glob("*.json"):
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        keys = ("run_id", "time_reference", "tracking_start_sec", "tracking_end_sec", "field_dims_m")
        meta = {k: doc.get(k) for k in keys}
        break
    written = []
    for color in ("red", "blue"):
        for team_key in lineup.get(color) or []:
            path = team_path_file(match_key, team_key or "")
            if path is None or path.exists():
                continue
            out_dir.mkdir(parents=True, exist_ok=True)
            with path.open("w", encoding="utf-8") as f:
                json.dump(not_detected_doc(match_key, team_key, color, meta), f, indent=1)
            written.append(str(path.resolve()))
    return written


def _match_transform(match_key: str, run_id: str | None) -> str | None:
    """Calibration layout transform a match was tracked with (None if unknown)."""
    try:
        robots = json.loads((team_paths_dir(match_key).parent / "robots.json").read_text(encoding="utf-8"))
        if robots.get("field_transform"):
            return str(robots["field_transform"])
        run_id = run_id or robots.get("run_id")
    except (OSError, ValueError):
        pass
    if run_id and re.fullmatch(r"[0-9a-f]{32}", run_id):
        try:
            run = json.loads((Path(settings.output_dir) / "runs" / f"{run_id}.json").read_text(encoding="utf-8"))
            if run.get("context", {}).get("tag_layout_transform"):
                return str(run["context"]["tag_layout_transform"])
        except (OSError, ValueError):
            pass
    event_key = parse_match_key(match_key)["event_key"]
    if event_key:
        from app.services.event_calibration_store import load_event_calibration

        try:
            cal = load_event_calibration(event_key)
        except ValueError:
            cal = None
        if cal:
            return str((cal.get("calibration_meta") or {}).get("tag_layout_transform") or "none")
    return None


def migrate_match_frame(match_key: str) -> list[str]:
    """Convert a match's older team files (calibration frame) to the official field frame."""
    written = []
    transform: str | None = None
    looked_up = False
    for f in sorted(team_paths_dir(match_key).glob("*.json")):
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if doc.get("field_frame"):
            continue
        if not looked_up:
            transform, looked_up = _match_transform(match_key, doc.get("run_id")), True
        if transform is None:
            break
        dims = doc.get("field_dims_m") or _DEFAULT_DIMS
        for k in ("path_points", "path_nodes", "trajectory"):
            doc[k] = to_wpilib_points(doc.get(k) or [], transform, dims)
        doc["field_frame"] = FIELD_FRAME
        f.write_text(json.dumps(doc, indent=1), encoding="utf-8")
        written.append(str(f.resolve()))
    return written


def migrate_event_frame(event_key: str) -> dict[str, list[str]]:
    """``migrate_match_frame`` for every scouted match of an event: ``{match_key: files}``."""
    out = {}
    for d in sorted(Path(settings.output_dir).glob(f"{event_key}_*")):
        if d.is_dir() and parse_match_key(d.name)["event_key"] == event_key:
            files = migrate_match_frame(d.name)
            if files:
                out[d.name] = files
    return out


def read_match_autos(match_key: str, with_points: bool = True) -> list[dict]:
    """Compact view of a match's saved team files (for the UI autos gallery)."""
    slot_order = {f"{c}{i}": n for n, (c, i) in enumerate((c, i) for c in ("red", "blue") for i in (1, 2, 3))}
    out = []
    for f in team_paths_dir(match_key).glob("*.json"):
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if not doc.get("team_key"):
            continue
        tid = doc.get("team_id") or {}
        pts = doc.get("path_points") or []
        item = {
            "team_key": doc["team_key"],
            "team_number": doc.get("team_number"),
            "alliance": doc.get("alliance"),
            "robot_slot": doc.get("robot_slot"),
            "detected": bool(doc.get("detected", bool(pts))),
            "method": tid.get("method"),
            "confidence": tid.get("confidence"),
            "needs_review": bool(tid.get("needs_review")),
        }
        if with_points:
            item["field_dims_m"] = doc.get("field_dims_m")
            item["points"] = [
                [round(p.get("t_sec", 0.0), 2), round(p["x_m"], 2), round(p["y_m"], 2), 1 if p.get("inferred") else 0]
                for p in pts
                if p.get("x_m") is not None and p.get("y_m") is not None
            ]
        out.append(item)
    out.sort(key=lambda d: (0 if d["alliance"] == "red" else 1, slot_order.get(d["robot_slot"] or "", 9), d["team_key"]))
    return out
