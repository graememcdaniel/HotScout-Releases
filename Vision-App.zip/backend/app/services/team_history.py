"""Team auto history: learn how each team runs its auto and use it to fix
which tracked robot is which team.

Teams nearly always start their auto from the same spot and run one of a few
routines. All of a team's scouted autos at an event form a small generative
model of that team: a kernel mixture over its start spot and path shape, in
its alliance's own frame (blue autos are mirrored onto the red side). How well
a tracked robot fits each team's model is added to the bumper-number votes and
the robots of each match are re-assigned to teams.

Manual assignments, matches a scout marked good and confident bumper reads are
never changed; they are the strongest examples the models learn from.
"""

from __future__ import annotations

import json
import logging
import math
import threading
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
from scipy.optimize import linear_sum_assignment

from app.core.config import settings
from app.services import rescout
from app.services.trajectory_export import migrate_event_frame, not_detected_doc, team_path_file, team_paths_dir

log = logging.getLogger(__name__)

# Kernel widths (m) for the start spot and the mean distance along the path.
SIG_START = 0.8
SIG_PATH = 1.5
START_SHARE = 0.6
# One strong history fit counts about as much as two clear bumper reads.
HISTORY_WEIGHT = 2.0
KEEP_BONUS = 0.15
# Bumper reads at least this confident are kept as they are.
TRUSTED_OCR = 0.6
MAX_ROUNDS = 6
_TIMES = np.arange(0.0, 15.01, 0.5)
_DEFAULT_DIMS = (16.54, 8.21)

_lock = threading.Lock()


@dataclass
class _Item:
    file: Path
    doc: dict
    match: str
    alliance: str
    team: str
    slot: str | None
    path: tuple[np.ndarray, np.ndarray] | None = None
    locked: bool = False
    weight: float = 0.3
    fits: dict = field(default_factory=dict)


def _method(doc: dict) -> str:
    tid = doc.get("team_id")
    # Files without team_id predate bumper reading: they were assigned by hand.
    return "manual" if tid is None else str(tid.get("method") or "manual")


def _confidence(doc: dict) -> float:
    return float((doc.get("team_id") or {}).get("confidence") or 0.0)


def _points(doc: dict) -> np.ndarray | None:
    pts = [
        (p["t_sec"], p["x_m"], p["y_m"])
        for p in doc.get("trajectory") or []
        if p.get("t_sec") is not None and p.get("x_m") is not None and p.get("y_m") is not None
    ]
    if len(pts) < 5:
        return None
    a = np.array(pts, dtype=float)
    return a[np.argsort(a[:, 0])]


def _to_own_frame(xy: np.ndarray, alliance: str, dims: tuple[float, float], symmetry: str) -> np.ndarray:
    if alliance == "red":
        return xy
    out = xy.copy()
    out[..., 0] = dims[0] - out[..., 0]
    if symmetry == "rotate":
        out[..., 1] = dims[1] - out[..., 1]
    return out


def _resample(pts: np.ndarray, alliance: str, dims, symmetry: str) -> tuple[np.ndarray, np.ndarray]:
    xy = np.column_stack([np.interp(_TIMES, pts[:, 0], pts[:, 1]), np.interp(_TIMES, pts[:, 0], pts[:, 2])])
    valid = (_TIMES >= pts[0, 0] - 0.5) & (_TIMES <= pts[-1, 0] + 0.5)
    return _to_own_frame(xy, alliance, dims, symmetry), valid


def _similarity(a: tuple[np.ndarray, np.ndarray], b: tuple[np.ndarray, np.ndarray]) -> float:
    (pa, va), (pb, vb) = a, b
    d_start = float(np.hypot(*(pa[0] - pb[0])))
    both = va & vb
    d_path = float(np.mean(np.hypot(*(pa[both] - pb[both]).T))) if both.sum() >= 4 else d_start
    return START_SHARE * math.exp(-0.5 * (d_start / SIG_START) ** 2) + (1 - START_SHARE) * math.exp(
        -0.5 * (d_path / SIG_PATH) ** 2
    )


def _symmetry(items: list[_Item], dims) -> str:
    """Mirror or 180-degree rotation: whichever makes teams' red and blue starts agree."""
    starts: dict[str, dict[str, list[np.ndarray]]] = defaultdict(lambda: {"red": [], "blue": []})
    for it in items:
        pts = _points(it.doc) if it.slot else None
        if pts is not None and it.alliance in ("red", "blue"):
            starts[it.team][it.alliance].append(pts[0, 1:3])
    score = {}
    for sym in ("mirror", "rotate"):
        d = [
            float(np.hypot(*(r - _to_own_frame(b, "blue", dims, sym))))
            for s in starts.values()
            for r in s["red"]
            for b in s["blue"]
        ]
        score[sym] = float(np.median(d)) if len(d) >= 4 else None
    if score["mirror"] is None or score["rotate"] is None:
        return "mirror"
    return "mirror" if score["mirror"] <= score["rotate"] else "rotate"


def _load(event_key: str) -> list[_Item]:
    items = []
    for f in sorted(Path(settings.output_dir).glob(f"{event_key}_*/teams/*.json")):
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if not doc.get("team_key") or doc.get("alliance") not in ("red", "blue") or not doc.get("match_key"):
            continue
        items.append(
            _Item(
                file=f,
                doc=doc,
                match=doc["match_key"],
                alliance=doc["alliance"],
                team=doc["team_key"],
                slot=doc.get("robot_slot") if doc.get("detected", True) is not False else None,
            )
        )
    return items


def _fit(team: str, path, match: str, exemplars: dict[str, list[tuple[str, tuple, float]]]) -> float | None:
    """How well a path fits the team's other autos (0..1), None without history."""
    best = None
    for m, p, w in exemplars.get(team, []):
        if m == match:
            continue
        s = w * _similarity(path, p)
        best = s if best is None else max(best, s)
    return best


def _solve_group(slots: list[_Item], teams: list[str], exemplars) -> dict[int, tuple[str, float, dict]] | None:
    """Best slot -> team assignment for one alliance of one match, or None without any history."""
    F = np.full((len(slots), len(teams)), np.nan)
    for i, s in enumerate(slots):
        for k, t in enumerate(teams):
            v = _fit(t, s.path, s.match, exemplars)
            if v is not None:
                F[i, k] = v
    if np.isnan(F).all():
        return None
    # Teams without history get a typical fit, so they are neither favoured nor penalised.
    Fn = np.where(np.isnan(F), np.nanmean(F), F)
    O = np.array([[float(((s.doc.get("team_id") or {}).get("scores") or {}).get(t, 0.0)) for t in teams] for s in slots])
    # Small preference for the current assignment: change only on real evidence.
    keep = np.array([[KEEP_BONUS if s.team == t else 0.0 for t in teams] for s in slots])
    C = O + HISTORY_WEIGHT * Fn + keep
    rows, cols = linear_sum_assignment(-C)
    total = C[rows, cols].sum()
    out = {}
    for i, k in zip(rows, cols):
        if len(slots) == 1 and len(teams) == 1:
            conf = 0.6
        else:
            alt = C.copy()
            alt[i, k] = -1e6
            ar, ac = linear_sum_assignment(-alt)
            alt_total = alt[ar, ac].sum()
            margin = total - alt_total if alt_total > -1e5 else 2.0
            conf = float(min(0.9, max(0.2, 0.2 + 0.3 * margin)))
        fits = {t: round(float(F[i, j]), 2) for j, t in enumerate(teams) if not np.isnan(F[i, j])}
        out[id(slots[i])] = (teams[k], conf, fits)
    return out


def refine_event(event_key: str, apply: bool = True) -> dict:
    """Re-assign robots to teams across an event using every team's auto history.

    Returns ``{symmetry, teams_modelled, changes, updated_files}``;
    ``updated_files`` maps match key -> rewritten team files.
    """
    with _lock:
        # Older files are in the calibration frame; models need one frame for the whole event.
        migrated = migrate_event_frame(event_key) if apply else {}
        items = _load(event_key)
        if not items:
            return {"event_key": event_key, "symmetry": None, "teams_modelled": 0, "changes": [], "updated_files": migrated}
        dims = tuple(next((it.doc["field_dims_m"] for it in items if it.doc.get("field_dims_m")), _DEFAULT_DIMS))
        symmetry = _symmetry(items, dims)

        by_match: dict[str, list[_Item]] = defaultdict(list)
        for it in items:
            by_match[it.match].append(it)
        locked_matches = {m for m, its in by_match.items() if any(_method(it.doc) in ("manual", "hand_check") for it in its)}
        locked_matches |= rescout.good_matches(event_key) & set(by_match)
        for it in items:
            pts = _points(it.doc) if it.slot else None
            if pts is not None:
                it.path = _resample(pts, it.alliance, dims, symmetry)
        # A start on the other alliance's half is a tracking error: neither learn from it nor relabel it.
        own_starts = [it.path[0][0, 0] for it in items if it.path is not None]
        if own_starts:
            left = float(np.median(own_starts)) < dims[0] / 2
            for it in items:
                if it.path is not None and (it.path[0][0, 0] > dims[0] / 2 + 0.5 if left else it.path[0][0, 0] < dims[0] / 2 - 0.5):
                    it.path = None
        for it in items:
            trusted = _method(it.doc) == "bumper_ocr" and _confidence(it.doc) >= TRUSTED_OCR
            it.locked = it.match in locked_matches or trusted or it.path is None
            it.weight = 1.0 if it.locked else min(0.8, max(0.25, _confidence(it.doc)))

        groups = []
        for m, its in by_match.items():
            if m in locked_matches:
                continue
            for al in ("red", "blue"):
                mine = [it for it in its if it.alliance == al]
                slots = [it for it in mine if it.slot]
                taken = {it.team for it in slots if it.locked}
                free = [it for it in slots if not it.locked]
                teams = [it.team for it in mine if it.team not in taken]
                if free and teams:
                    groups.append((free, teams))

        team_of = {id(it): it.team for it in items if it.slot}
        result: dict[int, tuple[str, float, dict]] = {}
        for _ in range(MAX_ROUNDS):
            exemplars: dict[str, list] = defaultdict(list)
            for it in items:
                if it.slot and it.path is not None:
                    w = it.weight if id(it) not in result else min(0.8, max(0.25, result[id(it)][1]))
                    exemplars[team_of[id(it)]].append((it.match, it.path, w))
            changed = False
            for free, teams in groups:
                solved = _solve_group(free, teams, exemplars)
                if solved is None:
                    continue
                for it in free:
                    if id(it) in solved:
                        result[id(it)] = solved[id(it)]
                        if team_of[id(it)] != solved[id(it)][0]:
                            team_of[id(it)] = solved[id(it)][0]
                            changed = True
            if not changed:
                break

        modelled = len({t for t, ex in exemplars.items() if ex})
        changes, updated = [], {m: list(files) for m, files in migrated.items()}
        for free, teams in groups:
            if not any(id(it) in result for it in free):
                continue
            new = {id(it): result[id(it)] for it in free if id(it) in result}
            moved = [it for it in free if id(it) in new and new[id(it)][0] != it.team]
            relabel = [it for it in free if id(it) in new and new[id(it)][0] == it.team and _method(it.doc) == "best_guess"]
            if not moved and not relabel:
                continue
            for it in moved:
                changes.append(
                    {
                        "match_key": it.match,
                        "robot_slot": it.slot,
                        "from": it.team,
                        "to": new[id(it)][0],
                        "confidence": round(new[id(it)][1], 2),
                    }
                )
            if apply:
                match, alliance = free[0].match, free[0].alliance
                files = _rewrite_alliance(by_match[match], alliance, new)
                done = updated.setdefault(match, [])
                done.extend([f for f in files if f not in done])
        return {
            "event_key": event_key,
            "symmetry": symmetry,
            "teams_modelled": modelled,
            "changes": changes,
            "updated_files": updated,
        }


def _rewrite_alliance(match_items: list[_Item], alliance: str, new: dict[int, tuple[str, float, dict]]) -> list[str]:
    """Write the alliance's team files for the new slot -> team assignment."""
    mine = [it for it in match_items if it.alliance == alliance]
    match_key = mine[0].match
    lineup = [it.team for it in mine]
    docs: dict[str, dict] = {}
    for it in mine:
        if not it.slot:
            continue
        if id(it) in new:
            team, conf, fits = new[id(it)]
            old_tid = it.doc.get("team_id") or {}
            tid = {
                **{k: v for k, v in old_tid.items() if k in ("scores", "reads")},
                "method": "team_history",
                "confidence": round(conf, 2),
                "needs_review": conf < 0.5,
                "history_fit": fits,
            }
            if team != it.team or old_tid.get("method") != "team_history":
                tid["previous"] = {"team_key": it.team, "method": old_tid.get("method"), "confidence": old_tid.get("confidence")}
            elif old_tid.get("previous"):
                tid["previous"] = old_tid["previous"]
        else:
            team, tid = it.team, it.doc.get("team_id")
        docs[team] = {**it.doc, "team_key": team, "team_number": int(team[3:]), "team_id": tid}
    meta_src = next((it.doc for it in mine), {})
    for team in lineup:
        if team not in docs:
            docs[team] = not_detected_doc(match_key, team, alliance, meta_src)
    written = []
    for team, doc in docs.items():
        path = team_path_file(match_key, team)
        if path is None:
            continue
        path.write_text(json.dumps(doc, indent=1), encoding="utf-8")
        written.append(str(path.resolve()))
    _update_robots_json(match_key, alliance, docs)
    return written


def swap_teams(match_key: str, team_a: str, team_b: str) -> list[str]:
    """Swap two teams' robots (paths) in a match's saved autos, by hand.

    The swap counts as a manual assignment, so ``refine_event`` never changes
    this match again. Returns the rewritten team files.
    """
    with _lock:
        items = []
        for f in sorted(team_paths_dir(match_key).glob("*.json")):
            try:
                doc = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if doc.get("team_key"):
                slot = doc.get("robot_slot") if doc.get("detected", True) is not False else None
                items.append(_Item(file=f, doc=doc, match=match_key, alliance=doc.get("alliance"), team=doc["team_key"], slot=slot))
        by_team = {it.team: it for it in items}
        a, b = by_team.get(team_a), by_team.get(team_b)
        if a is None or b is None:
            raise ValueError(f"{(team_a if a is None else team_b)[3:]} is not in {match_key}")
        if a.alliance != b.alliance:
            raise ValueError("Only teams on the same alliance can be swapped")
        if "hand_check" in (_method(a.doc), _method(b.doc)):
            raise ValueError("These autos come from your hand check; fix the teams there (Check)")
        if not a.slot and not b.slot:
            raise ValueError("Neither robot was seen; there is no path to swap")
        swap = {team_a: team_b, team_b: team_a}
        docs: dict[str, dict] = {}
        for it in (a, b):
            if not it.slot:
                continue
            team = swap[it.team]
            old = it.doc.get("team_id") or {}
            tid = {
                **{k: v for k, v in old.items() if k in ("scores", "reads")},
                "method": "manual",
                "confidence": 1.0,
                "needs_review": False,
                "previous": {"team_key": it.team, "method": old.get("method"), "confidence": old.get("confidence")},
            }
            docs[team] = {**it.doc, "team_key": team, "team_number": int(team[3:]), "team_id": tid}
        for it in (a, b):
            if it.team not in docs:  # its robot went to the other team: now not seen
                docs[it.team] = not_detected_doc(match_key, it.team, it.alliance, (a if a.slot else b).doc)
        written = []
        for team, doc in docs.items():
            path = team_path_file(match_key, team)
            path.write_text(json.dumps(doc, indent=1), encoding="utf-8")
            written.append(str(path.resolve()))
        _update_robots_json(match_key, a.alliance, docs)
        return written


def _update_robots_json(match_key: str, alliance: str, docs: dict[str, dict]) -> None:
    path = team_path_file(match_key, next(iter(docs))).parent.parent / "robots.json"
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    by_slot = {d.get("robot_slot"): d for d in docs.values() if d.get("robot_slot")}
    for r in payload.get("robots", []):
        d = by_slot.get(r.get("robot_id"))
        if d is not None:
            r["team_key"] = d["team_key"]
            r["team_id"] = d.get("team_id")
    assigned = {r.get("team_key") for r in payload.get("robots", []) if r.get("team_key")}
    lineup = payload.get("lineup") or {}
    payload["missing_teams"] = [
        {"team_key": t, "alliance": c} for c in ("red", "blue") for t in lineup.get(c, []) if t and t not in assigned
    ]
    path.write_text(json.dumps(payload, indent=1), encoding="utf-8")
