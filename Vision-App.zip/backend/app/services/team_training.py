"""Training the robot detector on several team GPUs at once.

Used when continuing from the season's current model while other team computers
(new enough, sharing their GPU, idle) are on. This computer cuts the tiles as
usual and uploads the training split once. Training then runs in rounds: each
computer trains a few epochs on its share of the tiles, all starting from the
same weights; this computer averages the results (weighted by tiles) and scores
the average on the held-out tiles. Shares follow each GPU's measured speed, so a
faster GPU gets more tiles. A computer that is much slower, stops or goes off is
dropped and the rest carry on. The best average then gets the usual held-out
frame test in ``detector_training``.

Only weights (plain tensors, loaded with ``weights_only=True``) and tiles travel
between computers, never pickled model files.

Layout::

    Storage   training/{run}/data_{i}.zip        training tiles (images/, labels/)
    Storage   training/{run}/global_{n}.pt       weights every computer starts round n from
    Storage   training/{run}/{device}_{n}.pt     a helper's weights after round n
    Firestore remote_jobs/{id}                   kind "train", request {run, season, arch, parts},
                                                 round {n, weights, seed, lo, hi, epochs, ...},
                                                 result {n, weights, seconds}, beat_at, status, ...
"""

from __future__ import annotations

import asyncio
import io
import json
import logging
import math
import re
import shutil
import tempfile
import time
import uuid
import zipfile
from pathlib import Path

import numpy as np
from fastapi.concurrency import run_in_threadpool

from app.core.gpu import torch_device
from app.services import cloud, devices, scout_jobs
from app.services import detector_training as dt
from app.services.detector_worker import OOM_EXIT
from app.tracking import training_data as td

log = logging.getLogger(__name__)

ROUND_EPOCHS = 5
PATIENCE_ROUNDS = 3  # stop after this many rounds without a better average (15 epochs, as when alone)
PART_BYTES = 80 * 2**20  # tiles per upload (Storage rules allow 100 MB)
CLAIM_SEC = 90  # computers that haven't taken their part by then are left out
JOIN_SEC = 20 * 60  # first round: helpers download the tiles before training
LATE_FACTOR = 2.5  # a helper that takes this many times longer than this computer's round is dropped
MIN_WAIT_SEC = 180
POLL_SEC = 5
BEAT_SEC = 20
MIN_SLICE = 16  # tiles; a smaller share isn't worth a round
LR0 = round(0.002 * 5 / (4 + len(td.CLASSES)), 6)  # what Ultralytics' "auto" optimizer picks (AdamW)
LRF = 0.01  # last epoch's learning rate, as a fraction of LR0 (Ultralytics' default)

_RUN_ID = re.compile(r"^[0-9a-f]{12}$")
_helping: dict | None = None
_tasks: set[asyncio.Task] = set()


class NotStarted(RuntimeError):
    """No other computer took part: nothing was trained, train here as usual."""


def available(arch: str) -> list[dict]:
    """Team computers that could help train ``arch`` right now."""
    need = dt.BASE_MODELS.get(arch, 0.0)
    found, _ = devices.list_devices()
    return [
        d
        for d in found
        if not d["this"]
        and d["online"]
        and d.get("accept_remote")
        and d.get("can_train")
        and not d.get("scout")
        and not d.get("training")
        and float((d.get("gpu") or {}).get("memory_gb") or 0) >= max(need, 1.0)
    ]


def helping() -> dict | None:
    """This computer's share of another computer's training run, if it is helping one."""
    return _helping


# ---------------------------------------------------------------- shared helpers


def _lr(epoch: int, total: int) -> float:
    """Ultralytics' linear schedule over the whole run."""
    return LR0 * ((1 - epoch / total) * (1 - LRF) + LRF)


def _slice(names: list[str], seed: int, lo: float, hi: float) -> list[str]:
    order = np.random.default_rng(seed).permutation(len(names))
    return [names[i] for i in order[int(round(lo * len(names))) : int(round(hi * len(names)))]]


def _round_data(images: Path, names: list[str], folder: Path) -> Path:
    """Dataset file for one round: this computer's share of the tiles."""
    paths = [str((images / n).resolve()) for n in names]
    (folder / "round.txt").write_text("\n".join(paths) + "\n", encoding="utf-8")
    (folder / "round_val.txt").write_text("\n".join(paths[:MIN_SLICE]) + "\n", encoding="utf-8")
    yaml = folder / "round.yaml"
    yaml.write_text(
        f"path: {json.dumps(str(folder.resolve()))}\n"
        f"train: {json.dumps(str((folder / 'round.txt').resolve()))}\n"
        f"val: {json.dumps(str((folder / 'round_val.txt').resolve()))}\n"
        "names:\n" + "".join(f"  {i}: {n}\n" for i, n in enumerate(td.CLASSES)),
        encoding="utf-8",
    )
    return yaml


def _run_round(job: dict, season: int, arch: str, images: Path, folder: Path, names: list[str], base: Path,
               weights: Path, r: dict, t0: float) -> dict | None:
    """Train one round here; None if cancelled."""
    yaml = _round_data(images, names, folder)
    out = folder / f"round_{r['n']}.pt"
    for batch in dt.batch_attempts(arch):
        args = [
            "--mode", "round",
            "--data", str(yaml.resolve()),
            "--base", str(base.resolve()),
            "--weights", str(weights.resolve()),
            "--project", str(folder.resolve()),
            "--epochs", str(r["epochs"]),
            "--imgsz", str(td.TILE),
            "--batch", str(batch),
            "--device", torch_device(),
            "--lr0", str(r["lr0"]),
            "--lrf", str(r["lrf"]),
            "--mosaic", str(r["mosaic"]),
            "--epoch-offset", str(r["offset"]),
            "--epochs-total", str(r["total"]),
            "--out", str(out.resolve()),
        ]
        code, result, tail = dt._spawn(job, args, t0)
        if job["cancel_requested"]:
            return None
        if code == OOM_EXIT:
            log.warning("training round out of GPU memory at batch %d; stepping down", batch)
            continue
        if code != 0 or result is None:
            raise RuntimeError(f"Training round stopped (exit {code}): {tail or 'no output'}")
        dt.remember_batch(arch, batch)
        return {**result, "out": out, "batch": batch}
    raise RuntimeError("Not enough free GPU memory to train, even at small sizes. Close other programs using the GPU.")


def _weights_of(model_file: Path, out: Path) -> None:
    """Plain weights of this computer's own model file."""
    import torch

    ckpt = torch.load(model_file, map_location="cpu", weights_only=False)  # our own file, not a download
    model = ckpt.get("ema") or ckpt["model"]
    torch.save({k: v.half() if v.is_floating_point() else v for k, v in model.state_dict().items()}, out)


def _build_base(arch: str, weights: Path, out: Path) -> None:
    """A model file of ``arch`` with downloaded plain weights (no pickled code is loaded)."""
    import torch
    from ultralytics.nn.tasks import DetectionModel

    model = DetectionModel(Path(arch).with_suffix(".yaml").name, nc=len(td.CLASSES), verbose=False)
    model.load_state_dict(torch.load(weights, map_location="cpu", weights_only=True))
    model.names = dict(enumerate(td.CLASSES))
    torch.save({"model": model.half(), "train_args": {}}, out)


# ---------------------------------------------------------------- this computer leads


def _pack(train: Path):
    """The training split as zip files of about ``PART_BYTES`` (jpgs are stored, not recompressed)."""
    buf = zf = None
    size = 0
    for img in sorted((train / "images").glob("*.jpg")):
        if zf is None:
            buf, size = io.BytesIO(), 0
            zf = zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED)
        zf.write(img, f"images/{img.name}")
        label = train / "labels" / f"{img.stem}.txt"
        if label.is_file():
            zf.write(label, f"labels/{label.name}")
        size += img.stat().st_size
        if size >= PART_BYTES:
            zf.close()
            yield buf.getvalue()
            zf = None
    if zf is not None:
        zf.close()
        yield buf.getvalue()


def _queue(target: dict, request: dict) -> str:
    jid = uuid.uuid4().hex
    now = time.time()
    cloud.set_doc(
        f"remote_jobs/{jid}",
        {
            "kind": "train",
            "target": target["id"],
            "target_name": target.get("name"),
            "request": request,
            "status": "queued",
            "created_by": devices.device_id(),
            "created_by_name": devices.device_name(),
            "created_by_email": cloud.status()["email"],
            "created_at": now,
            "updated_at": now,
            "beat_at": now,
            "round": None,
            "result": None,
            "error": None,
            "cancel_requested": False,
        },
    )
    return jid


def train(job: dict, season: int, ds: dict, work: Path, current: Path, arch: str, epochs: int, helpers: list[dict]) -> dict | None:
    """Train from ``current`` in rounds with ``helpers``. Returns ``{best, epochs_run, batch,
    computers}`` (None if cancelled); raises ``NotStarted`` if no other computer joined."""
    run = uuid.uuid4().hex[:12]
    prefix = f"training/{run}"
    folder = work / "team"
    shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir(parents=True)
    train_dir = work / "data" / "train"
    names = sorted(p.name for p in (train_dir / "images").glob("*.jpg"))
    uploaded: list[str] = []
    team: dict[str, dict] = {}  # remote job id -> {"name", "speed"}
    targets: list[str] = []  # helpers' device ids (their weights files are named after them)
    last_round = 0

    def drop(jid: str, why: str) -> None:
        h = team.pop(jid)
        log.info("team training: %s left (%s)", h["name"], why)
        cloud.quietly(cloud.set_doc, f"remote_jobs/{jid}", {"cancel_requested": True}, True)

    try:
        try:
            parts = []
            for i, blob in enumerate(_pack(train_dir)):
                if job["cancel_requested"]:
                    return None
                job["message"] = f"Sending {len(names)} tiles to {len(helpers)} team computer(s) (part {i + 1})"
                name = f"{prefix}/data_{i}.zip"
                cloud.upload(name, blob, "application/zip")
                uploaded.append(name)
                parts.append(name)
            request = {"run": run, "season": season, "arch": arch, "parts": parts}
            for d in helpers:
                team[_queue(d, request)] = {"name": d.get("name") or "another computer", "speed": None}
                targets.append(d["id"])
        except Exception as exc:
            raise NotStarted(f"could not send the tiles to the team ({exc})") from exc

        job["message"] = f"Waiting for {', '.join(h['name'] for h in team.values())} to join"
        until = time.monotonic() + CLAIM_SEC
        joined: set[str] = set()
        while time.monotonic() < until and len(joined) < len(team) and not job["cancel_requested"]:
            for jid in set(team) - joined:
                doc = cloud.get_doc(f"remote_jobs/{jid}") or {}
                if doc.get("status") not in (None, "queued"):
                    joined.add(jid)
            time.sleep(POLL_SEC)
        for jid in set(team) - joined:
            drop(jid, "did not join")
        if job["cancel_requested"]:
            return None
        if not team:
            raise NotStarted("no team computer joined")

        rounds = math.ceil(epochs / ROUND_EPOCHS)
        my_speed: float | None = None
        best_fit, best_file, stale, batch, done = -1.0, folder / "best.pt", 0, None, 0
        global_sd = folder / "global.pt"
        _weights_of(current, global_sd)
        t0 = time.monotonic()
        job["team"] = sorted(h["name"] for h in team.values())
        for n in range(1, rounds + 1):
            e0, e1 = (n - 1) * ROUND_EPOCHS, min(epochs, n * ROUND_EPOCHS)
            r = {
                "n": n, "seed": n, "epochs": e1 - e0, "offset": e0, "total": epochs,
                "lr0": _lr(e0, epochs), "lrf": _lr(e1, epochs) / _lr(e0, epochs),
                "mosaic": 0.0 if e0 >= epochs - 10 else 1.0,  # Ultralytics' close_mosaic=10
            }
            # Shares by measured speed (tiles x epochs per second); equal before the first round.
            known = [s for s in [my_speed, *(h["speed"] for h in team.values())] if s]
            default = float(np.mean(known)) if known else 1.0
            members = [("me", my_speed or default)] + [(jid, h["speed"] or default) for jid, h in team.items()]
            total_speed = sum(s for _, s in members)
            ranges, lo = {}, 0.0
            for key, s in members:
                ranges[key] = (lo, lo + s / total_speed)
                lo = ranges[key][1]
            ranges[members[-1][0]] = (ranges[members[-1][0]][0], 1.0)
            for jid in list(team):
                if len(_slice(names, n, *ranges[jid])) < MIN_SLICE:
                    drop(jid, "share too small")
            weights_name = f"{prefix}/global_{n}.pt"
            cloud.upload(weights_name, global_sd.read_bytes())
            uploaded.append(weights_name)
            last_round = n
            for jid in team:
                lo, hi = ranges[jid]
                cloud.set_doc(f"remote_jobs/{jid}", {"round": {**r, "weights": weights_name, "lo": lo, "hi": hi}}, merge=True)

            started = time.monotonic()
            mine = _slice(names, n, *ranges["me"])
            res = _run_round(job, season, arch, train_dir / "images", folder, mine, current, global_sd, r, t0)
            if res is None:
                break
            batch = res["batch"]
            my_speed = len(mine) * r["epochs"] / max(1.0, float(res["seconds"]))
            parts = [[str(res["out"].resolve()), len(mine)]]

            deadline = started + max(MIN_WAIT_SEC, LATE_FACTOR * (time.monotonic() - started)) + (JOIN_SEC if n == 1 else 0)
            got: dict[str, dict] = {}
            while set(team) - set(got) and time.monotonic() < deadline and not job["cancel_requested"]:
                waiting = [team[j]["name"] for j in team if j not in got]
                job["message"] = f"Round {n}/{rounds}: waiting for {', '.join(waiting)}"
                for jid in [j for j in team if j not in got]:
                    doc = cloud.get_doc(f"remote_jobs/{jid}")
                    result = (doc or {}).get("result") or {}
                    if doc is None or doc.get("status") in ("failed", "cancelled", "done"):
                        drop(jid, (doc or {}).get("error") or "stopped")
                    elif result.get("n") == n and str(result.get("weights") or "").startswith(prefix + "/"):
                        got[jid] = result
                    elif time.time() - float(doc.get("beat_at") or 0) > devices.ONLINE_SEC:
                        drop(jid, "went offline")
                if set(team) - set(got):
                    time.sleep(POLL_SEC)
            if job["cancel_requested"]:
                break
            for jid in set(team) - set(got):
                drop(jid, "too slow")
            for jid, result in got.items():
                f = folder / f"{jid}_{n}.pt"
                uploaded.append(result["weights"])
                f.write_bytes(cloud.download(result["weights"]))
                tiles = len(_slice(names, n, *ranges[jid]))
                parts.append([str(f.resolve()), tiles])
                team[jid]["speed"] = tiles * r["epochs"] / max(1.0, float(result.get("seconds") or 0))

            job["message"] = f"Round {n}/{rounds}: combining {len(parts)} computers' training"
            avg = folder / f"avg_{n}.pt"
            scores = _average(job, season, arch, ds, current, parts, avg)
            if scores is None:
                break
            done = e1
            _weights_of(avg, global_sd)
            fit = 0.1 * scores["map50"] + 0.9 * scores["map"]  # Ultralytics' fitness
            log.info("team training round %d/%d: %d computers, tile mAP50 %.3f", n, rounds, len(parts), scores["map50"])
            job["progress"] = {"epoch": e1, "epochs": epochs, "map50": round(scores["map50"], 3)}
            if fit > best_fit:
                best_fit, stale = fit, 0
                shutil.copy2(avg, best_file)
            else:
                stale += 1
                if stale >= PATIENCE_ROUNDS:
                    break
        if job["cancel_requested"] or best_fit < 0:
            return None
        return {"best": str(best_file), "epochs_run": done, "batch": batch, "computers": 1 + len(job.get("team") or [])}
    finally:
        for jid in list(team):
            cloud.quietly(cloud.set_doc, f"remote_jobs/{jid}", {"finish": True}, True)
        uploaded += [f"{prefix}/{t}_{k}.pt" for t in targets for k in range(1, last_round + 1)]
        for name in uploaded:
            cloud.quietly(cloud.delete_file, name)


def _average(job: dict, season: int, arch: str, ds: dict, base: Path, parts: list, out: Path) -> dict | None:
    for batch in dt.batch_attempts(arch):
        args = [
            "--mode", "average",
            "--base", str(base.resolve()),
            "--parts", json.dumps(parts),
            "--out", str(out.resolve()),
            "--data", str(Path(ds["data"]).resolve()),
            "--imgsz", str(td.TILE),
            "--batch", str(batch),
            "--device", torch_device(),
        ]
        code, result, tail = dt._spawn(job, args)
        if job["cancel_requested"]:
            return None
        if code == OOM_EXIT:
            continue
        if code != 0 or result is None:
            raise RuntimeError(f"Combining the team's training failed (exit {code}): {tail or 'no output'}")
        return result
    raise RuntimeError("Not enough free GPU memory to test the combined model.")


# ---------------------------------------------------------------- this computer helps


def _safe_member(name: str, allowed: tuple[str, ...]) -> tuple[str, str] | None:
    """(folder, file) of a zip entry, if it is a plain tile or label file."""
    folder, _, file = name.partition("/")
    if folder not in ("images", "labels") or not file or any(c in file for c in "/\\:") or file.startswith("."):
        return None
    return (folder, file) if Path(file).suffix.lower() in allowed else None


def _fetch(req: dict, folder: Path, state: dict) -> list[str]:
    data = folder / "data"
    for sub in ("images", "labels"):
        (data / sub).mkdir(parents=True, exist_ok=True)
    prefix = f"training/{req['run']}/"
    for i, name in enumerate(req["parts"]):
        if not str(name).startswith(prefix):
            raise RuntimeError(f"unexpected file {name}")
        state["message"] = f"Getting tiles from {state['for']} (part {i + 1}/{len(req['parts'])})"
        with zipfile.ZipFile(io.BytesIO(cloud.download(name))) as zf:
            for info in zf.infolist():
                where = _safe_member(info.filename, (".jpg", ".txt"))
                if where:
                    (data / where[0] / where[1]).write_bytes(zf.read(info))
    return sorted(p.name for p in (data / "images").glob("*.jpg"))


async def _beat(path: str, state: dict) -> None:
    """Tell the leading computer this one is alive; notice when it calls the run off."""
    while True:
        try:
            doc = await run_in_threadpool(cloud.get_doc, path)
            if doc is None or doc.get("cancel_requested") or doc.get("finish"):
                state["cancel_requested"] = True
            await run_in_threadpool(cloud.set_doc, path, {"beat_at": time.time(), "message": state.get("message")}, True)
        except Exception as exc:  # network trouble: the leader drops this computer if it lasts
            log.warning("team training heartbeat: %s", exc)
        await asyncio.sleep(BEAT_SEC)


def start_helping(jid: str, doc: dict, update_time: str) -> None:
    task = asyncio.get_running_loop().create_task(_help(jid, doc, update_time))
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)


async def _help(jid: str, doc: dict, update_time: str) -> None:
    global _helping
    path = f"remote_jobs/{jid}"
    req = doc.get("request") or {}
    now = time.time()
    if (not _RUN_ID.match(str(req.get("run") or "")) or req.get("arch") not in dt.BASE_MODELS
            or not str(req.get("season") or "").isdigit()):
        await run_in_threadpool(cloud.set_doc, path, {"status": "failed", "error": "bad request", "updated_at": now}, True)
        return
    claimed = await run_in_threadpool(
        cloud.set_doc, path, {"status": "claimed", "claimed_at": now, "updated_at": now, "beat_at": now}, True, update_time
    )
    if not claimed:
        return
    leader = doc.get("created_by_name") or "another computer"
    season, arch = int(req["season"]), req["arch"]
    _helping = state = {
        "status": "running", "season": season, "phase": "helping train", "auto": True, "progress": None,
        "message": f"Getting tiles from {leader}", "cancel_requested": False, "for": leader,
    }
    folder = Path(tempfile.gettempdir()) / "vision-tracker" / f"team-{req['run']}"
    shutil.rmtree(folder, ignore_errors=True)
    folder.mkdir(parents=True)
    beat = asyncio.get_running_loop().create_task(_beat(path, state))
    status, error = "done", None
    log.info("helping %s train the %d detector", leader, season)
    try:
        names = await run_in_threadpool(_fetch, req, folder, state)
        base, weights, done_n, t0 = folder / "base.pt", folder / "global.pt", 0, time.monotonic()
        while True:
            d = await run_in_threadpool(cloud.get_doc, path)
            if d is None or d.get("finish") or state["cancel_requested"]:
                status = "done" if d and d.get("finish") and done_n else "cancelled"
                break
            if scout_jobs.active_job() is not None:
                status, error = "failed", f"{devices.device_name()} started scouting"
                break
            r = d.get("round") or {}
            if int(r.get("n") or 0) <= done_n:
                state["message"] = f"Waiting for {leader}" if done_n else state["message"]
                await asyncio.sleep(POLL_SEC)
                continue
            n = done_n = int(r["n"])
            if not str(r.get("weights") or "").startswith(f"training/{req['run']}/"):
                raise RuntimeError("unexpected weights file")
            weights.write_bytes(await run_in_threadpool(cloud.download, r["weights"]))
            if not base.is_file():
                await run_in_threadpool(_build_base, arch, weights, base)
            mine = _slice(names, int(r["seed"]), float(r["lo"]), float(r["hi"]))
            state["message"] = f"Round {n}: training {len(mine)} tiles for {leader}"
            async with scout_jobs._gpu_lock:  # never alongside a scout run or this computer's own training
                res = await run_in_threadpool(_run_round, state, season, arch, folder / "data" / "images", folder, mine, base, weights, r, t0)
            if res is None:
                status = "cancelled"
                break
            name = f"training/{req['run']}/{devices.device_id()}_{n}.pt"
            await run_in_threadpool(cloud.upload, name, res["out"].read_bytes())
            await run_in_threadpool(
                cloud.set_doc, path, {"status": "running", "result": {"n": n, "weights": name, "seconds": res["seconds"]}, "updated_at": time.time()}, True
            )
            state["message"] = f"Round {n} sent to {leader}"
    except Exception as exc:
        log.exception("helping %s train failed", leader)
        status, error = "failed", str(exc)
    finally:
        beat.cancel()
        shutil.rmtree(folder, ignore_errors=True)
        await run_in_threadpool(cloud.quietly, cloud.set_doc, path, {"status": status, "error": error, "updated_at": time.time()}, True)
        _helping = None
