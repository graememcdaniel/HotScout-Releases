import json
import re
from datetime import datetime, timezone
from pathlib import Path

from app.core.config import settings

_EVENT_KEY_RE = re.compile(r"^[a-z0-9_-]{1,64}$")


def normalize_event_key(event_key: str) -> str:
    key = (event_key or "").strip().lower()
    if not _EVENT_KEY_RE.fullmatch(key):
        raise ValueError("Invalid event key (letters, digits, '_' or '-' only, e.g. 2026miket)")
    return key


def _calibration_dir() -> Path:
    return Path(settings.output_dir) / "calibrations"


def _path_for(event_key: str) -> Path:
    return _calibration_dir() / f"{normalize_event_key(event_key)}.json"


def save_event_calibration(
    *,
    event_key: str,
    season: int,
    video_path: str,
    image_width: int,
    image_height: int,
    calibration_request: dict,
    calibration_meta: dict,
    reference_frame_jpeg: str | None = None,
) -> dict:
    record = {
        "event_key": normalize_event_key(event_key),
        "season": int(season),
        "calibrated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "source_video_path": video_path,
        "image_width": int(image_width),
        "image_height": int(image_height),
        "calibration_request": calibration_request,
        "calibration_meta": calibration_meta,
    }
    if reference_frame_jpeg:
        # The clicked frame, to find later broadcast re-framing (tracking/view_shift).
        record["reference_frame_jpeg"] = reference_frame_jpeg
    write_record(record)
    return record


def write_record(record: dict) -> None:
    path = _path_for(record["event_key"])
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(record, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_event_calibration(event_key: str) -> dict | None:
    path = _path_for(event_key)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def delete_event_calibration(event_key: str) -> bool:
    path = _path_for(event_key)
    if not path.exists():
        return False
    path.unlink()
    return True


def list_event_calibrations() -> list[dict]:
    out = []
    root = _calibration_dir()
    if not root.exists():
        return out
    for path in sorted(root.glob("*.json")):
        try:
            rec = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        out.append(summarize_event_calibration(rec))
    return out


def summarize_event_calibration(record: dict) -> dict:
    meta = record.get("calibration_meta") or {}
    pose = (meta.get("apriltag") or {}).get("camera_pose") or {}
    return {
        "event_key": record.get("event_key"),
        "season": record.get("season"),
        "calibrated_at": record.get("calibrated_at"),
        "source_video_path": record.get("source_video_path"),
        "image_width": record.get("image_width"),
        "image_height": record.get("image_height"),
        "selected_projection_model": meta.get("selected_projection_model"),
        "detected_ids": (meta.get("apriltag") or {}).get("detected_ids"),
        "reprojection_rmse_px": pose.get("reprojection_rmse_px"),
        "tag_layout_transform": meta.get("tag_layout_transform"),
    }
