"""Robot detector that keeps learning over the season.

Scouting saves a few raw frames per match (``training_data.save_frames``)
under ``datasets/robot_detector/<season>/frames``. Only frames from matches a
scout marked good (``rescout.set_good``) are trained on: their labels come
from the confirmed robot paths (``training_data.match_labels``), so wrong
tracks never teach it. Keyframes a person corrected while hand-checking robot
positions are added from any match (``ground_truth.save_training_frames``).
Classes are robot, red bumper and blue bumper; frames
are cut into 640px tiles at full resolution. Outside YOLO-format datasets in
``datasets/external/<name>/`` (e.g. a Roboflow Universe export) are added to
the training split.

Training runs in its own process (``detector_worker``), continues from the
season's current model when there is one, and the new model replaces it only
if it finds more robots on the same held-out full frames. It is used for
tracking only once it also matches YOLO-World there. It starts by itself when
enough new good frames are in and nothing else needs the GPU; starting a scout
run stops such an automatic run.

One model learns every season: the other seasons' training pictures are mixed
in, and the new model also replaces another season's model where it scores
better on that season's own held-out frames.
"""

from __future__ import annotations

import asyncio
import gc
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from collections import defaultdict, deque
from pathlib import Path

import cv2
import numpy as np
from fastapi.concurrency import run_in_threadpool

from app.core.config import settings
from app.core.gpu import gpu_info, torch_device
from app.core.runtime_config import get_runtime_config
from app.services import ground_truth, rescout, scout_jobs
from app.services.detector_worker import MARK, OOM_EXIT
from app.services.tba_client import get_event_matches
from app.tracking import training_data as td

log = logging.getLogger(__name__)

MIN_MATCHES = 3  # good matches with labels (at least one is held out for testing)
WARM_EPOCHS = 30  # continuing from the current model needs fewer epochs
# Training prints progress every few seconds; this long without any output means it hung
# (seen on Windows: data loader workers stuck, GPU idle for hours).
STALL_SEC = 30 * 60
STALL_EXIT = -2  # _spawn's exit code when it stopped a hung child
# Continuing from the current model: train on every new picture plus at most this many tiles
# (or as many as the new ones, if more) from pictures it already learned, picked at random so it
# doesn't forget them. Keeps retraining time flat as the season's pictures pile up.
REPLAY_TILES = 3000
AUTO_DELAY_SEC = 120  # wait for a scout to finish marking matches
CHECK_DELAY_SEC = 20  # hand checks autosave while being edited; take their pictures once edits pause
VAL_PCT = 20
BASELINE_SLACK = 0.0  # used for tracking only if its AP50 is at least YOLO-World's (reliability over speed)
# Outside-dataset tiles per own training tile, at most. 0 = off: adding the Roboflow FRC set
# (2019-22 games, other camera angles) at 2x lowered held-out 2026 AP50 from 0.80 to 0.77.
EXTERNAL_TILE_RATIO = 0
# Other seasons' training tiles per tile of the season being trained, at most. Season test
# (yolo11s, equal tiles per season): 2025+2026 together scored 2026 AP50 0.91 (2026-only 0.91)
# and kept 2025 at 0.70, where 2026-only models fell to 0.38-0.44.
OTHER_SEASONS_RATIO = 1.0
# Share of training frames also cut from a randomly barrel-distorted copy, so the
# detector handles fisheye event cameras.
FISHEYE_FRACTION = 0.3
# (tile size, batch) tried in order until one fits in GPU memory.
ATTEMPTS = [(td.TILE, 64), (td.TILE, 32), (td.TILE, 16), (td.TILE, 8), (td.TILE, 4), (td.TILE, 2)]
# Base models, smallest first, with the GPU memory (GB) needed to train each at a useful batch.
# Bigger finds more robots but runs slower when tracking (about 2x / 3x yolo11s per frame).
BASE_MODELS = {"yolo11s.pt": 0.0, "yolo11m.pt": 6.0, "yolo11l.pt": 8.0, "yolo11x.pt": 16.0}
_BACKEND_DIR = Path(__file__).resolve().parents[2]
_job: dict | None = None
_tasks: set[asyncio.Task] = set()
_auto_task: asyncio.Task | None = None
_check_tasks: dict[str, asyncio.Task] = {}
_backfill_tried: set[str] = set()
_external_cache: dict = {"key": None, "value": []}


def _dataset(season: int) -> Path:
    return Path(settings.dataset_dir) / str(season)


def model_dir(season: int) -> Path:
    return Path(settings.models_dir) / str(season)


def base_for_gpu() -> str:
    """Base model to train from: ``DETECTOR_BASE_MODEL``, else the biggest this GPU can train."""
    if settings.detector_base_model:
        return settings.detector_base_model
    gb = float(gpu_info().get("memory_gb") or 0.0)
    return [b for b, need in BASE_MODELS.items() if gb >= need][-1]


def _size(base: str | None) -> int:
    return list(BASE_MODELS).index(base) if base in BASE_MODELS else -1


def _work_dir(season: int) -> Path:
    """Tiles and training runs: rebuilt every time, so kept out of the (synced) project folder."""
    return Path(tempfile.gettempdir()) / "vision-tracker" / f"detector-{season}"


def _meta(season: int) -> dict | None:
    try:
        return json.loads((model_dir(season) / "meta.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _write_meta(season: int, meta: dict) -> None:
    (model_dir(season) / "meta.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")


def _frames(season: int) -> list[Path]:
    return sorted(td.frames_dir(_dataset(season)).glob("*.jpg"))


def _other_seasons(season: int) -> list[int]:
    """Seasons with training pictures on this computer, other than ``season``."""
    root = Path(settings.dataset_dir)
    return sorted(int(p.name) for p in root.glob("[0-9][0-9][0-9][0-9]") if p.is_dir() and int(p.name) != season)


def active_model(season: int) -> str | None:
    """Path of the trained detector to track with, if it is good enough and enabled."""
    meta = _meta(season)
    weights = model_dir(season) / "best.pt"
    if meta and meta.get("enabled") and meta.get("active") and weights.is_file():
        return str(weights)
    return None


def tracking_models(season: int) -> str | list[str] | None:
    """Detector(s) for tracking. The season model and YOLO-World run together when both are
    available: on held-out frames the pair found more robots than either alone (AP50 0.85
    vs 0.80), at ~4x the time per frame.
    """
    trained = active_model(season)
    if trained and settings.robot_model:
        return [trained, settings.robot_model]
    return trained or settings.robot_model or None


def models_to_compare(season: int) -> list[str]:
    """The season's trained model (if any) and the generic one, for ``evaluation``."""
    weights = model_dir(season) / "best.pt"
    return ([str(weights)] if weights.is_file() else []) + [settings.robot_model]


def _external() -> list[dict]:
    """Outside datasets (name, image count, class mapping); rescanned only when they change."""
    root = Path(settings.external_dataset_dir)
    cfgs = sorted(root.glob("*/data.yaml"))
    key = [(str(c), c.stat().st_mtime, c.parent.stat().st_mtime) for c in cfgs]
    if key != _external_cache["key"]:
        _external_cache["value"] = td.external_datasets(root) if cfgs else []
        _external_cache["key"] = key
    return _external_cache["value"]


def status(season: int) -> dict:
    frames = _frames(season)
    good = rescout.season_good_matches(season)
    approved = [p for p in frames if td.match_of(p) in good]
    checked = td.checked_items(_dataset(season))
    n_checked = sum(len(v) for v in checked.values())
    meta = _meta(season) or {}
    return {
        "season": season,
        "images": len(frames),
        "matches": len({td.match_of(p) for p in frames}),
        "good_matches": len(good),
        "approved_images": len(approved) + n_checked,
        "approved_matches": len({td.match_of(p) for p in approved} | set(checked)),
        "good_frame_matches": len({td.match_of(p) for p in approved}),
        "checked_images": n_checked,
        "checked_matches": len(checked),
        # good frames not seen by the last training
        "new_images": max(0, len(approved) + n_checked - int(meta.get("last_trained_images") or 0)),
        "auto_retrain_images": settings.detector_auto_retrain_images,
        "min_matches": MIN_MATCHES,
        "min_map50": settings.detector_min_map50,
        "collecting": settings.collect_training_frames,
        "external": [
            {"name": d["name"], "images": len(d["images"]), "classes": d["classes"]} for d in _external()
        ],
        "model": meta or None,
        "in_use": active_model(season) is not None,
        "job": {k: v for k, v in _job.items() if k != "cancel_requested"} if _job else None,
    }


def _gallery_matches(season: int) -> list[str]:
    root = _dataset(season)
    return sorted(m for m in rescout.season_good_matches(season) if td.match_frames(root, m))


def team_gallery(season: int, exclude_match: str) -> dict:
    """Appearance gallery of the season's teams from good matches (not the one being scouted),
    here and on the other team computers (via the team cloud)."""
    from app.services import cloud
    from app.tracking import appearance

    local = _gallery_matches(season)
    matches = [m for m in local if m != exclude_match]
    gallery = appearance.season_gallery(matches, _dataset(season), Path(settings.output_dir), Path(settings.appearance_dir) / str(season))
    c_matches, c_teams, c_emb = cloud.cached_gallery(season)
    use = ~np.isin(c_matches, [*local, exclude_match]) if len(c_matches) else np.zeros(0, dtype=bool)
    if not use.any():
        return gallery
    parts: dict[str, list[np.ndarray]] = {t: [g] for t, g in gallery.items()}
    for t in sorted(set(c_teams[use])):
        parts.setdefault(str(t), []).append(c_emb[use & (c_teams == t)])
    return {t: np.concatenate(v) for t, v in parts.items()}


def local_gallery_rows(season: int) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """(match, team, embedding) rows of this computer's good matches, for the team cloud."""
    from app.tracking import appearance

    root, out, cache = _dataset(season), Path(settings.output_dir), Path(settings.appearance_dir) / str(season)
    matches, teams, embs = [], [], []
    for mk in _gallery_matches(season):
        try:
            t, e = appearance.match_embeddings(mk, root, out, cache)
        except Exception as exc:
            log.warning("appearance gallery: %s skipped (%s)", mk, exc)
            continue
        if len(t):
            matches += [mk] * len(t)
            teams += t
            embs.append(np.asarray(e, dtype=np.float32))
    emb = np.concatenate(embs) if embs else np.zeros((0, 0), dtype=np.float32)
    return np.array(matches, dtype=str), np.array(teams, dtype=str), emb


def prune_frames(season: int) -> int:
    """Delete old frames of matches nobody marked good (they are never trained on)."""
    cutoff = time.time() - settings.training_frames_keep_days * 86400
    good = rescout.season_good_matches(season)
    n = 0
    for p in _frames(season):
        if td.match_of(p) not in good and p.stat().st_mtime < cutoff:
            p.unlink(missing_ok=True)
            n += 1
    return n


def set_enabled(season: int, enabled: bool) -> dict:
    meta = _meta(season)
    if meta is None:
        raise ValueError("No trained detector for this season")
    meta["enabled"] = bool(enabled)
    _write_meta(season, meta)
    return meta


def busy() -> bool:
    return bool(_job and _job["status"] in {"queued", "running"})


def cancel() -> bool:
    if not busy():
        return False
    _job["cancel_requested"] = True
    return True


def yield_to_scouting() -> None:
    """A scout run is starting: stop an automatic training run (it will try again later)
    and this computer's help with another computer's training."""
    from app.services import team_training

    if busy() and _job.get("auto"):
        cancel()
    helping = team_training.helping()
    if helping:
        helping["cancel_requested"] = True


def schedule_auto_train(season: int) -> None:
    """Called when a match is marked good: retrain once marking stops and the GPU is free."""
    global _auto_task
    if _auto_task and not _auto_task.done():
        _auto_task.cancel()
    _auto_task = asyncio.get_running_loop().create_task(_auto_train(season))


async def _auto_train(season: int) -> None:
    from app.services import team_training

    await asyncio.sleep(AUTO_DELAY_SEC)
    while busy() or scout_jobs.active_job() is not None or team_training.helping():
        await asyncio.sleep(60)
    missing = await run_in_threadpool(_frameless_good, season)
    key = str(get_runtime_config().get("tba_auth_key") or "").strip()
    if missing and key and settings.collect_training_frames:
        # good matches scouted on another computer: their pictures come from the video
        _backfill_tried.update(missing)
        log.info("collecting training pictures for %d good matches", len(missing))
        job = start(season, train=False, backfill=True, tba_auth_key=key, epochs=60, auto=True)
        while busy():
            await asyncio.sleep(10)
        if job["status"] != "done":
            return
    st = await run_in_threadpool(status, season)
    if st["approved_matches"] >= MIN_MATCHES and st["new_images"] >= settings.detector_auto_retrain_images:
        log.info("auto-training the %d robot detector (%d new frames)", season, st["new_images"])
        start(season, train=True, backfill=False, tba_auth_key="", epochs=60, auto=True)


def _frameless_good(season: int) -> set[str]:
    """Good matches with saved autos and a tracking run but no training pictures (not yet tried)."""
    have = {td.match_of(p) for p in _frames(season)}
    out = set()
    for mk in rescout.season_good_matches(season) - have - _backfill_tried:
        saved = ground_truth._read_json(Path(settings.output_dir) / mk / "robots.json") or {}
        if saved.get("run_id") and (Path(settings.output_dir) / "runs" / f"{saved['run_id']}.json").is_file():
            out.add(mk)
    return out


def queue_checked_frames(match_key: str) -> None:
    """A hand check was saved: refresh its training pictures once editing pauses."""
    old = _check_tasks.get(match_key)
    if old and not old.done():
        old.cancel()
    _check_tasks[match_key] = asyncio.get_running_loop().create_task(_checked_frames(match_key))


async def _checked_frames(match_key: str) -> None:
    await asyncio.sleep(CHECK_DELAY_SEC)
    video = ground_truth.find_video(match_key)
    if video is None or not settings.collect_training_frames:
        return
    season = int(match_key[:4])
    try:
        n = await run_in_threadpool(ground_truth.save_training_frames, match_key, video, _dataset(season))
    except Exception as exc:  # a broken check must not break saving it
        log.warning("training pictures from the check of %s failed: %s", match_key, exc)
        return
    log.info("training pictures: %s has %d corrected keyframes", match_key, n)
    if n:
        schedule_auto_train(season)


def checked_status(match_key: str) -> dict:
    """Training pictures from a match's hand check (``ground_truth.training_status``)."""
    try:
        st = ground_truth.training_status(match_key, _dataset(int(match_key[:4])))
    except (FileNotFoundError, ValueError, KeyError) as exc:
        return {"error": str(exc)}
    task = _check_tasks.get(match_key)
    return {**st, "pending": bool(task and not task.done()), "delay_sec": CHECK_DELAY_SEC}


def start(season: int, *, train: bool, backfill: bool, tba_auth_key: str, epochs: int, auto: bool = False) -> dict:
    global _job
    _job = {
        "status": "queued",
        "season": season,
        "phase": None,
        "message": None,
        "progress": None,
        "backfill": backfill,
        "train": train,
        "auto": auto,
        "created_at": time.time(),
        "finished_at": None,
        "error": None,
        "cancel_requested": False,
    }
    task = asyncio.get_running_loop().create_task(_run(_job, season, train, backfill, tba_auth_key, epochs))
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)
    return _job


async def _run(job: dict, season: int, train: bool, backfill: bool, tba_auth_key: str, epochs: int) -> None:
    async with scout_jobs._gpu_lock:  # never alongside a scout run (one GPU)
        job["status"] = "running"
        try:
            if backfill:
                await _backfill(job, season, tba_auth_key)
            if train and not job["cancel_requested"]:
                job["phase"] = "training"
                await run_in_threadpool(_train, job, season, epochs)
                if not job["cancel_requested"]:
                    from app.services import cloud

                    job["phase"] = "sharing with the team"
                    shared = await run_in_threadpool(cloud.push_quietly, season)
                    for other in job.get("promoted_seasons") or []:
                        await run_in_threadpool(cloud.push_quietly, other)
                    failed = [e for e in shared.get("errors", []) if e.startswith("detector")]
                    if failed:
                        job["message"] = f"{job.get('message') or 'Trained'}; not shared with the team ({failed[0]})"
                    await run_in_threadpool(_release_gpu)
            job["status"] = "cancelled" if job["cancel_requested"] else "done"
        except Exception as exc:
            log.exception("detector job failed")
            job["status"] = "failed"
            job["error"] = str(exc)
        finally:
            job["finished_at"] = time.time()


async def _backfill(job: dict, season: int, tba_auth_key: str) -> None:
    """Frames for good-marked matches that have none (scouted before collecting
    started, or pruned); each video is downloaded once."""
    job["phase"] = "collecting"
    have = {td.match_of(p) for p in _frames(season)}
    by_event: dict[str, set[str]] = defaultdict(set)
    for mk in rescout.season_good_matches(season) - have:
        by_event[rescout.event_of(mk)].add(mk)
    todo = []
    for event_key in sorted(by_event):
        matches = await get_event_matches(event_key, tba_auth_key)
        for m in sorted(matches, key=scout_jobs._match_sort_key):
            robots_file = Path(settings.output_dir) / m["key"] / "robots.json"
            if m["key"] in by_event[event_key] and robots_file.is_file() and scout_jobs.youtube_video(m):
                todo.append((m, robots_file))
    for i, (m, robots_file) in enumerate(todo):
        if job["cancel_requested"]:
            return
        job["progress"] = {"done": i, "total": len(todo)}
        job["message"] = f"Collecting frames from {m['key']}"
        try:
            n = await run_in_threadpool(_frames_for_saved, m, robots_file, season)
            job["message"] = f"{m['key']}: {n} frames"
        except Exception as exc:  # one bad match must not stop the rest
            log.warning("training frames for %s failed: %s", m["key"], exc)
    job["progress"] = {"done": len(todo), "total": len(todo)}


def _frames_for_saved(m: dict, robots_file: Path, season: int) -> int:
    saved = json.loads(robots_file.read_text(encoding="utf-8"))
    run_file = Path(settings.output_dir) / "runs" / f"{saved['run_id']}.json"
    if not run_file.is_file():
        return 0
    data = json.loads(run_file.read_text(encoding="utf-8"))
    run = {"grid": data["grid"], "meta": data["meta"]}
    video_id, _ = scout_jobs.youtube_video(m)
    path = scout_jobs.download_video(video_id, m["key"])
    try:
        return td.save_frames(run, path, _dataset(season), m["key"])
    finally:
        Path(path).unlink(missing_ok=True)


def _hash(text: str) -> int:
    return int(hashlib.md5(text.encode()).hexdigest(), 16)


def _mtime(path: Path) -> float:
    try:
        return path.stat().st_mtime
    except OSError:
        return 0.0


def _split(matches: list[str]) -> tuple[list[str], list[str]]:
    """~20% of matches held out (whole matches, so test frames are unseen scenes).

    A match's side depends only on its key, so a match used to test one model
    was never trained on by an earlier one.
    """
    val = [m for m in matches if _hash(m) % 100 < VAL_PCT]
    if not val or len(val) == len(matches):
        val = [min(matches, key=_hash)]
    return [m for m in matches if m not in val], val


def _labelled(season: int, job: dict | None = None) -> tuple[dict[str, list[dict]], dict[str, str]]:
    root = _dataset(season)
    good = sorted(m for m in rescout.season_good_matches(season) if td.match_frames(root, m))
    labelled, skipped = {}, {}
    for i, m in enumerate(good):
        if job is not None:
            job["message"] = f"Labelling frames of {m}"
            job["progress"] = {"done": i, "total": len(good)}
        items, reason = td.match_labels(m, root, Path(settings.output_dir))
        if items:
            labelled[m] = items
        else:
            skipped[m] = reason or "no usable frames"
    for m, items in td.checked_items(root).items():
        labelled[m] = labelled.get(m, []) + items
        skipped.pop(m, None)
    return labelled, skipped


def _abs_items(season: int, items: list[dict]) -> list[dict]:
    frames = td.frames_dir(_dataset(season))
    return [{**it, "image": str((frames / it["image"]).resolve())} for it in items]


def eval_items(season: int) -> tuple[list[dict], list[str]]:
    """Held-out labelled frames (absolute image paths) and their matches."""
    labelled, _ = _labelled(season)
    if len(labelled) < 2:
        return [], []
    _, val = _split(sorted(labelled))
    return _abs_items(season, [it for m in val for it in labelled[m]]), val


def _write_tile(images: Path, labels: Path, stem: str, img: np.ndarray, rows) -> None:
    cv2.imwrite(str(images / f"{stem}.jpg"), img, [cv2.IMWRITE_JPEG_QUALITY, 92])
    (labels / f"{stem}.txt").write_text(td.yolo_rows(rows, img.shape[1], img.shape[0]), encoding="utf-8")


def _fisheye(img: np.ndarray, item: dict, rng: np.random.Generator) -> tuple[np.ndarray, dict]:
    """A random radial (barrel) lens distortion of a frame, with its boxes moved to match."""
    H, W = img.shape[:2]
    f = W * rng.uniform(0.45, 0.8)
    cx = W / 2 + rng.uniform(-0.08, 0.08) * W
    cy = H / 2 + rng.uniform(-0.1, 0.1) * H
    r_in = max(np.hypot(x - cx, y - cy) for x in (0, W) for y in (0, H)) / f
    k2 = rng.uniform(0.0, 0.06)
    # Keep the lens monotonic out to the frame corners (no fold-back).
    k1 = max(rng.uniform(-0.35, -0.08), (-0.7 - 5 * k2 * r_in**4) / (3 * r_in**2))

    ru_tab = np.linspace(0.0, r_in, 4096)
    rd_tab = ru_tab * (1 + k1 * ru_tab**2 + k2 * ru_tab**4)
    # Zoom in so the picture mostly fills the frame, as event fisheye cameras do.
    zoom = 1 + (r_in / rd_tab[-1] - 1) * rng.uniform(0.5, 1.0)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    dx, dy = (xx - cx) / (f * zoom), (yy - cy) / (f * zoom)
    rd = np.hypot(dx, dy)
    ru = np.interp(rd, rd_tab, ru_tab, right=-1.0)
    scale = np.where(rd > 1e-9, ru / np.maximum(rd, 1e-9), 1.0)
    map_x = np.where(ru < 0, -1, cx + dx * scale * f).astype(np.float32)
    map_y = np.where(ru < 0, -1, cy + dy * scale * f).astype(np.float32)
    out = cv2.remap(img, map_x, map_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

    t = np.linspace(0.0, 1.0, 9)
    cropped = []  # mostly cut off by the zoom: grey them out rather than teach them as background

    def move(box: list[float]) -> list[float] | None:
        x1, y1, x2, y2 = box
        xs = np.concatenate([x1 + (x2 - x1) * t, x1 + (x2 - x1) * t, np.full(9, x1), np.full(9, x2)])
        ys = np.concatenate([np.full(9, y1), np.full(9, y2), y1 + (y2 - y1) * t, y1 + (y2 - y1) * t])
        u, v = (xs - cx) / f, (ys - cy) / f
        r2 = u * u + v * v
        g = 1 + k1 * r2 + k2 * r2 * r2
        px, py = cx + u * g * f * zoom, cy + v * g * f * zoom
        full = (px.max() - px.min()) * (py.max() - py.min())
        nb = [max(0.0, px.min()), max(0.0, py.min()), min(float(W), px.max()), min(float(H), py.max())]
        w, h = nb[2] - nb[0], nb[3] - nb[1]
        if w >= 3 and h >= 3 and w * h >= 0.5 * full:
            return nb
        if w > 0 and h > 0:
            cropped.append(nb)
        return None

    def moved(rows: list[dict]) -> list[dict]:
        res = []
        for r in rows:
            nb = move(r["box"])
            if nb is not None:
                res.append({**r, "box": nb})
        return res

    new = {**item, "robots": moved(item["robots"]), "bumpers": moved(item["bumpers"])}
    td.apply_masks(out, cropped)
    return out, new


def _build_dataset(job: dict, season: int, work: Path, learned: dict | None = None) -> dict:
    """``learned``: the current model's meta when continuing from it."""
    data_at = time.time()
    labelled, skipped = _labelled(season, job)
    if len(labelled) < MIN_MATCHES:
        why = "; ".join(f"{m}: {r}" for m, r in sorted(skipped.items())[:5])
        raise RuntimeError(
            f"{len(labelled)} good matches with usable frames; need {MIN_MATCHES}. "
            "Mark more correct matches as good (and collect pictures for older ones)." + (f" Skipped {why}" if why else "")
        )
    train_m, val_m = _split(sorted(labelled))
    data = work / "data"
    shutil.rmtree(data, ignore_errors=True)
    dirs = {}
    for split in ("train", "val"):
        dirs[split] = (data / split / "images", data / split / "labels")
        for d in dirs[split]:
            d.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(0)
    frames = td.frames_dir(_dataset(season))
    counts = {"train": 0, "val": 0}

    def cut(split: str, it: dict, frames_of: Path = frames) -> None:
        img = cv2.imread(str(frames_of / it["image"]))
        if img is None:
            return
        td.apply_masks(img, it["masks"])
        for j, (tile, rows) in enumerate(td.tiles(img, it, rng)):
            _write_tile(*dirs[split], f"{Path(it['image']).stem}_{j}", tile, rows)
            counts[split] += 1
        if split == "train" and rng.random() < FISHEYE_FRACTION:
            fimg, fit = _fisheye(img, it, rng)
            for j, (tile, rows) in enumerate(td.tiles(fimg, fit, rng)):
                _write_tile(*dirs[split], f"{Path(it['image']).stem}_fe{j}", tile, rows)
                counts[split] += 1

    seen = set((learned or {}).get("train_matches") or [])
    since = float((learned or {}).get("data_at") or (learned or {}).get("trained_at") or 0)
    root = _dataset(season)
    old = []  # pictures the current model already trained on, with the same labels
    for split, matches in (("train", train_m), ("val", val_m)):
        for m in matches:
            job["message"] = f"Cutting tiles from {m}"
            name = td.safe_name(m)
            labels_at = max(_mtime(root / "labels" / f"{name}.json"), _mtime(td.checked_dir(root) / f"{name}.json"))
            for it in labelled[m]:
                if split == "train" and m in seen and max(labels_at, _mtime(frames / it["image"])) <= since:
                    old.append(it)
                else:
                    cut(split, it)
    new_tiles = counts["train"]
    replay = max(REPLAY_TILES, new_tiles)
    for i in rng.permutation(len(old)):
        if counts["train"] - new_tiles >= replay or job["cancel_requested"]:
            break
        job["message"] = f"Adding earlier pictures ({counts['train'] - new_tiles}/{replay} tiles)"
        cut("train", old[i])

    # Other seasons' training matches (never their held-out ones, which test their models).
    others: dict[int, dict] = {}
    pool_other = []
    for s in _other_seasons(season):
        if job["cancel_requested"]:
            break
        job["message"] = f"Adding pictures from {s}"
        lab, _ = _labelled(s)
        if len(lab) < MIN_MATCHES:
            continue
        tm, _ = _split(sorted(lab))
        others[s] = {"train_matches": tm, "tiles": 0}
        pool_other += [(s, it) for m in tm for it in lab[m]]
    own_tiles = counts["train"]
    for i in rng.permutation(len(pool_other)):
        if counts["train"] - own_tiles >= OTHER_SEASONS_RATIO * own_tiles or job["cancel_requested"]:
            break
        s, it = pool_other[i]
        before = counts["train"]
        cut("train", it, td.frames_dir(_dataset(s)))
        others[s]["tiles"] += counts["train"] - before
    other_tiles = counts["train"] - own_tiles

    # Outside datasets: training split only, so the test stays on this season's video.
    pool = [(d, p) for d in _external() if any(r != "ignored" for r in d["roles"].values()) for p in d["images"]]
    pool = [pool[i] for i in rng.permutation(len(pool))[: settings.external_max_images]]
    # Large outside pictures become many tiles; cap them so this season's video isn't drowned out.
    max_tiles = EXTERNAL_TILE_RATIO * counts["train"]
    external = ext_tiles = 0
    for k, (d, p) in enumerate(pool):
        if job["cancel_requested"] or ext_tiles >= max_tiles:
            break
        if k % 100 == 0:
            job["message"] = f"Adding outside pictures ({k}/{len(pool)})"
        img = cv2.imread(str(p))
        if img is None:
            continue
        it = td.external_item(img, p.parent.parent / "labels" / f"{p.stem}.txt", d["roles"])
        td.apply_masks(img, it["masks"])
        stem = f"ext_{td.safe_name(d['name'])}_{k}"
        if max(img.shape[:2]) > 1.4 * td.TILE:
            for j, (tile, rows) in enumerate(td.tiles(img, it, rng)):
                _write_tile(*dirs["train"], f"{stem}_{j}", tile, rows)
                ext_tiles += 1
        else:
            _write_tile(*dirs["train"], stem, img, td.boxes_of(it))
            ext_tiles += 1
        external += 1

    eval_list = _abs_items(season, [it for m in val_m for it in labelled[m]])
    eval_file = work / "eval.json"
    eval_file.write_text(json.dumps(eval_list), encoding="utf-8")
    yaml_file = work / "data.yaml"
    yaml_file.write_text(
        f"path: {json.dumps(str(data.resolve()))}\n"
        "train: train/images\nval: val/images\n"
        "names:\n" + "".join(f"  {i}: {n}\n" for i, n in enumerate(td.CLASSES)),
        encoding="utf-8",
    )
    width = max(it["width"] for it in eval_list)
    return {
        "data": yaml_file,
        "eval": eval_file,
        "eval_key": hashlib.md5(eval_file.read_bytes()).hexdigest(),
        "infer_imgsz": int(np.ceil(width / 32) * 32),
        "train_matches": train_m,
        "val_matches": val_m,
        "skipped": skipped,
        "train_tiles": counts["train"],
        "new_tiles": new_tiles,
        "other_season_tiles": other_tiles,
        "other_seasons": {str(s): v for s, v in others.items() if v["tiles"]},
        "data_at": data_at,
        "val_tiles": counts["val"],
        "val_frames": len(eval_list),
        "external_images": external,
        "approved_images": len([p for p in _frames(season) if td.match_of(p) in labelled])
        + sum(len(v) for v in td.checked_items(_dataset(season)).values()),
    }


def _release_gpu() -> None:
    """Give the training process as much GPU memory as possible."""
    from app.tracking import appearance, team_id

    team_id.release()
    appearance.release()
    gc.collect()
    try:
        import torch

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except ImportError:
        pass


def _ap(r: dict | None) -> float | None:
    return None if not r or "error" in r or r.get("ap50") is None else float(r["ap50"])


def _describe(new: dict, base: dict | None) -> str:
    def one(r: dict) -> str:
        ms = f", {r['ms_per_frame']:.0f} ms/frame" if r.get("ms_per_frame") else ""
        return f"{(r.get('recall') or 0):.0%} of robots (AP50 {(r.get('ap50') or 0):.2f}{ms})"

    text = f"finds {one(new)}"
    if _ap(base) is not None:
        text += f" vs YOLO-World {one(base)}"
    return text + f" on {new['frames']} held-out frames"


def _fit_file() -> Path:
    return Path(settings.models_dir) / "batch_fit.json"


def _fits() -> dict:
    try:
        return json.loads(_fit_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def batch_attempts(arch: str) -> list[int]:
    """Batches to try, largest first, starting from the largest that fit this GPU last time
    (kept locally: the shared model's meta carries the batch of whichever computer trained it)."""
    batches = [b for _, b in ATTEMPTS]
    last = _fits().get(f"{gpu_info().get('name') or 'cpu'} {arch}")
    return batches[batches.index(last):] if last in batches else batches


def remember_batch(arch: str, batch: int) -> None:
    _fit_file().parent.mkdir(parents=True, exist_ok=True)
    _fit_file().write_text(json.dumps({**_fits(), f"{gpu_info().get('name') or 'cpu'} {arch}": batch}), encoding="utf-8")


def _evaluate(job: dict, ds: dict, best: str, current: Path, baseline: bool) -> dict | None:
    """Held-out frame test of ``best`` (and the current model, and YOLO-World if ``baseline``)."""
    args = ["--mode", "eval", "--base", best, "--eval", str(ds["eval"].resolve()), "--infer-imgsz", str(ds["infer_imgsz"])]
    if current.is_file():
        args += ["--current", str(current.resolve())]
    if baseline:
        args += ["--baseline", settings.robot_model]
    code, result, tail = _spawn(job, args)
    if job["cancel_requested"]:
        return None
    if code != 0 or result is None:
        raise RuntimeError(f"Testing stopped (exit {code}): {tail or 'no output'}")
    return result


def _team_train(job: dict, season: int, ds: dict, work: Path, current: Path, arch: str, epochs: int, cached_base) -> dict | None:
    """Train with the other team GPUs that are free, if any. None = train here alone."""
    from app.services import cloud, team_training

    if not settings.detector_team_training or not cloud.signed_in():
        return None
    helpers = team_training.available(arch)
    if not helpers:
        return None
    try:
        team = team_training.train(job, season, ds, work, current, arch, epochs, helpers)
    except team_training.NotStarted as exc:
        log.info("training on this computer only: %s", exc)
        return None
    if team is None or job["cancel_requested"]:
        return None
    result = _evaluate(job, ds, team["best"], current, cached_base is None and bool(settings.robot_model))
    return result and {**result, **team}


def _train(job: dict, season: int, epochs: int) -> None:
    work = _work_dir(season)
    work.mkdir(parents=True, exist_ok=True)
    out = model_dir(season)
    meta = _meta(season) or {}
    current = out / "best.pt"
    # Continue from the current model if it has the same classes and training size and is
    # at least as big as this GPU's base model; otherwise start the bigger model fresh
    # (it replaces the current one only if it scores better).
    preferred = base_for_gpu()
    warm = (
        current.is_file()
        and meta.get("classes") == td.CLASSES
        and meta.get("imgsz") == td.TILE
        and _size(meta.get("base_model")) >= _size(preferred)
    )
    ds = _build_dataset(job, season, work, meta if warm else None)
    if job["cancel_requested"]:
        return

    out.mkdir(parents=True, exist_ok=True)
    arch = meta.get("base_model") if warm else preferred
    base = str(current.resolve()) if warm else preferred
    run_epochs = min(epochs, WARM_EPOCHS) if warm else epochs
    cached_base = meta.get("baseline") if (meta.get("baseline") or {}).get("eval_key") == ds["eval_key"] else None
    _release_gpu()

    result = None
    imgsz = td.TILE
    name = Path(str(arch)).stem
    if warm:  # several GPUs need the same starting weights: only when continuing
        result = _team_train(job, season, ds, work, current, arch, run_epochs, cached_base)
        if job["cancel_requested"]:
            return
        batch = result["batch"] if result else None
    for batch in [] if result else batch_attempts(arch):
        job["message"] = f"Training {name} on {ds['train_tiles']} tiles, batch {batch}" + (
            f" from the current model ({ds['new_tiles']} new)" if warm else " (new model)" if current.is_file() else ""
        )
        job["progress"] = None  # not the dataset-building count any more
        args = [
            "--data", str(ds["data"].resolve()),
            "--base", base,
            "--project", str(work.resolve()),
            "--epochs", str(run_epochs),
            "--imgsz", str(imgsz),
            "--batch", str(batch),
            "--device", torch_device(),
            "--eval", str(ds["eval"].resolve()),
            "--infer-imgsz", str(ds["infer_imgsz"]),
        ]
        if current.is_file():
            args += ["--current", str(current.resolve())]
        if cached_base is None and settings.robot_model:
            args += ["--baseline", settings.robot_model]
        code, result, tail = _spawn(job, args)
        if job["cancel_requested"]:
            return
        best = work / "run" / "weights" / "best.pt"
        if code == STALL_EXIT and best.is_file():  # keep the epochs it did finish
            epochs_run = int((job.get("progress") or {}).get("epoch") or 0)
            log.warning("detector training hung after %d epochs; testing its best model so far", epochs_run)
            job["message"] = f"Training stopped responding after {epochs_run} epochs; testing the best model so far"
            eval_args = ["--mode", "eval", "--base", str(best.resolve()), "--device", torch_device(),
                         "--eval", str(ds["eval"].resolve()), "--infer-imgsz", str(ds["infer_imgsz"])]
            eval_args += args[args.index("--current"):args.index("--current") + 2] if "--current" in args else []
            eval_args += args[args.index("--baseline"):args.index("--baseline") + 2] if "--baseline" in args else []
            code, result, tail = _spawn(job, eval_args)
            if job["cancel_requested"]:
                return
            if result is not None:
                result["epochs_run"] = epochs_run
        if code == OOM_EXIT:
            log.warning("detector training out of GPU memory at batch %d; stepping down", batch)
            result = None
            continue
        if code != 0 or result is None:
            raise RuntimeError(f"Training stopped (exit {code}): {tail or 'no output'}")
        remember_batch(arch, batch)
        break
    if result is None:
        raise RuntimeError("Not enough free GPU memory to train, even at small sizes. Close other programs using the GPU.")

    ev = result["eval"]
    new, cur = ev["new"], ev.get("current")
    if "baseline" in ev and "error" not in ev["baseline"]:
        cached_base = {"eval_key": ds["eval_key"], "result": ev["baseline"]}
    base_r = (cached_base or {}).get("result")
    new_ap, cur_ap, base_ap = _ap(new) or 0.0, _ap(cur), _ap(base_r)
    better = cur_ap is None or new_ap > cur_ap

    def usable(ap: float) -> bool:
        return ap >= settings.detector_min_map50 and (base_ap is None or ap >= base_ap - BASELINE_SLACK)

    history = (meta.get("history") or [])[-19:] + [{
        "trained_at": time.time(),
        "matches": len(ds["train_matches"]) + len(ds["val_matches"]),
        "train_tiles": ds["train_tiles"],
        "new_tiles": ds["new_tiles"],
        "other_season_tiles": ds["other_season_tiles"],
        "external_images": ds["external_images"],
        "val_frames": ds["val_frames"],
        "map50": round(new_ap, 4),
        "recall": new.get("recall"),
        "previous_map50": None if cur_ap is None else round(cur_ap, 4),
        "baseline_map50": None if base_ap is None else round(base_ap, 4),
        "promoted": better,
        "epochs_run": result["epochs_run"],
        "computers": result.get("computers", 1),
        "auto": bool(job.get("auto")),
    }]
    if better:
        shutil.copy2(result["best"], current)
        meta = _model_meta(season, arch, new, base_r, ds, result, imgsz, batch, usable(new_ap), meta.get("enabled", True))
    elif cur_ap is not None:  # keep the current model, scored on the latest held-out frames
        meta.update(map50=round(cur_ap, 4), recall=cur.get("recall"), precision=cur.get("precision"),
                    eval={"model": cur, "baseline": base_r}, val_frames=ds["val_frames"], val_images=ds["val_frames"],
                    active=usable(cur_ap))
    meta["baseline"] = cached_base
    meta["history"] = history
    meta["skipped_matches"] = ds["skipped"]
    meta["last_trained_images"] = ds["approved_images"]
    _write_meta(season, meta)
    promoted = _promote_elsewhere(job, season, ds, work, result, arch, imgsz, batch)
    job["promoted_seasons"] = [s for s, _ in promoted]
    # The tiles are only needed while training.
    shutil.rmtree(work / "data", ignore_errors=True)

    if not better:
        job["message"] = f"New model {_describe(new, None)}; the current one does as well or better ({cur_ap:.2f}), kept it"
    elif not meta["active"]:
        job["message"] = f"New model {_describe(new, base_r)}: not used yet; mark more good matches"
    else:
        use = "in use for tracking" if meta["enabled"] else "ready (turned off)"
        job["message"] = f"New model {_describe(new, base_r)}: {use}"
    if promoted:
        job["message"] += "; also better for " + ", ".join(text for _, text in promoted)


def _model_meta(season: int, arch: str, new: dict, base_r: dict | None, data: dict, result: dict,
                imgsz: int, batch: int, active: bool, enabled: bool) -> dict:
    return {
        "season": season,
        "base_model": arch,
        "classes": td.CLASSES,
        "map50": round(_ap(new) or 0.0, 4),
        "recall": new.get("recall"),
        "precision": new.get("precision"),
        "eval": {"model": new, "baseline": base_r},
        "infer_imgsz": data["infer_imgsz"],
        "matches": len(data["train_matches"]) + len(data["val_matches"]),
        "train_matches": data["train_matches"],
        "val_matches": data["val_matches"],
        "train_tiles": data["train_tiles"],
        "new_tiles": data["new_tiles"],
        "other_season_tiles": data.get("other_season_tiles", 0),
        "data_at": data["data_at"],
        "val_frames": data["val_frames"],
        "val_images": data["val_frames"],
        "external_images": data.get("external_images", 0),
        "epochs_run": result["epochs_run"],
        "imgsz": imgsz,
        "batch": batch,
        "trained_at": time.time(),
        "active": active,
        "enabled": enabled,
    }


def _promote_elsewhere(job: dict, season: int, ds: dict, work: Path, result: dict,
                       arch: str, imgsz: int, batch: int) -> list[tuple[int, str]]:
    """Use the new model for each other season it trained on where it beats that season's model
    on that season's own held-out frames. Returns (season, "0.70 -> 0.75") per season switched."""
    promoted = []
    for key, info in (ds.get("other_seasons") or {}).items():
        s = int(key)
        items, val_m = eval_items(s)
        if not items or job["cancel_requested"]:
            continue
        eval_file = work / f"eval_{s}.json"
        eval_file.write_text(json.dumps(items), encoding="utf-8")
        eval_key = hashlib.md5(eval_file.read_bytes()).hexdigest()
        sd = {"eval": eval_file, "infer_imgsz": int(np.ceil(max(it["width"] for it in items) / 32) * 32)}
        meta = _meta(s) or {}
        cached = meta.get("baseline") if (meta.get("baseline") or {}).get("eval_key") == eval_key else None
        current = model_dir(s) / "best.pt"
        job["message"] = f"Testing the new model on {s}'s held-out frames"
        ev = _evaluate(job, sd, result["best"], current, cached is None and bool(settings.robot_model))
        if ev is None:
            return promoted
        ev = ev["eval"]
        if "baseline" in ev and "error" not in ev["baseline"]:
            cached = {"eval_key": eval_key, "result": ev["baseline"]}
        base_r = (cached or {}).get("result")
        new_ap, cur_ap, base_ap = _ap(ev["new"]), _ap(ev.get("current")), _ap(base_r)
        log.info("new %d model on %d frames: AP50 %s vs current %s", season, s, new_ap, cur_ap)
        if new_ap is None or (cur_ap is not None and new_ap <= cur_ap):
            continue
        active = new_ap >= settings.detector_min_map50 and (base_ap is None or new_ap >= base_ap - BASELINE_SLACK)
        data = {
            **sd, "train_matches": info["train_matches"], "val_matches": val_m, "train_tiles": info["tiles"],
            "new_tiles": 0, "data_at": ds["data_at"], "val_frames": len(items),
        }
        model_dir(s).mkdir(parents=True, exist_ok=True)
        shutil.copy2(result["best"], current)
        new_meta = _model_meta(s, arch, ev["new"], base_r, data, result, imgsz, batch, active, meta.get("enabled", True))
        new_meta["trained_for"] = season
        new_meta["baseline"] = cached
        new_meta["history"] = (meta.get("history") or [])[-19:] + [{
            "trained_at": time.time(), "trained_for": season, "map50": round(new_ap, 4),
            "previous_map50": None if cur_ap is None else round(cur_ap, 4), "promoted": True,
        }]
        new_meta["last_trained_images"] = meta.get("last_trained_images", 0)
        _write_meta(s, new_meta)
        promoted.append((s, f"{s} ({'none' if cur_ap is None else f'{cur_ap:.2f}'} -> {new_ap:.2f})"))
    return promoted

def _eta(elapsed: float, done: float, epochs: int) -> str:
    """' - up to about 2 h 10 min left' (it can stop early once it stops improving)."""
    if done < 0.05:
        return ""
    left = int(elapsed * (epochs - done) / done / 60)
    return f" - up to about {left // 60} h {left % 60} min left" if left >= 60 else f" - up to about {max(1, left)} min left"


def _spawn(job: dict, args: list[str], t0: float | None = None) -> tuple[int, dict | None, str]:
    """Run one training attempt in a child process; returns (exit code, result, last output).
    ``t0``: when the whole run started (monotonic), if it spans several of these."""
    env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
    env["PYTHONPATH"] = os.pathsep.join(filter(None, [str(_BACKEND_DIR), env.get("PYTHONPATH")]))
    proc = subprocess.Popen(
        [sys.executable, "-m", "app.services.detector_worker", *args],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    stop = threading.Event()
    last_output = [time.monotonic()]
    stalled = threading.Event()

    def watch() -> None:  # cancel works even while the child prints nothing
        while not stop.wait(1.0):
            if proc.poll() is not None:
                continue
            if job["cancel_requested"]:
                proc.kill()
            elif time.monotonic() - last_output[0] > STALL_SEC:
                log.warning("detector worker printed nothing for %d min; stopping it", STALL_SEC // 60)
                stalled.set()
                proc.kill()

    threading.Thread(target=watch, daemon=True).start()
    tail: deque[str] = deque(maxlen=3)
    result = None
    started = time.monotonic() if t0 is None else t0
    map50 = None
    try:
        for line in proc.stdout:
            last_output[0] = time.monotonic()
            line = line.strip()
            if line.startswith(MARK):
                msg = json.loads(line[len(MARK):])
                if "step" in msg:
                    epochs, steps = msg["epochs"], max(1, msg["steps"])
                    done = msg["epoch_now"] - 1 + min(1.0, msg["step"] / steps)
                    job["progress"] = {"epoch": round(done, 3), "epochs": epochs}
                    job["message"] = (
                        f"Epoch {msg['epoch_now']}/{epochs}: {100 * msg['step'] // steps}%"
                        + (f" (tile mAP50 {map50:.2f})" if map50 is not None else "")
                        + _eta(time.monotonic() - started, done, epochs)
                    )
                elif "epoch" in msg:
                    map50 = msg["map50"]
                    job["progress"] = {"epoch": msg["epoch"], "epochs": msg["epochs"], "map50": round(map50, 3)}
                    job["message"] = f"Epoch {msg['epoch']}/{msg['epochs']} (tile mAP50 {map50:.2f})"
                elif msg.get("phase") == "testing":
                    job["message"] = "Testing on held-out frames against the current model and YOLO-World"
                elif msg.get("done"):
                    result = msg
            elif line:
                tail.append(line)
        code = proc.wait()
    finally:
        stop.set()
        if proc.poll() is None:
            proc.kill()
    if stalled.is_set():
        tail.append(f"no progress for {STALL_SEC // 60} min, stopped")
        code = STALL_EXIT
    return code, result, " | ".join(tail)
