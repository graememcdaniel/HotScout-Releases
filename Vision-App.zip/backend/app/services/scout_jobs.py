"""One-click scouting: download every match video of an event (or one team),
draw all autos, store them and delete the videos.

Jobs run one at a time in the server's event loop; the heavy work (download,
tracking, OCR) runs in worker threads via ``process_fn``/``run_in_threadpool``.
Live jobs keep polling TBA for new match videos until the event is over.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import json
import logging
import re
import time
import uuid
from pathlib import Path
from typing import Awaitable, Callable

import httpx
from fastapi.concurrency import run_in_threadpool

from app.core.config import settings
from app.services import firebase_store, rescout, team_history
from app.services.tba_client import get_event_matches, get_event_simple, get_team_event_matches
from app.services.trajectory_export import fill_missing_team_files, read_match_autos, team_paths_dir

log = logging.getLogger(__name__)

_LEVEL_ORDER = {"qm": 0, "ef": 1, "qf": 2, "sf": 3, "f": 4}
_YT_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_T_PARAM = re.compile(r"[?&#]t=(?:(\d+)h)?(?:(\d+)m)?(\d+)s?")
_ANSI = re.compile(r"\x1b\[[0-9;]*m")
# YouTube's anti-bot block: retrying right away only extends it, so downloads pause instead.
_BOT_CHECK = re.compile(r"confirm you.{0,3}re not a bot|Sign in to confirm", re.I)
_BLOCK_PAUSE_SEC = 15 * 60
_BLOCK_MAX_PAUSES = 4  # in a row, per job; then the remaining matches fail
_blocked_until = 0.0


class YouTubeBlocked(RuntimeError):
    pass


def _blocked_message() -> str:
    at = dt.datetime.fromtimestamp(_blocked_until).strftime("%H:%M")
    return (
        f"YouTube is asking this network to prove it's not a bot; downloads paused until {at}. "
        f"Too many videos in a short time, or a shared network. A youtube-cookies.txt file fixes it."
    )

_ACTIVE = {"queued", "running", "watching"}
# "elsewhere": another computer of an All-GPUs run is scouting it; "shared": it did.
_FINISHED_ENTRY = {"done", "skipped", "no_video", "failed", "cancelled", "shared"}
# After the finals are decided, keep waiting this long for late match videos.
_LIVE_VIDEO_GRACE_SEC = 3 * 3600
_POOL_POLL_SEC = 20

_jobs: dict[str, dict] = {}
_tasks: set[asyncio.Task] = set()
_gpu_lock = asyncio.Lock()


def get_job(job_id: str) -> dict | None:
    return _jobs.get(job_id)


def active_job() -> dict | None:
    return next((j for j in _jobs.values() if j["status"] in _ACTIVE), None)


def list_jobs() -> list[dict]:
    return sorted(_jobs.values(), key=lambda j: j["created_at"], reverse=True)


def cancel_job(job_id: str) -> bool:
    job = _jobs.get(job_id)
    if not job or job["status"] in {"done", "failed", "cancelled"}:
        return False
    job["cancel_requested"] = True
    return True


def youtube_video(match: dict) -> tuple[str, float] | None:
    """(video id, start offset seconds from a ``t=`` hint) of the match's first YouTube video."""
    for v in match.get("videos") or []:
        if v.get("type") != "youtube":
            continue
        key = str(v.get("key") or "")
        vid = re.split(r"[?&#]", key, maxsplit=1)[0]
        if not _YT_ID.match(vid):
            continue
        t = _T_PARAM.search(key)
        offset = 0.0
        if t:
            h, m, s = (int(x) if x else 0 for x in t.groups())
            offset = float(h * 3600 + m * 60 + s)
        return vid, offset
    return None


def download_video(video_id: str, match_key: str) -> str:
    global _blocked_until
    from yt_dlp import YoutubeDL

    if time.time() < _blocked_until:
        raise YouTubeBlocked(_blocked_message())
    out_dir = Path(settings.upload_dir) / "scout"
    out_dir.mkdir(parents=True, exist_ok=True)
    h = int(settings.scout_video_height)
    # Video only (no audio => no ffmpeg merge); H.264 mp4 decodes reliably in OpenCV.
    fmt = (
        f"bestvideo[height<={h}][vcodec^=avc1]/bestvideo[height<={h}][ext=mp4]"
        f"/best[height<={h}][ext=mp4]/best[height<={h}]"
    )
    opts = {
        "format": fmt,
        "outtmpl": str(out_dir / f"{match_key}.%(ext)s"),
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "noplaylist": True,
        "overwrites": True,
        "no_color": True,
        "retries": 5,
        "fragment_retries": 5,
        "sleep_interval_requests": 1,
    }
    cookies = Path(settings.youtube_cookies_file)
    if cookies.is_file():
        opts["cookiefile"] = str(cookies)
    # YouTube intermittently answers 403 on stream URLs; a fresh extraction
    # (new signed URLs) after a short wait usually succeeds.
    delays = (0, 10, 30, 60)
    for attempt, delay in enumerate(delays, 1):
        time.sleep(delay)
        try:
            with YoutubeDL(opts) as ydl:
                info = ydl.extract_info(f"https://www.youtube.com/watch?v={video_id}", download=True)
                return ydl.prepare_filename(info)
        except Exception as exc:
            if _BOT_CHECK.search(str(exc)):
                _blocked_until = time.time() + _BLOCK_PAUSE_SEC
                log.warning("download %s: YouTube bot check; pausing downloads", match_key)
                raise YouTubeBlocked(_blocked_message()) from exc
            if attempt == len(delays):
                raise RuntimeError(_ANSI.sub("", str(exc)).removeprefix("ERROR: ").strip()) from exc
            log.warning("download %s attempt %d failed: %s", match_key, attempt, _ANSI.sub("", str(exc)))
    raise AssertionError("unreachable")


def _match_sort_key(m: dict) -> tuple:
    return (_LEVEL_ORDER.get(m.get("comp_level"), 9), m.get("set_number") or 0, m.get("match_number") or 0)


def compile_team_autos(event_key: str, match_keys: list[str]) -> list[str]:
    """Gather each team's per-match path docs into ``outputs/<event>/teams/<team>_autos.json``."""
    by_team: dict[str, list[dict]] = {}
    for mk in match_keys:
        d = team_paths_dir(mk)
        if not d.is_dir():
            continue
        for f in d.glob("*.json"):
            try:
                doc = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if doc.get("team_key"):
                by_team.setdefault(doc["team_key"], []).append(doc)
    out_dir = Path(settings.output_dir) / event_key / "teams"
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    for team_key, docs in by_team.items():
        docs.sort(key=_match_sort_key)
        path = out_dir / f"{event_key}_{team_key[3:]}_autos.json"
        path.write_text(
            json.dumps(
                {
                    "season": int(event_key[:4]),
                    "event_key": event_key,
                    "team_key": team_key,
                    "team_number": int(team_key[3:]),
                    "auto_count": len(docs),
                    "autos": docs,
                },
                indent=1,
            ),
            encoding="utf-8",
        )
        written.append(str(path.resolve()))
    return written


def start_job(
    request,
    tba_auth_key: str,
    process_fn: Callable[[dict], Awaitable[dict]],
) -> dict:
    """Queue a scout job. ``process_fn(params)`` processes one downloaded match."""
    job_id = uuid.uuid4().hex
    job = {
        "job_id": job_id,
        "status": "queued",
        "event_key": request.event_key,
        "team_key": request.team_key,
        "live": bool(request.live),
        "created_at": time.time(),
        "started_at": None,
        "finished_at": None,
        "total": 0,
        "completed": 0,
        "current": None,
        "next_check_at": None,
        "retry_round": 0,
        "matches": [],
        "compiled_files": [],
        "error": None,
        "cancel_requested": False,
    }
    _jobs[job_id] = job
    task = asyncio.get_running_loop().create_task(_run(job, request, tba_auth_key, process_fn))
    _tasks.add(task)
    task.add_done_callback(_tasks.discard)
    return job


def _played(m: dict) -> bool:
    if m.get("actual_time"):
        return True
    alliances = m.get("alliances") or {}
    scores = [(alliances.get(c) or {}).get("score") for c in ("red", "blue")]
    return any(s is not None and s >= 0 for s in scores)


def _finals_decided(matches: list[dict]) -> bool:
    wins: dict[str, int] = {}
    for m in matches:
        w = m.get("winning_alliance")
        if m.get("comp_level") == "f" and w in ("red", "blue"):
            wins[w] = wins.get(w, 0) + 1
    return max(wins.values(), default=0) >= 2


def _new_entry(m: dict) -> dict:
    return {"match_key": m["key"], "status": "pending", "message": None, "teams": [], "attempts": 0}


def _refresh_counts(job: dict) -> None:
    job["total"] = len(job["matches"])
    job["completed"] = sum(1 for e in job["matches"] if e["status"] in _FINISHED_ENTRY)


async def _fetch_matches(req, tba_auth_key: str) -> list[dict]:
    if req.team_key:
        matches = await get_team_event_matches(req.event_key, req.team_key, tba_auth_key)
    else:
        matches = await get_event_matches(req.event_key, tba_auth_key)
    levels = set(req.comp_levels or _LEVEL_ORDER)
    matches = [m for m in matches if m.get("comp_level") in levels]
    if req.rescout_only:
        tagged = await run_in_threadpool(rescout.list_tags, req.event_key)
        matches = [m for m in matches if m["key"] in tagged]
    return sorted(matches, key=_match_sort_key)


async def _event_over(req, tba_auth_key: str) -> bool:
    """True once the day after the event's end date has passed."""
    try:
        end = (await get_event_simple(req.event_key, tba_auth_key)).get("end_date")
        return bool(end) and dt.date.today() > dt.date.fromisoformat(end) + dt.timedelta(days=1)
    except (httpx.HTTPError, ValueError):
        return False


async def _run(job: dict, req, tba_auth_key: str, process_fn) -> None:
    async with _gpu_lock:  # one job at a time: the GPU holds one tracker
        job["status"] = "running"
        job["started_at"] = time.time()
        try:
            from app.services import cloud, shared_matches  # latest team detector, looks and calibration

            if req.event_key[:4].isdigit():
                await run_in_threadpool(cloud.pull_quietly, int(req.event_key[:4]))
            if req.pool_id:  # matches the other computers already have are skipped, not redone
                await run_in_threadpool(shared_matches.sync)
            by_key: dict[str, tuple[dict, dict]] = {}
            finals_seen_at = None
            matches: list[dict] = []
            while True:
                matches = await _fetch_matches(req, tba_auth_key)
                if not req.live and req.max_matches:
                    matches = matches[: req.max_matches]
                for m in matches:
                    if m["key"] in by_key:
                        by_key[m["key"]] = (m, by_key[m["key"]][1])
                    elif not req.live or youtube_video(m) is not None:
                        entry = _new_entry(m)
                        by_key[m["key"]] = (m, entry)
                        job["matches"].append(entry)
                job["matches"].sort(key=lambda e: _match_sort_key(by_key[e["match_key"]][0]))
                _refresh_counts(job)
                await _process_pending(job, by_key, req, process_fn)
                if not req.live or job["cancel_requested"]:
                    break
                # Live: stop once the event is finished and every played match has a video.
                if _finals_decided(matches):
                    finals_seen_at = finals_seen_at or time.time()
                    waiting = [m for m in matches if _played(m) and m["key"] not in by_key]
                    if not waiting or time.time() - finals_seen_at > _LIVE_VIDEO_GRACE_SEC:
                        break
                if await _event_over(req, tba_auth_key):
                    break
                job["status"] = "watching"
                job["next_check_at"] = time.time() + req.live_poll_sec
                while time.time() < job["next_check_at"] and not job["cancel_requested"]:
                    await asyncio.sleep(2)
                job["next_check_at"] = None
                job["status"] = "running"
                if job["cancel_requested"]:
                    break

            # Played matches that never got a video.
            if req.live and not job["cancel_requested"]:
                for m in matches:
                    if m["key"] not in by_key and _played(m):
                        entry = {**_new_entry(m), "status": "no_video", "message": "No video on The Blue Alliance"}
                        by_key[m["key"]] = (m, entry)
                        job["matches"].append(entry)
                job["matches"].sort(key=lambda e: _match_sort_key(by_key[e["match_key"]][0]))

            # Re-scout anything that failed (YouTube hiccups, etc.).
            for rnd in range(1, req.retry_rounds + 1):
                failed = [e for e in job["matches"] if e["status"] == "failed"]
                if not failed or job["cancel_requested"]:
                    break
                job["retry_round"] = rnd
                for e in failed:
                    e["status"] = "pending"
                    e["message"] = f"Retrying (round {rnd})"
                _refresh_counts(job)
                await _process_pending(job, by_key, req, process_fn)

            if req.pool_id:
                await _wait_for_pool(job, by_key, req, process_fn)

            # Re-scout (once, more carefully) matches whose autos still look wrong.
            if req.auto_rescout and not job["cancel_requested"]:
                redo = []
                for e in job["matches"]:
                    if e["status"] not in {"done", "skipped"}:
                        continue
                    tag = await run_in_threadpool(rescout.auto_tag, e["match_key"])
                    if tag and tag.get("source") == "auto" and not tag.get("rescouts"):
                        redo.append((e, tag))
                for e, tag in redo:
                    e["status"] = "pending"
                    e["force"] = True
                    e["message"] = f"Re-scouting: {tag['reason']}"
                if redo:
                    job["rescout_round"] = True
                    _refresh_counts(job)
                    await _process_pending(job, by_key, req, process_fn)

            for e in job["matches"]:
                if e["status"] in {"pending", "elsewhere"}:
                    e["status"] = "cancelled"
            _refresh_counts(job)
            job["current"] = None
            if req.pool_id:  # bring in what the other computers scouted
                await run_in_threadpool(shared_matches.sync)
            done_keys = [e["match_key"] for e in job["matches"] if e["status"] in {"done", "skipped", "shared"}]
            for mk in done_keys:
                await run_in_threadpool(rescout.auto_tag, mk)
            job["compiled_files"] = await run_in_threadpool(compile_team_autos, req.event_key, done_keys)
            job["status"] = "cancelled" if job["cancel_requested"] else "done"
        except Exception as exc:
            log.exception("scout job %s failed", job["job_id"])
            job["status"] = "failed"
            job["error"] = str(exc)
        finally:
            job["current"] = None
            job["next_check_at"] = None
            job["finished_at"] = time.time()
            from app.services import shared_matches

            shared_matches.wake()


async def _process_pending(job: dict, by_key: dict, req, process_fn) -> None:
    for entry in list(job["matches"]):
        while entry["status"] == "pending":  # stays pending while YouTube blocks downloads
            if job["cancel_requested"]:
                entry["status"] = "cancelled"
                break
            if not await _wait_for_youtube(job, entry):
                break
            job["current"] = entry["match_key"]
            entry["attempts"] += 1
            await _process_one(by_key[entry["match_key"]][0], entry, req, process_fn)
        if entry["status"] == "done":
            job["yt_pauses"] = 0
            await _after_match(job, entry, req)
        _refresh_counts(job)
    job["current"] = None


async def _wait_for_youtube(job: dict, entry: dict) -> bool:
    """Sit out a YouTube bot-check pause. False (match failed) after too many in a row."""
    if time.time() >= _blocked_until:
        return True
    job["yt_pauses"] = job.get("yt_pauses", 0) + 1
    if job["yt_pauses"] > _BLOCK_MAX_PAUSES:
        entry["status"] = "failed"
        entry["message"] = _blocked_message()
        entry.pop("yt_wait", None)
        return False
    entry["message"] = _blocked_message()
    entry["yt_wait"] = True
    job["current"] = entry["match_key"]
    _refresh_counts(job)
    while time.time() < _blocked_until and not job["cancel_requested"]:
        await asyncio.sleep(2)
    entry.pop("yt_wait", None)
    entry["message"] = None
    return True


async def _wait_for_pool(job: dict, by_key: dict, req, process_fn) -> None:
    """All-GPUs run: wait for the matches other computers took; take over those
    whose computer went off or failed them."""
    from app.services import scout_pool

    while not job["cancel_requested"]:
        waiting = {e["match_key"]: e for e in job["matches"] if e["status"] == "elsewhere"}
        if not waiting:
            return
        try:
            states = await run_in_threadpool(scout_pool.states, req.pool_id)
        except Exception as exc:  # offline: look again later
            log.warning("All-GPUs run %s: %s", req.pool_id, exc)
            states = None
        retake = False
        for mk, e in (waiting.items() if states is not None else ()):
            state, name = states.get(mk, ("free", ""))  # no claim left: nobody has it
            if state == "done":
                e["status"] = "shared"
                e["message"] = f"Scouted on {name}"
            elif state == "free":
                e["status"] = "pending"
                e["message"] = f"Taking over from {name}" if name else None
                retake = True
            else:
                e["message"] = f"Scouting on {name}"
        _refresh_counts(job)
        if retake:
            await _process_pending(job, by_key, req, process_fn)
            continue
        until = time.time() + _POOL_POLL_SEC
        while time.time() < until and not job["cancel_requested"]:
            await asyncio.sleep(2)


async def _pool_claim(req, entry: dict) -> bool:
    """All-GPUs run: True if this computer scouts the match, False if another one has it."""
    from app.services import scout_pool

    try:
        other = await run_in_threadpool(scout_pool.claim, req.pool_id, entry["match_key"])
    except Exception as exc:  # can't reach the team cloud: scout it here rather than not at all
        log.warning("could not claim %s: %s", entry["match_key"], exc)
        return True
    if other is None:
        return True
    name = other.get("name") or "another computer"
    done = other.get("status") == "done"
    entry["status"] = "shared" if done else "elsewhere"
    entry["message"] = f"Scouted on {name}" if done else f"Scouting on {name}"
    return False


def _pool_release(req, match_key: str, ok: bool) -> None:
    from app.services import cloud, scout_pool

    cloud.quietly(scout_pool.release, req.pool_id, match_key, ok)


def _upload_files(req, updated: dict[str, list[str]]) -> dict:
    if not req.upload_firebase or not updated or not firebase_store.status()["configured"]:
        return {}
    out = {}
    for mk, files in updated.items():
        manifest = team_paths_dir(mk).parent / "firebase_docs.json"
        try:
            out[mk] = firebase_store.upload_team_files(files, manifest)
        except Exception as exc:  # upload is best-effort; files are saved locally
            log.warning("firebase upload for %s failed: %s", mk, exc)
            out[mk] = {"error": str(exc)}
    return out


async def _after_match(job: dict, entry: dict, req) -> None:
    """Fix team mix-ups with the event's auto history and re-check autos quality."""
    changed = set()
    if req.use_team_history:
        try:
            summary = await run_in_threadpool(team_history.refine_event, req.event_key)
        except Exception as exc:  # history is a refinement; never fail the match for it
            log.warning("team history for %s failed: %s", req.event_key, exc)
        else:
            changed = set(summary["updated_files"])
            await run_in_threadpool(_upload_files, req, summary["updated_files"])
    by_key = {e["match_key"]: e for e in job["matches"]}
    for mk in changed | {entry["match_key"]}:
        e = by_key.get(mk)
        tag = await run_in_threadpool(rescout.auto_tag, mk)
        if e is None:
            continue
        if mk in changed:
            e["teams"] = await run_in_threadpool(_entry_teams, mk)
        e["rescout_tag"] = tag
        e["rev"] = e.get("rev", 0) + 1
    from app.services import shared_matches

    shared_matches.wake()


def _entry_teams(match_key: str) -> list[dict]:
    return [
        {k: a[k] for k in ("team_key", "alliance", "robot_slot", "detected", "method", "confidence", "needs_review")}
        for a in read_match_autos(match_key, with_points=False)
    ]


async def _process_one(m: dict, entry: dict, req, process_fn) -> None:
    match_key = m["key"]
    alliances = m.get("alliances") or {}
    lineup = {c: list((alliances.get(c) or {}).get("team_keys") or []) for c in ("red", "blue")}
    existing = list(team_paths_dir(match_key).glob("*.json"))
    tag = await run_in_threadpool(rescout.get_tag, match_key)
    # Manual tags and explicit re-scout runs always redo the match; automatic
    # tags only once, so a match that stays hard is not re-tracked on every run.
    thorough = bool(
        entry.get("force")
        or (tag and (req.rescout_only or tag.get("source") == "manual" or not tag.get("rescouts")))
    )
    if req.skip_existing and existing and not thorough:
        # Older runs may lack files for undetected teams; add them now.
        added = await run_in_threadpool(fill_missing_team_files, match_key, lineup)
        if added and req.upload_firebase and firebase_store.status()["configured"]:
            manifest = team_paths_dir(match_key).parent / "firebase_docs.json"
            entry["firebase"] = await run_in_threadpool(firebase_store.upload_team_files, added, manifest)
        entry["status"] = "skipped"
        entry["message"] = "Already scouted"
        entry["rescout_tag"] = tag
        entry["teams"] = await run_in_threadpool(_entry_teams, match_key)
        return
    video = youtube_video(m)
    if video is None:
        entry["status"] = "no_video"
        entry["message"] = "No video on The Blue Alliance"
        return
    video_id, hint = video
    if req.pool_id and not await _pool_claim(req, entry):
        return
    path = None
    try:
        entry["status"] = "downloading"
        path = await run_in_threadpool(download_video, video_id, match_key)
        entry["status"] = "processing"
        target_alliance, position = "red", 1
        if req.team_key:
            for c in ("red", "blue"):
                if req.team_key in lineup[c]:
                    target_alliance, position = c, lineup[c].index(req.team_key) + 1
        result = await process_fn(
            {
                "season": req.season,
                "event_key": req.event_key,
                "team_key": req.team_key or (lineup[target_alliance] or ["frc0"])[0],
                "match_key": match_key,
                "target_alliance": target_alliance,
                "target_robot_position": position,
                "video_path": path,
                "tracking_start_sec": req.tracking_start_sec + hint,
                "auto_seconds": req.auto_seconds,
                "use_event_calibration": True,
                "auto_identify_teams": True,
                "upload_firebase": req.upload_firebase,
                "thorough": thorough,
                "align_auto_start": True,
            }
        )
        if thorough:
            await run_in_threadpool(rescout.clear_tag, match_key, True)
            entry["rescout"] = True
        entry["teams"] = await run_in_threadpool(_entry_teams, match_key)
        entry["firebase"] = result.get("firebase")
        entry["message"] = None
        entry["status"] = "done"
    except YouTubeBlocked as exc:
        entry["status"] = "pending"  # _process_pending waits and tries it again
        entry["message"] = str(exc)
    except Exception as exc:
        detail = getattr(exc, "detail", None)
        entry["status"] = "failed"
        entry["message"] = str(detail if detail is not None else exc)
        log.warning("scout %s failed: %s", match_key, entry["message"])
    finally:
        if req.pool_id:
            await run_in_threadpool(_pool_release, req, match_key, entry["status"] == "done")
        if path and not req.keep_videos:
            try:
                Path(path).unlink(missing_ok=True)
            except OSError as exc:
                log.warning("could not delete %s: %s", path, exc)
        try:
            import torch

            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except ImportError:
            pass
