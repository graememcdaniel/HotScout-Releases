from __future__ import annotations

import json
import re


def _to_float(value: object) -> float | None:
    try:
        if value is None:
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def _extract_from_tag_object(tag: dict) -> dict | None:
    tag_id = tag.get("id")
    if tag_id is None:
        tag_id = tag.get("ID")
    if tag_id is None:
        return None

    # Flat format: {"id": 1, "field_x_m": ..., "field_y_m": ...}
    fx = _to_float(tag.get("field_x_m"))
    fy = _to_float(tag.get("field_y_m"))
    fz = _to_float(tag.get("field_z_m"))
    if fx is not None and fy is not None:
        return {
            "id": int(tag_id),
            "field_x_m": fx,
            "field_y_m": fy,
            "field_z_m": fz if fz is not None else 0.0,
        }

    # WPILib-like: {"ID": 1, "pose": {"translation": {"x":..., "y":...}}}

    pose = tag.get("pose") or {}
    translation = pose.get("translation") if isinstance(pose, dict) else None
    rotation = pose.get("rotation") if isinstance(pose, dict) else None
    if isinstance(translation, dict):
        fx = _to_float(translation.get("x"))
        fy = _to_float(translation.get("y"))
        fz = _to_float(translation.get("z"))
        if fx is not None and fy is not None:
            out = {
                "id": int(tag_id),
                "field_x_m": fx,
                "field_y_m": fy,
                "field_z_m": fz if fz is not None else 0.0,
            }

            if isinstance(rotation, dict):
                if isinstance(rotation.get("quaternion"), dict):
                    rotation = rotation["quaternion"]
                qw = _to_float(rotation.get("W") if "W" in rotation else rotation.get("w"))
                qx = _to_float(rotation.get("X") if "X" in rotation else rotation.get("x"))
                qy = _to_float(rotation.get("Y") if "Y" in rotation else rotation.get("y"))
                qz = _to_float(rotation.get("Z") if "Z" in rotation else rotation.get("z"))
                if None not in (qw, qx, qy, qz):
                    out["qw"] = float(qw)
                    out["qx"] = float(qx)
                    out["qy"] = float(qy)
                    out["qz"] = float(qz)

            return out

    # Alternate flattened WPILib-like keys
    fx = _to_float(tag.get("x"))
    fy = _to_float(tag.get("y"))
    fz = _to_float(tag.get("z"))
    if fx is not None and fy is not None:
        return {
            "id": int(tag_id),
            "field_x_m": fx,
            "field_y_m": fy,
            "field_z_m": fz if fz is not None else 0.0,
        }

    return None


def _from_json_blob(layout_text: str) -> list[dict]:
    obj = json.loads(layout_text)

    if isinstance(obj, list):
        tags = obj
    elif isinstance(obj, dict):
        if isinstance(obj.get("tags"), list):
            tags = obj["tags"]
        elif isinstance(obj.get("field-tags"), list):
            tags = obj["field-tags"]
        elif isinstance(obj.get("field_tags"), list):
            tags = obj["field_tags"]
        elif isinstance(obj.get("apriltags"), list):
            tags = obj["apriltags"]
        else:
            tags = []
    else:
        tags = []

    out: list[dict] = []
    for item in tags:
        if not isinstance(item, dict):
            continue
        parsed = _extract_from_tag_object(item)
        if parsed is None:
            continue
        out.append(parsed)

    return out


def _from_table_text(layout_text: str) -> list[dict]:
    # Accept lines like: id,x,y  OR id x y OR with extra columns.
    # We pull the first three numeric tokens from each line as id/x/y.
    out: list[dict] = []
    lines = layout_text.splitlines()
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.lower().startswith("id"):
            continue

        nums = re.findall(r"-?\d+(?:\.\d+)?", line)
        if len(nums) < 3:
            continue

        tag_id = int(float(nums[0]))
        fx = float(nums[1])
        fy = float(nums[2])
        out.append({"id": tag_id, "field_x_m": fx, "field_y_m": fy, "field_z_m": 0.0})

    return out


def parse_layout_field_dimensions(layout_text: str) -> tuple[float, float] | None:
    # WPILib/FIRST layout JSON: {"field": {"length", "width"}} or
    # {"field-dimensions": {"length", "width"}}.
    try:
        obj = json.loads((layout_text or "").strip())
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict):
        return None
    for key in ("field-dimensions", "field_dimensions", "field"):
        dims = obj.get(key)
        if isinstance(dims, dict):
            length = _to_float(dims.get("length"))
            width = _to_float(dims.get("width"))
            if length and width and length > 0 and width > 0:
                return length, width
    return None


def parse_apriltag_layout_text(layout_text: str) -> list[dict]:
    text = (layout_text or "").strip()
    if not text:
        return []

    # Try JSON first.
    try:
        parsed = _from_json_blob(text)
        if parsed:
            return parsed
    except json.JSONDecodeError:
        pass

    parsed = _from_table_text(text)
    if parsed:
        return parsed

    raise ValueError(
        "Could not parse AprilTag layout text. Use FIRST/WPILib JSON (tags/field-tags array with ID + pose.translation x/y/z) or table lines like 'id,x,y'."
    )
