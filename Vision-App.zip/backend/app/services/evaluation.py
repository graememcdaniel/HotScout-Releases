"""How well do the robot detector and team identification really work?

Ground truth is the matches a scout marked good: their confirmed robot paths
label the saved frames (``tracking/training_data``) with every robot's box and
team. Robot boxes there come partly from the detector that tracked the match
(YOLO-World so far), so box shapes favour it slightly; IoU 0.5 is lenient
enough that this matters little.

    python -m app.services.evaluation --season 2026            # both
    python -m app.services.evaluation --season 2026 --teams    # team ID only
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np
from scipy.optimize import linear_sum_assignment

IOU = 0.5


def _iou(a, b) -> float:
    ix = max(0.0, min(a[2], b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[3], b[3]) - max(a[1], b[1]))
    inter = ix * iy
    union = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / union if union > 0 else 0.0


def _in_mask(box, masks) -> bool:
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    return any(m[0] <= cx <= m[2] and m[1] <= cy <= m[3] for m in masks)


def average_precision(preds: list[list[tuple[list[float], float]]], gts: list[list[list[float]]], masks: list[list[list[float]]], threshold: float) -> dict:
    """VOC all-point AP at IoU 0.5 plus recall/precision at ``threshold``.

    Predictions centred in a masked area (robots behind field structures,
    unsure spots) count neither way.
    """
    scored = []  # (conf, is_tp)
    n_gt = sum(len(g) for g in gts)
    for P, G, M in zip(preds, gts, masks):
        used = [False] * len(G)
        for box, conf in sorted(P, key=lambda p: -p[1]):
            best, j = 0.0, -1
            for k, g in enumerate(G):
                if not used[k]:
                    v = _iou(box, g)
                    if v > best:
                        best, j = v, k
            if best >= IOU:
                used[j] = True
                scored.append((conf, True))
            elif not _in_mask(box, M):
                scored.append((conf, False))
    if not n_gt:
        return {"ap50": None, "recall": None, "precision": None, "objects": 0}
    scored.sort(key=lambda s: -s[0])
    tp = np.cumsum([s[1] for s in scored]) if scored else np.zeros(0)
    fp = np.cumsum([not s[1] for s in scored]) if scored else np.zeros(0)
    rec = tp / n_gt
    prec = tp / np.maximum(1, tp + fp)
    mrec = np.concatenate([[0.0], rec, [1.0]])
    mpre = np.concatenate([[1.0], prec, [0.0]])
    mpre = np.maximum.accumulate(mpre[::-1])[::-1]
    ap = float(np.sum((mrec[1:] - mrec[:-1]) * mpre[1:]))
    at = [s for s in scored if s[0] >= threshold]
    hits = sum(1 for s in at if s[1])
    return {
        "ap50": round(ap, 4),
        "recall": round(hits / n_gt, 4),
        "precision": round(hits / len(at), 4) if at else None,
        "objects": n_gt,
    }


def detector_eval(model_path: str, items: list[dict], imgsz: int | None = None) -> dict:
    """Score a detector on full labelled frames, the way tracking runs it.

    ``items`` have an absolute ``image`` path, ``robots``/``bumpers``/``masks``.
    Recall and precision are at the confidence tracking accepts.
    """
    import torch

    from app.tracking.detector import RobotBoxModel
    from app.tracking.training_data import apply_masks

    model = RobotBoxModel(model_path, imgsz=imgsz)
    robots_p, bumpers_p, robots_g, bumpers_g, masks = [], [], [], [], []
    elapsed, frames = 0.0, 0
    for it in items:
        img = cv2.imread(it["image"])
        if img is None:
            continue
        apply_masks(img, it["masks"])
        t = time.perf_counter()
        robots, _ = model(img)
        if frames:  # the first call includes warm-up
            elapsed += time.perf_counter() - t
        frames += 1
        robots_p.append(robots)
        bumpers_p.append(list(model.last_bumpers))
        robots_g.append([r["box"] for r in it["robots"]])
        bumpers_g.append(it["bumpers"])
        masks.append(it["masks"])
    out = {
        "model": Path(model_path).name,
        "imgsz": model.imgsz,
        "frames": frames,
        "ms_per_frame": round(1000 * elapsed / max(1, frames - 1), 1) if frames > 1 else None,
        **average_precision(robots_p, robots_g, masks, model.conf),
    }
    if model.bumper_cls:
        for cls, colour in ((1, "red"), (2, "blue")):
            r = average_precision(
                [[(b, c) for b, col, c in P if col == colour] for P in bumpers_p],
                [[b["box"] for b in G if b["cls"] == cls] for G in bumpers_g],
                masks,
                model.conf,
            )
            out[f"{colour}_bumper_ap50"] = r["ap50"]
    del model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return out


# ------------------------------------------------------------------ teams ---


def _assign(M: np.ndarray) -> dict[int, int]:
    rows, cols = linear_sum_assignment(-M)
    return dict(zip(rows.tolist(), cols.tolist()))


def team_eval(season: int, log=print) -> dict:
    """Leave-one-match-out team identification on good matches' saved frames.

    For each good match and alliance: appearance (gallery from the *other*
    good matches), bumper OCR on the saved frames, and both together; each
    picks the best 3-way assignment, which is compared with the scout-confirmed
    teams. OCR here sees only ~12 single frames, fewer than live scouting
    (which also fuses frames and reads the still moments around auto).
    """
    from app.core.config import settings
    from app.services import rescout
    from app.tracking import appearance as app
    from app.tracking import training_data as td
    from app.tracking.team_id import _view_votes, bumper_strip_crop

    root = Path(settings.dataset_dir) / str(season)
    out_dir = Path(settings.output_dir)
    cache = Path(settings.appearance_dir) / str(season)
    good = sorted(m for m in rescout.season_good_matches(season) if td.match_frames(root, m))
    per_match = {m: app.match_embeddings(m, root, out_dir, cache) for m in good}
    counts = {k: {"slots": 0, "correct": 0} for k in ("appearance", "ocr", "combined")}
    details = []
    for mk in good:
        items, reason = td.match_labels(mk, root, out_dir)
        if not items:
            details.append({"match": mk, "skipped": reason})
            continue
        gallery: dict[str, list[np.ndarray]] = {}
        for other in good:
            if other != mk:
                teams, emb = per_match[other]
                for t, e in zip(teams, emb):
                    gallery.setdefault(t, []).append(e)
        G = {t: np.stack(v) for t, v in gallery.items()}
        q_teams, q_emb = per_match[mk]
        row = {"match": mk}
        for alliance in ("red", "blue"):
            teams = sorted({r["team_key"] for it in items for r in it["robots"] if r["alliance"] == alliance and r.get("team_key")})
            if len(teams) < 2:
                continue
            numbers = [t[3:] for t in teams]
            ocr = np.zeros((len(teams), len(teams)))
            for it in items:
                img = cv2.imread(str(td.frames_dir(root) / it["image"]))
                if img is None:
                    continue
                for r in it["robots"]:
                    if r["alliance"] != alliance or r.get("team_key") not in teams:
                        continue
                    strip = bumper_strip_crop(img, r["box"], alliance)
                    if strip is not None:
                        v, _ = _view_votes(strip, alliance, numbers)
                        ocr[teams.index(r["team_key"])] += v
            embs = [q_emb[[i for i, t in enumerate(q_teams) if t == team]] for team in teams]
            votes, sim = app.team_votes(embs, teams, G)
            for name, M in (("appearance", votes), ("ocr", ocr), ("combined", ocr + votes)):
                if name == "appearance" and np.isnan(sim).any():
                    continue
                pick = _assign(M)
                right = sum(1 for i, k in pick.items() if i == k)
                counts[name]["slots"] += len(teams)
                counts[name]["correct"] += right
                row[f"{alliance}_{name}"] = f"{right}/{len(teams)}"
        details.append(row)
        log(json.dumps(row))
    for c in counts.values():
        c["accuracy"] = round(c["correct"] / c["slots"], 3) if c["slots"] else None
    app.release()
    return {"season": season, "good_matches": len(good), "methods": counts, "matches": details}


def main() -> None:
    from app.services import detector_training

    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--season", type=int, required=True)
    p.add_argument("--teams", action="store_true", help="team identification only")
    p.add_argument("--detector", action="store_true", help="detectors only")
    a = p.parse_args()
    out = Path(detector_training.model_dir(a.season)) / "evaluation.json"
    result: dict = {}
    if out.is_file():  # keep the part not re-run
        try:
            result = json.loads(out.read_text(encoding="utf-8"))
        except ValueError:
            pass
    if not a.teams:
        items, val = detector_training.eval_items(a.season)
        print(f"detector: {len(items)} held-out frames from {len(val)} good matches")
        result["detectors"] = []
        for path in detector_training.models_to_compare(a.season):
            r = detector_eval(path, items)
            print(json.dumps(r))
            result["detectors"].append(r)
    if not a.detector:
        result["teams"] = team_eval(a.season)
        print(json.dumps(result["teams"]["methods"], indent=1))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=1), encoding="utf-8")
    print(f"saved {out}")


if __name__ == "__main__":
    main()
