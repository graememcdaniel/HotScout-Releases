from __future__ import annotations

import cv2
import numpy as np


def _project_with_camera_pose(px: float, py: float, pose: dict) -> tuple[float, float] | None:
    camera_matrix = pose.get("camera_matrix")
    rvec = pose.get("rvec")
    tvec = pose.get("tvec")
    if not camera_matrix or not rvec or not tvec:
        return None

    k = np.array(camera_matrix, dtype=float)
    if k.shape != (3, 3) or abs(float(k[0, 0])) < 1e-9 or abs(float(k[1, 1])) < 1e-9:
        return None
    dist = np.array(pose.get("dist_coeffs") or np.zeros(4), dtype=float).reshape(-1)

    rvec_np = np.array(rvec, dtype=float).reshape(3, 1)
    tvec_np = np.array(tvec, dtype=float).reshape(3, 1)
    rmat, _ = cv2.Rodrigues(rvec_np)
    r_inv = rmat.T

    cam_center_world = -(r_inv @ tvec_np).reshape(3)

    pix = np.array([[[float(px), float(py)]]], dtype=float)
    if np.any(dist):
        crit = (cv2.TERM_CRITERIA_COUNT | cv2.TERM_CRITERIA_EPS, 40, 1e-9)
        xn, yn = cv2.undistortPointsIter(pix, k, dist, None, None, crit).reshape(2)
    else:
        xn, yn = cv2.undistortPoints(pix, k, dist).reshape(2)
    ray_cam = np.array([xn, yn, 1.0], dtype=float)
    ray_world = r_inv @ ray_cam
    dz = float(ray_world[2])
    if abs(dz) < 1e-9:
        return None

    scale = -float(cam_center_world[2]) / dz
    if scale <= 0:
        return None

    hit = cam_center_world + (scale * ray_world)
    y = float(hit[1])
    if pose.get("ref_mirror_y"):
        # Manual poses may be solved in a y-reflected field frame.
        y = float(pose.get("ref_mirror_field_height_m", 0.0)) - y
    return float(hit[0]), y


def project_track_to_field(raw_tracks: dict, camera_pose: dict, homography: np.ndarray) -> list[dict]:
    apriltag_pose = camera_pose.get("camera_pose") if isinstance(camera_pose, dict) else None
    use_pose = bool(
        isinstance(apriltag_pose, dict)
        and apriltag_pose.get("model") in {"solvepnp_3d", "solvepnp_manual_3d"}
        and apriltag_pose.get("camera_matrix")
        and apriltag_pose.get("rvec")
        and apriltag_pose.get("tvec")
    )

    out: list[dict] = []

    for p in raw_tracks.get("points", []):
        x = None
        y = None

        if use_pose:
            hit = _project_with_camera_pose(float(p["px"]), float(p["py"]), apriltag_pose)
            if hit is not None:
                x, y = hit

        if x is None or y is None:
            vec = np.array([p["px"], p["py"], 1.0], dtype=float)
            warped = homography @ vec
            w = warped[2] if warped[2] else 1.0
            x = float(warped[0] / w) / 100.0
            y = float(warped[1] / w) / 100.0

        out.append(
            {
                "t_sec": p["t_sec"],
                "x_m": x,
                "y_m": y,
                "confidence": p["confidence"],
                "inferred": p["inferred"],
            }
        )

    return out
