@echo off
rem Installs or updates HotScout for this Windows user (no admin rights needed).
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\install.ps1"
if errorlevel 1 (
    echo.
    echo HotScout did not install. The error is shown above.
    pause
)
